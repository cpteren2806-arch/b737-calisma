# B737 Çalışma

737NG ve 737 MAX sistemlerini ATA bölümlerine göre çalışmak için çevrimdışı Android uygulaması.

## İçerik
- 11 bölüm: ATA 21, 24, 26, 27, 28, 29, 30, 32, 36, 49 ve motor (71-80)
- Her bölümde: genel bilgi, bileşenler, çalışma mantığı, kokpit kontrolleri, bakım/güvenlik notları, MAX farkları
- 6 sistem şeması (APU, hidrolik, pnömatik, elektrik, yakıt, motor), dokununca büyür
- Bölüm quizleri ve karışık quiz
- NG ↔ MAX karşılaştırma tablosu, kısaltma ve el kitabı sözlüğü (AMM, CMM, IPC, FIM…)
- Tüm içerikte arama
- **3D modeller (dokunmatik):** APU (131-9B), overhead panel arkası (modüller, konnektörler, kablo demetleri, kelepçeler, topraklama, CB paneli) ve yuvarlak konnektör anatomisi. Döndür, yakınlaştır, parçalara ayır, parçaya dokunup açıklamasını oku. Modeller temsilidir.
- **Belgelerim:** kendi ders notlarını, eğitim PDF'lerini ve fotoğraflarını ATA bölümüne bağlayıp sakla (yalnız telefonda tutulur, PDF uygulama içinde açılır)

> Eğitim amaçlıdır. İçerik özgün özetlerdir; Boeing AMM/CMM/FCOM değildir ve onların yerine geçmez.

## APK nasıl alınır
Bu depo GitHub'a gönderildiğinde **Actions** sekmesindeki "APK derle" iş akışı otomatik çalışır (3-6 dk).
Bitince **Releases** bölümünde `B737-Calisma.apk` dosyası çıkar. Telefondan indirip açın;
Android "bilinmeyen kaynaklardan yükleme" izni isterse bu kaynağa izin verin.

Elle tekrar derlemek için: Actions → APK derle → Run workflow.

## İçeriği düzenleme
- Metinler ve quiz: `app/src/main/assets/www/data.js`
- Şemalar: `app/src/main/assets/www/data-diagrams.js`
- 3D modeller: `app/src/main/assets/www/3d/models.js`
Dosyayı GitHub'da düzenleyip kaydettiğinizde yeni APK otomatik derlenir.
