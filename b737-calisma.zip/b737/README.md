# B737 Çalışma

737NG ve 737 MAX sistemlerini ATA bölümlerine göre çalışmak için çevrimdışı Android uygulaması.

## İçerik
- 11 bölüm: ATA 21, 24, 26, 27, 28, 29, 30, 32, 36, 49 ve motor (71-80)
- Her bölümde: genel bilgi, bileşenler, çalışma mantığı, kokpit kontrolleri, bakım/güvenlik notları, MAX farkları
- 6 sistem şeması (APU, hidrolik, pnömatik, elektrik, yakıt, motor), dokununca büyür
- Bölüm quizleri ve karışık quiz
- NG ↔ MAX karşılaştırma tablosu, kısaltma ve el kitabı sözlüğü (AMM, CMM, IPC, FIM…)
- Tüm içerikte arama
- **P5 ön overhead panel (3D):** yerleşim AMM 31-11-94 Fig.101'den ölçüldü; arka bağlantılar WDM 91-02-05'ten (her modülün D-konnektör numarası, W-demeti, TB507/TB508, GD blokları, menteşe hattı); konnektör parça numaraları WDM Equipment List'ten, BACC45FT yapısı SWPM 20-61-11'den. Anahtarlar/kapaklar/ışıklar çalışır, ışık testi, modül çıkarma ve panelin menteşeden açılması.
- **Diğer 3D modeller:** APU (131-9B) ve yuvarlak konnektör anatomisi. Döndür, yakınlaştır, parçalara ayır, parçaya dokunup açıklamasını oku. Modeller temsilidir.
- **Belgelerim:** kendi ders notlarını, eğitim PDF'lerini ve fotoğraflarını ATA bölümüne bağlayıp sakla (yalnız telefonda tutulur, PDF uygulama içinde açılır)

> Eğitim amaçlıdır. İçerik özgün özetlerdir; Boeing AMM/CMM/FCOM değildir ve onların yerine geçmez.

## APK nasıl alınır
Bu depo GitHub'a gönderildiğinde **Actions** sekmesindeki "APK derle" iş akışı otomatik çalışır (3-6 dk).
Bitince **Releases** bölümünde `B737-Calisma.apk` dosyası çıkar. Telefondan indirip açın;
Android "bilinmeyen kaynaklardan yükleme" izni isterse bu kaynağa izin verin.

Elle tekrar derlemek için: Actions → APK derle → Run workflow.

## İçeriği düzenleme
- Metinler ve quiz: `app/src/main/assets/www/data.js`
- Şemalar: `app/src/main/assets/www/data-diagrams.js`
- 3D modeller: `app/src/main/assets/www/3d/models.js`
- Overhead panel düzeni ve konnektör tablosu: `app/src/main/assets/www/3d/p5/layout.js`
Dosyayı GitHub'da düzenleyip kaydettiğinizde yeni APK otomatik derlenir.
