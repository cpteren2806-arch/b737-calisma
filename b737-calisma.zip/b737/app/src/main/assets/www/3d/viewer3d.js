// Basit dokunmatik 3D görüntüleyici: döndür / yakınlaştır / parçaya dokun → bilgi.
import * as THREE from './three.module.js';
import { OrbitControls } from './OrbitControls.js';
import { MODELS } from './models.js';

export const LIST = Object.entries(MODELS).map(([id, m]) => ({ id, title: m.title, sub: m.sub, chapter: m.chapter }));

const grp = p => p.id.replace(/\d+$/, "");
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

export function mount(root, id) {
  const def = MODELS[id];
  if (!def) { root.innerHTML = "<p>Model bulunamadı.</p>"; return () => {}; }

  root.innerHTML = `
  <div class="v3">
    <div class="v3-stage"><canvas></canvas>
      <div class="v3-hint">Döndür: tek parmak · Yakınlaştır: iki parmak · Parçaya dokun</div>
      <div class="v3-tools">
        <button data-t="explode">Parçalara ayır</button>
        <button data-t="shell">${esc(def.shellLabel || "Kabuğu gizle")}</button>
        <button data-t="iso" disabled>Sadece seçili</button>
        <button data-t="reset">Sıfırla</button>
      </div>
    </div>
    <div class="v3-info"><b>${esc(def.title)}</b><p>${def.intro}</p></div>
    <div class="v3-chips"></div>
    <p class="v3-note">${esc(def.note || "Temsili model, ölçeksiz. Gerçek yerleşim için yetkili dokümana bakın.")}</p>
  </div>`;
  const canvas = root.querySelector("canvas"), stage = root.querySelector(".v3-stage");
  const info = root.querySelector(".v3-info"), chips = root.querySelector(".v3-chips");

  const dark = matchMedia("(prefers-color-scheme: dark)").matches;
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
  } catch (e) {
    stage.innerHTML = '<p style="padding:16px">Bu cihazda 3D (WebGL) desteklenmiyor.</p>';
    return () => {};
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setClearColor(dark ? 0x121a24 : 0xe9eef4);

  const scene = new THREE.Scene();
  const cam = new THREE.PerspectiveCamera(40, 1, 0.05, 500);
  scene.add(new THREE.HemisphereLight(0xffffff, dark ? 0x223344 : 0x8899aa, 1.6));
  const sun = new THREE.DirectionalLight(0xffffff, 2.2); sun.position.set(6, 10, 8); scene.add(sun);
  const fill = new THREE.DirectionalLight(0xffffff, 0.8); fill.position.set(-8, -4, -6); scene.add(fill);

  const controls = new OrbitControls(cam, canvas);
  controls.enableDamping = true; controls.dampingFactor = 0.12;
  controls.minDistance = def.minDist || 2; controls.maxDistance = def.maxDist || 40;

  const parts = def.build(THREE, helpers(THREE));
  const pickables = [];
  for (const p of parts) {
    scene.add(p.obj);
    p.base = p.obj.position.clone();
    p.obj.traverse(o => {
      if (!o.isMesh) return;
      o.userData.part = p;
      o.material = o.material.clone();
      o.userData.baseOpacity = o.material.opacity;
      o.userData.baseTransparent = o.material.transparent;
      if (!p.noPick) pickables.push(o);
    });
  }

  // Kamerayı modeli ekrana sığdıracak uzaklığa yerleştir (dikey telefon ekranı için önemli)
  const fitBox = new THREE.Box3();
  for (const p of parts) if (!p.shell) fitBox.expandByObject(p.obj);
  const fitSphere = fitBox.getBoundingSphere(new THREE.Sphere());
  const home = () => {
    const tgt = new THREE.Vector3(...(def.target || [0, 0, 0]));
    const dir = new THREE.Vector3(...def.camera).sub(tgt).normalize();
    const vf = THREE.MathUtils.degToRad(cam.fov);
    const hf = 2 * Math.atan(Math.tan(vf / 2) * cam.aspect);
    const dist = (fitSphere.radius + fitSphere.center.distanceTo(tgt) * 0.5) / Math.sin(Math.min(vf, hf) / 2) * (def.fitScale || 0.74);
    cam.position.copy(tgt).addScaledVector(dir, Math.max(dist, controls.minDistance));
    controls.target.copy(tgt);
    controls.maxDistance = Math.max(controls.maxDistance, dist * 1.8);
    controls.update(); dirty = true;
  };

  // --- durum ---
  let dirty = true, explodeT = 0, explodeGoal = 0, selected = null, isolate = false, shellHidden = false;

  function applyLook() {
    for (const p of parts) {
      const show = !(p.shell && shellHidden);
      p.obj.visible = show;
      p.obj.traverse(o => {
        if (!o.isMesh) return;
        const m = o.material;
        const dim = isolate && selected && p !== selected && !p.shell;
        m.transparent = dim || o.userData.baseTransparent;
        m.opacity = dim ? 0.12 : o.userData.baseOpacity;
        m.depthWrite = !dim && !o.userData.baseTransparent;
        if (m.emissive) m.emissive.setHex(p === selected ? 0x1d5fd6 : 0x000000);
        if (m.emissiveIntensity !== undefined) m.emissiveIntensity = p === selected ? 0.55 : 0;
      });
    }
    dirty = true;
  }

  function select(p) {
    selected = p;
    chips.querySelectorAll("button").forEach(b => b.classList.toggle("on", !!p && b.dataset.grp === grp(p)));
    root.querySelector('[data-t="iso"]').disabled = !p;
    if (!p) { isolate = false; root.querySelector('[data-t="iso"]').classList.remove("on"); }
    info.innerHTML = p
      ? `<b>${esc(p.name)}</b>${p.en ? ` <i>${esc(p.en)}</i>` : ""}<p>${p.desc}</p>`
      : `<b>${esc(def.title)}</b><p>${def.intro}</p>`;
    applyLook();
  }

  chips.innerHTML = parts.filter(p => !p.noPick && p.chip !== false).map(p => `<button data-id="${p.id}" data-grp="${grp(p)}">${esc(p.chipName || p.name)}</button>`).join("");
  chips.querySelectorAll("button").forEach(b => b.onclick = () => {
    const p = parts.find(x => x.id === b.dataset.id);
    select(selected === p ? null : p);
    if (selected) focusOn(selected);
  });

  function focusOn(p) {
    const box = new THREE.Box3().setFromObject(p.obj);
    if (box.isEmpty()) return;
    const c = box.getCenter(new THREE.Vector3());
    const dir = cam.position.clone().sub(controls.target);
    controls.target.lerp(c, 0.6);
    cam.position.copy(controls.target).add(dir);
    dirty = true;
  }

  // --- dokunarak seçme ---
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  let down = null;
  canvas.addEventListener("pointerdown", e => { down = [e.clientX, e.clientY]; });
  canvas.addEventListener("pointerup", e => {
    if (!down) return;
    const moved = Math.hypot(e.clientX - down[0], e.clientY - down[1]); down = null;
    if (moved > 8) return;
    const r = canvas.getBoundingClientRect();
    ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    ray.setFromCamera(ndc, cam);
    const hits = ray.intersectObjects(pickables.filter(o => o.userData.part.obj.visible && !(isolate && selected && o.userData.part !== selected)), false);
    const p = hits.length ? hits[0].object.userData.part : null;
    select(p && p === selected ? null : p);
    if (p && selected) chips.querySelector(`[data-grp="${grp(p)}"]`)?.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
  });

  root.querySelectorAll(".v3-tools button").forEach(b => b.onclick = () => {
    const t = b.dataset.t;
    if (t === "explode") { explodeGoal = explodeGoal ? 0 : 1; b.classList.toggle("on", !!explodeGoal); b.textContent = explodeGoal ? "Birleştir" : "Parçalara ayır"; }
    if (t === "shell") { shellHidden = !shellHidden; b.classList.toggle("on", shellHidden); applyLook(); }
    if (t === "iso") { isolate = !isolate; b.classList.toggle("on", isolate); applyLook(); }
    if (t === "reset") { select(null); explodeGoal = 0; const eb = root.querySelector('[data-t="explode"]'); eb.classList.remove("on"); eb.textContent = "Parçalara ayır"; home(); }
  });
  controls.addEventListener("change", () => dirty = true);

  // --- boyut ve döngü ---
  function resize() {
    const w = stage.clientWidth, h = stage.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); dirty = true;
  }
  const ro = new ResizeObserver(resize); ro.observe(stage);

  let alive = true;
  function loop() {
    if (!alive) return;
    requestAnimationFrame(loop);
    controls.update();
    if (Math.abs(explodeT - explodeGoal) > 0.001) {
      explodeT += (explodeGoal - explodeT) * 0.14;
      if (Math.abs(explodeT - explodeGoal) < 0.002) explodeT = explodeGoal;
      for (const p of parts) if (p.explode) p.obj.position.copy(p.base).addScaledVector(new THREE.Vector3(...p.explode), explodeT);
      dirty = true;
    }
    if (dirty) { renderer.render(scene, cam); dirty = false; }
  }
  if (def.shellHiddenAtStart) { shellHidden = true; root.querySelector('[data-t="shell"]').classList.add("on"); }
  resize(); home(); applyLook(); loop();

  // Test/otomasyon kolaylığı
  root.__v3 = { select: pid => select(parts.find(p => p.id === pid) || null), explode: () => root.querySelector('[data-t="explode"]').click() };

  return function dispose() {
    alive = false; ro.disconnect(); controls.dispose();
    scene.traverse(o => { if (o.isMesh) { o.geometry.dispose(); if (o.material.map) o.material.map.dispose(); o.material.dispose(); } });
    renderer.dispose();
    renderer.forceContextLoss?.();
  };
}

// --- model oluşturma yardımcıları ---
function helpers(T) {
  const mat = (color, o = {}) => new T.MeshStandardMaterial({
    color, metalness: o.m ?? 0.45, roughness: o.r ?? 0.5,
    transparent: o.op != null, opacity: o.op ?? 1, side: o.double ? T.DoubleSide : T.FrontSide,
    emissive: 0x000000, emissiveIntensity: 0
  });
  const place = (m, pos, rot) => { if (pos) m.position.set(...pos); if (rot) m.rotation.set(...rot); return m; };
  const H = {
    mat,
    group: (...kids) => { const g = new T.Group(); kids.forEach(k => k && g.add(k)); return g; },
    box: (w, h, d, m, pos, rot) => place(new T.Mesh(new T.BoxGeometry(w, h, d), m), pos, rot),
    // X ekseni boyunca silindir
    cylX: (r1, r2, len, m, pos, seg = 40, open = false) => place(new T.Mesh(new T.CylinderGeometry(r2, r1, len, seg, 1, open), m), pos, [0, 0, -Math.PI / 2]),
    cylY: (r1, r2, len, m, pos, seg = 32) => place(new T.Mesh(new T.CylinderGeometry(r1, r2, len, seg), m), pos),
    cylZ: (r1, r2, len, m, pos, seg = 40, open = false) => place(new T.Mesh(new T.CylinderGeometry(r1, r2, len, seg, 1, open), m), pos, [Math.PI / 2, 0, 0]),
    torus: (R, r, m, pos, rot, arc = Math.PI * 2) => place(new T.Mesh(new T.TorusGeometry(R, r, 16, 64, arc), m), pos, rot),
    sphere: (r, m, pos) => place(new T.Mesh(new T.SphereGeometry(r, 24, 16), m), pos),
    tube: (pts, r, m, seg = 80) => new T.Mesh(new T.TubeGeometry(new T.CatmullRomCurve3(pts.map(p => new T.Vector3(...p))), seg, r, 10, false), m),
    v: (x, y, z) => new T.Vector3(x, y, z),
    // Yazılı plaka (panel etiketleri için)
    label: (text, w, h, o = {}) => {
      const c = document.createElement("canvas"); const k = 128;
      c.width = Math.round(w * k); c.height = Math.round(h * k);
      const g = c.getContext("2d");
      g.fillStyle = o.bg || "#3a4048"; g.fillRect(0, 0, c.width, c.height);
      g.fillStyle = o.fg || "#f2f2f2"; g.textAlign = "center"; g.textBaseline = "middle";
      const lines = String(text).split("\n"); const fs = o.size || Math.min(c.height / (lines.length + 1.2), 44);
      g.font = `600 ${fs}px sans-serif`;
      lines.forEach((ln, i) => g.fillText(ln, c.width / 2, c.height / 2 + (i - (lines.length - 1) / 2) * fs * 1.15));
      const tex = new T.CanvasTexture(c); tex.colorSpace = T.SRGBColorSpace;
      const m = new T.MeshStandardMaterial({ map: tex, roughness: 0.8, metalness: 0.1, emissive: 0x000000, emissiveIntensity: 0 });
      return new T.Mesh(new T.PlaneGeometry(w, h), m);
    }
  };
  return H;
}
