// 737NG P5 ön overhead panel – gerçekçi 3D model ve etkileşimli görüntüleyici.
import * as THREE from '../three.module.js';
import { OrbitControls } from '../OrbitControls.js';
import { RoomEnvironment } from '../RoomEnvironment.js';
import { mergeGeometries } from '../BufferGeometryUtils.js';
import { MODULES, BOTTOM, U, MW, CONNECTORS } from './layout.js';

const PPI = 112;                       // panel yüzü doku çözünürlüğü (piksel/inç)
const FF = '"RC", "Roboto Condensed", "Arial Narrow", sans-serif';
const COLS = 4, COLU = 55;             // 4 sütun, sütun yüksekliği 55 adım (20.625")
const PANEL_W = COLS * MW;
const DEPTH = 3.0;                     // modül gövdesi derinliği
const Z_RECEPT = -0.05 - DEPTH;
const Z_TRUNK = Z_RECEPT - 1.55;
const PULL = 7;                        // modül çekme mesafesi (inç)

const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const LEGEND_COL = { a: 0xffa424, b: 0x55b8ff, g: 0x5ee07a, w: 0xf2f2f2 };

let fontsP = null;
function loadFonts() {
  if (!fontsP) fontsP = Promise.all([["rc500.woff2", "500"], ["rc700.woff2", "700"]].map(([f, w]) => {
    try {
      const ff = new FontFace("RC", `url(${new URL("./" + f, import.meta.url)})`, { weight: w });
      return ff.load().then(x => document.fonts.add(x)).catch(() => {});
    } catch (e) { return Promise.resolve(); }
  }));
  return fontsP;
}

/* ============================ YERLEŞİM ============================ */
function natural(it) {
  switch (it.t) {
    case "T": return 1.02;
    case "R": return it.small ? 0.5 : 1.32;
    case "L": return 0.5;
    case "B": return 0.62;
    case "G": return it.size + 0.27;
    case "D": return it.h + (it.lab ? 0.2 : 0.02);
    case "X": return 0.24;
    case "S": return it.items.reduce((a, c) => a + natural(c), 0) + 0.05 * (it.items.length - 1);
    default: return 0;
  }
}
// Her öğe için modül-yerel konum (x sağa, y aşağı, inç) hesapla
function layoutModule(m, w, h) {
  const out = [];
  const padT = 0.14, padB = 0.14;
  const sum = m.rows.reduce((a, r) => a + r.h, 0);
  const k = (h - padT - padB) / sum;
  let y = padT;
  for (const r of m.rows) {
    const rh = r.h * k;
    let top = y;
    if (r.title) { out.push({ t: "title", txt: r.title, x: w / 2, y: y + 0.13, w }); top += 0.24; }
    const avail = rh - (top - y);
    const tw = r.items.reduce((a, it) => a + (it.wf ?? 1), 0);
    let acc = 0;
    for (const it of r.items) {
      const wf = it.wf ?? 1;
      const cx = 0.12 + (w - 0.24) * (acc + wf / 2) / tw; acc += wf;
      const nh = natural(it);
      let iy = top + Math.max(0, (avail - nh) / 2);
      const place = (o, yy) => {
        if (o.t === "S") {
          let sy = yy;
          for (const c of o.items) { place(c, sy); sy += natural(c) + 0.05; }
        } else if (o.t !== "_") out.push({ ...o, x: cx, y: yy, nh: natural(o) });
      };
      place(it, iy);
    }
    y += rh;
  }
  return out;
}
// Kontrolün "merkez" noktası (yerel, y aşağı)
function anchor(o) {
  switch (o.t) {
    case "T": return o.y + 0.6;
    case "R": return o.small ? o.y + 0.25 : o.y + 0.8;
    case "L": return o.y + 0.25;
    case "B": return o.y + 0.31;
    case "G": return o.y + o.size / 2;
    case "D": return o.y + (o.lab ? 0.2 : 0.02) + o.h / 2;
    default: return o.y + 0.12;
  }
}
const rotAngles = o => {
  const n = o.pos.length, s = o.spread || 42;
  return o.pos.map((_, i) => (i - (n - 1) / 2) * s);
};

/* ============================ DOKULAR ============================ */
function canvas(w, h) { const c = document.createElement("canvas"); c.width = Math.max(4, Math.round(w)); c.height = Math.max(4, Math.round(h)); return c; }
function tex(c, aniso) { const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = aniso || 4; return t; }
function textLines(g, txt, x, y, size, opts = {}) {
  const lines = String(txt).split("\n");
  g.font = `${opts.weight || 700} ${size}px ${FF}`;
  g.textAlign = opts.align || "center"; g.textBaseline = "middle";
  const lh = size * 1.02;
  const y0 = opts.up ? y - (lines.length - 1) * lh : y - (lines.length - 1) * lh / 2;
  lines.forEach((ln, i) => g.fillText(ln, x, y0 + i * lh));
}

function drawFace(m, w, h, items) {
  const c = canvas(w * PPI, h * PPI), g = c.getContext("2d"), P = v => v * PPI;
  // Boeing gri boya, hafif doku
  const grd = g.createLinearGradient(0, 0, 0, c.height);
  grd.addColorStop(0, "#737b81"); grd.addColorStop(1, "#6b7379");
  g.fillStyle = grd; g.fillRect(0, 0, c.width, c.height);
  const img = g.getImageData(0, 0, c.width, c.height), d = img.data;
  for (let i = 0; i < d.length; i += 4) { const n = (Math.random() - 0.5) * 7; d[i] += n; d[i + 1] += n; d[i + 2] += n; }
  g.putImageData(img, 0, 0);
  // kenar pahı
  g.strokeStyle = "rgba(255,255,255,.18)"; g.lineWidth = 3; g.beginPath(); g.moveTo(2, c.height - 2); g.lineTo(2, 2); g.lineTo(c.width - 2, 2); g.stroke();
  g.strokeStyle = "rgba(0,0,0,.35)"; g.beginPath(); g.moveTo(c.width - 2, 2); g.lineTo(c.width - 2, c.height - 2); g.lineTo(2, c.height - 2); g.stroke();
  // Dzus delikleri
  g.fillStyle = "#3a3f44";
  for (const [x, y] of dzusPts(w, h)) { g.beginPath(); g.arc(P(x), P(y), P(0.115), 0, 7); g.fill(); }

  g.fillStyle = "#f3f3ee"; g.strokeStyle = "#f3f3ee";
  for (const o of items) {
    const ay = anchor(o);
    if (o.t === "title") {
      textLines(g, o.txt, P(o.x), P(o.y), P(0.125));
      const tw = g.measureText(o.txt).width / PPI;
      g.lineWidth = P(0.016);
      g.beginPath(); g.moveTo(P(0.25), P(o.y)); g.lineTo(P(o.x - tw / 2 - 0.08), P(o.y));
      g.moveTo(P(o.x + tw / 2 + 0.08), P(o.y)); g.lineTo(P(o.w - 0.25), P(o.y)); g.stroke();
    } else if (o.t === "X") {
      if (o.txt.trim()) textLines(g, o.txt, P(o.x), P(o.y + 0.12), P(0.11));
    } else if (o.t === "T") {
      if (o.lab) textLines(g, o.lab, P(o.x), P(o.y + 0.13), P(0.112), { up: true });
      const n = o.pos.length;
      o.pos.forEach((p, i) => {
        if (!p) return;
        const yy = ay + (n === 2 ? (i === 0 ? -0.3 : 0.3) : (i - 1) * 0.3);
        textLines(g, p, P(o.x + 0.2), P(yy), P(0.09), { align: "left", weight: 500 });
      });
      g.fillStyle = "#2b2f33"; g.beginPath(); g.arc(P(o.x), P(ay), P(0.17), 0, 7); g.fill(); g.fillStyle = "#f3f3ee";
    } else if (o.t === "R") {
      if (o.lab) textLines(g, o.lab, P(o.x), P(o.y + 0.11), P(0.108), { up: true });
      if (!o.small) {
        const angs = rotAngles(o), r = 0.5;
        g.lineWidth = P(0.014);
        angs.forEach((a, i) => {
          const rad = (a - 90) * Math.PI / 180, cx = o.x + Math.cos(rad) * 0.38, cy = ay + Math.sin(rad) * 0.38;
          g.beginPath(); g.moveTo(P(cx), P(cy)); g.lineTo(P(o.x + Math.cos(rad) * 0.45), P(ay + Math.sin(rad) * 0.45)); g.stroke();
          const p = o.pos[i]; if (!p) return;
          const lx = o.x + Math.cos(rad) * (r + 0.06), ly = ay + Math.sin(rad) * (r + 0.02);
          textLines(g, p, P(lx), P(ly), P(0.08), { weight: 500, align: Math.abs(a) < 12 ? "center" : a < 0 ? "right" : "left" });
        });
        if (o.dim) { g.beginPath(); g.arc(P(o.x), P(ay), P(0.42), (-90 - 60) * Math.PI / 180, (-90 + 60) * Math.PI / 180); g.stroke(); }
      }
    } else if (o.t === "L" || o.t === "B") {
      g.fillStyle = "#1e2124"; const lw = o.t === "B" ? 0.56 : 0.82, lh = o.t === "B" ? 0.56 : 0.46;
      g.fillRect(P(o.x - lw / 2), P(ay - lh / 2), P(lw), P(lh)); g.fillStyle = "#f3f3ee";
    } else if (o.t === "G") {
      g.fillStyle = "#1b1d20"; g.beginPath(); g.arc(P(o.x), P(ay), P(o.size / 2 + 0.07), 0, 7); g.fill(); g.fillStyle = "#f3f3ee";
      textLines(g, o.lab, P(o.x), P(o.y + o.size + 0.15), P(0.1));
    } else if (o.t === "D") {
      if (o.lab) textLines(g, o.lab, P(o.x), P(o.y + 0.1), P(0.1));
      g.fillStyle = "#1b1d20"; g.fillRect(P(o.x - o.w / 2 - 0.05), P(ay - o.h / 2 - 0.05), P(o.w + 0.1), P(o.h + 0.1)); g.fillStyle = "#f3f3ee";
    }
  }
  return tex(c, 8);
}

function legendTex(txt, w, h, color = "#f2f2f2") {
  const c = canvas(220, 220 * h / w), g = c.getContext("2d");
  g.fillStyle = "#151413"; g.fillRect(0, 0, c.width, c.height);
  const lines = txt.split("\n"); let size = Math.min(c.height / (lines.length + 0.9), 40);
  g.font = `700 ${size}px ${FF}`;
  const mw = Math.max(...lines.map(l => g.measureText(l).width));
  if (mw > c.width * 0.9) size *= c.width * 0.9 / mw;
  g.fillStyle = color; textLines(g, txt, c.width / 2, c.height / 2, size);
  return tex(c);
}

const DIALS = {
  fueltemp: { min: -50, max: 50, a0: -135, a1: 135, major: 25, val: [18], unit: "°C" },
  egt: { min: 0, max: 12, a0: -135, a1: 135, major: 2, val: [0], unit: "x100°C", red: 10.5 },
  duct: { min: 0, max: 80, a0: -135, a1: 135, major: 20, val: [32, 30], unit: "PSI", tags: ["L", "R"] },
  airtemp: { min: 0, max: 100, a0: -135, a1: 135, major: 20, val: [24], unit: "°C" },
  cabalt: { min: 0, max: 50, a0: -135, a1: 135, major: 10, val: [0.4, 0], unit: "x1000 FT", inner: { min: 0, max: 10, major: 2, a0: -100, a1: 100 } },
  climb: { min: -4, max: 4, a0: -270, a1: 90, major: 1, val: [0], unit: "x1000 FPM", labels: [[-4, "4"], [-2, "2"], [-1, "1"], [0, "0"], [1, "1"], [2, "2"], [4, "4"]] },
  outflow: { min: 0, max: 1, a0: -70, a1: 70, major: 1, val: [0.85], unit: "", labels: [[0, "CLOSE"], [1, "OPEN"]] }
};
const dialAngle = (s, v, inner) => { const q = inner || s; return q.a0 + (v - q.min) / (q.max - q.min) * (q.a1 - q.a0); };
function dialTex(kind) {
  const s = DIALS[kind], N = 384, c = canvas(N, N), g = c.getContext("2d"), r = N / 2;
  g.fillStyle = "#0f1012"; g.beginPath(); g.arc(r, r, r, 0, 7); g.fill();
  g.strokeStyle = "#f0f0ea"; g.fillStyle = "#f0f0ea";
  const ring = (q, R, lab) => {
    const step = q.major / 5;
    for (let v = q.min; v <= q.max + 1e-6; v += step) {
      const a = (dialAngle(s, v, q) - 90) * Math.PI / 180, maj = Math.abs((v - q.min) / q.major - Math.round((v - q.min) / q.major)) < 1e-6;
      g.lineWidth = maj ? 4 : 2; const r1 = R * (maj ? 0.8 : 0.87);
      g.beginPath(); g.moveTo(r + Math.cos(a) * r1, r + Math.sin(a) * r1); g.lineTo(r + Math.cos(a) * R * 0.95, r + Math.sin(a) * R * 0.95); g.stroke();
    }
    const labs = q.labels || (() => { const L = []; for (let v = q.min; v <= q.max + 1e-6; v += q.major) L.push([v, String(Math.round(v * 10) / 10)]); return L; })();
    for (const [v, t] of labs) {
      const a = (dialAngle(s, v, q) - 90) * Math.PI / 180;
      textLines(g, t, r + Math.cos(a) * R * 0.64, r + Math.sin(a) * R * 0.64, lab);
    }
  };
  ring(s, r * 0.96, kind === "outflow" ? 34 : 40);
  if (s.inner) { g.strokeStyle = "#9fd7ff"; g.fillStyle = "#9fd7ff"; ring({ ...s.inner }, r * 0.5, 26); g.fillStyle = "#f0f0ea"; }
  if (s.red != null) { const a = (dialAngle(s, s.red) - 90) * Math.PI / 180; g.strokeStyle = "#e23b2e"; g.lineWidth = 9; g.beginPath(); g.moveTo(r + Math.cos(a) * r * 0.72, r + Math.sin(a) * r * 0.72); g.lineTo(r + Math.cos(a) * r * 0.93, r + Math.sin(a) * r * 0.93); g.stroke(); }
  g.fillStyle = "#d8d8d0"; textLines(g, s.unit, r, r + r * 0.42, 26, { weight: 500 });
  if (kind === "climb") { textLines(g, "UP", r - r * 0.25, r - r * 0.42, 24); textLines(g, "DN", r - r * 0.25, r + r * 0.18, 24); }
  return tex(c);
}

function lcdTex(kind, w, h) {
  const c = canvas(w * 140, h * 140), g = c.getContext("2d");
  g.fillStyle = "#121611"; g.fillRect(0, 0, c.width, c.height);
  const H = c.height, W = c.width;
  if (kind === "elec") {
    g.fillStyle = "#9da29a";
    const cells = [["DC AMPS", "0"], ["CPS FREQ", "400"], ["DC VOLTS", "26"], ["AC AMPS", "0"], ["AC VOLTS", "115"]];
    const cw = W / 5;
    cells.forEach(([l, v], i) => {
      g.fillStyle = "#8c9189"; textLines(g, l, cw * (i + 0.5), H * 0.2, H * 0.13, { weight: 500 });
      g.fillStyle = "#f4ad3a"; textLines(g, v, cw * (i + 0.5), H * 0.62, H * 0.42);
    });
    g.strokeStyle = "#3a4038"; g.lineWidth = 3; g.beginPath(); g.moveTo(cw * 3, 8); g.lineTo(cw * 3, H - 8); g.stroke();
  } else {
    g.fillStyle = "#f4ad3a"; textLines(g, kind === "fltalt" ? "35000" : "200", W * 0.92, H / 2 + 2, H * 0.7, { align: "right" });
  }
  return tex(c);
}

function moduleLabelTex(m) {
  const c = canvas(512, 256), g = c.getContext("2d");
  g.fillStyle = "#e9e6dc"; g.fillRect(0, 0, 512, 256);
  g.strokeStyle = "#555"; g.lineWidth = 4; g.strokeRect(6, 6, 500, 244);
  g.fillStyle = "#222"; textLines(g, "BOEING", 256, 40, 30);
  textLines(g, m.en.toUpperCase(), 256, 100, 30, { weight: 500 });
  textLines(g, "P/N: —   S/N: —", 256, 160, 26, { weight: 500 });
  textLines(g, "P5 MODULE (IPC/WDM)", 256, 210, 24, { weight: 500 });
  return tex(c);
}
function insertTex(sockets) {
  const N = 256, c = canvas(N, N), g = c.getContext("2d"), r = N / 2;
  g.fillStyle = "#1d1d1d"; g.beginPath(); g.arc(r, r, r, 0, 7); g.fill();
  g.fillStyle = sockets ? "#0b0b0b" : "#d4a537";
  const pts = [[0, 0]];
  for (const [n, rr] of [[6, 0.3], [12, 0.6], [18, 0.85]]) for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; pts.push([Math.cos(a) * rr, Math.sin(a) * rr]); }
  for (const [x, y] of pts) { g.beginPath(); g.arc(r + x * r * 0.86, r + y * r * 0.86, sockets ? 7 : 6, 0, 7); g.fill(); if (sockets) { g.strokeStyle = "#555"; g.lineWidth = 1.5; g.stroke(); } }
  g.fillStyle = "#cfcfcf"; g.font = `600 18px ${FF}`; g.textAlign = "center"; g.fillText("A", r, 22);
  return tex(c);
}

const dzusPts = (w, h) => [[0.2, 0.2], [w - 0.2, 0.2], [0.2, h - 0.2], [w - 0.2, h - 0.2]];

/* ============================ MODEL ============================ */
function buildScene(scene) {
  const M = {
    chrome: new THREE.MeshStandardMaterial({ color: 0xd8dadc, metalness: 1, roughness: 0.22 }),
    black: new THREE.MeshStandardMaterial({ color: 0x141517, metalness: 0.2, roughness: 0.55 }),
    blackGloss: new THREE.MeshStandardMaterial({ color: 0x0c0c0d, metalness: 0.3, roughness: 0.3 }),
    white: new THREE.MeshStandardMaterial({ color: 0xf2f2ee, roughness: 0.5 }),
    edge: new THREE.MeshStandardMaterial({ color: 0x5c646a, metalness: 0.4, roughness: 0.5 }),
    housing: new THREE.MeshStandardMaterial({ color: 0x4a5056, metalness: 0.65, roughness: 0.45 }),
    alodine: new THREE.MeshStandardMaterial({ color: 0xb9a66a, metalness: 0.8, roughness: 0.38 }),
    rail: new THREE.MeshStandardMaterial({ color: 0x2f3439, metalness: 0.7, roughness: 0.4 }),
    connShell: new THREE.MeshStandardMaterial({ color: 0x5f6a4c, metalness: 0.75, roughness: 0.38 }),
    connRing: new THREE.MeshStandardMaterial({ color: 0x4d573c, metalness: 0.7, roughness: 0.42 }),
    backshell: new THREE.MeshStandardMaterial({ color: 0x9fa6ad, metalness: 0.9, roughness: 0.3 }),
    wire: new THREE.MeshStandardMaterial({ color: 0xe6e2d3, metalness: 0, roughness: 0.75 }),
    wireLt: new THREE.MeshStandardMaterial({ color: 0xd9d4c2, metalness: 0, roughness: 0.8 }),
    sleeve: new THREE.MeshStandardMaterial({ color: 0x232527, metalness: 0, roughness: 0.9 }),
    clamp: new THREE.MeshStandardMaterial({ color: 0x2e6fb8, metalness: 0.2, roughness: 0.6 }),
    nylon: new THREE.MeshStandardMaterial({ color: 0xe8e3cf, metalness: 0, roughness: 0.6 }),
    gold: new THREE.MeshStandardMaterial({ color: 0xd4a537, metalness: 1, roughness: 0.3 }),
    guardRed: new THREE.MeshStandardMaterial({ color: 0xb3221b, metalness: 0.05, roughness: 0.35 }),
    guardYel: new THREE.MeshStandardMaterial({ color: 0xd8b21f, metalness: 0.05, roughness: 0.38 }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0xffffff, metalness: 0, roughness: 0.04, transmission: 0, transparent: true, opacity: 0.14, depthWrite: false }),
    ceiling: new THREE.MeshStandardMaterial({ color: 0x9aa7b4, metalness: 0.2, roughness: 0.8, transparent: true, opacity: 0.18, side: THREE.DoubleSide, depthWrite: false })
  };
  // Ortak geometriler
  const Gm = {};
  const cylZ = (r1, r2, h, seg = 24) => { const g = new THREE.CylinderGeometry(r1, r2, h, seg); g.rotateX(Math.PI / 2); return g; };
  Gm.bushing = mergeGeometries([cylZ(0.085, 0.085, 0.2, 20).translate(0, 0, 0.1), cylZ(0.15, 0.15, 0.055, 6).translate(0, 0, 0.03)]);
  Gm.lever = mergeGeometries([cylZ(0.032, 0.045, 0.46, 14).translate(0, 0, 0.23), cylZ(0.062, 0.05, 0.13, 16).translate(0, 0, 0.5), new THREE.SphereGeometry(0.062, 16, 10).translate(0, 0, 0.565)]);
  Gm.skirt = cylZ(0.29, 0.31, 0.07, 32).translate(0, 0, 0.035);
  Gm.knobRound = mergeGeometries([cylZ(0.19, 0.21, 0.3, 28).translate(0, 0, 0.2)]);
  Gm.knobSmall = cylZ(0.13, 0.14, 0.24, 24).translate(0, 0, 0.12);
  Gm.knobBar = new THREE.BoxGeometry(0.2, 0.66, 0.26).translate(0, 0.04, 0.2);
  Gm.pointerBar = new THREE.BoxGeometry(0.04, 0.24, 0.01).translate(0, 0.24, 0.335);
  Gm.pointerRound = new THREE.BoxGeometry(0.035, 0.14, 0.01).translate(0, 0.11, 0.355);
  Gm.lensFrame = new THREE.BoxGeometry(0.84, 0.48, 0.06).translate(0, 0, 0.03);
  Gm.btnFrame = new THREE.BoxGeometry(0.58, 0.58, 0.05).translate(0, 0, 0.025);
  Gm.dzus = mergeGeometries([cylZ(0.105, 0.105, 0.04, 20).translate(0, 0, 0.02)]);
  Gm.dzusSlot = new THREE.BoxGeometry(0.15, 0.025, 0.01).translate(0, 0, 0.042);
  Gm.needle = new THREE.BoxGeometry(0.028, 1, 0.01).translate(0, 0.5, 0);

  const parts = [];     // seçilebilir parçalar
  const ctrls = [];     // etkileşimli kontroller
  const lightsById = {};
  const tracks = [];    // kablo/klemp yolları (arka)
  const conns = [];

  const shadowAll = o => o.traverse(x => { if (x.isMesh) { x.castShadow = true; x.receiveShadow = true; } });

  /* ---------- Modül kurucu ---------- */
  function buildModule(m, x0, yTop, w, h) {
    const grp = new THREE.Group(); grp.position.set(x0, yTop, 0);
    const part = { id: m.id, kind: "module", m, name: m.name, obj: grp, base: grp.position.clone(), pull: 0 };
    const items = layoutModule(m, w, h);
    // plaka
    const faceTex = drawFace(m, w, h, items);
    const faceMat = new THREE.MeshStandardMaterial({ map: faceTex, metalness: 0.15, roughness: 0.62 });
    const plate = new THREE.Mesh(new THREE.BoxGeometry(w - 0.05, h - 0.05, 0.1), [M.edge, M.edge, M.edge, M.edge, faceMat, M.edge]);
    plate.position.set(w / 2, -h / 2, 0); plate.receiveShadow = true; grp.add(plate);
    // gövde (arka kutu)
    const hous = new THREE.Mesh(new THREE.BoxGeometry(w - 0.42, h - 0.42, DEPTH), M.housing);
    hous.position.set(w / 2, -h / 2, -0.05 - DEPTH / 2); grp.add(hous);
    // arka etiket
    const lab = new THREE.Mesh(new THREE.PlaneGeometry(Math.min(2.4, w * 0.45), Math.min(1.2, w * 0.225)), new THREE.MeshStandardMaterial({ map: moduleLabelTex(m), roughness: 0.8 }));
    lab.position.set(w * 0.3, -h / 2 + (h > 3 ? h * 0.25 : 0), Z_RECEPT - 0.005); lab.rotation.y = Math.PI; grp.add(lab);

    // statik parçalar (birleştirilmiş)
    const stat = { chrome: [], black: [], blackGloss: [] };
    for (const [x, y] of dzusPts(w, h)) {
      stat.chrome.push(Gm.dzus.clone().translate(x, -y, 0.05));
      stat.black.push(Gm.dzusSlot.clone().rotateZ(Math.random() * 3).translate(x, -y, 0.05));
    }

    for (const o of items) {
      const ay = anchor(o), X = o.x, Y = -ay, Z = 0.05;
      if (o.t === "T") {
        stat.chrome.push(Gm.bushing.clone().translate(X, Y, Z));
        const piv = new THREE.Group(); piv.position.set(X, Y, Z + 0.14);
        const lever = new THREE.Mesh(Gm.lever, M.chrome); piv.add(lever);
        grp.add(piv);
        const c = { o, mod: part, kind: "T", piv, state: o.st, target: 0, dir: 1 };
        lever.userData.ctrl = c;
        if (o.guard) {
          const hinge = new THREE.Group(); hinge.position.set(X, Y + 0.42, Z);
          const gm = o.guard === "yellow" ? M.guardYel : M.guardRed;
          const gg = mergeGeometries([
            new THREE.BoxGeometry(0.52, 0.86, 0.045).translate(0, -0.43, 0.46),
            new THREE.BoxGeometry(0.04, 0.86, 0.46).translate(-0.25, -0.43, 0.23),
            new THREE.BoxGeometry(0.04, 0.86, 0.46).translate(0.25, -0.43, 0.23),
            new THREE.BoxGeometry(0.52, 0.04, 0.46).translate(0, -0.86, 0.23)
          ]);
          const gmesh = new THREE.Mesh(gg, gm); hinge.add(gmesh); grp.add(hinge);
          stat.black.push(new THREE.BoxGeometry(0.62, 0.12, 0.1).translate(X, Y + 0.42, Z + 0.05));
          c.hinge = hinge; c.guardOpen = o.st !== o.gst; gmesh.userData.ctrl = c;
        }
        ctrls.push(c);
      } else if (o.t === "R") {
        const piv = new THREE.Group(); piv.position.set(X, Y, Z); grp.add(piv);
        if (!o.small) stat.black.push(Gm.skirt.clone().translate(X, Y, Z));
        const body = new THREE.Mesh(o.small ? Gm.knobSmall : o.bar ? Gm.knobBar : Gm.knobRound, M.blackGloss);
        const ptr = new THREE.Mesh(o.bar ? Gm.pointerBar : Gm.pointerRound, M.white);
        if (o.small) ptr.position.z = -0.12;
        piv.add(body, ptr);
        const c = { o, mod: part, kind: "R", piv, state: o.st, target: 0 };
        body.userData.ctrl = c; ptr.userData.ctrl = c; ctrls.push(c);
      } else if (o.t === "L" || o.t === "B") {
        const isB = o.t === "B";
        const lw = isB ? 0.48 : 0.76, lh = isB ? 0.48 : 0.4;
        stat.black.push((isB ? Gm.btnFrame : Gm.lensFrame).clone().translate(X, Y, Z));
        const lt = legendTex(o.txt, lw, lh);
        const mat = new THREE.MeshStandardMaterial({ map: lt, emissiveMap: lt, emissive: 0x000000, color: 0x4a4642, roughness: 0.25, metalness: 0 });
        const lens = new THREE.Mesh(new THREE.BoxGeometry(lw, lh, isB ? 0.14 : 0.07), [M.black, M.black, M.black, M.black, mat, M.black]);
        lens.position.set(X, Y, Z + (isB ? 0.09 : 0.065)); grp.add(lens);
        const c = { o, mod: part, kind: o.t, mesh: lens, mat, lit: false, color: LEGEND_COL[o.c || "w"], baseZ: lens.position.z };
        lens.userData.ctrl = c; ctrls.push(c);
        if (o.t === "L") lightsById[o.id] = c;
      } else if (o.t === "G") {
        const R0 = o.size / 2;
        const wall = new THREE.Mesh(new THREE.CylinderGeometry(R0 + 0.02, R0 + 0.02, 0.16, 48, 1, true).rotateX(Math.PI / 2), M.black);
        wall.position.set(X, Y, Z + 0.07); grp.add(wall);
        stat.blackGloss.push(new THREE.RingGeometry(R0 - 0.01, R0 + 0.1, 48).translate(X, Y, Z + 0.15));
        const face = new THREE.Mesh(new THREE.CircleGeometry(R0, 48), new THREE.MeshStandardMaterial({ map: dialTex(o.kind), roughness: 0.7 }));
        face.position.set(X, Y, Z + 0.012); grp.add(face);
        const s = DIALS[o.kind];
        const c = { o, mod: part, kind: "G", needles: [], mesh: face };
        s.val.forEach((v, i) => {
          const isInner = s.inner && i === 1;
          const n = new THREE.Mesh(Gm.needle, i === 1 && s.tags ? M.white : M.white);
          const len = R0 * (isInner ? 0.45 : 0.82);
          n.scale.set(i === 1 && !isInner ? 0.8 : 1, len, 1);
          n.position.set(X, Y, Z + 0.03 + i * 0.006);
          n.rotation.z = -dialAngle(s, v, isInner ? s.inner : null) * Math.PI / 180;
          grp.add(n); c.needles.push(n);
        });
        stat.black.push(new THREE.CylinderGeometry(0.06, 0.06, 0.04, 16).rotateX(Math.PI / 2).translate(X, Y, Z + 0.05));
        const glass = new THREE.Mesh(new THREE.CircleGeometry(R0 + 0.02, 48), M.glass);
        glass.position.set(X, Y, Z + 0.13); grp.add(glass);
        [face, wall, glass, ...c.needles].forEach(x => x.userData.ctrl = c); ctrls.push(c);
      } else if (o.t === "D") {
        const lt = lcdTex(o.kind, o.w, o.h);
        const mat = new THREE.MeshStandardMaterial({ map: lt, emissiveMap: lt, emissive: 0xffffff, emissiveIntensity: 0.55, roughness: 0.15 });
        const win = new THREE.Mesh(new THREE.BoxGeometry(o.w, o.h, 0.04), [M.black, M.black, M.black, M.black, mat, M.black]);
        win.position.set(X, Y, Z + 0.0); grp.add(win);
        stat.black.push(new THREE.BoxGeometry(o.w + 0.12, o.h + 0.12, 0.05).translate(X, Y, Z + 0.0));
        const c = { o, mod: part, kind: "D", mesh: win }; win.userData.ctrl = c; ctrls.push(c);
      }
    }
    for (const k in stat) if (stat[k].length) { const sm = new THREE.Mesh(mergeGeometries(stat[k]), M[k]); grp.add(sm); }

    // Arka priz(ler) – modülle birlikte hareket eder
    const n = CONNECTORS[m.id]?.length || (h > 6 ? 3 : h > 3.2 ? 2 : 1);
    const cdata = CONNECTORS[m.id] || Array.from({ length: n }, () => ({}));
    part.conns = [];
    cdata.forEach((cd, i) => {
      const cx = w * (i + 1) / (n + 1) + (n === 1 ? w * 0.15 : 0), cy = -h / 2 - (h > 3 ? h * 0.12 : 0);
      const rec = new THREE.Group(); rec.position.set(cx, cy, Z_RECEPT);
      const flange = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.95, 0.07), M.connShell); flange.position.z = -0.035;
      const shell = new THREE.Mesh(cylZ(0.34, 0.34, 0.32, 32), M.connShell); shell.position.z = -0.2;
      const ins = new THREE.Mesh(new THREE.CircleGeometry(0.31, 32), new THREE.MeshStandardMaterial({ map: insertTex(false), roughness: 0.6 }));
      ins.position.z = -0.3; ins.rotation.y = Math.PI;
      rec.add(flange, shell, ins); grp.add(rec);
      part.conns.push({ cd, idx: i, local: new THREE.Vector3(cx, cy, Z_RECEPT), rec });
      [flange, shell, ins].forEach(x => x.userData.connRef = { mod: part, i });
    });
    // panel aydınlatma konnektörü (küçük, 2 pin)
    part.lightConn = new THREE.Vector3(0.55, -h + 0.55, Z_RECEPT);
    const lc = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.24, 0.2), M.nylon); lc.position.set(0.55, -h + 0.55, Z_RECEPT - 0.1); grp.add(lc);

    shadowAll(grp);
    grp.traverse(x => { if (x.isMesh && !x.userData.ctrl && !x.userData.connRef) x.userData.part = part; });
    plate.castShadow = false;
    part.items = items; part.w = w; part.h = h; part.x0 = x0; part.yTop = yTop;
    scene.add(grp); parts.push(part);
    return part;
  }

  // Sütunlar
  const mods = [];
  for (let c = 0; c < COLS; c++) {
    let y = 0;
    for (const m of MODULES.filter(q => q.col === c)) {
      const h = m.hu * U;
      mods.push(buildModule(m, c * MW, y, MW, h));
      y -= h;
    }
  }
  const yBot = -COLU * U, hB = BOTTOM.hu * U;
  mods.push(buildModule(BOTTOM, 0, yBot, PANEL_W, hB));
  const panelBottom = yBot - hB;

  /* ---------- Arka yapı ---------- */
  const back = [];
  const addPart = (id, name, desc, obj, extra = {}) => { const p = { id, kind: "struct", name, desc, obj, base: obj.position.clone(), ...extra }; shadowAll(obj); obj.traverse(x => { if (x.isMesh) x.userData.part = p; }); scene.add(obj); parts.push(p); back.push(p); return p; };

  // Dzus rayları ve çerçeve
  const rails = new THREE.Group();
  const railGeo = [];
  for (let c = 0; c <= COLS; c++) railGeo.push(new THREE.BoxGeometry(0.26, -panelBottom + 0.5, 0.55).translate(c * MW, panelBottom / 2, -0.33));
  for (const yy of [0.05, yBot, panelBottom - 0.05]) railGeo.push(new THREE.BoxGeometry(PANEL_W + 0.3, 0.26, 0.55).translate(PANEL_W / 2, yy, -0.33));
  rails.add(new THREE.Mesh(mergeGeometries(railGeo), M.rail));
  // ray üstündeki Dzus yuvaları (receptacle şeritleri)
  const recGeo = [];
  for (let c = 0; c <= COLS; c++) for (let y = -0.2; y > panelBottom; y -= U * 2) recGeo.push(new THREE.CylinderGeometry(0.05, 0.05, 0.2, 8).rotateX(Math.PI / 2).translate(c * MW, y, -0.68));
  rails.add(new THREE.Mesh(mergeGeometries(recGeo), M.alodine));
  addPart("rails", "Dzus rayları ve panel çerçevesi", "Modüllerin oturduğu raylar. Rayların arka yüzündeki yaylı Dzus yuvaları (receptacle) modüllerin çeyrek tur bağlantı elemanlarını tutar. Raylar ve çerçeve modüllerin elektriksel topraklama (bonding) yoludur. Sütun genişliği standart 5,75 inç, dikey adım 3/8 inçtir.", rails);

  // Çevre çerçeve (ön)
  const bez = new THREE.Group();
  const bw = 0.7;
  const bzGeo = [
    new THREE.BoxGeometry(PANEL_W + bw * 2, bw, 0.35).translate(PANEL_W / 2, bw / 2, -0.05),
    new THREE.BoxGeometry(PANEL_W + bw * 2, bw, 0.35).translate(PANEL_W / 2, panelBottom - bw / 2, -0.05),
    new THREE.BoxGeometry(bw, -panelBottom + bw * 2, 0.35).translate(-bw / 2, panelBottom / 2, -0.05),
    new THREE.BoxGeometry(bw, -panelBottom + bw * 2, 0.35).translate(PANEL_W + bw / 2, panelBottom / 2, -0.05)
  ];
  bez.add(new THREE.Mesh(mergeGeometries(bzGeo), new THREE.MeshStandardMaterial({ color: 0x9aa0a4, metalness: 0.1, roughness: 0.7 })));
  addPart("bezel", "Overhead çevre kaplaması", "Panelin etrafındaki kokpit tavan kaplaması (trim). Modüllere önden erişim içindir; panel bir bütün olarak sökülmez, her modül tek tek çıkarılır.", bez);

  // Gövde tavanı (kabuk)
  const ceil = new THREE.Group();
  ceil.add(new THREE.Mesh(new THREE.BoxGeometry(PANEL_W + 6, -panelBottom + 8, 0.08).translate(PANEL_W / 2, panelBottom / 2 + 2, Z_TRUNK - 2.2), M.ceiling));
  const frameGeo = [];
  for (let y = 1.5; y > panelBottom - 2; y -= 7) frameGeo.push(new THREE.BoxGeometry(PANEL_W + 6, 0.12, 1.6).translate(PANEL_W / 2, y, Z_TRUNK - 1.4));
  ceil.add(new THREE.Mesh(mergeGeometries(frameGeo), new THREE.MeshStandardMaterial({ color: 0x8796a5, metalness: 0.5, roughness: 0.5, transparent: true, opacity: 0.35, depthWrite: false })));
  const ceilP = addPart("ceiling", "Gövde tavan yapısı", "Overhead panelin arkasında kalan tavan yapısı: gövde çerçeveleri ve kaplama. Kablo demetleri bu yapıya kelepçelerle tutturulur.", ceil, { shell: true, noPick: true });

  // Ana demetler – her sütunun sağ rayı boyunca
  const trunkX = c => c * MW + MW - 0.42;
  const yTopOut = 1.6;
  for (let c = 0; c < COLS; c++) {
    const x = trunkX(c);
    const pts = [[x, panelBottom + hB / 2, Z_TRUNK], [x, -6, Z_TRUNK], [x, yTopOut - 0.8, Z_TRUNK], [x + (PANEL_W / 2 - x) * 0.35, yTopOut + 0.6, Z_TRUNK - 0.4]];
    const curve = new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(...p)));
    const g = new THREE.Group(); g.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 80, 0.26, 14), M.wire));
    // bağlama ipi halkaları
    const laceGeo = [];
    for (let t = 0.04; t < 0.96; t += 0.045) { const p = curve.getPointAt(t), tg = curve.getTangentAt(t); const tor = new THREE.TorusGeometry(0.27, 0.018, 6, 20); const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), tg); tor.applyQuaternion(q).translate(p.x, p.y, p.z); laceGeo.push(tor); }
    g.add(new THREE.Mesh(mergeGeometries(laceGeo), M.sleeve));
    addPart("trunk" + c, `Kablo demeti – ${c + 1}. sütun`, `${c + 1}. sütundaki modüllerin konnektörlerinden gelen dallar bu demette toplanır. Demet sütun rayı boyunca arkaya (kabin yönüne) ilerler, panelin üst (arka) kenarında diğer demetlerle birleşir. Demetin kablo numaraları ve hangi konnektörlere gittiği WDM'den eklenecek.`, g, { curve, grpName: "Kablo demetleri" });
    tracks.push({ c, curve, x });
  }
  // Ana çıkış demeti – tavana doğru
  {
    const pts = [[PANEL_W / 2 - 3, yTopOut + 0.8, Z_TRUNK - 0.4], [PANEL_W / 2, yTopOut + 2.2, Z_TRUNK - 0.8], [PANEL_W / 2 + 1, yTopOut + 6, Z_TRUNK - 1.2], [PANEL_W / 2 + 1.5, yTopOut + 11, Z_TRUNK - 1.0]];
    const curve = new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(...p)));
    const g = new THREE.Group(); g.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 60, 0.55, 18), M.wire));
    const sl = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.slice(1, 3).map(p => new THREE.Vector3(...p))), 20, 0.58, 18), M.sleeve); g.add(sl);
    addPart("mainHarness", "Ana çıkış demeti (P5 → tavan)", "Sütun demetleri panelin arka (kabin tarafı) kenarında birleşerek tavana çıkar. Buradan kokpit tavanı ve yan duvar boyunca P18/P6 devre kesici panellerine ve kokpit altındaki E/E bölümüne iner. Kesin güzergâh ve ayrım (disconnect) noktaları WDM'e göre eklenecek.", g, { grpName: "Kablo demetleri" });
  }
  // Aydınlatma demeti (5V AC panel ışıkları) – her sütunun sol rayı boyunca, ince
  const ltTracks = [];
  for (let c = 0; c < COLS; c++) {
    const x = c * MW + 0.35;
    const curve = new THREE.CatmullRomCurve3([[x, panelBottom + 0.5, Z_RECEPT - 0.6], [x, -10, Z_RECEPT - 0.6], [x, yTopOut - 0.5, Z_RECEPT - 0.7], [PANEL_W / 2 - 2, yTopOut + 0.7, Z_TRUNK - 0.3]].map(p => new THREE.Vector3(...p)));
    ltTracks.push({ c, curve, x });
  }
  {
    const g = new THREE.Group();
    const geos = ltTracks.map(t => new THREE.TubeGeometry(t.curve, 60, 0.08, 8));
    g.add(new THREE.Mesh(mergeGeometries(geos), M.wireLt));
    addPart("ltHarness", "Panel aydınlatma kabloları (5V AC)", "Modüllerin arka aydınlatma plakalarını (integral lighting) besleyen ince kablolar. Her modülün küçük, ayrı bir aydınlatma konnektörü vardır. Parlaklık Merkez Kontrol Panelindeki PANEL düğmesiyle ayarlanır.", g, { grpName: "Kablo demetleri" });
  }

  // Bağlantı: her modül konnektörü için fiş + backshell + dal
  const plugParts = [];
  for (const mp of mods) {
    const col = mp.m === BOTTOM ? null : mp.m.col;
    mp.conns.forEach(cn => {
      const wp = new THREE.Vector3(mp.x0, mp.yTop, 0).add(cn.local);
      const g = new THREE.Group(); g.position.copy(wp);
      const ring = new THREE.Mesh(cylZ(0.42, 0.42, 0.36, 32), M.connRing); ring.position.z = -0.48;
      const body = new THREE.Mesh(cylZ(0.36, 0.36, 0.25, 28), M.connShell); body.position.z = -0.75;
      const bs = new THREE.Mesh(cylZ(0.24, 0.34, 0.48, 24), M.backshell); bs.position.z = -1.08;
      const saddle = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.08, 0.14), M.backshell); saddle.position.z = -1.3;
      const sock = new THREE.Mesh(new THREE.CircleGeometry(0.31, 32), new THREE.MeshStandardMaterial({ map: insertTex(true), roughness: 0.7 }));
      sock.position.z = -0.31;
      g.add(ring, body, bs, saddle, sock);
      // dal → sütun demeti
      const tr = tracks.find(t => t.c === (col ?? Math.min(COLS - 1, Math.floor(wp.x / MW))));
      const tPt = new THREE.Vector3(tr.x, wp.y + 0.9, Z_TRUNK);
      const loc = v => v.clone().sub(wp);
      const curve = new THREE.CatmullRomCurve3([new THREE.Vector3(0, 0, -1.32), new THREE.Vector3(0, 0.05, -1.75), loc(new THREE.Vector3((wp.x + tr.x) / 2, wp.y + 0.6, Z_TRUNK + 0.15)), loc(tPt)]);
      g.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 30, 0.11, 10), M.wire));
      // kimlik etiketi (beyaz kılıf)
      const idm = new THREE.Mesh(cylZ(0.135, 0.135, 0.22, 16), M.white); idm.position.set(0, 0.04, -1.7); g.add(idm);
      const ref = cn.cd.ref || null;
      const p = {
        id: `plug-${mp.id}-${cn.idx}`, kind: "plug", grpName: "Modül konnektörleri", mod: mp, cn,
        name: `${mp.m.name} – arka konnektör ${cn.idx + 1}${ref ? " (" + ref + ")" : ""}`,
        obj: g, base: g.position.clone()
      };
      shadowAll(g); g.traverse(x => { if (x.isMesh) x.userData.part = p; });
      scene.add(g); parts.push(p); plugParts.push(p); back.push(p);
      cn.plug = p;
    });
    // aydınlatma konnektörü fişi + ince kablo
    const lw = new THREE.Vector3(mp.x0, mp.yTop, 0).add(mp.lightConn);
    const lt = ltTracks.find(t => t.c === (col ?? Math.min(COLS - 1, Math.floor(lw.x / MW))));
    const lcurve = new THREE.CatmullRomCurve3([lw.clone().add(new THREE.Vector3(0, 0, -0.2)), lw.clone().add(new THREE.Vector3(0, 0.1, -0.5)), new THREE.Vector3(lt.x, lw.y + 0.5, Z_RECEPT - 0.6)]);
    const lg = new THREE.Group();
    lg.add(new THREE.Mesh(new THREE.TubeGeometry(lcurve, 16, 0.04, 6), M.wireLt));
    const lplug = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.2, 0.2), M.nylon); lplug.position.copy(lw).add(new THREE.Vector3(0, 0, -0.3)); lg.add(lplug);
    const lp = { id: `lt-${mp.id}`, kind: "ltplug", grpName: "Modül konnektörleri", mod: mp, name: `${mp.m.name} – aydınlatma konnektörü`, obj: lg, base: lg.position.clone() };
    lg.traverse(x => { if (x.isMesh) x.userData.part = lp; });
    scene.add(lg); parts.push(lp); back.push(lp);
  }

  // P-kelepçeler + destek braketleri
  {
    const g = new THREE.Group(); const cg = [], bg = [];
    for (const t of tracks) {
      for (let k = 0.12; k < 0.8; k += 0.17) {
        const p = t.curve.getPointAt(k);
        cg.push(new THREE.TorusGeometry(0.33, 0.05, 8, 22).rotateX(Math.PI / 2).translate(p.x, p.y, p.z));
        bg.push(new THREE.BoxGeometry(0.75, 0.1, 0.12).translate(p.x + 0.65, p.y, p.z));
        bg.push(new THREE.BoxGeometry(0.12, 0.1, Math.abs(p.z) - 0.6).translate(p.x + 1.0, p.y, (p.z - 0.6) / 2));
      }
    }
    g.add(new THREE.Mesh(mergeGeometries(cg), M.clamp), new THREE.Mesh(mergeGeometries(bg), M.alodine));
    addPart("clamps", "P-kelepçeler ve destek braketleri", "Demetleri raylara bağlı braketlere tutturan, iç yüzü yastıklı kelepçeler. Kelepçe aralığı demetin sarkmasını ve titreşimle sürtünmesini (chafing) önleyecek şekilde belirlenir. Yastığı yırtılmış veya demeti sıkıştıran kelepçe değiştirilir.", g, { grpName: "Arka yapı" });
  }
  // Topraklama saplamaları
  {
    const g = new THREE.Group(); const sg = [], rg = [], wg = [];
    for (let c = 0; c < COLS; c++) {
      const x = c * MW + MW / 2, y = 0.25, z = -0.62;
      sg.push(new THREE.CylinderGeometry(0.07, 0.07, 0.5, 12).rotateX(Math.PI / 2).translate(x, y, z - 0.25));
      for (let k = 0; k < 3; k++) rg.push(new THREE.TorusGeometry(0.12, 0.03, 6, 16).translate(x, y, z - 0.15 - k * 0.07));
      const cv = new THREE.CatmullRomCurve3([new THREE.Vector3(x, y, z - 0.2), new THREE.Vector3(x + 0.6, y + 0.4, z - 0.8), new THREE.Vector3(trunkX(c), y + 0.8, Z_TRUNK)]);
      wg.push(new THREE.TubeGeometry(cv, 16, 0.045, 6));
    }
    g.add(new THREE.Mesh(mergeGeometries(sg), M.backshell), new THREE.Mesh(mergeGeometries(rg), M.gold), new THREE.Mesh(mergeGeometries(wg), new THREE.MeshStandardMaterial({ color: 0x2f8a4a, roughness: 0.7 })));
    addPart("ground", "Topraklama saplamaları", "Modül ve demet toprak kabloları halka terminallerle (ring terminal) yapıya bağlı saplamalara toplanır. Temas yüzeyi temiz ve iletken olmalı, montajdan sonra korozyona karşı korunmalıdır. Saplama numaraları (GDxxx) WDM'den eklenecek.", g, { grpName: "Arka yapı" });
  }

  return { parts, ctrls, lightsById, mods, back, M, panelBottom, ceilP };
}

/* ============================ GÖRÜNTÜLEYİCİ ============================ */
export async function mount(root) {
  root.innerHTML = `
  <div class="v3">
    <div class="v3-stage"><canvas></canvas>
      <div class="v3-hint">Döndür · Yakınlaştır · Anahtara dokun: çalıştır</div>
      <div class="v3-load">Panel yükleniyor…</div>
      <div class="v3-tools">
        <button data-t="front" class="on">Ön</button>
        <button data-t="back">Arka</button>
        <button data-t="pull" disabled>Modülü çıkar</button>
        <button data-t="pullAll">Tümünü çıkar</button>
        <button data-t="test">Işık testi</button>
        <button data-t="ceil">Tavanı göster</button>
        <button data-t="reset">Sıfırla</button>
      </div>
    </div>
    <div class="v3-info"></div>
    <div class="v3-chips"></div>
    <p class="v3-note">737NG P5 ön overhead paneli. Modül düzeni ve kontroller açık kaynaklardan derlenmiştir; gerçek uçak ve AMM ile doğrulanacaktır. Konnektör numaraları (D…), pin sayıları ve kablo güzergâhları WDM'den eklenecek. Işık/anahtar mantığı basitleştirilmiştir.</p>
  </div>`;
  const canvasEl = root.querySelector("canvas"), stage = root.querySelector(".v3-stage");
  const info = root.querySelector(".v3-info"), chips = root.querySelector(".v3-chips");

  await loadFonts();
  let renderer;
  try { renderer = new THREE.WebGLRenderer({ canvas: canvasEl, antialias: true, powerPreference: "high-performance" }); }
  catch (e) { stage.innerHTML = '<p style="padding:16px">Bu cihazda 3D (WebGL) desteklenmiyor.</p>'; return () => {}; }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  const dark = matchMedia("(prefers-color-scheme: dark)").matches;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(dark ? 0x10161d : 0xdfe5eb);
  const pmrem = new THREE.PMREMGenerator(renderer);
  const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environment = envTex; scene.environmentIntensity = 0.62;
  const key = new THREE.DirectionalLight(0xffffff, 1.7);
  key.position.set(PANEL_W / 2 - 8, 6, 22); key.target.position.set(PANEL_W / 2, -12, 0);
  key.castShadow = true; key.shadow.mapSize.set(2048, 2048);
  Object.assign(key.shadow.camera, { left: -16, right: 16, top: 16, bottom: -16, near: 1, far: 60 });
  key.shadow.bias = -0.0004; key.shadow.normalBias = 0.02;
  scene.add(key, key.target);
  const rim = new THREE.DirectionalLight(0xffffff, 0.6); rim.position.set(PANEL_W / 2 + 10, -20, -25); scene.add(rim);

  const cam = new THREE.PerspectiveCamera(38, 1, 0.1, 400);
  const controls = new OrbitControls(cam, canvasEl);
  controls.enableDamping = true; controls.dampingFactor = 0.12; controls.minDistance = 2.5; controls.maxDistance = 90;
  controls.zoomSpeed = 1.2; controls.screenSpacePanning = true;

  const S = buildScene(scene);
  root.querySelector(".v3-load").remove();
  const center = new THREE.Vector3(PANEL_W / 2, S.panelBottom / 2, 0);

  let dirty = true;
  const resize = () => { const w = stage.clientWidth, h = stage.clientHeight; if (!w || !h) return; renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); dirty = true; };
  const ro = new ResizeObserver(resize); ro.observe(stage); resize();

  const fitDist = () => { const vf = THREE.MathUtils.degToRad(cam.fov), hf = 2 * Math.atan(Math.tan(vf / 2) * cam.aspect); const r = 16.5; return r / Math.sin(Math.min(vf, hf) / 2) * 0.82; };
  let camAnim = null;
  function goView(side) {
    const d = fitDist();
    const pos = side === "back" ? new THREE.Vector3(center.x + 6, center.y + 9, -d) : new THREE.Vector3(center.x, center.y - 2, d);
    camAnim = { from: cam.position.clone(), to: pos, tf: controls.target.clone(), tt: center.clone(), t: 0 };
    root.querySelectorAll('[data-t="front"],[data-t="back"]').forEach(b => b.classList.toggle("on", b.dataset.t === side));
  }
  cam.position.set(center.x, center.y - 2, fitDist()); controls.target.copy(center); controls.update();

  /* ---- durum / ışıklar ---- */
  let lampTest = false;
  function computeLights() {
    const on = {};
    for (const c of S.ctrls) if (c.o.lights) for (const L of c.o.lights) if (L.on.includes(c.state)) on[L.id] = true;
    for (const id in S.lightsById) setLit(S.lightsById[id], lampTest || !!on[id]);
    dirty = true;
  }
  function setLit(c, v) {
    c.lit = v;
    c.mat.color.setHex(v ? 0x9a948c : 0x4a4642);
    c.mat.emissive.setHex(v ? c.color : 0x000000);
    c.mat.emissiveIntensity = v ? 1.9 : 0;
  }
  // kontrol hedef açıları
  function targetFor(c) {
    if (c.kind === "T") { const n = c.o.pos.length; return n === 2 ? [-0.5, 0.5][c.state] : [-0.5, 0, 0.5][c.state]; }
    if (c.kind === "R") { if (c.o.pos.length === 1) return c.spin || 0; return -rotAngles(c.o)[c.state] * Math.PI / 180; }
    return 0;
  }
  for (const c of S.ctrls) {
    if (c.kind === "T") { c.piv.rotation.x = c.target = targetFor(c); if (c.hinge) c.hinge.rotation.x = c.guardOpen ? -1.75 : 0; }
    if (c.kind === "R") c.piv.rotation.z = c.target = targetFor(c);
  }
  computeLights();

  /* ---- seçim ve vurgulama ---- */
  let selPart = null, selCtrl = null; const hl = [];
  function clearHL() { while (hl.length) { const m = hl.pop(); m.material = m.userData.origMat; } }
  function highlight(obj) {
    obj.traverse(m => { if (!m.isMesh) return; m.userData.origMat = m.material; const mk = mt => { const q = mt.clone(); if (q.emissive && !(q.emissiveIntensity > 0.6)) { q.emissive = new THREE.Color(0x2a6cf0); q.emissiveIntensity = 0.38; } return q; }; m.material = Array.isArray(m.material) ? m.material.map(mk) : mk(m.material); hl.push(m); });
  }
  const modOf = p => p ? (p.kind === "module" ? p : p.mod || null) : null;
  function showInfo() {
    const p = selPart, c = selCtrl;
    if (c) {
      const o = c.o, m = c.mod.m;
      let st = "";
      if (c.kind === "T" || c.kind === "R") { const v = o.pos[c.state]; st = o.pos.length > 1 ? `<span class="v3-st">Konum: <b>${esc((v || "orta").replace("\n", " "))}</b>${c.guardOpen === false ? " · kapak kapalı" : c.hinge ? " · kapak açık" : ""}</span>` : ""; }
      if (c.kind === "L") st = `<span class="v3-st">${c.lit ? "Yanıyor" : "Sönük"}</span>`;
      const nm = c.kind === "L" ? o.txt.replace("\n", " ") + " ışığı" : c.kind === "B" ? o.txt.replace("\n", " ") + " düğmesi" : (o.lab || o.txt || "").replace("\n", " ") || "Kontrol";
      info.innerHTML = `<small>${esc(m.name)}</small><b>${esc(nm)}</b> ${st}<p>${o.d || LDESC(o) || "Bu kontrol için açıklama eklenecek."}</p>`;
      return;
    }
    if (p && p.kind === "module") {
      const m = p.m;
      const cl = p.conns.map((cn, i) => `<li>Konnektör ${i + 1}: <b>${esc(cn.cd.ref || "WDM no. bekleniyor")}</b>${cn.cd.pins ? " · " + cn.cd.pins + " pin" : ""}${cn.cd.harness ? " · demet " + esc(cn.cd.harness) : ""}</li>`).join("");
      info.innerHTML = `<small>ATA ${esc(m.ata)} · ${esc(m.en)}</small><b>${esc(m.name)}</b><p>${m.desc}</p><p class="v3-sub">Arka konnektörler (${p.conns.length} + 1 aydınlatma):</p><ul class="v3-ul">${cl}</ul>`;
      return;
    }
    if (p && p.kind === "plug") {
      const cd = p.cn.cd;
      info.innerHTML = `<small>${esc(p.mod.m.name)}</small><b>Arka konnektör ${p.cn.idx + 1}</b><p>Modülün arkasındaki prize (receptacle) takılan kablo tarafı fiş. Kilitleme halkası, soketli insert, backshell ve gerilim giderici kelepçeden oluşur. Modül önden çekildiğinde bu fiş yerinde kalır ve prizden ayrılır; çıkarmadan önce ilgili devre kesicileri açılıp etiketlenir.</p>
      <table class="v3-tbl"><tr><td>WDM no.</td><td>${esc(cd.ref || "— (WDM'den eklenecek)")}</td></tr><tr><td>Tip</td><td>${esc(cd.type || "Dairesel (doğrulanacak)")}</td></tr><tr><td>Pin</td><td>${esc(cd.pins || "—")}</td></tr><tr><td>Demet</td><td>${esc(cd.harness || "—")}</td></tr></table>`;
      return;
    }
    if (p && p.kind === "ltplug") { info.innerHTML = `<small>${esc(p.mod.m.name)}</small><b>Aydınlatma konnektörü</b><p>Modülün entegre aydınlatma plakasını (panel arka ışığı) besleyen küçük konnektör. Panel ışıkları 5V AC ile çalışır ve PANEL dimmer düğmesiyle ayarlanır.</p>`; return; }
    if (p) { info.innerHTML = `<b>${esc(p.name)}</b><p>${p.desc}</p>`; return; }
    info.innerHTML = `<b>737NG ön overhead paneli (P5)</b><p>Modüllere dokunarak bilgi al, anahtarları ve düğmeleri çalıştır. <b>Arka</b> ile panelin arkasındaki modül gövdelerini, konnektörleri ve kablo demetlerini gör. Bir modül seçip <b>Modülü çıkar</b>'a basınca modül önden çekilir ve arka konnektörü ayrılır.</p>`;
  }
  function select(p, c) {
    clearHL(); selPart = p; selCtrl = c || null;
    if (c) highlight(c.piv || c.mesh);
    else if (p) highlight(p.obj);
    const mod = modOf(p || c?.mod);
    const pb = root.querySelector('[data-t="pull"]'); pb.disabled = !mod;
    if (mod) pb.textContent = mod.pull ? "Modülü tak" : "Modülü çıkar";
    chips.querySelectorAll("button").forEach(b => b.classList.toggle("on", !!p && b.dataset.id === (c ? c.mod.id : p.id)));
    showInfo(); dirty = true;
  }

  /* ---- etkileşim ---- */
  const timers = [];
  function operate(c) {
    if (c.kind === "T") {
      if (c.hinge && !c.guardOpen) { c.guardOpen = true; return; }
      const n = c.o.pos.length; const prev = c.state;
      if (n === 2) c.state = 1 - c.state;
      else if (c.o.spring && c.o.spring.length === 2) { c.alt = !c.alt; c.state = c.alt ? 0 : 2; }
      else { if (c.state === 0) c.dir = 1; if (c.state === n - 1) c.dir = -1; c.state += c.dir; }
      if (c.o.spring && c.o.spring.includes(c.state)) {
        const back = c.o.st; timers.push(setTimeout(() => { c.state = back; c.target = targetFor(c); if (c.hinge && c.state === c.o.gst) c.guardOpen = false; computeLights(); if (selCtrl === c) showInfo(); }, 650));
      }
      if (c.hinge && c.state === c.o.gst && prev !== c.state) c.guardOpen = false;
      c.target = targetFor(c);
    } else if (c.kind === "R") {
      if (c.o.pos.length === 1) { c.spin = (c.spin || 0) - 0.5; c.target = c.spin; return; }
      const n = c.o.pos.length; if (c.dir == null) c.dir = 1;
      let ns = c.state + c.dir; if (ns < 0 || ns >= n) { c.dir = -c.dir; ns = c.state + c.dir; }
      c.state = ns;
      if (c.o.spring && c.o.spring.includes(c.state)) {
        const back = c.state - c.dir; c.dir = -c.dir; timers.push(setTimeout(() => { c.state = back; c.target = targetFor(c); computeLights(); if (selCtrl === c) showInfo(); }, 800));
      }
      c.target = targetFor(c);
    } else if (c.kind === "B") {
      c.mesh.position.z = c.baseZ - 0.06; timers.push(setTimeout(() => { c.mesh.position.z = c.baseZ; dirty = true; }, 220));
    }
    computeLights();
  }

  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  let down = null;
  canvasEl.addEventListener("pointerdown", e => { down = [e.clientX, e.clientY]; });
  canvasEl.addEventListener("pointerup", e => {
    if (!down) return; const mv = Math.hypot(e.clientX - down[0], e.clientY - down[1]); down = null; if (mv > 8) return;
    const r = canvasEl.getBoundingClientRect();
    ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    ray.setFromCamera(ndc, cam);
    const hits = ray.intersectObjects(scene.children, true).filter(h => h.object.visible && isVisible(h.object) && (h.object.userData.ctrl || h.object.userData.part || h.object.userData.connRef) && !(h.object.userData.part?.noPick));
    if (!hits.length) { select(null); return; }
    const o = hits[0].object;
    if (o.userData.ctrl) { const c = o.userData.ctrl; if (c.kind === "T" || c.kind === "R" || c.kind === "B") operate(c); select(c.mod, c); return; }
    if (o.userData.connRef) { const { mod, i } = o.userData.connRef; select(mod.conns[i].plug); return; }
    select(o.userData.part);
  });
  const isVisible = o => { while (o) { if (!o.visible) return false; o = o.parent; } return true; };

  // chips: modüller + arka yapı
  const chipList = [...S.mods.map(p => ({ id: p.id, label: p.m.name, p })), ...S.back.filter(p => p.kind === "struct" && !p.noPick).map(p => ({ id: p.id, label: p.name, p }))];
  chips.innerHTML = `<div class="v3-chhead">Modüller</div>` + chipList.map((c, i) => (i === S.mods.length ? `<div class="v3-chhead">Panel arkası</div>` : "") + `<button data-id="${c.id}">${esc(c.label)}</button>`).join("");
  chips.querySelectorAll("button").forEach(b => b.onclick = () => {
    const c = chipList.find(x => x.id === b.dataset.id);
    if (selPart === c.p && !selCtrl) { select(null); return; }
    if (c.p.kind === "struct") goView("back");
    select(c.p);
    // seçilen modüle odaklan
    const box = new THREE.Box3().setFromObject(c.p.kind === "module" ? c.p.obj.children[0] : c.p.obj); const ctr = box.getCenter(new THREE.Vector3());
    const dir = cam.position.clone().sub(controls.target).normalize(); const size = box.getSize(new THREE.Vector3()).length();
    camAnim = { from: cam.position.clone(), to: ctr.clone().addScaledVector(dir, Math.max(8, size * 1.5)), tf: controls.target.clone(), tt: ctr, t: 0 };
    stage.scrollIntoView({ behavior: "smooth", block: "start" });
  });

  function setPull(mp, v) { mp.pull = v; dirty = true; }
  root.querySelectorAll(".v3-tools button").forEach(b => b.onclick = () => {
    const t = b.dataset.t;
    if (t === "front" || t === "back") goView(t);
    if (t === "pull") { const mod = modOf(selCtrl ? selCtrl.mod : selPart); if (mod) { setPull(mod, mod.pull ? 0 : 1); b.textContent = mod.pull ? "Modülü tak" : "Modülü çıkar"; } }
    if (t === "pullAll") { const any = S.mods.some(m => m.pull); S.mods.forEach((m, i) => setPull(m, any ? 0 : 1)); b.classList.toggle("on", !any); b.textContent = any ? "Tümünü çıkar" : "Tümünü tak"; }
    if (t === "test") { lampTest = !lampTest; b.classList.toggle("on", lampTest); computeLights(); if (selCtrl) showInfo(); }
    if (t === "ceil") { const v = !S.ceilP.obj.visible; S.ceilP.obj.visible = v; b.classList.toggle("on", v); dirty = true; }
    if (t === "reset") {
      for (const c of S.ctrls) { if (c.kind === "T" || c.kind === "R") { c.state = c.o.st; c.spin = 0; c.target = targetFor(c); if (c.hinge) c.guardOpen = c.o.st !== c.o.gst; } }
      S.mods.forEach(m => setPull(m, 0)); lampTest = false; root.querySelector('[data-t="test"]').classList.remove("on");
      const pa = root.querySelector('[data-t="pullAll"]'); pa.classList.remove("on"); pa.textContent = "Tümünü çıkar";
      computeLights(); select(null); goView("front");
    }
  });
  S.ceilP.obj.visible = false;
  controls.addEventListener("change", () => dirty = true);

  /* ---- döngü ---- */
  let alive = true;
  const ease = (a, b, k) => a + (b - a) * k;
  function loop() {
    if (!alive) return;
    requestAnimationFrame(loop);
    let moving = false;
    if (camAnim) {
      camAnim.t = Math.min(1, camAnim.t + 0.06); const k = 1 - Math.pow(1 - camAnim.t, 3);
      cam.position.lerpVectors(camAnim.from, camAnim.to, k); controls.target.lerpVectors(camAnim.tf, camAnim.tt, k);
      if (camAnim.t >= 1) camAnim = null; moving = true;
    }
    controls.update();
    for (const c of S.ctrls) {
      if (c.kind === "T") {
        if (Math.abs(c.piv.rotation.x - c.target) > 0.002) { c.piv.rotation.x = ease(c.piv.rotation.x, c.target, 0.35); moving = true; }
        if (c.hinge) { const g = c.guardOpen ? -1.75 : 0; if (Math.abs(c.hinge.rotation.x - g) > 0.002) { c.hinge.rotation.x = ease(c.hinge.rotation.x, g, 0.25); moving = true; } }
      } else if (c.kind === "R") {
        if (Math.abs(c.piv.rotation.z - c.target) > 0.002) { c.piv.rotation.z = ease(c.piv.rotation.z, c.target, 0.3); moving = true; }
      }
    }
    for (const m of S.mods) {
      const z = m.base.z + m.pull * PULL;
      if (Math.abs(m.obj.position.z - z) > 0.002) { m.obj.position.z = ease(m.obj.position.z, z, 0.12); moving = true; }
    }
    if (moving) dirty = true;
    if (dirty) { renderer.render(scene, cam); dirty = false; }
  }
  select(null); loop();
  root.__p5 = { S, select, operate, goView, cam, controls, setPull, render: () => { dirty = true; } };

  return () => {
    alive = false; timers.forEach(clearTimeout); ro.disconnect(); controls.dispose();
    scene.traverse(o => { if (o.isMesh) { o.geometry.dispose(); const ms = Array.isArray(o.material) ? o.material : [o.material]; ms.forEach(m => { m.map?.dispose(); m.emissiveMap?.dispose(); m.dispose(); }); } });
    envTex.dispose(); pmrem.dispose(); renderer.dispose(); renderer.forceContextLoss?.();
  };
}

// Işık açıklamaları (genel)
function LDESC(o) {
  const t = (o.txt || "").replace("\n", " ");
  const map = {
    "LOW PRESSURE": "İlgili pompanın çıkış basıncı düşük. Pompa kapalıyken de yanar.",
    "OVERHEAT": "Elektrikli hidrolik pompa aşırı ısındı.",
    "VALVE OPEN": "Valf açık (mavi). Valf hareket halindeyken veya konumu anahtarla uyuşmazken parlak yanar.",
    "ENG VALVE CLOSED": "Motor yakıt valfi kapalı (sönük mavi) / geçişte veya uyumsuz (parlak).",
    "SPAR VALVE CLOSED": "Kanat ön sparındaki yakıt kesme valfi kapalı (sönük) / geçişte (parlak).",
    "FILTER BYPASS": "Motor yakıt filtresi tıkanmak üzere; yakıt filtreyi bypass edebilir.",
    "TRANSFER BUS OFF": "İlgili AC transfer bara enerjisiz.",
    "SOURCE OFF": "Transfer baraya kokpitten seçilmiş bir kaynak bağlı değil.",
    "GEN OFF BUS": "Motor jeneratörü baraya bağlı değil (mavi).",
    "APU GEN OFF BUS": "APU hazır, jeneratörü baraya bağlı değil (mavi).",
    "GRD POWER AVAILABLE": "Yer gücü bağlı ve parametreleri uygun (mavi).",
    "DRIVE": "IDG düşük yağ basıncı veya yüksek yağ sıcaklığı – ya da IDG ayrılmış.",
    "STANDBY PWR OFF": "Standby AC/DC baralardan biri veya daha fazlası enerjisiz.",
    "BAT DISCHARGE": "Batarya aşırı deşarj oluyor.",
    "TR UNIT": "TRU arızası.",
    "ELEC": "Elektrik sisteminde bakım gerektiren arıza (yalnız yerde).",
    "WING-BODY OVERHEAT": "Pnömatik kanalda sıcak hava kaçağı algılandı.",
    "BLEED TRIP OFF": "Aşırı sıcaklık veya basınç nedeniyle motor bleed valfi kapandı.",
    "PACK": "Paket aşırı ısındı ve kapandı veya kontrol arızası.",
    "DUAL BLEED": "APU bleed valfi ile motor bleed valfi aynı anda açık.",
    "RAM DOOR FULL OPEN": "Ram hava giriş kapağı tam açık (mavi) – yerde ve düşük hızda normal.",
    "ZONE TEMP": "Bölge kanalında aşırı ısınma veya kontrol arızası.",
    "AUTO FAIL": "Otomatik basınç kontrolcüsü arızası.",
    "OFF SCHED DESCENT": "Uçak seçilen FLT ALT'a ulaşmadan alçalmaya başladı.",
    "ALTN": "Yedek (alternate) basınç kontrolcüsü aktif.",
    "MANUAL": "Basınçlandırma manuel modda.",
    "COWL ANTI-ICE": "Motor giriş buz önleme kanalında aşırı basınç.",
    "COWL VALVE OPEN": "Motor buz önleme valfi açık (mavi).",
    "ON": "Isıtma çalışıyor (yeşil).",
    "YAW DAMPER": "Yaw damper devrede değil.",
    "STBY RUD ON": "Standby rudder sistemi basınçlandırıldı.",
    "LOW QUANTITY": "Standby hidrolik rezervuar seviyesi düşük.",
    "FEEL DIFF PRESS": "Elevator feel sisteminde A ve B basınçları arasında fark var.",
    "SPEED TRIM FAIL": "Speed trim sistemi arızalı.",
    "MACH TRIM FAIL": "Mach trim sistemi arızalı.",
    "AUTO SLAT FAIL": "Autoslat sistemi arızalı.",
    "NOT ARMED": "Acil çıkış ışıkları ARMED konumunda değil.",
    "OFF": "Fan hava akışı yetersiz; yedek (ALTN) fana geçin.",
    "MAINT": "APU bakım gerektiriyor (mavi).",
    "LOW OIL PRESSURE": "APU yağ basıncı düşük (start sırasında normal).",
    "FAULT": "APU arızası – APU otomatik kapanır.",
    "OVER SPEED": "APU aşırı devir – APU kapanır.",
    "OVER HEAT": "Cam ısıtmasında aşırı ısınma.",
    "L VALVE OPEN": "Sol kanat buz önleme valfi açık (mavi).",
    "R VALVE OPEN": "Sağ kanat buz önleme valfi açık (mavi)."
  };
  if (map[t]) return map[t];
  if (/PITOT|VANE|PROBE/.test(t)) return "İlgili prob ısıtılmıyor. Prob ısıtma anahtarı kapalıyken de yanar.";
  return "";
}
