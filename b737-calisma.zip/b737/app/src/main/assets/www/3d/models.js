// Temsili 3D eğitim modelleri. Basit geometrik parçalardan oluşur; ölçeksizdir.
// Boeing/Honeywell CAD verisi veya WDM kablo güzergâhı DEĞİLDİR.

const C = {
  steel: 0x9aa3ad, dark: 0x4a525c, gear: 0x8d8576, alu: 0xc4ccd4, hot: 0x8a6a55, ti: 0xa7a19a,
  blue: 0x3d7fd1, green: 0x4f9a63, red: 0xc0392b, orange: 0xd9822b, rubber: 0x2a2d31, gold: 0xd4a537,
  wire: 0xe8e4d8, panel: 0x5b636d, black: 0x22262b, white: 0xf2f2f2, yellow: 0xe5c33a
};

/* =====================================================================
   1) APU – Honeywell 131-9B (temsili)
   ===================================================================== */
const APU = {
  title: "APU (131-9B) – temsili 3D",
  sub: "Parçalara ayır, parçaya dokun, bilgisini gör",
  chapter: "apu",
  camera: [7.5, 4.2, 8.5], target: [0, 0.4, 0], minDist: 3, maxDist: 30,
  shellLabel: "Bölmeyi gizle",
  intro: "Kuyruk konisindeki APU bölmesi. Önde (solda) dişli kutusu ve jeneratör, ortada kompresörler ve yanma odası, arkada türbin ve egzoz bulunur. Bir parçaya dokun veya aşağıdaki listeden seç.",
  note: "Temsili model, ölçeksiz. Parça şekil ve konumları basitleştirilmiştir; gerçek yerleşim için yetkili dokümana bakın.",
  build(T, H) {
    const P = [];
    const add = (id, name, en, desc, obj, explode, extra = {}) => P.push({ id, name, en, desc, obj, explode, ...extra });

    // Bölme (kabuk)
    const shellM = H.mat(0x8fb3d9, { op: 0.13, double: true, m: 0.1, r: 0.9 });
    const shell = H.group(
      H.cylX(3.1, 1.7, 10, shellM, [0.5, 0.6, 0], 48, true),
      H.cylX(3.1, 3.1, 0.06, H.mat(0xc9d6e3, { op: 0.35, double: true }), [-4.5, 0.6, 0])
    );
    add("shell", "APU bölmesi ve yangın perdesi", "APU compartment / firewall",
      "APU, gövdenin geri kalanından yangına dayanıklı bir perde (firewall) ile ayrılmış bölmede durur. Bölme altındaki menteşeli kapaklardan bakım erişimi sağlanır.",
      shell, null, { shell: true, noPick: true });

    // Dişli kutusu
    const gb = H.group(
      H.box(1.0, 1.6, 1.5, H.mat(C.gear, { m: 0.6, r: 0.45 }), [-2.4, 0, 0]),
      H.cylX(0.35, 0.35, 0.25, H.mat(C.dark), [-2.95, -0.45, 0.4]),
      H.cylY(0.09, 0.09, 0.35, H.mat(C.dark), [-2.2, 0.95, -0.45])
    );
    add("gearbox", "Dişli kutusu", "Accessory gearbox",
      "Türbin şaftının yüksek devrini aksesuarların kullanabileceği devire düşürür. Jeneratörü, yağ pompasını, yakıt kontrol ünitesini tahrik eder. Yağ haznesi (sump) dişli kutusuyla bütünleşiktir. Üzerindeki küçük sensör devir (speed) algılayıcısıdır.",
      gb, [-1.3, 0, 0]);

    // Jeneratör (starter-generator)
    const gen = H.group(
      H.cylX(0.58, 0.58, 1.25, H.mat(C.blue, { m: 0.5, r: 0.4 }), [-3.55, 0, 0]),
      H.cylX(0.7, 0.7, 0.1, H.mat(C.dark), [-2.95, 0, 0]),
      H.box(0.35, 0.25, 0.3, H.mat(C.black), [-3.6, 0.65, 0])
    );
    add("gen", "Jeneratör (starter-generator)", "APU generator",
      "115V AC, 400 Hz, tipik 90 kVA güç üretir. 131-9B'de aynı ünite start sırasında marş motoru olarak çalışır; start gücü SCU (Start Converter Unit) üzerinden verilir. Üstteki kutu elektrik bağlantı (terminal) bloğudur.",
      gen, [-2.4, 0, 0]);

    // Yakıt kontrol ünitesi
    const fcu = H.group(
      H.box(0.55, 0.5, 0.35, H.mat(C.green), [-2.4, -0.35, 0.95]),
      H.tube([[-2.4, -0.6, 1.1], [-2.0, -1.1, 1.3], [-0.5, -1.15, 1.25], [0.5, -1.15, 1.1]], 0.04, H.mat(C.yellow))
    );
    add("fcu", "Yakıt kontrol ünitesi ve yakıt hattı", "Fuel control unit",
      "Dişli kutusuna bağlı yakıt pompası ve ölçüm ünitesidir. ECU'nun komutuna göre yanma odasına giden yakıtı ayarlar. Sarı hat, yakıtı nozul manifolduna taşır. Uçak tarafındaki besleme sol yakıt manifoldundan ve APU yakıt kesme valfinden gelir.",
      fcu, [-1.3, -0.4, 1.4]);

    // Yağ dolum / gözetleme
    const oil = H.group(
      H.cylZ(0.12, 0.12, 0.25, H.mat(C.yellow), [-2.2, -0.4, -0.85]),
      H.cylZ(0.13, 0.13, 0.05, H.mat(0x88ccff, { op: 0.8 }), [-2.6, -0.55, -0.78])
    );
    add("oil", "Yağ dolum ve seviye camı", "Oil fill / sight glass",
      "APU'nun kendi yağ sistemi vardır. Seviye, gözetleme camından veya göstergeden okunur. Kontrol, APU durduktan sonra belirtilen süre içinde yapılmalıdır. Doğru yağ tipini kullanın, farklı tipleri karıştırmayın.",
      oil, [-1.3, -0.3, -1.3]);

    // Yağ soğutucu
    const fins = H.group(H.box(0.8, 0.35, 0.8, H.mat(C.alu, { m: 0.7 }), [-2.4, 1.0, -0.3]));
    for (let i = 0; i < 7; i++) fins.add(H.box(0.02, 0.36, 0.82, H.mat(C.dark), [-2.75 + i * 0.12, 1.0, -0.3]));
    add("cooler", "Yağ soğutucu", "Oil cooler",
      "Yağın ısısını bölmeden geçen soğutma havasına aktaran ısı eşanjörüdür. Kanatçıkların (fin) kirlenmesi veya hasarı yüksek yağ sıcaklığına ve otomatik kapanmaya yol açabilir.",
      fins, [-1.3, 1.1, -0.6]);

    // Hava girişi
    const inletM = H.mat(C.alu, { m: 0.5 });
    const inlet = H.group(
      H.box(1.2, 1.0, 1.4, inletM, [-0.75, 1.35, 0]),
      H.box(0.85, 1.7, 1.0, inletM, [-0.75, 2.6, 0]),
      H.box(0.95, 0.04, 1.1, H.mat(C.dark), [-0.45, 3.6, 0], [0, 0, -0.5])
    );
    add("inlet", "Hava girişi ve giriş kapağı", "Inlet plenum / inlet door",
      "Dış hava gövdedeki giriş kapağından girer ve plenum ile kompresörlere dağıtılır. Kapak APU çalışırken açılır, kapatılınca kapanır. Kapak tam açılmazsa APU start edilmez veya kapanır.",
      inlet, [0, 1.8, 0]);

    // Yük kompresörü
    const lc = H.group(
      H.cylX(0.95, 0.95, 0.7, H.mat(C.steel, { m: 0.7, r: 0.35 }), [-1.4, 0, 0]),
      H.torus(0.95, 0.24, H.mat(C.ti, { m: 0.7 }), [-1.4, 0, 0], [0, Math.PI / 2, 0])
    );
    add("lc", "Yük kompresörü", "Load compressor",
      "Uçağın kullandığı bleed havasını üretir: klima paketleri ve motor marşı için. Girişindeki ayarlanabilir kanatçıklar (IGV) hava miktarını talebe göre değiştirir. Güç bölümünden ayrı bir kompresördür.",
      lc, [-0.6, 0, 0]);

    // Bleed valfi ve kanalı
    const bv = H.group(
      H.tube([[-1.4, 0, -1.1], [-1.4, 0, -1.9], [-1.4, 0.4, -2.4], [-1.4, 1.8, -2.6]], 0.18, H.mat(C.alu)),
      H.cylZ(0.3, 0.3, 0.35, H.mat(C.orange), [-1.4, 0, -1.55]),
      H.box(0.35, 0.3, 0.3, H.mat(C.dark), [-1.4, 0.4, -1.55])
    );
    add("bleed", "APU bleed valfi ve kanalı", "Load control / bleed valve",
      "Yük kompresöründen gelen havayı uçağın pnömatik manifolduna verir veya keser. Kokpitteki APU BLEED anahtarıyla ve ECU tarafından kontrol edilir. Üstteki kutu valf aktüatörüdür. Kanal kelepçe ve contaları kaçak açısından kontrol edilir.",
      bv, [-0.6, 0, -1.4]);

    // Surge kontrol valfi
    const scv = H.group(
      H.tube([[-1.4, -1.1, 0], [-1.4, -1.6, 0], [0.4, -1.6, 0], [2.4, -1.4, 0], [3.2, -0.65, 0]], 0.13, H.mat(C.alu)),
      H.cylX(0.24, 0.24, 0.35, H.mat(C.orange), [-0.3, -1.6, 0]),
      H.box(0.3, 0.28, 0.3, H.mat(C.dark), [-0.3, -1.95, 0])
    );
    add("scv", "Surge kontrol valfi", "Surge control valve",
      "Uçağın hava talebi azaldığında yük kompresöründen fazla havayı egzoza boşaltır. Böylece kompresörün surge (akış kopması) yapması önlenir.",
      scv, [0, -1.3, 0]);

    // Güç kompresörü
    const pc = H.cylX(0.8, 0.8, 0.6, H.mat(C.steel, { m: 0.75, r: 0.3 }), [-0.35, 0, 0]);
    add("pc", "Güç bölümü kompresörü", "Power section compressor",
      "APU'nun kendi yanması için gereken havayı sıkıştırır. Yük kompresöründen bağımsızdır, ikisi aynı şaft üzerinde döner.",
      H.group(pc), [0.1, 0, 0]);

    // Yanma odası + nozullar
    const comb = H.group(H.torus(0.75, 0.3, H.mat(C.hot, { m: 0.5, r: 0.55 }), [0.5, 0, 0], [0, Math.PI / 2, 0]));
    add("comb", "Yanma odası", "Combustor",
      "Sıkıştırılmış hava ile yakıt burada karışıp yanar. Halka (annular) tiptedir. Sıcak gazlar türbine gider.",
      comb, [0.7, 0, 0]);

    const noz = H.group(H.torus(1.08, 0.04, H.mat(C.yellow), [0.5, 0, 0], [0, Math.PI / 2, 0]));
    for (let i = 0; i < 8; i++) {
      const a = i / 8 * Math.PI * 2;
      const n = H.cylY(0.05, 0.05, 0.3, H.mat(C.dark), [0.5, Math.cos(a) * 1.0, Math.sin(a) * 1.0]);
      n.rotation.x = a; noz.add(n);
    }
    add("noz", "Yakıt nozulları ve manifold", "Fuel nozzles / manifold",
      "Yakıt halka şeklindeki manifolddan nozullara dağılır ve yanma odasına püskürtülür. Tıkalı nozul düzensiz sıcaklık dağılımına ve türbin hasarına yol açabilir.",
      noz, [0.7, 1.4, 0]);

    // Ateşleme
    const ign = H.group(
      H.cylY(0.07, 0.07, 0.5, H.mat(C.white), [0.6, -1.05, 0.55]),
      H.box(0.45, 0.3, 0.3, H.mat(C.dark), [-0.6, -1.1, 1.45]),
      H.tube([[-0.4, -1.05, 1.35], [0.2, -1.4, 1.0], [0.6, -1.3, 0.6]], 0.035, H.mat(C.orange))
    );
    add("ign", "Ateşleme: ikaz ünitesi ve buji", "Ignition exciter / igniter",
      "İkaz ünitesi (exciter) yüksek enerjili kıvılcım üretir, buji (igniter plug) yanma odasında karışımı tutuşturur. Start tamamlanınca ateşleme kesilir. Yüksek gerilim nedeniyle sökmeden önce sistem kapalı olmalı ve belirtilen süre beklenmelidir.",
      ign, [0.6, -1.2, 1.3]);

    // Türbin
    const tb = H.group(H.cylX(0.72, 0.72, 0.55, H.mat(0x6d6258, { m: 0.8, r: 0.35 }), [1.3, 0, 0]));
    for (let i = 0; i < 24; i++) {
      const a = i / 24 * Math.PI * 2;
      const b = H.box(0.4, 0.05, 0.1, H.mat(0x8a7b6c), [1.3, Math.cos(a) * 0.74, Math.sin(a) * 0.74]);
      b.rotation.x = -a; tb.add(b);
    }
    add("turb", "Türbin", "Turbine",
      "Sıcak gazların enerjisini şaft gücüne çevirir. Bu güç kompresörleri ve dişli kutusunu döndürür. Aşırı EGT türbin ömrünü kısaltır; ECU bu yüzden EGT'yi sınırlar.",
      tb, [1.4, 0, 0]);

    // EGT termokuplları
    const egt = H.group();
    for (let i = 0; i < 3; i++) {
      const a = i / 3 * Math.PI * 2 + 0.4;
      const r = H.cylY(0.04, 0.04, 0.5, H.mat(C.gold, { m: 0.8 }), [1.75, Math.cos(a) * 0.75, Math.sin(a) * 0.75]);
      r.rotation.x = a; egt.add(r);
    }
    add("egt", "EGT termokuplları", "EGT thermocouples",
      "Egzoz gazı sıcaklığını ölçer ve ECU'ya gönderir. Kokpitte APU EGT olarak görünür. Bağlantı uçlarındaki gevşeklik hatalı okumaya yol açar.",
      egt, [1.4, 0, 1.3]);

    // Egzoz
    const ex = H.cylX(0.62, 0.5, 2.6, H.mat(C.hot, { m: 0.6, r: 0.5, double: true }), [3.1, 0, 0], 40, true);
    add("exh", "Egzoz kanalı", "Exhaust duct",
      "Gazları kuyruk konisinin ucundan dışarı atar. Çalışma sonrası uzun süre sıcak kalır. Çatlak ve yanık izi açısından kontrol edilir.",
      H.group(ex), [2.3, 0, 0]);

    // Askı bağlantıları
    const mount = H.group();
    const rod = H.mat(C.dark), iso = H.mat(C.rubber, { m: 0.1, r: 0.9 });
    [[-2.4, 0.8, 0.5, -2.4, 2.7, 0.6], [1.3, 0.7, 0.5, 1.9, 2.5, 1.3], [1.3, 0.7, -0.5, 1.9, 2.5, -1.3]].forEach(([a, b, c, d, e, f]) => {
      mount.add(H.tube([[a, b, c], [d, e, f]], 0.05, rod, 4));
      mount.add(H.cylY(0.14, 0.14, 0.18, iso, [d, e, f]));
    });
    add("mount", "Askılar ve titreşim izolatörleri", "Mounts / vibration isolators",
      "APU, bölme tavanındaki yapıya askı çubuklarıyla bağlanır. Kauçuk izolatörler titreşimin gövdeye geçmesini azaltır. İzolatörlerde çatlak, ezilme ve yağ bulaşması kontrol edilir.",
      mount, [0, 1.0, 0]);

    // Yangın dedektörü
    const fd = H.tube([[-4.2, 2.3, 1.2], [-1, 2.5, 1.6], [2, 2.0, 1.2], [3.5, 1.6, 0], [2, 2.0, -1.2], [-1, 2.5, -1.6], [-4.2, 2.3, -1.2]], 0.04, H.mat(C.red));
    add("fire", "Yangın dedektörü", "Fire detector",
      "Bölme tavanı boyunca uzanan algılama elemanı sıcaklık artışını algılar. Yangın uyarısı kokpitte ve yerde sağ ana teker yuvasındaki panelde (korna) verilir. Yerde APU yangınında APU otomatik kapanır. Söndürme için bölmede bir tüp bulunur.",
      H.group(fd), [0, 0.6, 0]);

    // ECU + kablo demeti
    const ecu = H.group(
      H.box(0.9, 0.6, 0.35, H.mat(0x2f3d55, { m: 0.4 }), [-6.2, 1.4, 0]),
      H.box(0.15, 0.25, 0.25, H.mat(C.black), [-5.7, 1.4, 0.05])
    );
    add("ecu", "ECU (elektronik kontrol ünitesi)", "Electronic control unit",
      "APU bölmesi dışında, gövde içinde ayrı bir yerde durur. Start sırasını, devri, EGT limitini ve otomatik kapanma korumalarını yönetir. Arıza kayıtlarını (BITE) saklar; arıza izolasyonunda ilk bakılacak yerdir.",
      ecu, [-1.2, 0, 0]);

    const har = H.group(
      H.tube([[-5.6, 1.4, 0.05], [-4.5, 1.55, 0.6], [-3.3, 1.1, 0.95], [-2.6, 0.55, 0.85]], 0.07, H.mat(C.wire, { m: 0.1, r: 0.8 })),
      H.cylZ(0.13, 0.13, 0.22, H.mat(C.dark, { m: 0.8 }), [-2.6, 0.5, 0.85]),
      H.torus(0.08, 0.025, H.mat(C.white), [-4.5, 1.55, 0.6], [0, Math.PI / 2, 0])
    );
    add("harness", "Kablo demeti ve yangın perdesi geçişi", "Wire harness / firewall feed-through",
      "ECU'yu APU üzerindeki sensör, valf ve ateşleme bağlantılarına bağlar. Yangın perdesinden sızdırmaz bir geçiş elemanıyla geçer. Uçta yuvarlak konnektör vardır. Kablolar ısıya dayanıklı tiptedir; kelepçe, sürtünme ve ısı hasarı açısından kontrol edilir.",
      har, [-0.6, 0, 0.9]);

    return P;
  }
};

/* =====================================================================
   2) Overhead panel arkası – modüller, konnektörler, kablo demetleri (temsili)
   ===================================================================== */
const OVH = {
  title: "Overhead panel arkası – temsili 3D",
  sub: "Modüller, arka konnektörler, kablo demetleri",
  chapter: "elec",
  camera: [5.8, 3.2, -6.8], target: [0, 0.2, -1.0], minDist: 2.5, maxDist: 30,
  shellLabel: "Yapıyı gizle",
  intro: "Kokpit tavanındaki (overhead) panelin arkadan görünüşü. Her panel modülünün arkasında bir konnektör vardır; buradan çıkan kablo dalları ana demete birleşir ve gövde yapısı boyunca devre kesici panellerine ve elektronik bölmeye (E/E) iner. <b>Parçalara ayır</b> ile modülleri öne çıkararak konnektörlerin nasıl ayrıldığını görebilirsin.",
  note: "Temsili model. Modül dizilimi ve kablo güzergâhı gerçek uçağı birebir yansıtmaz; gerçek güzergâh ve konnektör numaraları WDM'dedir.",
  build(T, H) {
    const P = [];
    const add = (o) => P.push(o);
    const names = ["FLT CONTROL", "FUEL", "ELEC", "APU / GEN", "HYD PUMPS", "BLEED / AIR", "PRESS", "ANTI-ICE", "DOORS", "ENG START", "LIGHTS", "WIPER"];
    const cols = 4, rows = 3, w = 1.5, h = 0.95, gap = 0.08;
    const x0 = -((cols - 1) * (w + gap)) / 2, y0 = ((rows - 1) * (h + gap)) / 2;
    const trunkY = 1.85, trunkZ = -1.7;
    const bundleM = H.mat(C.wire, { m: 0.05, r: 0.85 });

    // Yapı (kabuk)
    const sM = H.mat(0x9fb4c8, { op: 0.16, double: true, m: 0.1, r: 0.9 });
    const st = H.group(H.box(8.6, 0.06, 3.2, sM, [-0.3, 2.45, -1.4]));
    [-3.2, -0.4, 2.4].forEach(x => st.add(H.box(0.12, 0.35, 3.2, H.mat(0x8899aa, { op: 0.35 }), [x, 2.25, -1.4])));
    add({ id: "struct", name: "Tavan yapısı", desc: "Gövde tavan kirişleri ve kaplaması.", obj: st, shell: true, noPick: true });

    // Panel çerçevesi
    const fr = H.group();
    const frM = H.mat(C.dark, { m: 0.6 });
    for (let r = 0; r <= rows; r++) fr.add(H.box(cols * (w + gap) + 0.1, 0.05, 0.9, frM, [0, y0 + h / 2 + gap / 2 - r * (h + gap), -0.45]));
    for (let c = 0; c <= cols; c++) fr.add(H.box(0.05, rows * (h + gap), 0.9, frM, [x0 - w / 2 - gap / 2 + c * (w + gap), 0, -0.45]));
    add({ id: "frame", name: "Panel çerçevesi / montaj rayları", en: "Panel frame / rails",
      desc: "Modüllerin oturduğu çerçevedir. Modüller önden bu raylara hızlı bağlantı elemanlarıyla (Dzus) sabitlenir. Çerçeve aynı zamanda modüllerin topraklama yoludur.",
      obj: fr });

    let k = 0;
    for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++, k++) {
      const x = x0 + c * (w + gap), y = y0 - r * (h + gap), nm = names[k];
      // Modül: ön plaka + gövde + arka priz (receptacle)
      const mod = H.group(
        H.box(w, h, 0.06, H.mat(0x3a4048, { m: 0.3, r: 0.6 }), [x, y, 0]),
        H.box(w * 0.86, h * 0.8, 0.8, H.mat(0x2b3036, { m: 0.4 }), [x, y, -0.45]),
        H.box(0.62, 0.22, 0.12, H.mat(C.steel, { m: 0.8 }), [x, y, -0.91])
      );
      const lb = H.label(nm, w * 0.9, 0.22, { bg: "#3a4048", fg: "#ffffff" }); lb.position.set(x, y + h * 0.33, 0.032); mod.add(lb);
      for (let s = 0; s < 3; s++) {
        mod.add(H.cylZ(0.07, 0.07, 0.08, H.mat(C.black, { m: 0.2 }), [x - 0.45 + s * 0.45, y - 0.12, 0.07], 20));
        mod.add(H.box(0.04, 0.12, 0.04, H.mat(C.alu, { m: 0.8 }), [x - 0.45 + s * 0.45, y - 0.12, 0.13]));
      }
      add({ id: "mod" + k, name: "Panel modülü – " + nm, chipName: "Panel modülleri", chip: k === 0, en: "Panel module",
        desc: `<b>${nm}</b> modülü (temsili). Her modül anahtar, ışık ve göstergeleri içeren ayrı bir ünitedir (LRU gibi değiştirilir). Arkasında modülün tüm bağlantılarını taşıyan dikdörtgen bir priz (receptacle) bulunur. Modül önden çıkarılırken arka fiş ayrılır; bu yüzden çıkarmadan önce ilgili devre kesicileri açılmalı ve etiketlenmelidir.`,
        obj: mod, explode: [0, 0, 1.9] });

      // Dzus bağlantı elemanları (modülle birlikte hareket eder)
      const dz = H.group();
      [[-1, 1], [1, 1], [-1, -1], [1, -1]].forEach(([sx, sy]) => {
        dz.add(H.cylZ(0.045, 0.045, 0.03, H.mat(C.alu, { m: 0.9, r: 0.2 }), [x + sx * (w / 2 - 0.08), y + sy * (h / 2 - 0.08), 0.045], 16));
        dz.add(H.box(0.06, 0.012, 0.012, H.mat(C.black), [x + sx * (w / 2 - 0.08), y + sy * (h / 2 - 0.08), 0.062]));
      });
      add({ id: "dz" + k, name: "Dzus bağlantı elemanı", chip: k === 0, en: "Quarter-turn fastener",
        desc: "Çeyrek tur kilitlenen hızlı bağlantı elemanı. Modülü çerçeveye sabitler; tornavidayla çeyrek tur çevrilerek açılır. Aşırı zorlamak yayı veya yuvayı bozar.",
        obj: dz, explode: [0, 0, 1.9] });

      // Arka fiş + backshell + kablo dalı (demette kalır)
      const plug = H.group(
        H.box(0.64, 0.24, 0.2, H.mat(C.dark, { m: 0.7 }), [x, y, -1.07]),
        H.box(0.42, 0.18, 0.2, H.mat(C.steel, { m: 0.7 }), [x, y, -1.27])
      );
      add({ id: "plug" + k, name: "Arka konnektör (fiş) ve backshell", chip: k === 0, en: "Rack/panel connector",
        desc: "Kablo tarafındaki dikdörtgen fiş, modülün arkasındaki prize takılır. Fişin arkasındaki <b>backshell</b> kabloları gerilmeye karşı tutar ve sızdırmazlığı destekler. Pin'leri eğik, korozyonlu veya geri kaçmış (pushed-back) kontaklar arıza nedenidir; kontrol ve kontak değişimi için uygun söküm/takma aleti kullanılır.",
        obj: plug });
      const branch = H.tube([[x, y, -1.38], [x, y, -1.55], [x * 0.95, (y + trunkY) / 2 + 0.2, trunkZ + 0.05], [x * 0.9, trunkY - 0.1, trunkZ]], 0.045, bundleM, 40);
      add({ id: "br" + k, name: "Kablo dalı", chip: k === 0, en: "Branch / breakout",
        desc: "Modül fişinden çıkan kablolar demetlenerek ana demete birleşir. Dallar keskin bükülmemeli; minimum bükülme yarıçapı kablo çapına göre belirlenir. Kenarlara ve vida uçlarına sürtünme (chafing) en sık hasar nedenidir.",
        obj: H.group(branch) });
    }

    // Ana demet: modüllerin üstünden sola, sonra gövde yanından aşağı
    const trunkPts = [[3.6, trunkY, trunkZ], [0, trunkY, trunkZ], [-3.4, trunkY, trunkZ], [-4.1, trunkY - 0.5, trunkZ], [-4.3, 0, trunkZ - 0.2], [-4.3, -2.3, trunkZ - 0.3], [-4.0, -3.6, trunkZ - 0.3]];
    add({ id: "trunk", name: "Ana kablo demeti", en: "Main wire bundle",
      desc: "Modül dallarının birleştiği ana demet. Tavan boyunca ilerler, gövde yan yapısından aşağı inerek devre kesici panellerine ve kokpit altındaki elektronik bölmeye (E/E bay) ulaşır. Demetler, ayrı güzergâhlarla (separation) yedekli sistemlerin aynı hasarda birlikte kaybedilmemesi için ayrılır. Bu EWIS (Electrical Wiring Interconnection System) kurallarının parçasıdır.",
      obj: H.group(H.tube(trunkPts, 0.14, bundleM, 120)) });

    // Kablo kimlik işaretleri
    const ids = H.group();
    [[2.5, trunkY, trunkZ], [-1.5, trunkY, trunkZ], [-4.3, -1.2, trunkZ - 0.25]].forEach((p, i) => {
      ids.add(H.cylX(0.17, 0.17, 0.18, H.mat(C.white, { m: 0, r: 0.9 }), p, 20));
      if (i === 2) ids.children[ids.children.length - 1].rotation.set(0, 0, 0);
    });
    add({ id: "idsl", name: "Kablo/demet kimlik işareti", en: "Wire / bundle ID marking",
      desc: "Her kablonun ve demetin üzerinde kimlik numarası bulunur (doğrudan baskı veya işaret kılıfı). Bu numara WDM'deki kablo numarasıyla eşleşir ve arızalı kabloyu demet içinde bulmayı sağlar.",
      obj: ids });

    // P-kelepçeler
    const pc = H.group();
    [[1.6, trunkY, trunkZ], [-2.2, trunkY, trunkZ], [-4.3, -0.4, trunkZ - 0.2], [-4.3, -2.0, trunkZ - 0.3]].forEach((p, i) => {
      const vertical = i >= 2;
      const t = H.torus(0.17, 0.035, H.mat(C.blue, { m: 0.3 }), p, vertical ? [Math.PI / 2, 0, 0] : [0, Math.PI / 2, 0]);
      pc.add(t);
      pc.add(H.box(0.06, vertical ? 0.08 : 0.35, vertical ? 0.08 : 0.08, H.mat(C.alu), [p[0], p[1] + (vertical ? 0 : 0.3), p[2]]));
      if (!vertical) pc.add(H.box(0.06, 0.04, 0.3, H.mat(C.alu), [p[0], p[1] + 0.48, p[2] + 0.1]));
    });
    add({ id: "clamp", name: "P-kelepçe (yastıklı)", en: "Cushion clamp",
      desc: "Demeti yapıya sabitleyen, iç yüzü kauçuk yastıklı kelepçe. Demet kelepçede sıkışmamalı, gevşek de olmamalıdır. Kelepçe aralıkları demetin sarkmasını ve sürtünmesini önleyecek şekilde belirlenir. Yastığı yırtılmış kelepçe değiştirilir.",
      obj: pc });

    // Bağlama (lacing / tie)
    const lace = H.group();
    for (let i = 0; i < 6; i++) lace.add(H.torus(0.155, 0.015, H.mat(C.black), [3.0 - i * 1.1, trunkY, trunkZ], [0, Math.PI / 2, 0]));
    add({ id: "lace", name: "Demet bağı (lacing / kelepçe bağı)", en: "Lacing / tie wraps",
      desc: "Kabloları demet hâlinde tutar. Havacılıkta çoğunlukla mumlu bağlama ipi (lacing tape) veya onaylı plastik bağlar kullanılır. Bağlar aşırı sıkılmamalıdır; izolasyonu ezer.",
      obj: lace });

    // Ayrım konnektörleri (disconnect bracket)
    const db = H.group(H.box(0.08, 1.1, 0.9, H.mat(C.alu, { m: 0.7 }), [-4.75, -1.2, trunkZ - 0.25]));
    [-1.55, -1.2, -0.85].forEach(yy => {
      db.add(H.cylX(0.13, 0.13, 0.3, H.mat(C.green, { m: 0.6 }), [-4.6, yy, trunkZ - 0.25], 24));
      db.add(H.cylX(0.15, 0.15, 0.08, H.mat(C.dark, { m: 0.8 }), [-4.47, yy, trunkZ - 0.25], 24));
    });
    add({ id: "disc", name: "Ayrım konnektörleri (disconnect bracket)", en: "Production break / disconnect",
      desc: "Demetin bir braket üzerindeki yuvarlak konnektörlerle ikiye ayrıldığı nokta. Bölümlerin ayrı üretilip birleştirilmesini ve bakımda demetin parça parça değiştirilmesini sağlar. Arıza aramada ölçüm yapılan tipik noktalardır. Yuvarlak konnektörün iç yapısını <b>Konnektör anatomisi</b> modelinde görebilirsin.",
      obj: db });

    // Ek (splice)
    const spl = H.group(
      H.tube([[1.0, 0.6, -1.4], [1.3, 1.0, -1.55], [1.5, trunkY - 0.15, trunkZ + 0.05]], 0.025, bundleM, 20),
      H.cylY(0.05, 0.05, 0.22, H.mat(C.yellow, { m: 0.1, r: 0.7 }), [1.3, 1.05, -1.55])
    );
    add({ id: "splice", name: "Ek (splice)", en: "Splice",
      desc: "İki kablonun sıkıştırma (crimp) ile birleştirildiği nokta. Üzerine ısıyla daralan sızdırmaz kılıf geçirilir. Ek sayısı ve konumu onarım kurallarıyla sınırlıdır; ekler demette yan yana getirilmez, kademeli yerleştirilir.",
      obj: spl });

    // Topraklama
    const gnd = H.group(
      H.cylX(0.05, 0.05, 0.25, H.mat(C.steel, { m: 0.9 }), [3.42, -1.0, -0.6], 16),
      H.torus(0.07, 0.02, H.mat(C.gold, { m: 0.9 }), [3.52, -1.0, -0.6], [0, Math.PI / 2, 0]),
      H.torus(0.07, 0.02, H.mat(C.gold, { m: 0.9 }), [3.58, -1.0, -0.6], [0, Math.PI / 2, 0]),
      H.tube([[3.55, -1.0, -0.6], [3.7, -0.4, -1.2], [3.6, trunkY, trunkZ]], 0.025, H.mat(0x2e8b57), 20)
    );
    add({ id: "gnd", name: "Topraklama noktası", en: "Ground stud",
      desc: "Kablo uçlarındaki halka terminaller (ring terminal) yapıya bağlı bir saplamaya bağlanır. Temas yüzeyi temiz ve iletken olmalıdır; boya ve korozyon kaldırılır, sonra korozyona karşı koruma uygulanır. Gevşek topraklama, açıklanması zor aralıklı arızaların yaygın nedenidir.",
      obj: gnd });

    // CB paneli
    const cb = H.group(H.box(1.8, 1.2, 0.3, H.mat(C.panel, { m: 0.4 }), [-3.8, -4.3, trunkZ - 0.3]));
    for (let r = 0; r < 3; r++) for (let c = 0; c < 6; c++) cb.add(H.cylZ(0.06, 0.06, 0.12, H.mat(C.black, { m: 0.2 }), [-4.45 + c * 0.26, -3.95 - r * 0.33, trunkZ - 0.1], 14));
    const cbl = H.label("CIRCUIT BREAKERS", 1.6, 0.18, { bg: "#5b636d" }); cbl.position.set(-3.8, -3.78, trunkZ - 0.14); cb.add(cbl);
    add({ id: "cb", name: "Devre kesici paneli (temsili)", en: "Circuit breaker panel",
      desc: "Overhead modüllerinin beslemeleri devre kesicilerden (CB) gelir. 737'de CB'ler kokpitte pilot koltuklarının arkasındaki panellerde (P18 ve P6) toplanır. Bakımda çalışılan devrenin CB'si açılır ve üzerine <b>uyarı etiketi/klipsi</b> takılır.",
      obj: cb });

    return P;
  }
};

/* =====================================================================
   3) Yuvarlak konnektör anatomisi (MIL-DTL-38999 tipi, temsili)
   ===================================================================== */
const CONN = {
  title: "Konnektör anatomisi – temsili 3D",
  sub: "Yuvarlak konnektörün katmanları, pin ve soket",
  chapter: "elec",
  camera: [3.6, 1.8, 3.8], target: [0, 0, 0.5], minDist: 1.2, maxDist: 14,
  shellLabel: "Kabloları gizle",
  intro: "Uçakta en çok kullanılan tiplerden biri olan dairesel konnektörün iç yapısı. Solda panele veya brakete bağlanan priz (receptacle), sağda kablo tarafındaki fiş (plug). <b>Parçalara ayır</b> ile katmanları ayrı ayrı gör.",
  note: "Temsili model, ölçeksiz. Gerçek parça numarası, kontak boyutu ve alet seçimi için yetkili dokümana ve konnektör üreticisinin verisine bakın.",
  build(T, H) {
    const P = [];
    const add = (id, name, en, desc, obj, explode, extra = {}) => P.push({ id, name, en, desc, obj, explode, ...extra });
    const shellM = () => H.mat(0x6f7a5a, { m: 0.7, r: 0.4 }); // kadmiyum/olive drab görünümü

    // Priz (receptacle)
    const rc = H.group(
      H.box(0.95, 0.95, 0.06, shellM(), [0, 0, 0]),
      H.cylZ(0.34, 0.34, 0.5, shellM(), [0, 0, 0.22], 48, true),
      H.cylZ(0.3, 0.3, 0.3, shellM(), [0, 0, -0.18], 48),
      H.box(0.06, 0.06, 0.4, H.mat(C.dark), [0, 0.31, 0.25])
    );
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([a, b]) => rc.add(H.cylZ(0.04, 0.04, 0.08, H.mat(C.black), [a * 0.36, b * 0.36, 0], 12)));
    add("rc", "Priz gövdesi (receptacle)", "Receptacle shell",
      "Panele veya brakete flanşından vidalanır. İçindeki ana kama (master key, üstteki çıkıntı) fişin yalnız doğru yönde takılmasını sağlar. Farklı kama dizilimleri (clocking) yan yana duran konnektörlerin karıştırılmasını önler.",
      rc, [0, 0, -0.9]);

    // Pinli insert
    const pi = H.group(H.cylZ(0.29, 0.29, 0.12, H.mat(0x2b2b2b, { m: 0.1, r: 0.8 }), [0, 0, 0.32], 40));
    const pinPos = [[0, 0]]; for (let i = 0; i < 6; i++) pinPos.push([Math.cos(i * Math.PI / 3) * 0.16, Math.sin(i * Math.PI / 3) * 0.16]);
    pinPos.forEach(([a, b]) => pi.add(H.cylZ(0.018, 0.018, 0.2, H.mat(C.gold, { m: 1, r: 0.25 }), [a, b, 0.45], 10)));
    add("pins", "Pin'li insert", "Pin insert",
      "Erkek kontakların (pin) yerleştirildiği yalıtkan blok. Her kontak deliğinin bir harf veya numarası vardır; bu numaralar WDM'de belirtilir. Genel kural: <b>gerilim veren (kaynak) taraf soketli</b> olur, böylece açıkta kalan pin'lerde gerilim bulunmaz.",
      pi, [0, 0, -0.35]);

    // Arayüz contası
    add("seal", "Arayüz contası", "Interfacial seal",
      "İki insert arasına oturan elastomer conta. Konnektör birleştiğinde kontaklar arasına nem girmesini önler. Yırtık veya eksik conta korozyon ve kısa devreye yol açar.",
      H.group(H.cylZ(0.29, 0.29, 0.04, H.mat(0x3c6e9e, { m: 0, r: 0.9 }), [0, 0, 0.55], 40)), [0, 0, 0.05]);

    // Soketli insert
    const si = H.group(H.cylZ(0.29, 0.29, 0.14, H.mat(0x2b2b2b, { m: 0.1, r: 0.8 }), [0, 0, 0.7], 40));
    pinPos.forEach(([a, b]) => si.add(H.cylZ(0.03, 0.03, 0.15, H.mat(C.gold, { m: 1, r: 0.3 }), [a, b, 0.7], 12)));
    add("sockets", "Soketli insert", "Socket insert",
      "Dişi kontakların (soket) bulunduğu blok, fiş gövdesinin içindedir. Soketlerin gevşemesi (tutuş kuvvetinin azalması) aralıklı arızalara neden olur; şüpheli soket uygun ölçü pimiyle kontrol edilir.",
      si, [0, 0, 0.45]);

    // Fiş gövdesi
    const pl = H.group(H.cylZ(0.33, 0.33, 0.5, shellM(), [0, 0, 0.85], 48, true));
    add("plugshell", "Fiş gövdesi (plug)", "Plug shell",
      "Soketli insert'i taşır. İçindeki kama yuvası (keyway) priz üzerindeki kamaya denk gelir. Gövdede ezik veya çatlak varsa konnektör tam kilitlenmez.",
      pl, [0, 0, 0.8]);

    // Kilitleme halkası
    const cr = H.group(H.cylZ(0.41, 0.41, 0.34, H.mat(0x77815f, { m: 0.75, r: 0.35 }), [0, 0, 0.78], 48, true));
    for (let i = 0; i < 30; i++) { const a = i / 30 * Math.PI * 2; const r = H.box(0.025, 0.025, 0.3, H.mat(0x5b6449), [Math.cos(a) * 0.415, Math.sin(a) * 0.415, 0.78]); cr.add(r); }
    add("ring", "Kilitleme halkası", "Coupling ring",
      "Fişi prize çeker ve kilitler. 38999 tipinde üç yivli bayonet benzeri dişli vardır ve kilitlenince klik hissedilir. Elle sıkılır; gerekirse yumuşak çeneli konnektör pensesi kullanılır. Pense ile aşırı sıkmak halkayı bozar. Bazı yerlerde emniyet teli (safety wire) istenir.",
      cr, [0, 0, 1.15]);

    // Arka conta (grommet)
    const gr = H.group(H.cylZ(0.3, 0.3, 0.12, H.mat(0x3c6e9e, { m: 0, r: 0.9 }), [0, 0, 1.12], 40));
    pinPos.forEach(([a, b]) => gr.add(H.cylZ(0.022, 0.022, 0.13, H.mat(C.black), [a, b, 1.12], 10)));
    add("grommet", "Arka conta (grommet)", "Wire sealing grommet",
      "Kabloların konnektöre girdiği arka taraftaki elastomer conta. Her kablo kendi deliğinden geçer ve sızdırmazlık sağlar. Kullanılmayan delikler <b>sızdırmazlık tapası (sealing plug)</b> ile, kontak yuvaları gerekiyorsa boş kontakla doldurulur.",
      gr, [0, 0, 1.5]);

    // Backshell
    const bs = H.group(
      H.cylZ(0.34, 0.26, 0.42, H.mat(C.steel, { m: 0.85, r: 0.3 }), [0, 0, 1.4], 40, true),
      H.box(0.7, 0.07, 0.1, H.mat(C.steel, { m: 0.85 }), [0, 0.17, 1.66]),
      H.box(0.7, 0.07, 0.1, H.mat(C.steel, { m: 0.85 }), [0, -0.17, 1.66]),
      H.cylY(0.025, 0.025, 0.42, H.mat(C.dark), [0.3, 0, 1.66], 8),
      H.cylY(0.025, 0.025, 0.42, H.mat(C.dark), [-0.3, 0, 1.66], 8)
    );
    add("backshell", "Backshell ve gerilim giderici", "Backshell / strain relief",
      "Konnektörün arkasına vidalanır. Kelepçe (saddle) kabloları tutarak çekme kuvvetinin kontaklara gelmesini önler. EMI korumalı tiplerde kablo blendajı (shield) burada gövdeye bağlanır. Backshell'i sıkarken konnektörün dönmemesi için karşı tutulur.",
      bs, [0, 0, 1.95]);

    // Kablolar (kabuk – gizlenebilir)
    const wires = H.group();
    const cols = [0xe8e4d8, 0xd9d2c0, 0xf0ece0, 0xcfc8b5, 0xe1dccb, 0xd5cfbd, 0xebe6d6];
    pinPos.forEach(([a, b], i) => {
      wires.add(H.tube([[a, b, 1.1], [a * 0.8, b * 0.8, 1.7], [a * 0.5 + 0.1, b * 0.5, 2.4], [a * 0.4 + 0.5, b * 0.4 + 0.1, 3.2]], 0.02, H.mat(cols[i], { m: 0, r: 0.85 }), 30));
      wires.add(H.tube([[a, b, -0.3], [a * 0.9, b * 0.9, -0.9], [a * 0.6 - 0.2, b * 0.6, -1.6]], 0.02, H.mat(cols[i], { m: 0, r: 0.85 }), 20));
    });
    add("wires", "Kablolar", "Wires", "Konnektöre bağlı kablolar.", wires, [0, 0, 2.0], { shell: true, noPick: true });

    // Kontak detayı (büyütülmüş)
    const ct = H.group();
    const gold = H.mat(C.gold, { m: 1, r: 0.25 }), ins = H.mat(0xe8e4d8, { m: 0, r: 0.8 }), cu = H.mat(0xc77b4a, { m: 0.9, r: 0.3 });
    // pin
    ct.add(H.cylX(0.03, 0.03, 0.5, gold, [1.55, 0.55, 0.6], 16));
    ct.add(H.cylX(0.07, 0.07, 0.12, gold, [1.86, 0.55, 0.6], 16));
    ct.add(H.cylX(0.065, 0.065, 0.3, gold, [2.05, 0.55, 0.6], 16));
    ct.add(H.cylX(0.045, 0.045, 0.2, cu, [2.25, 0.55, 0.6], 12));
    ct.add(H.cylX(0.06, 0.06, 0.7, ins, [2.65, 0.55, 0.6], 16));
    // soket
    ct.add(H.cylX(0.07, 0.07, 0.55, gold, [1.6, -0.35, 0.6], 16, false));
    ct.add(H.cylX(0.075, 0.075, 0.12, gold, [1.94, -0.35, 0.6], 16));
    ct.add(H.cylX(0.065, 0.065, 0.3, gold, [2.12, -0.35, 0.6], 16));
    ct.add(H.cylX(0.045, 0.045, 0.2, cu, [2.32, -0.35, 0.6], 12));
    ct.add(H.cylX(0.06, 0.06, 0.7, ins, [2.72, -0.35, 0.6], 16));
    const l1 = H.label("PIN", 0.4, 0.14, { bg: "#1f2933" }); l1.position.set(1.55, 0.8, 0.6); ct.add(l1);
    const l2 = H.label("SOKET", 0.5, 0.14, { bg: "#1f2933" }); l2.position.set(1.6, -0.1, 0.6); ct.add(l2);
    add("contacts", "Kontaklar: pin ve soket (büyütülmüş)", "Crimp contacts",
      "Kontaklar kabloya <b>crimp</b> (sıkıştırma) ile bağlanır, lehim kullanılmaz. Doğru crimp aleti ve kontak boyutuna uygun pozisyoner şarttır. Crimp sonrası kablonun gözetleme deliğinden görünmesi, izolasyonun crimp bölgesine girmemesi kontrol edilir. Kontak, insert'e <b>takma/sökme aleti</b> ile arkadan yerleştirilir; kilitlendiği hafifçe çekilerek doğrulanır.",
      ct, [0.6, 0, 0]);

    return P;
  }
};

export const MODELS = { apu: APU, overhead: OVH, connector: CONN };
