// 737NG P5 ön (forward) overhead panel – modül ve kontrol düzeni.
// Birim: inç. Modül genişliği 5.75", yükseklikler 3/8" (0.375") katları (Dzus ray standardı).
// Düzen açık kaynaklardan derlenmiştir; gerçek uçak fotoğrafı / AMM şekliyle doğrulanacaktır.
// Konnektör referansları (D-numaraları, pin sayıları) kullanıcının WDM'inden doldurulacaktır.

export const U = 0.375;      // Dzus adımı
export const MW = 5.75;      // standart modül genişliği

// ---- kısa yardımcılar ----
const T = (id, lab, pos, st, o = {}) => ({ t: "T", id, lab, pos, st, ...o });          // toggle
const R = (id, lab, pos, st, o = {}) => ({ t: "R", id, lab, pos, st, ...o });          // döner seçici
const L = (id, txt, c = "a", o = {}) => ({ t: "L", id, txt, c, ...o });                // ikaz lambası (a=amber, b=mavi, g=yeşil)
const B = (id, txt, o = {}) => ({ t: "B", id, txt, ...o });                            // basmalı (ışıklı) düğme
const G = (id, lab, kind, o = {}) => ({ t: "G", id, lab, kind, ...o });                // gösterge
const D = (id, lab, kind, o = {}) => ({ t: "D", id, lab, kind, ...o });                // dijital pencere
const X = (txt, o = {}) => ({ t: "X", txt, ...o });                                    // yazı
const S = (...items) => ({ t: "S", items });                                           // dikey yığın
const _ = (wf = 1) => ({ t: "_", wf });

const LP = id => L(id, "LOW\nPRESSURE");

/* =========================== MODÜLLER =========================== */
export const MODULES = [
/* ---------------- 1. sütun ---------------- */
{
  id: "fltctl", col: 0, hu: 20, name: "Uçuş Kumanda Paneli", en: "Flight Control Panel", ata: "27",
  desc: "Birincil uçuş kumandalarının hidrolik kaynaklarını, alternatif flap sistemini, spoylerleri ve yaw damper'ı kontrol eder. Uçuş kumandalarıyla ilgili arıza ışıkları da buradadır.",
  rows: [
    { title: "FLIGHT CONTROL", h: 3.2, items: [
      S(T("fltA", "A", ["STBY RUD", "OFF", "ON"], 2, { guard: "red", gst: 2, lights: [{ id: "lpA", on: [0, 1] }],
        d: "A hidrolik sisteminin aileron, elevator ve rudder'a giden basıncını kontrol eder. STBY RUD: A kapatılır, standby hidrolik pompası çalışır ve standby rudder PCU'yu besler. Normalde ON konumunda kapakla korunur." }), LP("lpA")),
      S(T("fltB", "B", ["STBY RUD", "OFF", "ON"], 2, { guard: "red", gst: 2, lights: [{ id: "lpB", on: [0, 1] }],
        d: "B hidrolik sistemi için aynı işlev. STBY RUD konumunda standby sistem devreye girer." }), LP("lpB")),
      S(X("STANDBY HYD"), L("sbLQ", "LOW\nQUANTITY"), L("sbLP", "LOW\nPRESSURE"), L("sbRud", "STBY RUD\nON")),
      S(X("ALTERNATE FLAPS"), T("altArm", "", ["ARM", "OFF"], 1, { guard: "red", gst: 1,
        d: "Alternatif flap ana anahtarı. ARM: normal (hidrolik) flap kumandası devreden çıkar, standby pompası çalışır, flaplar elektrik motoruyla sürülebilir." })),
      S(X(" "), T("altPos", "", ["UP", "OFF", "DOWN"], 1, { spring: [0],
        d: "ARM konumundayken TE flapları elektrikle hareket ettirir. DOWN konumu LE cihazları da standby hidrolikle tam açar. UP konumu yay geri dönüşlüdür." }))
    ] },
    { title: "", h: 2.6, items: [
      S(X("SPOILER"), T("splA", "A", ["ON", "OFF"], 0, { guard: "red", gst: 0, d: "A sistemi flight spoyler aktüatörlerine hidrolik basınç verir veya keser." })),
      S(X(" "), T("splB", "B", ["ON", "OFF"], 0, { guard: "red", gst: 0, d: "B sistemi flight spoyler aktüatörlerine hidrolik basınç verir veya keser." })),
      S(L("ydLt", "YAW\nDAMPER"), T("yd", "YAW DAMPER", ["ON", "OFF"], 0, { lights: [{ id: "ydLt", on: [1] }],
        d: "Yaw damper'ı açar. Kapalıyken veya devreden çıktığında YAW DAMPER ışığı yanar." })),
      S(L("feel", "FEEL\nDIFF PRESS"), L("spdTrim", "SPEED TRIM\nFAIL")),
      S(L("machTrim", "MACH TRIM\nFAIL"), L("autoSlat", "AUTO SLAT\nFAIL"))
    ] }
  ]
},
{
  id: "navdsp", col: 0, hu: 9, name: "Navigasyon / Ekran Kaynak Paneli", en: "Navigation / Displays Panel", ata: "34",
  desc: "Bir sistem arızalandığında VHF NAV, IRS, FMC verilerini ve ekran (DEU) kaynaklarını tek tarafa aktarmak için kullanılan transfer seçicileri.",
  rows: [
    { title: "NAVIGATION", h: 1.55, items: [
      R("vhfNav", "VHF NAV", ["BOTH ON 1", "NORMAL", "BOTH ON 2"], 1, { d: "Her iki pilotun navigasyon göstergesini VHF NAV 1 veya 2 alıcısından besler." }),
      R("irsSel", "IRS", ["BOTH ON L", "NORMAL", "BOTH ON R"], 1, { d: "Her iki tarafın ekranlarını sol veya sağ IRS'ten besler." }),
      R("fmcSel", "FMC", ["BOTH ON L", "NORMAL", "BOTH ON R"], 1, { d: "Her iki CDU'yu ve ekranları sol veya sağ FMC'den besler." })
    ] },
    { title: "DISPLAYS", h: 1.55, items: [
      R("dspSrc", "SOURCE", ["ALL ON 1", "AUTO", "ALL ON 2"], 1, { d: "Ekran elektronik ünitesi (DEU) kaynağını seçer. AUTO normal konumdur." }),
      _(0.4),
      R("ctlPnl", "CONTROL PANEL", ["BOTH ON 1", "NORMAL", "BOTH ON 2"], 1, { d: "EFIS kontrol panellerinden birini her iki taraf için kullanır." })
    ] }
  ]
},
{
  id: "fuel", col: 0, hu: 26, name: "Yakıt Paneli", en: "Fuel Panel", ata: "28",
  desc: "Yakıt pompalarını ve crossfeed valfini kontrol eder; motor ve spar valf durumu, filtre bypass ve yakıt sıcaklığı burada izlenir. Alt bölüm şematik düzendedir: pompaların yerleşimi tankların yerleşimine karşılık gelir.",
  rows: [
    { title: "", h: 2.4, items: [
      G("fuelTemp", "FUEL TEMP", "fueltemp", { size: 1.55, d: "Ana tank 1'deki yakıt sıcaklığını gösterir (°C)." }),
      S(L("ev1", "ENG VALVE\nCLOSED", "b"), L("sv1", "SPAR VALVE\nCLOSED", "b"), L("fb1", "FILTER\nBYPASS")),
      S(L("ev2", "ENG VALVE\nCLOSED", "b"), L("sv2", "SPAR VALVE\nCLOSED", "b"), L("fb2", "FILTER\nBYPASS"))
    ] },
    { title: "", h: 1.6, items: [
      _(0.5), S(L("xfOpen", "VALVE\nOPEN", "b"), X("CROSSFEED")),
      R("xfeed", "", ["CLOSED", "OPEN"], 0, { bar: true, d: "Crossfeed valfini açar; iki motor besleme manifoldunu birleştirir. Valf hareket halindeyken VALVE OPEN ışığı parlak, açıkken sönük yanar.", lights: [{ id: "xfOpen", on: [1] }] }), _(0.5)
    ] },
    { title: "CENTER", h: 1.9, items: [
      _(0.6),
      S(LP("lpCL"), T("pCL", "L", ["ON", "OFF"], 1, { lights: [{ id: "lpCL", on: [1] }], d: "Merkez tank sol pompası. Merkez tank pompaları ana tank pompalarından yüksek basınçlıdır; bu yüzden önce merkez tank yakıtı kullanılır." })),
      S(LP("lpCR"), T("pCR", "R", ["ON", "OFF"], 1, { lights: [{ id: "lpCR", on: [1] }], d: "Merkez tank sağ pompası." })),
      _(0.6)
    ] },
    { title: "", h: 2.3, items: [
      S(LP("lpA1"), T("pA1", "AFT", ["ON", "OFF"], 1, { lights: [{ id: "lpA1", on: [1] }], d: "Ana tank 1 arka pompası." }), X("1")),
      S(LP("lpF1"), T("pF1", "FWD", ["ON", "OFF"], 1, { lights: [{ id: "lpF1", on: [1] }], d: "Ana tank 1 ön pompası." })),
      _(0.7),
      S(LP("lpF2"), T("pF2", "FWD", ["ON", "OFF"], 1, { lights: [{ id: "lpF2", on: [1] }], d: "Ana tank 2 ön pompası." })),
      S(LP("lpA2"), T("pA2", "AFT", ["ON", "OFF"], 1, { lights: [{ id: "lpA2", on: [1] }], d: "Ana tank 2 arka pompası." }), X("2"))
    ] }
  ]
},
/* ---------------- 2. sütun ---------------- */
{
  id: "elecMeter", col: 1, hu: 18, name: "AC/DC Ölçüm ve Batarya Paneli", en: "AC and DC Metering Panel", ata: "24",
  desc: "Seçilen DC ve AC kaynakların voltaj, akım ve frekans değerlerini gösterir. Batarya ana anahtarı, kabin/galley ve yolcu koltuğu güç anahtarları ile elektrik arıza ışıkları bu paneldedir.",
  rows: [
    { title: "", h: 1.9, items: [D("elecLcd", "", "elec", { w: 4.6, h: 1.15, d: "LCD gösterge: solda DC (AMPS, VOLTS), sağda AC (AMPS, VOLTS, CPS FREQ). Değerler alttaki DC ve AC seçicilerine göre değişir." })] },
    { title: "", h: 1.7, items: [
      R("dcSel", "DC", ["STBY PWR", "BAT BUS", "BAT", "AUX BAT", "TR1", "TR2", "TR3", "TEST"], 2, { spread: 28, d: "DC ölçüm kaynağını seçer." }),
      S(L("batDis", "BAT\nDISCHARGE"), L("trUnit", "TR UNIT"), L("elecLt", "ELEC")),
      R("acSel", "AC", ["STBY PWR", "GRD PWR", "GEN 1", "APU GEN", "GEN 2", "INV", "TEST"], 1, { spread: 30, d: "AC ölçüm kaynağını seçer." })
    ] },
    { title: "", h: 1.6, items: [
      B("maint", "MAINT", { d: "Bakım test düğmesi. Elektrik sistemi BITE/arıza kayıtlarına erişim için kullanılır." }),
      T("bat", "BAT", ["ON", "OFF"], 0, { guard: "red", gst: 0, d: "Batarya ana anahtarı. Kapakla ON konumunda korunur. OFF'a alınırsa (yerde) uçağın güç beslemesi kesilir; hot battery bus beslenmeye devam eder." }),
      T("cabUtil", "CAB/UTIL", ["ON", "OFF"], 0, { d: "Galley ve kabin servis (utility) yüklerinin gücünü açar/kapatır." }),
      T("ifePass", "IFE/PASS\nSEAT", ["ON", "OFF"], 0, { d: "Uçuş içi eğlence ve yolcu koltuğu elektrik beslemesi." })
    ] }
  ]
},
{
  id: "genDrive", col: 1, hu: 8, name: "Jeneratör Tahrik ve Yedek Güç Paneli", en: "Generator Drive and Standby Power Panel", ata: "24",
  desc: "IDG ayırma (disconnect) anahtarları, IDG arıza ışıkları ve standby güç anahtarı.",
  rows: [
    { title: "", h: 2.6, items: [
      S(L("drive1", "DRIVE"), T("disc1", "DISCONNECT 1", ["", "NORMAL"], 1, { guard: "red", gst: 1, spring: [0],
        d: "IDG 1'i motordan mekanik olarak ayırır. Geri dönüşü yoktur; reset yerde, motor kapalıyken yapılır. DRIVE ışığı düşük yağ basıncı veya yüksek yağ sıcaklığında yanar." })),
      S(L("stbyOff", "STANDBY\nPWR OFF"), T("stbyPwr", "STANDBY POWER", ["BAT", "OFF", "AUTO"], 2, { guard: "red", gst: 2, lights: [{ id: "stbyOff", on: [1] }],
        d: "AUTO: normal. Uçuşta tüm AC kaybında standby baralar bataryadan otomatik beslenir. BAT: standby baralar bataryadan beslenir. OFF: standby baralar beslenmez, ışık yanar." })),
      S(L("drive2", "DRIVE"), T("disc2", "DISCONNECT 2", ["", "NORMAL"], 1, { guard: "red", gst: 1, spring: [0], d: "IDG 2 ayırma anahtarı." }))
    ] }
  ]
},
{
  id: "busSw", col: 1, hu: 20, name: "Yer Gücü ve Bara Anahtarlama Paneli", en: "Ground Power and Bus Switching Panel", ata: "24",
  desc: "Yer gücü, jeneratör ve APU jeneratörünün AC transfer baralarına bağlanmasını kontrol eder. 737'de kaynaklar paralel çalışmaz: bir baraya bağlanan yeni kaynak, eskisini otomatik ayırır.",
  rows: [
    { title: "", h: 1.8, items: [
      _(0.7), S(L("grdAvail", "GRD POWER\nAVAILABLE", "b"), T("grdPwr", "GROUND POWER", ["ON", "", "OFF"], 1, { spring: [0, 2],
        d: "Yer gücü takılı ve kalitesi uygunsa GRD POWER AVAILABLE yanar. ON: yer gücünü her iki transfer baraya bağlar. OFF: ayırır. Yay geri dönüşlüdür." })), _(0.7)
    ] },
    { title: "", h: 2.0, items: [
      S(L("tbo1", "TRANSFER\nBUS OFF"), L("so1", "SOURCE\nOFF")),
      T("busXfr", "BUS TRANSFER", ["AUTO", "OFF"], 0, { guard: "red", gst: 0,
        d: "AUTO: bir kaynak kaybolursa BTB'ler transfer barayı diğer kaynağa otomatik aktarır. OFF: otomatik transfer engellenir (arıza izolasyonu)." }),
      S(L("tbo2", "TRANSFER\nBUS OFF"), L("so2", "SOURCE\nOFF"))
    ] },
    { title: "", h: 0.9, items: [L("gob1", "GEN OFF\nBUS", "b"), L("apuGob", "APU GEN\nOFF BUS", "b", { wf: 2 }), L("gob2", "GEN OFF\nBUS", "b")] },
    { title: "", h: 1.6, items: [
      T("gen1", "GEN 1", ["ON", "", "OFF"], 1, { spring: [0, 2], d: "Jeneratör 1'i transfer bara 1'e bağlar (ON) veya ayırır (OFF). Merkez konumuna yayla döner." }),
      T("apuGen1", "APU GEN", ["ON", "", "OFF"], 1, { spring: [0, 2], d: "APU jeneratörünü transfer bara 1'e bağlar." }),
      T("apuGen2", "", ["ON", "", "OFF"], 1, { spring: [0, 2], d: "APU jeneratörünü transfer bara 2'ye bağlar." }),
      T("gen2", "GEN 2", ["ON", "", "OFF"], 1, { spring: [0, 2], d: "Jeneratör 2'yi transfer bara 2'ye bağlar veya ayırır." })
    ] }
  ]
},
{
  id: "apu", col: 1, hu: 9, name: "APU Gösterge Paneli", en: "APU Panel", ata: "49",
  desc: "APU egzoz gazı sıcaklığı (EGT) göstergesi ve APU arıza ışıkları. APU start anahtarı alt sıradaki ışık panelindedir.",
  rows: [{ title: "", h: 2.8, items: [
    G("apuEgt", "APU EGT", "egt", { size: 1.45, d: "APU egzoz gazı sıcaklığı (°C x100)." }),
    S(L("apuMaint", "MAINT", "b"), L("apuLop", "LOW OIL\nPRESSURE")),
    S(L("apuFault", "FAULT"), L("apuOvs", "OVER\nSPEED"))
  ] }]
},
/* ---------------- 3. sütun ---------------- */
{
  id: "misc", col: 2, hu: 15, name: "Merkez Kontrol Paneli", en: "Central Control Panel", ata: "33/21/44",
  desc: "Panel aydınlatma ayarı, ekipman (E&E) soğutma, acil çıkış ışıkları, yolcu ikaz işaretleri ve ikaz/çağrı düğmeleri.",
  rows: [
    { title: "", h: 1.2, items: [
      R("cbLt", "CIRCUIT\nBREAKERS", ["OFF", "", "", "", "BRT"], 2, { spread: 30, dim: true, d: "Devre kesici panellerinin (P6, P18) aydınlatma şiddeti." }),
      R("pnlLt", "PANEL", ["OFF", "", "", "", "BRT"], 2, { spread: 30, dim: true, d: "Overhead panel arka aydınlatma (5V AC panel ışıkları) şiddeti." })
    ] },
    { title: "", h: 1.85, items: [
      S(X("EQUIP COOLING")),
      S(L("eqSup", "OFF"), T("eqSupply", "SUPPLY", ["NORMAL", "ALTN"], 0, { d: "E/E bölümü besleme fanı seçimi. OFF ışığı hava akışı yetersizse yanar." })),
      S(L("eqExh", "OFF"), T("eqExhaust", "EXHAUST", ["NORMAL", "ALTN"], 0, { d: "E/E bölümü egzoz fanı seçimi." })),
      S(L("emerNA", "NOT\nARMED"), T("emerExit", "EMER EXIT LIGHTS", ["ON", "ARMED", "OFF"], 1, { guard: "yellow", gst: 1, lights: [{ id: "emerNA", on: [0, 2] }],
        d: "ARMED: uçak DC gücü kesilirse acil çıkış ışıkları otomatik yanar. Kapakla ARMED konumunda korunur. ON veya OFF'ta NOT ARMED yanar." }))
    ] },
    { title: "", h: 1.6, items: [
      T("noSmk", "NO SMOKING", ["ON", "AUTO", "OFF"], 1, { d: "Sigara içilmez işaretleri. AUTO: iniş takımı veya flap konumuna göre otomatik yanar." }),
      T("belts", "FASTEN BELTS", ["ON", "AUTO", "OFF"], 1, { d: "Kemer bağlayın işaretleri." }),
      B("attend", "ATTEND", { d: "Kabin ekibini çağırır (kabinde çağrı tonu ve ışığı)." }),
      B("grdCall", "GRD CALL", { d: "Yer ekibini çağırır (burun teker yuvası kornası)." })
    ] }
  ]
},
{
  id: "winProbe", col: 2, hu: 18, name: "Cam ve Prob Isıtma Paneli", en: "Window and Probe Heat Panel", ata: "30",
  desc: "Kokpit camlarının elektrikli ısıtması ile pitot tüpleri, AOA vane'leri ve TAT probunun ısıtmasını kontrol eder. Isıtılmayan prob için ışık yanar.",
  rows: [
    { title: "WINDOW HEAT", h: 2.5, items: [
      S(L("wOv1", "OVER\nHEAT"), L("wOn1", "ON", "g"), T("wLS", "L SIDE", ["ON", "OFF"], 0, { lights: [{ id: "wOn1", on: [0] }], d: "Sol yan camın ısıtması." })),
      S(L("wOv2", "OVER\nHEAT"), L("wOn2", "ON", "g"), T("wLF", "L FWD", ["ON", "OFF"], 0, { lights: [{ id: "wOn2", on: [0] }], d: "Sol ön cam ısıtması. Ön camlar ayrıca kuş çarpmasına dayanıklılık için ısıtılır." })),
      S(X(" "), T("wTest", "TEST", ["OVHT", "", "PWR TEST"], 1, { spring: [0, 2], d: "OVHT: aşırı ısınma devresini test eder. PWR TEST: ısıtma kontrolcülerini test eder." })),
      S(L("wOv3", "OVER\nHEAT"), L("wOn3", "ON", "g"), T("wRF", "R FWD", ["ON", "OFF"], 0, { lights: [{ id: "wOn3", on: [0] }], d: "Sağ ön cam ısıtması." })),
      S(L("wOv4", "OVER\nHEAT"), L("wOn4", "ON", "g"), T("wRS", "R SIDE", ["ON", "OFF"], 0, { lights: [{ id: "wOn4", on: [0] }], d: "Sağ yan camın ısıtması." }))
    ] },
    { title: "PROBE HEAT", h: 2.9, items: [
      T("prbA", "A", ["ON", "OFF"], 1, { lights: [{ id: "pCapt", on: [1] }, { id: "pLel", on: [1] }, { id: "pLav", on: [1] }, { id: "pTemp", on: [1] }],
        d: "Kaptan tarafı problarının ısıtması: kaptan pitot, sol elevator pitot, sol alpha vane, TAT probu." }),
      S(L("pCapt", "CAPT\nPITOT"), L("pLel", "L ELEV\nPITOT"), L("pLav", "L ALPHA\nVANE"), L("pTemp", "TEMP\nPROBE")),
      S(L("pFo", "F/O\nPITOT"), L("pRel", "R ELEV\nPITOT"), L("pRav", "R ALPHA\nVANE"), L("pAux", "AUX\nPITOT")),
      T("prbB", "B", ["ON", "OFF"], 1, { lights: [{ id: "pFo", on: [1] }, { id: "pRel", on: [1] }, { id: "pRav", on: [1] }, { id: "pAux", on: [1] }],
        d: "F/O tarafı problarının ısıtması: F/O pitot, sağ elevator pitot, sağ alpha vane, yardımcı pitot." })
    ] }
  ]
},
{
  id: "antiIce", col: 2, hu: 11, name: "Buz Önleme Paneli", en: "Anti-Ice Panel", ata: "30",
  desc: "Kanat ve motor giriş kaportası buz önleme sistemleri. Bleed havası kullanır.",
  rows: [{ title: "", h: 3.4, items: [
    S(X("WING ANTI-ICE"), L("waL", "L VALVE\nOPEN", "b"), L("waR", "R VALVE\nOPEN", "b"), T("wingAI", "", ["ON", "OFF"], 1, { lights: [{ id: "waL", on: [0] }, { id: "waR", on: [0] }],
      d: "Kanat buz önleme valflerini açar; bleed havası hücum kenarı slatlarına gider. Yerde kullanımında koruma mantığı vardır." })),
    S(L("cai1", "COWL\nANTI-ICE"), L("cvo1", "COWL VALVE\nOPEN", "b"), T("engAI1", "ENG 1", ["ON", "OFF"], 1, { lights: [{ id: "cvo1", on: [0] }],
      d: "Motor 1 giriş dudağı buz önleme valfi. COWL ANTI-ICE ışığı kanalda aşırı basınç olduğunu gösterir." })),
    S(L("cai2", "COWL\nANTI-ICE"), L("cvo2", "COWL VALVE\nOPEN", "b"), T("engAI2", "ENG 2", ["ON", "OFF"], 1, { lights: [{ id: "cvo2", on: [0] }],
      d: "Motor 2 giriş dudağı buz önleme valfi." }))
  ] }]
},
{
  id: "hyd", col: 2, hu: 11, name: "Hidrolik Pompa Paneli", en: "Hydraulic Panel", ata: "29",
  desc: "A ve B sistemlerinin motor tahrikli (ENG) ve elektrik motorlu (ELEC) pompalarının anahtarları. Soldaki iki anahtar A, sağdaki iki anahtar B sistemidir.",
  rows: [{ title: "HYD PUMPS", h: 3.3, items: [
    S(X(" "), LP("hlpE1"), T("hydE1", "ENG 1", ["ON", "OFF"], 0, { lights: [{ id: "hlpE1", on: [1] }], d: "A sistemi motor tahrikli pompa (EDP). Pompa kompansatörünü kapatır; pompa motor dönerken dönmeye devam eder ama basınç vermez." }), X("A")),
    S(L("hovE2", "OVERHEAT"), LP("hlpEl2"), T("hydEl2", "ELEC 2", ["ON", "OFF"], 1, { lights: [{ id: "hlpEl2", on: [1] }], d: "A sistemi elektrikli pompa (EMDP)." })),
    S(L("hovE1", "OVERHEAT"), LP("hlpEl1"), T("hydEl1", "ELEC 1", ["ON", "OFF"], 1, { lights: [{ id: "hlpEl1", on: [1] }], d: "B sistemi elektrikli pompa (EMDP)." })),
    S(X(" "), LP("hlpE2"), T("hydE2", "ENG 2", ["ON", "OFF"], 0, { lights: [{ id: "hlpE2", on: [1] }], d: "B sistemi motor tahrikli pompa (EDP)." }), X("B"))
  ] }]
},
/* ---------------- 4. sütun ---------------- */
{
  id: "airCond", col: 3, hu: 15, name: "Klima Sıcaklık Paneli", en: "Air Conditioning Panel", ata: "21",
  desc: "Kokpit ve kabin bölgelerinin sıcaklık seçicileri, trim hava anahtarı ve seçilen noktanın sıcaklığını gösteren gösterge.",
  rows: [
    { title: "", h: 2.0, items: [
      G("airTemp", "AIR TEMP", "airtemp", { size: 1.35, d: "Seçilen besleme kanalı veya kabin bölgesinin sıcaklığı (°C)." }),
      R("airSrc", "", ["CONT CAB", "FWD DUCT", "FWD CAB", "AFT DUCT", "AFT CAB"], 0, { spread: 32, d: "AIR TEMP göstergesinin ölçüm noktasını seçer." }),
      T("trimAir", "TRIM AIR", ["ON", "OFF"], 0, { d: "Trim hava basınç düzenleme ve kesme valfini açar; bölgelerin ayrı sıcaklık ayarına izin verir." })
    ] },
    { title: "", h: 2.6, items: [
      S(L("zt1", "ZONE\nTEMP"), R("tCont", "CONT CAB", ["C", "", "", "", "W"], 2, { spread: 34, d: "Kokpit sıcaklık seçici (AUTO aralığı: C serin – W sıcak)." })),
      S(L("zt2", "ZONE\nTEMP"), R("tFwd", "FWD CAB", ["C", "", "", "", "W"], 2, { spread: 34, d: "Ön kabin sıcaklık seçici." })),
      S(L("zt3", "ZONE\nTEMP"), R("tAft", "AFT CAB", ["C", "", "", "", "W"], 2, { spread: 34, d: "Arka kabin sıcaklık seçici." }))
    ] }
  ]
},
{
  id: "bleed", col: 3, hu: 22, name: "Bleed Hava Paneli", en: "Bleed Air Controls Panel", ata: "36",
  desc: "Motor ve APU bleed valfleri, izolasyon valfi, klima paketleri ve resirkülasyon fanları. Kanal basınç göstergesi ve aşırı ısınma/trip ışıkları da buradadır.",
  rows: [
    { title: "", h: 2.1, items: [
      S(L("ram1", "RAM DOOR\nFULL OPEN", "b")),
      G("duct", "DUCT PRESS", "duct", { size: 1.5, d: "Sol ve sağ pnömatik kanal basıncı (PSI). İki ibre: L ve R." }),
      S(L("ram2", "RAM DOOR\nFULL OPEN", "b"))
    ] },
    { title: "", h: 1.6, items: [
      T("recL", "L RECIRC FAN", ["AUTO", "OFF"], 0, { d: "Sol resirkülasyon fanı." }),
      S(L("dualBleed", "DUAL\nBLEED"), B("ovhtTest", "OVHT\nTEST", { d: "Kanat-gövde aşırı ısınma algılama devrelerini test eder." })),
      T("recR", "R RECIRC FAN", ["AUTO", "OFF"], 0, { d: "Sağ resirkülasyon fanı." })
    ] },
    { title: "", h: 2.0, items: [
      S(L("packLt1", "PACK"), T("packL", "L PACK", ["HIGH", "AUTO", "OFF"], 1, { d: "Sol klima paketi. AUTO normal, HIGH yüksek akış." })),
      R("isoVlv", "ISOLATION VALVE", ["CLOSE", "AUTO", "OPEN"], 1, { bar: true, d: "Sol ve sağ pnömatik manifoldu ayırır veya birleştirir. AUTO: bir bleed veya paket kapalıysa otomatik açılır." }),
      S(L("packLt2", "PACK"), T("packR", "R PACK", ["HIGH", "AUTO", "OFF"], 1, { d: "Sağ klima paketi." }))
    ] },
    { title: "", h: 1.5, items: [
      S(L("wbo1", "WING-BODY\nOVERHEAT"), L("bto1", "BLEED TRIP\nOFF")),
      B("tripReset", "TRIP\nRESET", { d: "BLEED TRIP OFF, PACK ve ZONE TEMP ışıklarını sıfırlar (arıza durumu düzeldiyse)." }),
      S(L("wbo2", "WING-BODY\nOVERHEAT"), L("bto2", "BLEED TRIP\nOFF"))
    ] },
    { title: "", h: 1.5, items: [
      T("bl1", "1", ["ON", "OFF"], 0, { d: "Motor 1 bleed valfi (PRSOV)." }),
      T("apuBl", "APU", ["ON", "OFF"], 1, { lights: [{ id: "dualBleed", on: [0] }], d: "APU bleed valfi. Motor bleed ile birlikte açıksa DUAL BLEED yanar (basit mantık)." }),
      T("bl2", "2", ["ON", "OFF"], 0, { d: "Motor 2 bleed valfi (PRSOV)." })
    ] }
  ]
},
{
  id: "press", col: 3, hu: 18, name: "Kabin Basınçlandırma Paneli", en: "Cabin Pressurization Panel", ata: "21",
  desc: "Kabin irtifası, fark basıncı ve kabin tırmanma oranı göstergeleri; uçuş ve iniş irtifası seçicileri; mod seçici ve manuel outflow valf kontrolü.",
  rows: [
    { title: "", h: 1.8, items: [
      G("cabAlt", "CABIN ALT / DIFF", "cabalt", { size: 1.4, d: "Dış skala kabin irtifası (x1000 ft), iç skala fark basıncı (PSI)." }),
      G("cabClimb", "CABIN CLIMB", "climb", { size: 1.4, d: "Kabin irtifa değişim hızı (x1000 ft/dk)." })
    ] },
    { title: "", h: 1.45, items: [
      S(D("fltAlt", "FLT ALT", "fltalt", { w: 1.25, h: 0.36 }), R("fltAltK", "", [""], 0, { small: true, d: "Planlanan seyir irtifasını girer." })),
      S(D("landAlt", "LAND ALT", "landalt", { w: 1.25, h: 0.36 }), R("landAltK", "", [""], 0, { small: true, d: "Varış havaalanı rakımını girer." }))
    ] },
    { title: "", h: 1.3, items: [
      S(L("autoFail", "AUTO\nFAIL"), L("offSched", "OFF SCHED\nDESCENT")),
      S(L("altnLt", "ALTN", "g"), L("manLt", "MANUAL", "g")),
      G("outflow", "VALVE", "outflow", { size: 0.95, d: "Outflow valf konumu (CLOSE–OPEN)." })
    ] },
    { title: "", h: 1.6, items: [
      R("pressMode", "", ["AUTO", "ALTN", "MAN"], 0, { bar: true, lights: [{ id: "altnLt", on: [1] }, { id: "manLt", on: [2] }], d: "AUTO: otomatik kontrolcü. ALTN: yedek kontrolcü. MAN: outflow valfi aşağıdaki anahtarla elle kontrol edilir." }),
      T("ofv", "OUTFLOW VALVE", ["CLOSE", "", "OPEN"], 1, { spring: [0, 2], d: "MAN modunda outflow valfini kapatır/açar. Yay geri dönüşlüdür." }),
      B("hornCut", "ALT HORN\nCUTOUT", { d: "Kabin irtifa uyarı kornasını susturur." })
    ] }
  ]
}
];

// Alt sıra (ön kenar, cama yakın): dış aydınlatma, APU, motor start, silecekler
export const BOTTOM = {
  id: "lights", hu: 7, name: "Dış Aydınlatma / APU / Motor Start Paneli", en: "Exterior Lights, APU and Engine Start Panel", ata: "33/49/80",
  desc: "Overhead'in ön kenarı boyunca uzanan sıra. İniş, pist dönüş ve taksi ışıkları; APU anahtarı; motor start anahtarları ve ateşleme seçici; konum, logo, çarpışma önleme, kanat ve teker yuvası ışıkları; iki yanda silecek seçicileri.",
  rows: [{ title: "", h: 2.45, items: [
    R("wiperL", "WIPER", ["PARK", "INT", "LOW", "HIGH"], 0, { spread: 34, d: "Kaptan tarafı silecek. PARK: kapalı ve park konumunda." }),
    T("llRL", "RETRACTABLE", ["ON", "EXTEND", "RETRACT"], 2, { d: "Sol geri çekilebilir iniş ışığı: RETRACT/EXTEND/ON." }),
    T("llRR", "", ["ON", "EXTEND", "RETRACT"], 2, { d: "Sağ geri çekilebilir iniş ışığı." }),
    T("llFL", "FIXED", ["ON", "OFF"], 1, { d: "Sol sabit (iç) iniş ışığı." }),
    T("llFR", "", ["ON", "OFF"], 1, { d: "Sağ sabit (iç) iniş ışığı." }),
    T("rtL", "RUNWAY TURNOFF", ["ON", "OFF"], 1, { d: "Sol pist dönüş ışığı." }),
    T("rtR", "", ["ON", "OFF"], 1, { d: "Sağ pist dönüş ışığı." }),
    T("taxi", "TAXI", ["ON", "OFF"], 1, { d: "Burun takımındaki taksi ışığı." }),
    R("apuSw", "APU", ["OFF", "ON", "START"], 0, { spread: 40, spring: [2], bar: true, d: "APU start anahtarı. START'a çevrilip bırakılır, ON'a döner. OFF: APU soğuma süresinden sonra durur." }),
    R("eng1St", "ENGINE START 1", ["GRD", "OFF", "CONT", "FLT"], 1, { spread: 36, bar: true, d: "GRD: start valfi açılır, ateşleme verilir (start lever IDLE iken). Start sonrası OFF'a otomatik döner (solenoidle tutulur). CONT: sürekli ateşleme. FLT: uçuşta yeniden start." }),
    R("ign", "IGNITION", ["IGN L", "BOTH", "IGN R"], 0, { spread: 40, d: "Start ve CONT konumunda hangi ateşleyicinin kullanılacağını seçer." }),
    R("eng2St", "ENGINE START 2", ["GRD", "OFF", "CONT", "FLT"], 1, { spread: 36, bar: true, d: "Motor 2 start anahtarı." }),
    T("logo", "LOGO", ["ON", "OFF"], 1, { d: "Dikey stabilize logo ışıkları." }),
    T("posLt", "POSITION", ["STROBE &\nSTEADY", "OFF", "STEADY"], 1, { d: "Seyir (konum) ışıkları ve strob ışıkları." }),
    T("antiCol", "ANTI\nCOLLISION", ["ON", "OFF"], 1, { d: "Kırmızı çarpışma önleme (beacon) ışıkları. Motor çalıştırmadan önce açılır." }),
    T("wingLt", "WING", ["ON", "OFF"], 1, { d: "Kanat hücum kenarını aydınlatır (buz kontrolü)." }),
    T("wwLt", "WHEEL\nWELL", ["ON", "OFF"], 1, { d: "Teker yuvası ışıkları." }),
    R("wiperR", "WIPER", ["PARK", "INT", "LOW", "HIGH"], 0, { spread: 34, d: "F/O tarafı silecek." })
  ] }]
};

// Konnektörler – WDM'den doldurulacak. ref: "D...." gibi WDM konnektör numarası.
// Kullanıcı WDM/IPC sayfalarını paylaştığında bu tablo güncellenecek.
export const CONNECTORS = {
  // modül id: [{ ref, type, pins, harness, note }]
};
