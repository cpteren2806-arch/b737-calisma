(function(){
"use strict";
const C = window.CHAPTERS, $ = s => document.querySelector(s);
const view = $("#view");
const esc = s => String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const strip = s => String(s).replace(/<[^>]+>/g, "");
const ls = {
  get(k, d){ try{ const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); }catch(e){ return d; } },
  set(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
};
function toast(msg){ const t = $("#toast"); t.textContent = msg; t.hidden = false; clearTimeout(toast._t); toast._t = setTimeout(() => t.hidden = true, 2200); }

/* ---------- Model filtresi ---------- */
function setModel(m){
  document.body.classList.remove("m-ng","m-max"); if(m !== "all") document.body.classList.add("m-" + m);
  document.querySelectorAll("#modelSeg button").forEach(b => b.classList.toggle("on", b.dataset.m === m));
  ls.set("model", m);
}
document.querySelectorAll("#modelSeg button").forEach(b => b.onclick = () => setModel(b.dataset.m));
setModel(ls.get("model","all"));

/* ---------- IndexedDB: kullanıcı belgeleri ---------- */
let dbp = null;
function db(){
  if(!dbp) dbp = new Promise((res, rej) => {
    const r = indexedDB.open("b737", 1);
    r.onupgradeneeded = () => { const s = r.result.createObjectStore("files", {keyPath:"id"}); s.createIndex("chapter","chapter"); };
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  return dbp;
}
async function tx(mode, fn){
  const d = await db();
  return new Promise((res, rej) => {
    const t = d.transaction("files", mode), s = t.objectStore("files"); let out;
    Promise.resolve(fn(s)).then(v => out = v);
    t.oncomplete = () => res(out); t.onerror = () => rej(t.error);
  });
}
const req = r => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
async function listFiles(chapter){
  return tx("readonly", s => req(chapter ? s.index("chapter").getAll(chapter) : s.getAll()))
    .then(a => (a || []).sort((x,y) => y.added - x.added));
}
async function addFiles(chapter, files){
  for(const f of files){
    const rec = {id: Date.now() + "-" + Math.random().toString(36).slice(2), chapter, name: f.name, type: f.type || (f.name.toLowerCase().endsWith(".pdf") ? "application/pdf" : "image/*"), blob: f, added: Date.now()};
    await tx("readwrite", s => { s.put(rec); });
  }
}
async function delFile(id){ return tx("readwrite", s => { s.delete(id); }); }
async function getFile(id){ return tx("readonly", s => req(s.get(id))); }

let pickTarget = null;
$("#filePick").addEventListener("change", async e => {
  const files = [...e.target.files]; e.target.value = "";
  if(!files.length || !pickTarget) return;
  try{ await addFiles(pickTarget, files); toast(files.length + " dosya eklendi"); }
  catch(err){ toast("Dosya kaydedilemedi: " + err.message); }
  route();
});
function pick(chapter){ pickTarget = chapter; $("#filePick").click(); }

/* ---------- Görüntüleyiciler ---------- */
const ov = $("#overlay"), ovBody = $("#ovBody"), ovCtrl = $("#ovCtrl");
let ovUrl = null;
function closeOv(){ ov.hidden = true; ovBody.innerHTML = ""; ovCtrl.innerHTML = ""; if(ovUrl){ URL.revokeObjectURL(ovUrl); ovUrl = null; } }
$("#ovClose").onclick = closeOv;
function openOv(title){ $("#ovTitle").textContent = title; ov.hidden = false; ovBody.innerHTML = ""; ovCtrl.innerHTML = ""; }

function zoomCtl(apply){
  let z = 1;
  ovCtrl.innerHTML = '<button data-z="-">−</button><button data-z="+">+</button>';
  ovCtrl.querySelectorAll("button").forEach(b => b.onclick = () => { z = Math.max(.5, Math.min(4, z + (b.dataset.z === "+" ? .25 : -.25))); apply(z); });
}
async function openFile(id){
  const f = await getFile(id); if(!f) return;
  openOv(f.name); ovUrl = URL.createObjectURL(f.blob);
  if(f.type === "application/pdf") return openPdf(f.blob);
  const img = new Image(); img.src = ovUrl; ovBody.appendChild(img);
  zoomCtl(z => { img.style.maxWidth = "none"; img.style.width = (z * 100) + "%"; });
}
async function openPdf(blob){
  if(!window.pdfjsLib){ ovBody.innerHTML = '<p style="color:#fff;padding:16px">PDF görüntüleyici yüklenemedi.</p>'; return; }
  pdfjsLib.GlobalWorkerOptions.workerSrc = "lib/pdf.worker.min.js";
  let doc, page = 1, z = 1;
  try{ const buf = new Uint8Array(await blob.arrayBuffer()); doc = await pdfjsLib.getDocument({data: buf}).promise; }
  catch(e){ ovBody.innerHTML = '<p style="color:#fff;padding:16px">PDF açılamadı: ' + esc(e.message) + '</p>'; return; }
  ovCtrl.innerHTML = '<button data-a="p">‹</button><span id="pg"></span><button data-a="n">›</button><button data-a="-">−</button><button data-a="+">+</button>';
  const cv = document.createElement("canvas"); ovBody.appendChild(cv);
  let rendering = null;
  async function draw(){
    const p = await doc.getPage(page);
    const base = p.getViewport({scale:1});
    const scale = (Math.min(window.innerWidth, 900) - 16) / base.width * z;
    const vp = p.getViewport({scale: scale * (window.devicePixelRatio || 1)});
    cv.width = vp.width; cv.height = vp.height;
    cv.style.width = (vp.width / (window.devicePixelRatio || 1)) + "px";
    if(rendering) try{ rendering.cancel(); }catch(e){}
    rendering = p.render({canvasContext: cv.getContext("2d"), viewport: vp});
    try{ await rendering.promise; }catch(e){}
    $("#pg").textContent = page + " / " + doc.numPages;
  }
  ovCtrl.querySelectorAll("button").forEach(b => b.onclick = () => {
    const a = b.dataset.a;
    if(a === "p" && page > 1) page--; else if(a === "n" && page < doc.numPages) page++;
    else if(a === "+") z = Math.min(4, z + .25); else if(a === "-") z = Math.max(.5, z - .25);
    else return; ovBody.scrollTop = 0; draw();
  });
  draw();
}
function openDiagram(key, title){
  openOv(title);
  const box = document.createElement("div"); box.className = "svgbox"; box.innerHTML = window.DIAGRAMS[key];
  ovBody.appendChild(box);
  zoomCtl(z => { box.style.minWidth = (600 * z) + "px"; });
}

/* ---------- Görünümler ---------- */
function setTop(title, back){ $("#topTitle").textContent = title; $("#backBtn").hidden = !back; }
$("#backBtn").onclick = () => { if(history.length > 1) history.back(); else location.hash = "#/"; };

function home(){
  setTop("B737 Çalışma", false);
  const best = ls.get("best", {});
  view.innerHTML = `
  <form class="search" id="sf"><input id="sq" type="search" placeholder="Ara: APU, PTU, IDG, bleed…" autocomplete="off"><button class="btn pri">Ara</button></form>
  ${ls.get("ack", false) ? "" : `<div class="note"><b>Eğitim amaçlıdır.</b> İçerik özgün özetlerden oluşur. Boeing AMM/CMM/FCOM değildir, onların yerine geçmez. Gerçek bakımda yalnız işletmenin güncel, yetkili dokümanını kullanın. <button class="btn sm" id="ack">Anladım</button></div>`}
  <h3 class="sec">3D modeller</h3>
  <div class="grid g3">${M3D.map(m => `<a class="tile t3" href="#/3d/${m.id}"><span class="ata">3D</span><b>${esc(m.t)}</b><small>${esc(m.s)}</small></a>`).join("")}</div>
  <h3 class="sec">Sistemler</h3>
  <div class="grid">${C.map(c => `<a class="tile" href="#/c/${c.id}" style="text-decoration:none"><span class="ata">ATA ${c.ata}</span><b>${esc(c.title)}</b><small>${esc(c.en)}${best[c.id] != null ? " · Quiz %" + best[c.id] : ""}</small></a>`).join("")}</div>
  <div class="row">
    <a class="btn" href="#/diff">NG ↔ MAX farkları</a>
    <a class="btn" href="#/gloss">Kısaltmalar ve el kitapları</a>
    <a class="btn" href="#/q/all">Karışık quiz</a>
    <a class="btn" href="#/docs">Belgelerim</a>
  </div>`;
  $("#sf").onsubmit = e => { e.preventDefault(); const q = $("#sq").value.trim(); if(q) location.hash = "#/s/" + encodeURIComponent(q); };
  const a = $("#ack"); if(a) a.onclick = () => { ls.set("ack", true); home(); };
}

function list(items){ return "<ul>" + items.map(i => "<li>" + i + "</li>").join("") + "</ul>"; }

async function chapter(id){
  const c = C.find(x => x.id === id); if(!c) return home();
  setTop("ATA " + c.ata + " · " + c.title, true);
  view.innerHTML = `
  <span class="ata">ATA ${c.ata} · ${esc(c.en)}</span>
  <h2>${esc(c.title)}</h2>
  <p class="lead">${c.summary}</p>
  <nav class="tabs">
    ${c.diagram ? '<a href="#dg">Şema</a>' : ""}
    ${c.sections.map((s,i) => `<a href="#s${i}">${esc(s.h)}</a>`).join("")}
    <a href="#ck">Kokpit</a><a href="#mt">Bakım</a><a href="#mx">MAX farkı</a><a href="#my">Belgelerim</a>
  </nav>
  ${c.diagram ? `<div class="dgwrap" id="dg" data-dg="${c.diagram}">${window.DIAGRAMS[c.diagram]}<div class="cap">Basitleştirilmiş özgün şema · büyütmek için dokunun</div></div>` : ""}
  ${c.sections.map((s,i) => `<div class="card" id="s${i}"><h3>${esc(s.h)}</h3>${list(s.list)}</div>`).join("")}
  <div class="card" id="ck"><h3>Kokpit kontrolleri ve göstergeler</h3>${list(c.cockpit)}</div>
  <div class="warn" id="mt"><h3>⚠ Bakım ve güvenlik notları</h3>${list(c.maint)}</div>
  <div class="maxbox" id="mx"><h3>737 MAX farkları</h3>${list(c.max)}</div>
  <div class="row"><a class="btn pri" href="#/q/${c.id}">Bu bölümün quizini başlat (${c.quiz.length} soru)</a>${M3D.filter(m => m.ch === c.id).map(m => `<a class="btn" href="#/3d/${m.id}">3D: ${esc(m.t)}</a>`).join("")}</div>
  <div class="card" id="my"><h3>Belgelerim ve notlarım</h3>
    <p class="empty">Ders notu, eğitim PDF'i veya fotoğraf ekleyebilirsin. Dosyalar yalnız bu telefonda saklanır.</p>
    <div class="files" id="files"></div>
    <div class="row"><button class="btn" id="addf">+ Resim / PDF ekle</button></div>
    <textarea id="note" placeholder="Bu bölüm için notların…"></textarea>
  </div>`;
  view.querySelectorAll(".tabs a").forEach(a => a.onclick = e => { e.preventDefault(); const t = document.getElementById(a.getAttribute("href").slice(1)); if(t) t.scrollIntoView({behavior:"smooth", block:"start"}); });
  const dg = view.querySelector(".dgwrap"); if(dg) dg.onclick = () => openDiagram(c.diagram, c.title);
  $("#addf").onclick = () => pick(c.id);
  const n = $("#note"); n.value = ls.get("note:" + c.id, ""); n.oninput = () => ls.set("note:" + c.id, n.value);
  await renderFiles($("#files"), c.id);
  const jump = sessionStorage.getItem("jump"); if(jump){ sessionStorage.removeItem("jump"); const t = document.getElementById(jump); if(t) t.scrollIntoView({block:"start"}); }
}

async function renderFiles(el, chapterId){
  let files = [];
  try{ files = await listFiles(chapterId); }catch(e){ el.innerHTML = '<p class="empty">Depolama kullanılamıyor.</p>'; return; }
  if(!files.length){ el.innerHTML = '<p class="empty">Henüz dosya yok.</p>'; return; }
  el.innerHTML = "";
  for(const f of files){
    const d = document.createElement("div"); d.className = "file";
    const isPdf = f.type === "application/pdf";
    let inner = isPdf ? '<span class="pdf">PDF</span>' : "";
    if(!isPdf){ const u = URL.createObjectURL(f.blob); inner = `<img src="${u}" alt="">`; }
    const ch = C.find(x => x.id === f.chapter);
    d.innerHTML = inner + `<span class="nm">${esc(f.name)}${!chapterId && ch ? " · ATA " + ch.ata : ""}</span><button class="del" aria-label="Sil">✕</button>`;
    d.onclick = e => { if(e.target.classList.contains("del")) return; openFile(f.id); };
    d.querySelector(".del").onclick = async e => { e.stopPropagation(); if(confirm(f.name + " silinsin mi?")){ await delFile(f.id); renderFiles(el, chapterId); } };
    el.appendChild(d);
  }
}

async function docs(){
  setTop("Belgelerim", true);
  view.innerHTML = `<h2>Belgelerim</h2>
  <p class="lead">Okulunun verdiği ders notlarını, eğitim PDF'lerini ve kendi çektiğin fotoğrafları ATA bölümüne bağlayarak sakla. Dosyalar yalnız bu cihazda tutulur.</p>
  <div class="row"><select id="ch">${C.map(c => `<option value="${c.id}">ATA ${c.ata} – ${esc(c.title)}</option>`).join("")}<option value="genel">Genel</option></select><button class="btn pri" id="add">+ Dosya ekle</button></div>
  <div class="files" id="files"></div>`;
  $("#add").onclick = () => pick($("#ch").value);
  renderFiles($("#files"), null);
}

function diff(){
  setTop("NG ↔ MAX farkları", true);
  const [h, ...rows] = window.DIFFS;
  view.innerHTML = `<h2>737NG ve 737 MAX</h2><p class="lead">Temel farklar. Ayrıntılar her ATA bölümündeki "MAX farkı" kutusunda.</p>
  <div class="card"><table><tr><th>Konu</th><th class="ngcol">NG</th><th class="maxcol">MAX</th></tr>
  ${rows.map(r => `<tr><td><b>${esc(r[0])}</b></td><td class="ngcol">${esc(r[1])}</td><td class="maxcol">${esc(r[2])}</td></tr>`).join("")}</table></div>`;
}

function gloss(){
  setTop("Kısaltmalar", true);
  view.innerHTML = `<h2>Kısaltmalar ve el kitapları</h2>
  <form class="search" onsubmit="return false"><input id="gq" type="search" placeholder="Filtrele…"></form>
  <div id="gl"></div>`;
  const draw = q => { q = (q || "").toLowerCase();
    $("#gl").innerHTML = window.GLOSSARY.filter(g => !q || g.join(" ").toLowerCase().includes(q))
      .map(g => `<div class="gl"><b>${esc(g[0])}</b> <i>${esc(g[1])}</i><br>${esc(g[2])}</div>`).join("") || '<p class="empty">Sonuç yok.</p>'; };
  $("#gq").oninput = e => draw(e.target.value); draw("");
}

async function search(q){
  setTop("Arama", true);
  const ql = q.toLocaleLowerCase("tr");
  const hl = t => { const s = esc(strip(t)); const i = s.toLocaleLowerCase("tr").indexOf(ql); if(i < 0) return s.slice(0,140);
    const a = Math.max(0, i - 50); return (a ? "…" : "") + s.slice(a, i) + "<mark>" + s.slice(i, i + q.length) + "</mark>" + s.slice(i + q.length, i + q.length + 80) + "…"; };
  const out = [];
  for(const c of C){
    const parts = [["top", c.title + " " + c.en + " " + c.summary]];
    c.sections.forEach((s,i) => parts.push(["s"+i, s.h + " " + s.list.join(" ")]));
    parts.push(["ck", c.cockpit.join(" ")], ["mt", c.maint.join(" ")], ["mx", c.max.join(" ")]);
    const note = ls.get("note:" + c.id, ""); if(note) parts.push(["my", note]);
    for(const [anc, txt] of parts) if(strip(txt).toLocaleLowerCase("tr").includes(ql)) out.push({c, anc, txt});
  }
  const gl = window.GLOSSARY.filter(g => g.join(" ").toLocaleLowerCase("tr").includes(ql));
  let files = []; try{ files = (await listFiles(null)).filter(f => f.name.toLocaleLowerCase("tr").includes(ql)); }catch(e){}
  view.innerHTML = `<form class="search" id="sf"><input id="sq" type="search" value="${esc(q)}"><button class="btn pri">Ara</button></form>
  <p class="score">${out.length + gl.length + files.length} sonuç</p>
  ${out.map((r,i) => `<a class="res" href="#/c/${r.c.id}" data-anc="${r.anc}"><small>ATA ${r.c.ata} · ${esc(r.c.title)}</small>${hl(r.txt)}</a>`).join("")}
  ${gl.map(g => `<a class="res" href="#/gloss"><small>Kısaltma</small><b>${esc(g[0])}</b> – ${esc(g[1])}: ${esc(g[2])}</a>`).join("")}
  ${files.map(f => `<a class="res" href="#" data-file="${f.id}"><small>Belgem</small>${esc(f.name)}</a>`).join("")}
  ${!out.length && !gl.length && !files.length ? '<p class="empty">Sonuç bulunamadı. Farklı bir terim dene (ör. "bleed", "IDG", "fren").</p>' : ""}`;
  $("#sf").onsubmit = e => { e.preventDefault(); const v = $("#sq").value.trim(); if(v) location.hash = "#/s/" + encodeURIComponent(v); };
  view.querySelectorAll("[data-anc]").forEach(a => a.onclick = () => sessionStorage.setItem("jump", a.dataset.anc));
  view.querySelectorAll("[data-file]").forEach(a => a.onclick = e => { e.preventDefault(); openFile(a.dataset.file); });
}

function shuffle(a){ for(let i = a.length - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function quiz(id){
  const all = id === "all";
  const c = all ? null : C.find(x => x.id === id);
  if(!all && !c) return home();
  const qs = all ? shuffle(C.flatMap(ch => ch.quiz.map(q => ({...q, ch})))).slice(0, 15) : shuffle(c.quiz.map(q => ({...q, ch: c})));
  setTop(all ? "Karışık quiz" : "Quiz · ATA " + c.ata, true);
  let i = 0, score = 0;
  const show = () => {
    if(i >= qs.length){
      const pct = Math.round(score / qs.length * 100);
      if(!all){ const b = ls.get("best", {}); if(b[id] == null || pct > b[id]){ b[id] = pct; ls.set("best", b); } }
      view.innerHTML = `<h2>Sonuç: ${score} / ${qs.length} (%${pct})</h2>
      <p class="lead">${pct >= 75 ? "İyi gidiyorsun." : "Bölümü tekrar okuyup yeniden dene."}</p>
      <div class="row"><button class="btn pri" id="again">Tekrar</button>${all ? "" : `<a class="btn" href="#/c/${id}">Bölüme dön</a>`}<a class="btn" href="#/">Ana sayfa</a></div>`;
      $("#again").onclick = () => quiz(id); return;
    }
    const q = qs[i];
    const order = shuffle(q.o.map((t, k) => ({t, k})));
    view.innerHTML = `<div class="score">Soru ${i + 1} / ${qs.length} · ATA ${q.ch.ata} · Doğru: ${score}</div>
    <div class="prog"><i style="width:${i / qs.length * 100}%"></i></div>
    <div class="q">${esc(q.q)}</div>
    ${order.map(o => `<button class="opt" data-k="${o.k}">${esc(o.t)}</button>`).join("")}
    <div id="fb"></div>`;
    view.querySelectorAll(".opt").forEach(b => b.onclick = () => {
      if(view.querySelector(".opt.ok")) return;
      const k = +b.dataset.k, right = k === q.a; if(right) score++;
      view.querySelectorAll(".opt").forEach(x => { if(+x.dataset.k === q.a) x.classList.add("ok"); });
      if(!right) b.classList.add("bad");
      $("#fb").innerHTML = `<div class="exp"><b>${right ? "Doğru." : "Yanlış."}</b> ${esc(q.e)}</div><div class="row"><button class="btn pri" id="nx">${i + 1 < qs.length ? "Sonraki" : "Sonucu gör"}</button></div>`;
      $("#nx").onclick = () => { i++; show(); window.scrollTo(0,0); };
    });
  };
  show();
}

/* ---------- 3D modeller ---------- */
const M3D = [
  {id:"apu", ch:"apu", t:"APU (131-9B)", s:"Parçalara ayır, dokun, incele"},
  {id:"p5", ch:"elec", t:"Overhead panel (P5)", s:"Gerçekçi ön yüz, çalışan anahtarlar, arka konnektörler"},
  {id:"connector", ch:"elec", t:"Konnektör anatomisi", s:"Pin, soket, conta, backshell"}
];
async function view3d(id){
  const m = M3D.find(x => x.id === id); if(!m) return home();
  setTop("3D · " + m.t, true);
  document.body.classList.add("full3d");
  view.innerHTML = '<p class="empty">3D model yükleniyor…</p>';
  try{
    if(id === "p5"){
      const mod = await import("./3d/p5/overhead.js");
      if(location.hash !== "#/3d/" + id) return;
      const d = await mod.mount(view);
      if(location.hash !== "#/3d/" + id){ d(); return; }
      disposeView = d;
    } else {
      const mod = await import("./3d/viewer3d.js");
      if(location.hash !== "#/3d/" + id) return;
      disposeView = mod.mount(view, id);
    }
  }catch(e){
    view.innerHTML = '<p class="empty">3D model açılamadı: ' + esc(e.message) + '</p>';
  }
}

/* ---------- Yönlendirme ---------- */
let disposeView = null;
function route(){
  closeOv();
  if(disposeView){ try{ disposeView(); }catch(e){} disposeView = null; }
  document.body.classList.remove("full3d");
  const h = location.hash.replace(/^#\/?/, "").split("/");
  window.scrollTo(0, 0);
  switch(h[0]){
    case "c": return chapter(h[1]);
    case "q": return quiz(h[1]);
    case "s": return search(decodeURIComponent(h.slice(1).join("/")));
    case "diff": return diff();
    case "gloss": return gloss();
    case "docs": return docs();
    case "3d": return view3d(h[1]);
    default: return home();
  }
}
window.addEventListener("hashchange", route);
// Android geri tuşu için (MainActivity çağırır): overlay açıksa kapat
window.__onBack = function(){ if(!ov.hidden){ closeOv(); return true; } return false; };
route();
})();
