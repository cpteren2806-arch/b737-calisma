// B737 Çalışma – özgün eğitim içeriği. Boeing AMM/CMM/FCOM metni değildir.
// Rakamlar tipik değerlerdir; konfigürasyona göre değişir. Kesin değer için
// okulunuzun/işletmenin güncel, yetkili dokümanına bakın.
window.CHAPTERS = [
{
 id:"apu", ata:"49", title:"APU – Yardımcı Güç Ünitesi", en:"Auxiliary Power Unit", diagram:"apu",
 summary:"APU, kuyruk konisine yerleştirilmiş küçük bir gaz türbinidir. Yerde ve uçuşta elektrik gücü (jeneratör) ve pnömatik hava (bleed air) sağlar. Böylece uçak yer güç ünitesine ihtiyaç duymadan klima çalıştırabilir ve ana motorları çalıştırabilir.",
 sections:[
  {h:"Genel", list:[
   "Model: 737NG ve MAX'te çoğunlukla Honeywell 131-9B. Bazı erken NG'lerde APS 2000 bulunur.",
   "Konum: arka basınç perdesinin gerisinde, kuyruk konisinde, yangına dayanıklı (fireproof) bir bölmede. Bakım erişimi alttaki kapaklardan yapılır.",
   "Sabit hızlı (constant speed) çalışır. Yük ne olursa olsun devir sabit tutulur, yük değişince yakıt akışı ayarlanır.",
   "Kendi yağ sistemi vardır: yağ tankı, pompa, filtre ve soğutucu motor yağ sisteminden bağımsızdır."]},
  {h:"Ana bileşenler", list:[
   "<b>Güç bölümü (power section):</b> kompresör, yanma odası ve türbin. Dişli kutusunu ve jeneratörü döndürür.",
   "<b>Yük kompresörü (load compressor):</b> bleed havası üretir. Giriş yönlendirici kanatçıkları (IGV) hava miktarını ayarlar.",
   "<b>Dişli kutusu (gearbox):</b> jeneratörü, yağ pompasını, yakıt kontrol ünitesini ve soğutma fanını tahrik eder.",
   "<b>Jeneratör:</b> 115V AC, 400 Hz, tipik 90 kVA. 131-9B'de jeneratör aynı zamanda marş motoru olarak kullanılır (starter-generator). Start gücü Start Converter Unit (SCU) üzerinden verilir.",
   "<b>ECU (Electronic Control Unit):</b> start sırası, devir ve EGT kontrolü, otomatik koruma (shutdown) ve arıza kaydı (BITE).",
   "<b>Hava girişi kapağı (inlet door):</b> APU çalışırken açılır, kapatılınca kapanır.",
   "<b>APU bleed valfi:</b> APU havasını pnömatik manifolda verir."]},
  {h:"Çalışma mantığı", list:[
   "Batarya anahtarı ON. APU anahtarı START'a alınır, bırakınca ON'a döner.",
   "Yakıt sol yakıt manifoldundan gelir. AC boost pompaları kapalıysa emme (suction) beslemesiyle de çalışabilir.",
   "Start sırasında inlet door açılır, ECU yakıtı ve ateşlemeyi açar, devir yükselir, starter devreden çıkar.",
   "APU hazır olduğunda kokpitte <i>APU GEN OFF BUS</i> ışığı yanar: jeneratör baraya bağlanmaya hazırdır.",
   "Kapatma: APU anahtarı OFF. Bleed havası kullanıldıysa yaklaşık 60 saniyelik soğuma (cooldown) sonrası durur."]},
  {h:"Otomatik kapanma (protective shutdown) örnekleri", list:[
   "Aşırı devir (overspeed)", "Düşük yağ basıncı", "Yüksek yağ sıcaklığı", "Aşırı EGT", "ECU arızası", "Yerde APU yangını"]}
 ],
 cockpit:[
  "APU anahtarı: OFF / ON / START",
  "Işıklar: MAINT, LOW OIL PRESSURE, FAULT, OVERSPEED",
  "APU EGT göstergesi",
  "APU GEN OFF BUS ışığı ve APU GEN 1/2 anahtarları",
  "APU BLEED anahtarı ve DUAL BLEED ışığı (APU bleed ve motor bleed aynı anda kanala açıksa)",
  "Yangın paneli: APU fire switch (çek ve çevir), APU BOTTLE DISCHARGE ışığı",
  "Sağ ana teker yuvasında yer yangın kontrol paneli: yangın kornası, korna susturma, tüp boşaltma"],
 maint:[
  "Yağ seviyesini APU durduktan sonra üreticinin belirttiği süre içinde kontrol edin. Sıcak ve soğuk okuma farklı olabilir.",
  "APU bölmesine girmeden önce APU'nun kapalı olduğundan ve start edilemeyecek şekilde etiketlendiğinden (tag) emin olun.",
  "Yangın tüpü squib bağlantılarında statik ve elektrik güvenliği kurallarına uyun.",
  "ECU arıza kayıtları (BITE) arıza izolasyonunda ilk bakılacak yerdir.",
  "Egzoz ve kuyruk konisi bölgesi çalışma sonrası uzun süre sıcak kalır."],
 max:[
  "MAX'te de 131-9B kullanılır. Kuyruk konisi ve arka gövde aerodinamik olarak yeniden şekillendirilmiştir.",
  "Kokpit göstergeleri büyük ekranlara taşınmıştır, APU parametrelerinin görünümü farklıdır."],
 quiz:[
  {q:"737NG'de APU yakıtı hangi taraftan beslenir?", o:["Sağ manifold","Sol manifold","Merkez tanktan doğrudan","Ayrı APU tankından"], a:1, e:"APU yakıtı sol yakıt manifoldundan alınır. AC pompalar kapalıysa emme beslemesi de mümkündür."},
  {q:"APU GEN OFF BUS ışığı ne anlama gelir?", o:["Jeneratör arızalı","APU hazır, jeneratör baraya bağlı değil","APU yangını","Yağ basıncı düşük"], a:1, e:"Işık, APU'nun hazır olduğunu ve jeneratörün henüz baraya bağlanmadığını gösterir."},
  {q:"Bleed havası kullanıldıktan sonra APU kapatılınca ne olur?", o:["Hemen durur","Soğuma süresi sonrası durur","Yeniden start eder","Yangın testi yapar"], a:1, e:"Yaklaşık 60 saniyelik soğuma süresi ECU tarafından otomatik uygulanır."},
  {q:"APU'da sabit tutulan parametre hangisidir?", o:["EGT","Yağ sıcaklığı","Devir (RPM)","Bleed basıncı"], a:2, e:"APU sabit hızlı çalışır. Yük değiştikçe yakıt akışı değişir, devir sabit tutulur."}]
},
{
 id:"hyd", ata:"29", title:"Hidrolik Güç", en:"Hydraulic Power", diagram:"hyd",
 summary:"737'de üç hidrolik sistem vardır: A, B ve Standby. A ve B normal basıncı 3000 psi'dır ve kumanda yüzeyleri, iniş takımı, frenler ve flaplar gibi ana kullanıcıları besler. Standby sistemi yedektir.",
 sections:[
  {h:"Sistemler ve pompalar", list:[
   "<b>Sistem A:</b> 1 numaralı motordaki motor tahrikli pompa (EDP) ve bir elektrik motorlu pompa (EMDP / ACMP).",
   "<b>Sistem B:</b> 2 numaralı motordaki EDP ve bir EMDP.",
   "<b>Standby:</b> tek elektrikli pompa. Rezervuarı sistem B rezervuarından beslenir. Otomatik veya ALTERNATE FLAPS ya da FLT CONTROL anahtarlarıyla devreye girer.",
   "Rezervuarlar pnömatik sistemden gelen havayla basınçlandırılır. Bu, pompa girişinde kavitasyonu önler.",
   "Akışkan: fosfat ester bazlı yangına dayanıklı hidrolik sıvı (ör. Skydrol / HyJet tipi)."]},
  {h:"Kullanıcılar", list:[
   "<b>A:</b> aileron, rudder, elevator ve elevator feel, flight spoilerlar, ground spoilerlar, alternate fren, burun teker dümenlemesi, iniş takımı, otopilot A, reverser 1.",
   "<b>B:</b> aileron, rudder, elevator ve feel, flight spoilerlar, firar kenarı (TE) flapları, hücum kenarı (LE) flap/slatları, normal fren, otopilot B, autoslat, yaw damper, reverser 2, landing gear transfer.",
   "<b>Standby:</b> standby rudder PCU, her iki reverser, LE cihazların açılması (yalnız açma yönünde), konfigürasyona göre standby yaw damper."]},
  {h:"PTU ve LGTU", list:[
   "<b>PTU (Power Transfer Unit):</b> A sisteminin basıncıyla dönen bir hidrolik motor, B sisteminin sıvısını basınçlandıran bir pompayı çevirir. Sıvılar karışmaz. B EDP'si basınç kaybettiğinde, havadayken ve flaplar belirli konumdayken LE cihazlar ve autoslat için yedek sağlar.",
   "<b>LGTU (Landing Gear Transfer Unit):</b> kalkışta 1 numaralı motorun devri düşerse, iniş takımının toplanması için B sistemi hacmini kullanır."]}
 ],
 cockpit:[
  "ENG 1 / ENG 2 HYD PUMPS anahtarları ve LOW PRESSURE ışıkları",
  "ELEC 1 / ELEC 2 pompa anahtarları, LOW PRESSURE ve OVERHEAT ışıkları",
  "Hidrolik basınç ve miktar göstergesi (sistem ekranı)",
  "FLT CONTROL A/B anahtarları: STBY RUD / OFF / ON",
  "STANDBY HYD LOW QUANTITY / LOW PRESSURE ışıkları"],
 maint:[
  "Hidrolik hattı açmadan önce sistemi ve rezervuarı basınçsızlandırın. Akümülatör basıncının da boşaltılması gerekebilir.",
  "Fosfat ester sıvı göze ve cilde zararlıdır. Koruyucu gözlük ve uygun eldiven kullanın.",
  "Farklı sıvı tiplerini karıştırmayın. Yanlış sıvı contaları bozar.",
  "Miktar kontrolünü uçağın belirtilen konfigürasyonunda yapın (flap, spoyler, takım, reverser konumu sonucu etkiler).",
  "Pompaları çalıştırmadan önce kumanda yüzeyleri, flap ve takım çevresinin personelden temiz olduğunu kontrol edin."],
 max:[
  "MAX'te temel A/B/Standby mimarisi korunur.",
  "Bazı spoyler panellerinin kumandası elektriksel sinyalle yapılır (fly-by-wire). Hidrolik güç hâlâ A/B sistemlerinden gelir."],
 quiz:[
  {q:"737'de A ve B hidrolik sistemlerinin normal basıncı nedir?", o:["1500 psi","3000 psi","5000 psi","2200 psi"], a:1, e:"A ve B sistemleri normalde 3000 psi'da çalışır."},
  {q:"PTU ne yapar?", o:["B'den A'ya sıvı aktarır","A basıncıyla B sıvısını basınçlandırır","Standby'ı doldurur","Fren akümülatörünü şarj eder"], a:1, e:"PTU, A basıncını kullanarak sıvıları karıştırmadan B sistemine yedek güç sağlar."},
  {q:"Standby rezervuarı hangi sistemden beslenir?", o:["A","B","Pnömatik","Yakıt"], a:1, e:"Standby rezervuarı B rezervuarından beslenir."},
  {q:"Normal frenler hangi sistemle çalışır?", o:["A","B","Standby","Elektrik"], a:1, e:"Normal fren B, alternate fren A sistemidir. Ayrıca fren akümülatörü bulunur."}]
},
{
 id:"pneu", ata:"36", title:"Pnömatik", en:"Pneumatic", diagram:"pneu",
 summary:"Pnömatik sistem, motor kompresöründen, APU'dan veya yer arabasından gelen sıcak ve basınçlı havayı (bleed air) klima paketlerine, buz önleme sistemlerine, motor marşına ve rezervuar basınçlandırmaya dağıtır.",
 sections:[
  {h:"Bleed havası kaynağı", list:[
   "<b>CFM56-7B (NG):</b> HPC 5. kademe (düşük) ve 9. kademe (yüksek).",
   "<b>LEAP-1B (MAX):</b> HPC 4. kademe (düşük) ve 10. kademe (yüksek).",
   "Düşük motor gücünde düşük kademe basıncı yetersizdir. High stage valf açılır ve yüksek kademeden hava alınır. Güç arttıkça high stage valf kapanır.",
   "Check valf, yüksek kademe havasının düşük kademeye geri akmasını önler."]},
  {h:"Ana bileşenler", list:[
   "<b>PRSOV (engine bleed air valve):</b> basıncı düzenler ve kapatma yapar. Kokpitteki BLEED anahtarıyla kumanda edilir.",
   "<b>Precooler:</b> fan havasıyla bleed havasını soğutan ısı eşanjörü. Precooler kontrol valfi fan hava akışını ayarlar.",
   "<b>İzolasyon valfi:</b> sol ve sağ manifoldu ayırır veya birleştirir. AUTO / CLOSE / OPEN.",
   "<b>APU bleed valfi</b> ve <b>yer pnömatik bağlantısı</b> (ground cart).",
   "Aşırı sıcaklık ve aşırı basınç sensörleri: limit aşılırsa ilgili bleed valfi kapanır ve BLEED TRIP OFF ışığı yanar.",
   "Kanal kaçak algılama: WING-BODY OVERHEAT ışığı sıcak hava kaçağını gösterir."]},
  {h:"Kullanıcılar", list:["Klima paketleri (ATA 21)","Kanat ve motor buz önleme (ATA 30)","Motor marşı (pnömatik marş motoru)","Hidrolik rezervuarları ve içme suyu tankı basınçlandırma"]}
 ],
 cockpit:[
  "ENG 1 / ENG 2 BLEED ve APU BLEED anahtarları",
  "ISOLATION VALVE anahtarı: CLOSE / AUTO / OPEN",
  "L / R DUCT PRESSURE çift ibreli göstergesi",
  "BLEED TRIP OFF ışıkları ve TRIP RESET düğmesi",
  "WING-BODY OVERHEAT ışıkları",
  "DUAL BLEED ışığı"],
 maint:[
  "Bleed kanalları çok sıcaktır. Çalışma sonrası soğumasını bekleyin.",
  "Kanal kelepçe (clamp) ve contalarının doğru tork ve konumda olması kaçak algılama hatalarını önler.",
  "Yer arabasıyla basınç verirken bağlantı ve valf konumlarını iki kez kontrol edin.",
  "BLEED TRIP OFF arızalarında önce sensör ve precooler kontrol valfi gibi sık arıza veren bileşenleri değerlendirin. Sıralamayı yetkili arıza izolasyon dokümanı belirler."],
 max:[
  "Bleed kademeleri farklıdır: 4. ve 10. kademe (LEAP-1B).",
  "Bleed kontrolü daha fazla elektronik izleme içerir. Kokpit göstergeleri büyük ekranlardadır."],
 quiz:[
  {q:"CFM56-7B'de yüksek basınçlı bleed hangi kademeden alınır?", o:["5.","9.","4.","10."], a:1, e:"NG'de düşük kademe 5., yüksek kademe 9.'dur. MAX'te 4. ve 10."},
  {q:"Precooler bleed havasını neyle soğutur?", o:["Ram havası","Fan havası","Yakıt","Hidrolik sıvı"], a:1, e:"Precooler, motor fan havasını kullanan bir ısı eşanjörüdür."},
  {q:"BLEED TRIP OFF ışığı neyi gösterir?", o:["Kanal kaçağı","Aşırı sıcaklık veya basınçla bleed valfi kapandı","APU bleed açık","İzolasyon valfi açık"], a:1, e:"Aşırı sıcaklık veya basınç algılandığında valf kapanır ve ışık yanar. TRIP RESET ile sıfırlanır."},
  {q:"WING-BODY OVERHEAT ışığı neyi gösterir?", o:["Motor yangını","Sıcak bleed havası kaçağı","Paket arızası","Kanat buzlanması"], a:1, e:"Kanal kaçak algılama döngüleri sıcak hava kaçağını algılar."}]
},
{
 id:"elec", ata:"24", title:"Elektrik Gücü", en:"Electrical Power", diagram:"elec",
 summary:"Ana AC güç, motorlardaki IDG'lerden ve APU jeneratöründen gelir: 115V AC, 400 Hz, üç faz. DC güç TRU'lar ve batarya tarafından sağlanır: 28V DC. 737'de jeneratörler paralel çalışmaz, her bara aynı anda tek kaynaktan beslenir.",
 sections:[
  {h:"AC güç", list:[
   "<b>IDG (Integrated Drive Generator):</b> sabit hız tahriki (CSD) ve jeneratör bir aradadır. Değişken motor devrini sabit 400 Hz çıkışa çevirir. Tipik 90 kVA.",
   "IDG yağı yakıt-yağ ısı eşanjörüyle soğutulur. IDG'nin kendi yağ sistemi vardır.",
   "<b>IDG disconnect:</b> arıza durumunda kokpitten mekanik olarak ayrılır. Uçuşta yeniden bağlanamaz, yerde bakım tarafından resetlenir.",
   "<b>APU jeneratörü</b> ve <b>harici güç (external power)</b> alternatif kaynaklardır.",
   "<b>BTB (Bus Transfer Breaker):</b> kaynak kaybında transfer baralarını otomatik olarak diğer kaynağa aktarır.",
   "<b>GCU (Generator Control Unit):</b> voltaj regülasyonu ve koruma yapar (aşırı/düşük voltaj, frekans)."]},
  {h:"DC güç ve yedek güç", list:[
   "Üç TRU (Transformer Rectifier Unit) 115V AC'yi 28V DC'ye çevirir.",
   "Ana batarya: 24V nikel-kadmiyum. Batarya şarj cihazıyla şarj edilir.",
   "<b>Static inverter:</b> bataryanın DC gücünü 115V AC'ye çevirir ve AC standby barayı besler.",
   "Tüm jeneratörler kaybedilirse batarya, standby baraları belirli bir süre (temel konfigürasyonda yaklaşık 30 dakika) besler. Yardımcı batarya ile süre uzar.",
   "Hot battery bus: batarya anahtarı kapalıyken bile beslenen bara (ör. yangın tüpü squib'leri, bazı saatler)."]}
 ],
 cockpit:[
  "BAT anahtarı, STANDBY POWER anahtarı: BAT / OFF / AUTO",
  "GEN 1 / GEN 2, APU GEN 1/2 anahtarları, GRD POWER anahtarı",
  "TRANSFER BUS OFF, SOURCE OFF, GEN OFF BUS ışıkları",
  "DRIVE ışıkları ve IDG DISCONNECT anahtarları",
  "Elektrik ölçüm paneli: DC/AC voltaj, frekans, akım"],
 maint:[
  "Uçağa güç vermeden önce panelleri, devre kesicileri ve uyarı etiketlerini (tag) kontrol edin. Üzerinde çalışılan sistemin CB'si açık ve etiketli olmalıdır.",
  "Ni-Cd batarya elektroliti alkalidir (potasyum hidroksit). Asit bataryalarla aynı alet ve odayı paylaşmamalıdır.",
  "IDG reset işlemi, motor kapalıyken ve prosedürüne uygun yapılır.",
  "Konektör pinleri ve kablo hasarı için uygun bakım tekniklerini kullanın (ATA 20 standart uygulamalar)."],
 max:[
  "Temel AC/DC mimarisi benzerdir. Ekranlar ve bazı sistemlerin elektronik yükü farklıdır.",
  "MAX'te büyük ekranlı kokpit ve yeni sistemler (ör. fly-by-wire spoyler elektroniği) ek elektriksel yük getirir."],
 quiz:[
  {q:"737 AC sistemi frekansı nedir?", o:["50 Hz","60 Hz","400 Hz","Değişken"], a:2, e:"115V AC, 400 Hz, üç fazdır."},
  {q:"737 jeneratörleri paralel çalışır mı?", o:["Evet, her zaman","Hayır, her bara tek kaynaktan","Sadece yerde","Sadece APU ile"], a:1, e:"737'de jeneratörler paralellenmez. BTB'ler kaynak transferini yapar."},
  {q:"Static inverter ne yapar?", o:["AC'yi DC'ye çevirir","DC'yi AC'ye çevirir","Bataryayı şarj eder","Frekansı ayarlar"], a:1, e:"Bataryanın DC gücünü 115V AC'ye çevirip AC standby barayı besler."},
  {q:"IDG uçuşta disconnect edilirse ne olur?", o:["Kokpitten yeniden bağlanır","Uçuşta yeniden bağlanamaz","APU otomatik çalışır","Motor durur"], a:1, e:"IDG disconnect mekaniktir. Reset yerde bakım tarafından yapılır."}]
},
{
 id:"fuel", ata:"28", title:"Yakıt", en:"Fuel", diagram:"fuel",
 summary:"Yakıt üç tankta taşınır: iki ana kanat tankı ve merkez tank. Her tankta iki AC boost pompa vardır. Merkez tank yakıtı önce kullanılır. Crossfeed valfi gerektiğinde iki tarafı birleştirir.",
 sections:[
  {h:"Tanklar", list:[
   "Ana Tank 1 (sol kanat), Ana Tank 2 (sağ kanat), Merkez Tank (gövde ve kanat kökleri).",
   "Örnek 737-800 kullanılabilir yakıt: yaklaşık 6.875 US galon (yaklaşık 26.000 litre). Ana tanklar yaklaşık 1.288 gal, merkez yaklaşık 4.299 gal.",
   "Kanat uçlarında havalandırma ve taşma (surge) tankları bulunur. Tanklar dış havaya havalandırılır."]},
  {h:"Pompalar ve besleme", list:[
   "Ana tanklarda FWD ve AFT, merkez tankta L ve R olmak üzere ikişer AC pompa vardır.",
   "Merkez tank pompalarının çıkış basıncı daha yüksektir. İkisi de çalışırken önce merkez tanktan çekilir (override).",
   "Pompalar çalışmazsa motorlar ana tanklardan emme (suction feed) ile beslenebilir. Bu, irtifaya bağlı sınırlamalar getirir.",
   "Scavenge jet pump, merkez tanktaki artık yakıtı ana tank 1'e aktarır.",
   "<b>Engine fuel shutoff (spar) valfi:</b> kanat ön sparında bulunur. Start lever ve yangın anahtarıyla kapanır.",
   "Motor üzerinde motor tahrikli yakıt pompası, filtre ve HMU (hydromechanical unit) / FMU bulunur."]},
  {h:"İkmal ve gösterge", list:[
   "Tek nokta basınçlı ikmal (single point refueling) istasyonu sağ kanattadır.",
   "Miktar ölçümü tank içindeki kapasitif problarla yapılır. Ayrıca manuel ölçüm çubukları (measuring sticks) bulunur.",
   "Yakıt sıcaklığı ana tank 1'de ölçülür."]}
 ],
 cockpit:[
  "FUEL PUMPS anahtarları ve LOW PRESSURE ışıkları",
  "CROSSFEED seçici ve VALVE OPEN ışığı",
  "ENG VALVE CLOSED, SPAR VALVE CLOSED ışıkları",
  "FILTER BYPASS ışıkları",
  "Yakıt miktarı göstergesi (sistem ekranı), yakıt sıcaklığı"],
 maint:[
  "Tank içine giriş kapalı alan (confined space) çalışmasıdır. Havalandırma, gaz ölçümü, gözcü ve izin prosedürü zorunludur.",
  "İkmalde topraklama (bonding) kablosunu ilk bağlayın, son sökün.",
  "Su drenaj (sump drain) kontrollerini düzenli yapın. Su ve mikrobiyal kirlenme yakıt sistemine zarar verir.",
  "Kıvılcım çıkarmayan aletler ve antistatik ekipman kullanın."],
 max:[
  "Tank düzeni benzerdir. Yakıt tüketimi yeni motorlarla belirgin şekilde düşer.",
  "Yakıt göstergeleri büyük ekranlardadır."],
 quiz:[
  {q:"Hangi tank yakıtı önce kullanılır?", o:["Ana tank 1","Ana tank 2","Merkez tank","Hepsi aynı anda"], a:2, e:"Merkez tank pompaları daha yüksek basınçtadır, bu yüzden önce merkez tanktan çekilir."},
  {q:"Tek nokta ikmal istasyonu nerededir?", o:["Sol kanat","Sağ kanat","Burun","Kuyruk"], a:1, e:"Basınçlı ikmal istasyonu sağ kanattadır."},
  {q:"Spar valfi nerededir?", o:["Motor üzerinde","Kanat ön sparında","Merkez tankta","APU bölmesinde"], a:1, e:"Engine fuel shutoff (spar) valfi kanat ön sparındadır."},
  {q:"İkmalde topraklama kablosu ne zaman bağlanır?", o:["İkmalden sonra","Hortumdan önce, ilk","Hortumla aynı anda","Gerekmez"], a:1, e:"Bonding ilk bağlanır, son sökülür."}]
},
{
 id:"ac", ata:"21", title:"Klima ve Basınçlandırma", en:"Air Conditioning & Pressurization", diagram:null,
 summary:"İki klima paketi bleed havasını soğutur ve kabine verir. Basınçlandırma sistemi, arka gövdedeki outflow valfini açıp kapatarak kabin irtifasını kontrol eder.",
 sections:[
  {h:"Klima", list:[
   "<b>Paketler (packs):</b> her biri bir hava çevrim makinesi (ACM) içerir: kompresör ve türbin aynı şafttadır. Isı eşanjörleri ram havasıyla soğutulur.",
   "Ram hava giriş kapakları uçuşta paket ihtiyacına göre ayarlanır. Yerde tam açıktır.",
   "<b>Karışım manifoldu (mix manifold):</b> paket havası ile resirkülasyon havası burada karışır.",
   "Resirkülasyon fanları kabin havasının bir kısmını filtreleyip geri kullanır.",
   "Bölge sıcaklık kontrolü: kokpit, ön kabin ve arka kabin. Trim havası ile ince ayar yapılır.",
   "Elektronik ekipman soğutması (E&E cooling): besleme ve egzoz fanları, normal ve alternate."]},
  {h:"Basınçlandırma", list:[
   "Kabin basınç kontrol sistemi (CPCS): iki otomatik kontrolcü, bir alternate ve manuel mod.",
   "<b>Outflow valfi:</b> kabinden dışarı akan havayı ayarlayarak kabin irtifasını kontrol eder.",
   "Maksimum fark basıncı tipik 8,35 psi'dır. Güvenlik (relief) valfleri aşırı basıncı önler. Negatif basınç rahatlatma valfi de vardır.",
   "Kabin irtifası yaklaşık 10.000 ft'i aşarsa kabin irtifa uyarısı (aralıklı korna/uyarı) verilir."]}
 ],
 cockpit:["PACK anahtarları: OFF / AUTO / HIGH","RECIRC FAN anahtarları","PACK, ZONE TEMP ışıkları","Pressurization paneli: FLT ALT, LAND ALT, mod seçici AUTO / ALTN / MAN","Kabin irtifa ve fark basıncı göstergesi","EQUIP COOLING SUPPLY/EXHAUST anahtarları ve OFF ışıkları"],
 maint:["Paket çalıştırırken ram hava egzozu çevresi tehlikeli olabilir.","Yerde basınçlandırma testi özel prosedür ve güvenlik önlemleri gerektirir. Kapı ve panellerin durumu kontrol edilmelidir.","Resirkülasyon ve HEPA filtrelerini aralığına göre değiştirin.","Outflow valf bölgesinde yabancı madde olmamalıdır."],
 max:["MAX'te iç mekân (Boeing Sky Interior) ve bazı kontrol yazılımları farklıdır. Temel paket mimarisi benzerdir."],
 quiz:[
  {q:"ACM'de kompresör ve türbin nasıl bağlıdır?", o:["Dişliyle","Aynı şaftta","Ayrı motorlarla","Hidrolikle"], a:1, e:"Hava çevrim makinesinde kompresör ve türbin ortak şafttadır."},
  {q:"Kabin irtifasını doğrudan ne kontrol eder?", o:["Paket valfi","Outflow valfi","Ram kapağı","Recirc fan"], a:1, e:"Outflow valfinin açıklığı kabin irtifasını belirler."},
  {q:"Tipik maksimum fark basıncı?", o:["5,5 psi","8,35 psi","12 psi","3 psi"], a:1, e:"737NG için tipik değer 8,35 psi'dır."},
  {q:"Kabin irtifa uyarısı hangi irtifada verilir?", o:["8.000 ft","10.000 ft","14.000 ft","25.000 ft"], a:1, e:"Kabin irtifası yaklaşık 10.000 ft'i aşınca uyarı gelir."}]
},
{
 id:"fire", ata:"26", title:"Yangın Koruma", en:"Fire Protection", diagram:null,
 summary:"Motor, APU, kargo bölümleri, ana teker yuvası ve tuvaletlerde yangın veya duman algılama vardır. Motorlar, APU ve kargo bölümleri için söndürme sistemi bulunur.",
 sections:[
  {h:"Algılama", list:[
   "Her motorda iki algılama döngüsü (loop A ve loop B) vardır. Hem aşırı ısınma (overheat) hem yangın algılarlar.",
   "APU bölmesinde yangın dedektörü bulunur.",
   "Ana teker yuvasında yangın algılama döngüsü vardır. Söndürme yoktur, ekip takımı indirir.",
   "Ön ve arka kargo bölmesinde duman dedektörleri bulunur.",
   "Tuvaletlerde duman dedektörü ve çöp kutusunda otomatik söndürücü bulunur."]},
  {h:"Söndürme", list:[
   "Motorlar için iki tüp vardır. Her tüp iki motordan birine boşaltılabilir.",
   "APU için bir tüp vardır.",
   "Kargo için temel konfigürasyonda bir tüp vardır, ön veya arka bölmeye yönlendirilir.",
   "Tüpler squib (elektrikle ateşlenen küçük patlayıcı) ile boşaltılır."]},
  {h:"Motor yangın anahtarı çekilince", list:[
   "Motor yakıt kesme valfi (spar valf) kapanır", "Motor bleed valfi kapanır", "Jeneratör devreden çıkar", "Hidrolik kesme valfi kapanır, EDP LOW PRESSURE ışığı devre dışı kalır", "Reverser devre dışı kalır", "Söndürme squib'leri hazırlanır (arm). Anahtar çevrilince tüp boşalır."]}
 ],
 cockpit:["Engine fire switch (1, APU, 2): çek ve çevir","ENG OVERHEAT / FIRE ışıkları ve yangın zili","OVHT DET seçici: A / NORMAL / B","TEST anahtarı: FAULT/INOP ve OVHT/FIRE","CARGO FIRE paneli: ARM ve DISCH","BOTTLE DISCHARGE ışıkları"],
 maint:["Squib değişimi ve tüp sökümünde elektrik bağlantıları önce ayrılır. Statik elektrik riskine dikkat edin.","Tüp basıncı sıcaklığa bağlıdır. Basınç-sıcaklık tablosuyla değerlendirin.","Dedektör döngüleri ve konektörleri sürtünme ve kırılma için kontrol edin.","Tüp boşaltma sonrası, söndürücü madde temizliği ve ilgili bileşenlerin kontrolü gerekir."],
 max:["Algılama ve söndürme mantığı benzerdir. Gösterge ve uyarılar yeni kokpit ekranlarına uyarlanmıştır."],
 quiz:[
  {q:"Her motor yangın tüpü nereye boşaltılabilir?", o:["Yalnız kendi motoruna","İki motordan birine","APU'ya","Kargoya"], a:1, e:"İki motor tüpünden her biri iki motordan birine yönlendirilebilir."},
  {q:"Ana teker yuvası yangınında söndürme nasıl yapılır?", o:["Özel tüp ile","Söndürme yok, takım indirilir","Kargo tüpüyle","APU tüpüyle"], a:1, e:"Teker yuvasında yalnız algılama vardır."},
  {q:"Motor yangın anahtarı çekildiğinde hangisi OLMAZ?", o:["Spar valf kapanır","Bleed valfi kapanır","Tüp otomatik boşalır","Jeneratör ayrılır"], a:2, e:"Çekmek squib'leri hazırlar. Boşaltma için anahtar çevrilmelidir."},
  {q:"Motorda kaç algılama döngüsü vardır?", o:["1","2","3","4"], a:1, e:"Loop A ve loop B."}]
},
{
 id:"fc", ata:"27", title:"Uçuş Kumandaları", en:"Flight Controls", diagram:null,
 summary:"Birincil kumandalar (aileron, elevator, rudder) A ve B hidrolik sistemleriyle çalışan PCU'lar ile hareket eder. İkincil kumandalar: flaplar, slatlar, spoylerler ve stabilizer trim.",
 sections:[
  {h:"Birincil kumandalar", list:[
   "<b>Aileron:</b> A ve B ile çalışan iki PCU. İki sistem de kaybedilirse manuel kumandaya geçilir (manual reversion), balans tabları yardımcı olur.",
   "Roll kontrolüne flight spoylerlar yardım eder.",
   "<b>Elevator:</b> PCU'lar, elevator feel computer ve Mach trim. Manuel reversion'da tablar yardımcıdır.",
   "<b>Rudder:</b> A ve B ile ana rudder PCU, ayrıca standby hidrolikli standby rudder PCU. Yaw damper bulunur.",
   "Kokpitteki kumanda hareketi kablolar ve çubuklarla PCU'lara iletilir."]},
  {h:"İkincil kumandalar", list:[
   "<b>Firar kenarı flapları:</b> çift yarıklı (double slotted). Konumlar 1, 2, 5, 10, 15, 25, 30, 40. B sistemi hidrolik motoruyla, yedek olarak elektrik motoruyla sürülür.",
   "<b>Hücum kenarı cihazları:</b> iç bölümde Krueger flaplar, dış bölümde slatlar. Normalde B, alternatif olarak standby sistemle (yalnız açma).",
   "<b>Spoylerler:</b> her kanatta flight ve ground spoylerlar. Speed brake kolu ARMED konumunda inişte otomatik açılır.",
   "<b>Stabilizer trim:</b> elektrik motorları (ana elektrik ve otopilot) ile, yedek olarak manuel trim çarkları ile. Stab trim cutout anahtarları bulunur.",
   "<b>Autoslat:</b> yüksek hücum açısında slatları tam açık konuma götürür."]}
 ],
 cockpit:["FLT CONTROL A / B anahtarları","SPEED BRAKE kolu, SPEED BRAKE ARMED / DO NOT ARM ışıkları","Flap kolu ve flap konum göstergesi","ALTERNATE FLAPS anahtarları","STAB TRIM CUTOUT anahtarları ve trim çarkları","FEEL DIFF PRESS, YAW DAMPER, AUTO SLAT FAIL ışıkları"],
 maint:["Kumanda yüzeyi çevresinde çalışırken hidrolik pompaların istemeden çalıştırılmasını önlemek için uyarı etiketleri ve CB'ler kullanın.","Kablo gerginliği sıcaklığa bağlıdır. Tablo ile kontrol edilir.","Flap ve slat hareket testlerinde bölgenin personelden temiz olduğundan emin olun.","Rigging ve ayar işlemleri yalnız yetkili doküman ve özel aletle yapılır."],
 max:["Bazı spoyler panelleri elektriksel sinyalle (fly-by-wire) kumanda edilir.","<b>MCAS:</b> speed trim sisteminin parçasıdır. Flaplar kapalıyken, manuel uçuşta yüksek hücum açısında stabilizer trimi burun aşağı yönde ayarlar. 2020 sonrası güncellemelerle iki AOA sensörü karşılaştırılır, bir olayda bir kez devreye girer ve yetkisi sınırlıdır."],
 quiz:[
  {q:"A ve B sistemleri kaybedilirse aileron ne olur?", o:["Kilitlenir","Manuel reversion ile kumanda edilir","Standby ile çalışır","Elektrikle çalışır"], a:1, e:"Aileron ve elevator manuel reversion ile kumanda edilebilir."},
  {q:"Standby hidrolik hangi birincil kumandayı besler?", o:["Aileron","Elevator","Rudder","Spoyler"], a:2, e:"Standby rudder PCU standby sistemle çalışır."},
  {q:"TE flapların normal güç kaynağı?", o:["A sistemi","B sistemi","Standby","Pnömatik"], a:1, e:"B sistemi, yedek olarak elektrik motoru."},
  {q:"MCAS hangi yüzeyi kullanır?", o:["Elevator","Stabilizer trim","Spoyler","Rudder"], a:1, e:"MCAS stabilizer trimi burun aşağı yönde ayarlar."}]
},
{
 id:"ice", ata:"30", title:"Buz ve Yağmur Koruması", en:"Ice & Rain Protection", diagram:null,
 summary:"Kanat ve motor giriş buz önleme sistemleri bleed havası kullanır. Camlar, problar ve drenaj direkleri elektrikle ısıtılır. Ön camlarda silecekler bulunur.",
 sections:[
  {h:"Sistemler", list:[
   "<b>Kanat buz önleme (wing anti-ice):</b> bleed havası hücum kenarı slatlarının bir bölümüne verilir. Yerde kullanımında sıcaklık korumaları vardır.",
   "<b>Motor buz önleme (engine anti-ice):</b> motorun kendi bleed havası motor giriş kaportasının dudağını (inlet lip) ısıtır.",
   "<b>Prob ısıtma:</b> pitot tüpleri, AOA vanları, TAT probu ve bazı statik portlar elektrikle ısıtılır.",
   "<b>Cam ısıtma (window heat):</b> ön ve yan camlarda iletken film ile ısıtma yapılır. Aşırı ısınma koruması bulunur. Isıtma camı darbelere karşı daha esnek tutar.",
   "<b>Yağmur:</b> ön cam silecekleri."]}
 ],
 cockpit:["WING ANTI-ICE anahtarı ve VALVE OPEN ışıkları","ENG ANTI-ICE anahtarları ve COWL ANTI-ICE / COWL VALVE OPEN ışıkları","WINDOW HEAT anahtarları, OVERHEAT ve ON ışıkları, TEST anahtarı","PROBE HEAT anahtarları ve ışıkları","WIPER seçicileri"],
 maint:["Isıtılmış problar yerde çok sıcak olabilir. Çalışırken dokunmayın, prob kapakları ile çalıştırmayın.","Cam ısıtma bağlantılarında delaminasyon ve ark izi kontrol edin.","Kuru camda silecek çalıştırmak camı çizebilir."],
 max:["Temel mantık benzerdir. LEAP-1B giriş kaportası ve buz önleme detayları farklıdır."],
 quiz:[
  {q:"Motor giriş dudağı neyle ısıtılır?", o:["Elektrikle","Motor bleed havasıyla","Hidrolikle","Yakıtla"], a:1, e:"Motor anti-ice kendi motorunun bleed havasını kullanır."},
  {q:"Pitot tüpü nasıl ısıtılır?", o:["Bleed havası","Elektrik","Fan havası","Isıtılmaz"], a:1, e:"Problar elektrikle ısıtılır."},
  {q:"Prob kapağı takılıyken prob ısıtması açılırsa?", o:["Sorun olmaz","Kapak ve prob hasar görebilir","Sistem kapanır","Daha hızlı ısınır"], a:1, e:"Isı tahliye edilemez, hasar ve yangın riski oluşur."}]
},
{
 id:"lg", ata:"32", title:"İniş Takımı", en:"Landing Gear", diagram:null,
 summary:"Üç tekerli düzen: iki ana takım ve bir burun takımı. Takımlar A sistemi hidroliğiyle toplanır ve indirilir. Yedek olarak manuel serbest düşüş (manual extension) vardır.",
 sections:[
  {h:"Yapı", list:[
   "Amortisörler (shock strut) oleo-pnömatiktir: azot ve hidrolik sıvı içerir.",
   "Ana takımlar kanat yönünde içe doğru toplanır. Ana takım kapağı yoktur, teker yan yüzeyi ve hub cap aerodinamik kapanmayı sağlar.",
   "Burun takımı ileri doğru toplanır ve kapaklarla kapanır.",
   "Kilitler: yukarıda uplock, aşağıda downlock (yan destek / lock link)."]},
  {h:"Çalışma", list:[
   "Takım kolu: UP / OFF / DN. A sistemi kullanılır. LGTU ile B hacmi kullanılabilir.",
   "<b>Manuel indirme:</b> kokpit tabanındaki üç kol uplock'ları açar, takımlar yerçekimi ve hava akımıyla iner ve kilitlenir.",
   "<b>Hava/yer algılama:</b> PSEU (Proximity Switch Electronics Unit) yakınlık sensörleriyle takım ve kapı durumunu ve uçağın havada mı yerde mi olduğunu belirler.",
   "<b>Burun teker dümenlemesi:</b> tiller ile yaklaşık ±78°, rudder pedallarıyla yaklaşık ±7°. Towing sırasında bypass pimi takılır."]},
  {h:"Frenler", list:[
   "Çok diskli frenler (çelik veya karbon). Normal B, alternate A, ayrıca akümülatör.",
   "Antiskid her tekerleği ayrı izler.",
   "Autobrake: RTO, 1, 2, 3, MAX.",
   "Park freni akümülatör basıncıyla tutulabilir."]}
 ],
 cockpit:["Takım kolu ve takım göstergesi (yeşil: aşağıda kilitli, kırmızı: geçişte/uyumsuz)","AUTO BRAKE seçici, AUTO BRAKE DISARM ışığı","ANTISKID INOP ışığı","Fren basınç göstergesi","Park freni kolu ve ışığı","Manuel indirme kolları (tabanda)"],
 maint:["Takım bölgesinde çalışmadan önce takım emniyet pimlerini (gear pins) takın.","Lastik basıncını soğukken ölçün. Sıcak lastikte basıncı düşürmeyin, söndürmeyin.","Fren aşınma pimi (wear pin) ile aşınmayı kontrol edin.","Amortisör servisi (azot/sıvı) yük durumuna bağlı tabloya göre yapılır.","Burun teker towing sırasında bypass pimi takılı değilse dümenleme sistemi hasar görebilir."],
 max:["MAX 8'de burun takımı, daha büyük LEAP-1B fan çapı için yerden yüksekliği artırmak amacıyla uzatılmıştır (yaklaşık 8 inç).","MAX 10'da kalkışta gövde yüksekliğini artıran levered ana takım kullanılır."],
 quiz:[
  {q:"Takımların normal hidrolik kaynağı?", o:["A","B","Standby","Elektrik"], a:0, e:"A sistemi. LGTU ile B hacmi de kullanılabilir."},
  {q:"Ana takımda kapak var mı?", o:["Evet, iki kapak","Hayır","Yalnız burunda kapak yok","Sadece MAX'te"], a:1, e:"737 ana takım yuvasında kapak yoktur."},
  {q:"Hava/yer algılamayı hangi ünite yapar?", o:["ECU","PSEU","GCU","FMC"], a:1, e:"PSEU yakınlık sensörlerini işler."},
  {q:"Lastik basıncı ne zaman ölçülmelidir?", o:["İnişten hemen sonra","Soğukken","Uçuşta","Fark etmez"], a:1, e:"Doğru ölçüm soğuk lastikte yapılır."}]
},
{
 id:"eng", ata:"71-80", title:"Motor (CFM56-7B / LEAP-1B)", en:"Powerplant", diagram:"eng",
 summary:"737NG'de CFM56-7B, MAX'te CFM LEAP-1B motorları kullanılır. İkisi de iki şaftlı, yüksek bypass oranlı turbofan motorlardır ve FADEC ile kontrol edilir.",
 sections:[
  {h:"CFM56-7B (NG)", list:[
   "Fan + 3 kademeli booster (LPC), 9 kademeli HPC, 1 kademeli HPT, 4 kademeli LPT.",
   "Fan çapı yaklaşık 61 inç (155 cm), 24 fan kanadı.",
   "Bypass oranı yaklaşık 5:1."]},
  {h:"LEAP-1B (MAX)", list:[
   "Fan + 3 kademeli booster, 10 kademeli HPC, 2 kademeli HPT, 5 kademeli LPT.",
   "Fan çapı yaklaşık 69 inç (176 cm), 18 adet 3D örgülü kompozit fan kanadı.",
   "Bypass oranı yaklaşık 9:1. Bazı sıcak bölüm parçalarında seramik matris kompozit (CMC) kullanılır."]},
  {h:"Ortak sistemler", list:[
   "<b>N1:</b> fan ve düşük basınç rotoru. <b>N2:</b> yüksek basınç rotoru.",
   "<b>FADEC / EEC:</b> çift kanallı elektronik motor kontrolü. Yakıt akışını HMU üzerinden yönetir, motoru limitler içinde tutar.",
   "<b>Aksesuar dişli kutusu (AGB):</b> N2'den radyal şaftla tahrik edilir. IDG, EDP, yakıt pompası, yağ pompası ve pnömatik marş motoru bağlıdır.",
   "<b>Start:</b> pnömatik marş motoru. Start valfi açılır, N2 döner. Yeterli devirde yakıt ve ateşleme verilir.",
   "<b>Ateşleme:</b> motor başına iki ateşleyici (sol ve sağ).",
   "<b>Thrust reverser:</b> fan havası yönlendirmeli kaydırmalı (translating sleeve) tip, hidrolikle çalışır.",
   "EGT, yağ basıncı, yağ sıcaklığı, yağ miktarı ve titreşim izlenir."]}
 ],
 cockpit:["Thrust leverlar ve reverser kolları","Start lever: CUTOFF / IDLE","Engine start anahtarları: GRD / OFF / CONT / FLT","IGNITION seçici: L / BOTH / R","Motor göstergeleri: N1, EGT, N2, yakıt akışı, yağ, titreşim","EEC anahtarları ve ENGINE CONTROL ışıkları","REVERSER ışıkları"],
 maint:["Motor çalışırken giriş (emme) ve egzoz tehlike bölgelerine kesinlikle girmeyin. Bölgeler yer çalıştırma prosedüründe tanımlıdır.","Yağ seviyesi kontrolü motor durduktan sonra belirtilen süre içinde yapılır.","Reverser üzerinde çalışırken deaktivasyon (lockout) pimleri ve prosedürü kullanılır.","Ateşleme sistemi yüksek enerjilidir. Ateşleyici sökmeden önce sistemin kapalı ve beklenmiş olması gerekir.","Borescope muayenesi iç hasar tespitinde temel yöntemdir."],
 max:["LEAP-1B daha büyük fan çapına sahiptir. Bu yüzden motor kanadın daha önünde ve yukarısında konumlandırılmıştır.","Kaportada egzoz ses azaltma için tırtıklı (chevron) nozul bulunur.","Daha yüksek bypass oranı sayesinde yakıt tüketimi NG'ye göre yaklaşık %14 civarında daha düşüktür (Boeing verisi, karşılaştırma koşullarına göre değişir)."],
 quiz:[
  {q:"CFM56-7B HPC kaç kademelidir?", o:["9","10","5","14"], a:0, e:"CFM56-7B'de 9, LEAP-1B'de 10 kademe."},
  {q:"AGB hangi rotordan tahrik edilir?", o:["N1","N2","Fan","LPT"], a:1, e:"AGB, N2 rotorundan radyal şaftla tahrik edilir."},
  {q:"LEAP-1B fan kanatları neyden yapılır?", o:["Titanyum","3D örgülü kompozit","Alüminyum","Çelik"], a:1, e:"18 adet 3D örgülü karbon kompozit kanat."},
  {q:"Motor başına kaç ateşleyici vardır?", o:["1","2","3","4"], a:1, e:"Sol ve sağ olmak üzere iki ateşleyici."}]
}
];

window.DIFFS = [
 ["Motor","CFM56-7B","LEAP-1B"],
 ["Fan çapı","~61 inç (155 cm)","~69 inç (176 cm)"],
 ["Fan kanadı","24, titanyum","18, 3D örgülü kompozit"],
 ["HPC / HPT / LPT kademe","9 / 1 / 4","10 / 2 / 5"],
 ["Bleed kademeleri","5. ve 9.","4. ve 10."],
 ["Kanat ucu","Blended winglet (ops.) / split scimitar","Advanced Technology (AT) winglet"],
 ["Kokpit ekranları","6 adet ekran (DU)","4 adet büyük (15,1 inç) ekran"],
 ["Spoyler kumandası","Mekanik + hidrolik","Bazı paneller fly-by-wire"],
 ["Burun takımı","Standart","MAX 8'de ~8 inç uzatılmış"],
 ["Uçuş kontrol yazılımı","–","MCAS (speed trim sisteminin parçası)"],
 ["Kuyruk konisi","Standart","Yeniden şekillendirilmiş arka gövde"],
 ["Motor nozulu","Düz","Chevron (tırtıklı)"]
];

window.GLOSSARY = [
 ["AMM","Aircraft Maintenance Manual","Uçak Bakım El Kitabı. Uçak üzerindeki bakım görevleri, servis, test ve söküm-takma prosedürleri."],
 ["CMM","Component Maintenance Manual","Komponent Bakım El Kitabı. Uçaktan sökülen parçanın atölyede onarım ve testi."],
 ["IPC","Illustrated Parts Catalog","Resimli parça kataloğu. Parça numaraları ve yerleşimi."],
 ["SRM","Structural Repair Manual","Yapısal onarım el kitabı. Hasar limitleri ve onarımlar."],
 ["WDM","Wiring Diagram Manual","Kablo şeması el kitabı."],
 ["SSM","System Schematics Manual","Sistem şemaları el kitabı."],
 ["FIM","Fault Isolation Manual","Arıza izolasyon el kitabı (737NG/MAX için)."],
 ["MEL","Minimum Equipment List","Asgari ekipman listesi. Arızalı ekipmanla uçuş koşulları."],
 ["DDG","Dispatch Deviations Guide","MEL maddeleri için bakım ve operasyon prosedürleri rehberi."],
 ["AD","Airworthiness Directive","Uçuşa elverişlilik direktifi. Otorite tarafından zorunlu kılınır."],
 ["SB","Service Bulletin","Üreticinin servis bülteni."],
 ["ATA 100 / iSpec 2200","ATA chapter","Sistemlerin bölüm numaralandırma standardı (ör. 29 hidrolik, 49 APU)."],
 ["APU","Auxiliary Power Unit","Yardımcı güç ünitesi."],
 ["ECU","Electronic Control Unit","APU elektronik kontrol ünitesi."],
 ["EEC / FADEC","Electronic Engine Control / Full Authority Digital Engine Control","Tam yetkili dijital motor kontrolü."],
 ["HMU","Hydromechanical Unit","Motor yakıt ölçüm ünitesi."],
 ["AGB","Accessory Gearbox","Aksesuar dişli kutusu."],
 ["N1 / N2","Low / High pressure rotor speed","Düşük ve yüksek basınç rotor devri."],
 ["EGT","Exhaust Gas Temperature","Egzoz gazı sıcaklığı."],
 ["IDG","Integrated Drive Generator","Entegre tahrikli jeneratör."],
 ["GCU","Generator Control Unit","Jeneratör kontrol ünitesi."],
 ["BTB","Bus Transfer Breaker","Bara transfer kesicisi."],
 ["TRU","Transformer Rectifier Unit","Transformatör doğrultucu ünitesi (AC→DC)."],
 ["CB","Circuit Breaker","Devre kesici."],
 ["EDP","Engine Driven Pump","Motor tahrikli hidrolik pompa."],
 ["EMDP / ACMP","Electric Motor Driven Pump","Elektrik motorlu hidrolik pompa."],
 ["PTU","Power Transfer Unit","Güç transfer ünitesi (A → B)."],
 ["LGTU","Landing Gear Transfer Unit","İniş takımı transfer ünitesi."],
 ["PCU","Power Control Unit","Kumanda yüzeyi hidrolik aktüatörü."],
 ["PRSOV","Pressure Regulating & Shutoff Valve","Basınç düzenleme ve kesme valfi."],
 ["ACM","Air Cycle Machine","Hava çevrim makinesi."],
 ["CPCS","Cabin Pressure Control System","Kabin basınç kontrol sistemi."],
 ["PSEU","Proximity Switch Electronics Unit","Yakınlık anahtarı elektronik ünitesi."],
 ["AOA","Angle of Attack","Hücum açısı."],
 ["MCAS","Maneuvering Characteristics Augmentation System","MAX manevra karakteristiği artırma sistemi."],
 ["TAT","Total Air Temperature","Toplam hava sıcaklığı."],
 ["BITE","Built-In Test Equipment","Dahili test donanımı."],
 ["LRU","Line Replaceable Unit","Hatta değiştirilebilir ünite."],
 ["LVDT / RVDT","Linear / Rotary Variable Differential Transformer","Konum sensörleri."],
 ["Squib","Cartridge","Yangın tüpünü boşaltan elektrikli patlayıcı kartuş."],
 ["Bonding","Elektriksel bağlama","Parçalar arası aynı potansiyel; statik ve yıldırım koruması."]
];
