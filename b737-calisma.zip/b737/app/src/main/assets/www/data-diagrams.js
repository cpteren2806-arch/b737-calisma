// Özgün, basitleştirilmiş eğitim şemaları (ölçeksiz). AMM şeması değildir.
window.DIAGRAMS = {
apu: `<svg viewBox="0 0 360 300" class="dg" role="img" aria-label="APU şeması">
<defs><marker id="ar1" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" class="ah"/></marker></defs>
<text x="180" y="16" class="tt">APU – kuyruk konisi (basitleştirilmiş)</text>
<rect x="10" y="40" width="70" height="40" rx="6" class="bx b2"/><text x="45" y="58" class="tx">Hava girişi</text><text x="45" y="71" class="ts">inlet door</text>
<rect x="110" y="30" width="140" height="120" rx="10" class="bx"/>
<text x="180" y="48" class="tx">APU (131-9B)</text>
<rect x="120" y="58" width="55" height="34" rx="4" class="bx b3"/><text x="147" y="73" class="ts">Kompresör</text><text x="147" y="85" class="ts">(load comp.)</text>
<rect x="185" y="58" width="55" height="34" rx="4" class="bx b3"/><text x="212" y="73" class="ts">Yanma +</text><text x="212" y="85" class="ts">türbin</text>
<rect x="120" y="102" width="120" height="38" rx="4" class="bx b3"/><text x="180" y="118" class="ts">Dişli kutusu (gearbox)</text><text x="180" y="131" class="ts">yağ pompası, yakıt kontrol</text>
<rect x="275" y="45" width="75" height="40" rx="6" class="bx b2"/><text x="312" y="63" class="tx">Egzoz</text><text x="312" y="76" class="ts">kuyruk ucu</text>
<line x1="80" y1="60" x2="118" y2="70" class="ln" marker-end="url(#ar1)"/>
<line x1="250" y1="70" x2="273" y2="65" class="ln" marker-end="url(#ar1)"/>
<rect x="10" y="170" width="100" height="42" rx="6" class="bx b4"/><text x="60" y="188" class="tx">Jeneratör</text><text x="60" y="201" class="ts">90 kVA, 115V AC</text>
<line x1="110" y1="135" x2="62" y2="168" class="ln" marker-end="url(#ar1)"/>
<rect x="130" y="170" width="100" height="42" rx="6" class="bx b5"/><text x="180" y="188" class="tx">APU bleed valf</text><text x="180" y="201" class="ts">→ pnömatik kanal</text>
<line x1="180" y1="150" x2="180" y2="168" class="ln" marker-end="url(#ar1)"/>
<rect x="250" y="170" width="100" height="42" rx="6" class="bx b6"/><text x="300" y="188" class="tx">ECU</text><text x="300" y="201" class="ts">elektronik kontrol</text>
<line x1="300" y1="170" x2="252" y2="140" class="ln dash"/>
<rect x="10" y="240" width="160" height="42" rx="6" class="bx b1"/><text x="90" y="258" class="tx">Yakıt: sol manifold</text><text x="90" y="271" class="ts">APU yakıt kesme valfi</text>
<line x1="120" y1="240" x2="120" y2="153" class="ln" marker-end="url(#ar1)"/>
<rect x="190" y="240" width="160" height="42" rx="6" class="bx b6"/><text x="270" y="258" class="tx">Yangın: 1 tüp</text><text x="270" y="271" class="ts">dedektör + söndürücü</text>
</svg>`,

hyd: `<svg viewBox="0 0 360 330" class="dg" role="img" aria-label="Hidrolik sistem şeması">
<defs><marker id="ar2" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" class="ah"/></marker></defs>
<text x="180" y="16" class="tt">Hidrolik: A – B – Standby (3000 psi)</text>
<rect x="8" y="30" width="105" height="120" rx="8" class="bx b1"/>
<text x="60" y="48" class="tx">Sistem A</text>
<text x="60" y="66" class="ts">EDP – Motor 1</text><text x="60" y="80" class="ts">EMDP (elektrikli)</text><text x="60" y="94" class="ts">Rezervuar (bleed</text><text x="60" y="106" class="ts">havasıyla basınçlı)</text>
<rect x="128" y="30" width="105" height="120" rx="8" class="bx b2"/>
<text x="180" y="48" class="tx">Sistem B</text>
<text x="180" y="66" class="ts">EDP – Motor 2</text><text x="180" y="80" class="ts">EMDP (elektrikli)</text><text x="180" y="94" class="ts">Rezervuar</text><text x="180" y="106" class="ts">(standby'ı da besler)</text>
<rect x="248" y="30" width="105" height="120" rx="8" class="bx b5"/>
<text x="300" y="48" class="tx">Standby</text>
<text x="300" y="66" class="ts">Elektrikli pompa</text><text x="300" y="80" class="ts">Kendi rezervuarı</text><text x="300" y="94" class="ts">(B'den beslenir)</text>
<rect x="100" y="165" width="160" height="32" rx="6" class="bx b3"/><text x="180" y="185" class="tx">PTU  (A basıncı → B hacmi)</text>
<line x1="70" y1="150" x2="110" y2="165" class="ln" marker-end="url(#ar2)"/>
<line x1="250" y1="165" x2="200" y2="152" class="ln" marker-end="url(#ar2)"/>
<rect x="8" y="215" width="105" height="105" rx="8" class="bx b4"/>
<text x="60" y="232" class="ts">• İniş takımı</text><text x="60" y="246" class="ts">• Burun teker dümen.</text><text x="60" y="260" class="ts">• Alternate fren</text><text x="60" y="274" class="ts">• Ground spoyler</text><text x="60" y="288" class="ts">• Reverser 1, A/P A</text><text x="60" y="302" class="ts">• Kumanda yüzeyleri</text>
<rect x="128" y="215" width="105" height="105" rx="8" class="bx b4"/>
<text x="180" y="232" class="ts">• Normal fren</text><text x="180" y="246" class="ts">• TE flap, LE cihazlar</text><text x="180" y="260" class="ts">• Autoslat, yaw damper</text><text x="180" y="274" class="ts">• Reverser 2, A/P B</text><text x="180" y="288" class="ts">• Gear transfer (LGTU)</text><text x="180" y="302" class="ts">• Kumanda yüzeyleri</text>
<rect x="248" y="215" width="105" height="105" rx="8" class="bx b4"/>
<text x="300" y="232" class="ts">• Standby rudder</text><text x="300" y="246" class="ts">• Reverserlar</text><text x="300" y="260" class="ts">• LE flap/slat</text><text x="300" y="274" class="ts">(yalnız açma)</text><text x="300" y="288" class="ts">• Yaw damper</text><text x="300" y="302" class="ts">(bazı konfig.)</text>
<line x1="60" y1="197" x2="60" y2="213" class="ln" marker-end="url(#ar2)"/><line x1="180" y1="197" x2="180" y2="213" class="ln" marker-end="url(#ar2)"/><line x1="300" y1="150" x2="300" y2="213" class="ln" marker-end="url(#ar2)"/>
</svg>`,

pneu: `<svg viewBox="0 0 360 300" class="dg" role="img" aria-label="Pnömatik sistem şeması">
<defs><marker id="ar3" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" class="ah"/></marker></defs>
<text x="180" y="16" class="tt">Pnömatik (bleed air) – bir taraf</text>
<rect x="10" y="30" width="110" height="100" rx="8" class="bx b2"/>
<text x="65" y="48" class="tx">Motor HPC</text>
<text x="65" y="66" class="ts">Düşük kademe</text><text x="65" y="79" class="ts">NG: 5. / MAX: 4.</text>
<text x="65" y="98" class="ts">Yüksek kademe</text><text x="65" y="111" class="ts">NG: 9. / MAX: 10.</text>
<rect x="140" y="85" width="90" height="34" rx="6" class="bx b3"/><text x="185" y="100" class="ts">High stage valf</text><text x="185" y="112" class="ts">(düşük güçte açık)</text>
<line x1="120" y1="104" x2="138" y2="102" class="ln" marker-end="url(#ar3)"/>
<rect x="140" y="35" width="90" height="34" rx="6" class="bx b3"/><text x="185" y="50" class="ts">Check valf</text><text x="185" y="62" class="ts">(düşük kademe)</text>
<line x1="120" y1="56" x2="138" y2="52" class="ln" marker-end="url(#ar3)"/>
<rect x="250" y="55" width="100" height="44" rx="6" class="bx b5"/><text x="300" y="73" class="tx">PRSOV</text><text x="300" y="87" class="ts">engine bleed valf</text>
<line x1="230" y1="52" x2="250" y2="70" class="ln" marker-end="url(#ar3)"/><line x1="230" y1="102" x2="250" y2="85" class="ln" marker-end="url(#ar3)"/>
<rect x="250" y="118" width="100" height="44" rx="6" class="bx b1"/><text x="300" y="136" class="tx">Precooler</text><text x="300" y="150" class="ts">fan havasıyla soğutma</text>
<line x1="300" y1="99" x2="300" y2="116" class="ln" marker-end="url(#ar3)"/>
<rect x="10" y="185" width="340" height="36" rx="6" class="bx b6"/><text x="180" y="201" class="tx">Pnömatik manifold</text><text x="180" y="214" class="ts">İzolasyon valfi ↔ karşı taraf · APU · yer arabası</text>
<line x1="300" y1="162" x2="300" y2="183" class="ln" marker-end="url(#ar3)"/>
<rect x="10" y="240" width="76" height="46" rx="6" class="bx b4"/><text x="48" y="260" class="ts">Paketler</text><text x="48" y="274" class="ts">(klima)</text>
<rect x="96" y="240" width="76" height="46" rx="6" class="bx b4"/><text x="134" y="260" class="ts">Kanat/motor</text><text x="134" y="274" class="ts">anti-ice</text>
<rect x="182" y="240" width="76" height="46" rx="6" class="bx b4"/><text x="220" y="260" class="ts">Motor</text><text x="220" y="274" class="ts">marşı</text>
<rect x="268" y="240" width="82" height="46" rx="6" class="bx b4"/><text x="309" y="260" class="ts">Hid. rezervuar</text><text x="309" y="274" class="ts">+ su tankı bas.</text>
<line x1="48" y1="221" x2="48" y2="238" class="ln" marker-end="url(#ar3)"/><line x1="134" y1="221" x2="134" y2="238" class="ln" marker-end="url(#ar3)"/><line x1="220" y1="221" x2="220" y2="238" class="ln" marker-end="url(#ar3)"/><line x1="309" y1="221" x2="309" y2="238" class="ln" marker-end="url(#ar3)"/>
</svg>`,

elec: `<svg viewBox="0 0 360 330" class="dg" role="img" aria-label="Elektrik sistemi şeması">
<defs><marker id="ar4" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" class="ah"/></marker></defs>
<text x="180" y="16" class="tt">Elektrik – ana kaynaklar ve baralar</text>
<rect x="8" y="30" width="80" height="40" rx="6" class="bx b2"/><text x="48" y="48" class="tx">IDG 1</text><text x="48" y="61" class="ts">90 kVA</text>
<rect x="140" y="30" width="80" height="40" rx="6" class="bx b5"/><text x="180" y="48" class="tx">APU GEN</text><text x="180" y="61" class="ts">/ Harici güç</text>
<rect x="272" y="30" width="80" height="40" rx="6" class="bx b2"/><text x="312" y="48" class="tx">IDG 2</text><text x="312" y="61" class="ts">90 kVA</text>
<rect x="8" y="100" width="150" height="34" rx="6" class="bx b3"/><text x="83" y="121" class="tx">AC Transfer Bus 1</text>
<rect x="202" y="100" width="150" height="34" rx="6" class="bx b3"/><text x="277" y="121" class="tx">AC Transfer Bus 2</text>
<line x1="48" y1="70" x2="48" y2="98" class="ln" marker-end="url(#ar4)"/><line x1="312" y1="70" x2="312" y2="98" class="ln" marker-end="url(#ar4)"/>
<line x1="165" y1="70" x2="110" y2="98" class="ln dash" marker-end="url(#ar4)"/><line x1="195" y1="70" x2="250" y2="98" class="ln dash" marker-end="url(#ar4)"/>
<text x="180" y="90" class="tx">BTB</text>
<rect x="8" y="160" width="100" height="40" rx="6" class="bx b1"/><text x="58" y="178" class="tx">TRU 1</text><text x="58" y="191" class="ts">115VAC→28VDC</text>
<rect x="130" y="160" width="100" height="40" rx="6" class="bx b1"/><text x="180" y="178" class="tx">TRU 3</text><text x="180" y="191" class="ts">yedek/batarya bara</text>
<rect x="252" y="160" width="100" height="40" rx="6" class="bx b1"/><text x="302" y="178" class="tx">TRU 2</text><text x="302" y="191" class="ts">115VAC→28VDC</text>
<line x1="58" y1="134" x2="58" y2="158" class="ln" marker-end="url(#ar4)"/><line x1="302" y1="134" x2="302" y2="158" class="ln" marker-end="url(#ar4)"/><line x1="240" y1="134" x2="200" y2="158" class="ln" marker-end="url(#ar4)"/>
<rect x="8" y="222" width="150" height="34" rx="6" class="bx b6"/><text x="83" y="243" class="tx">DC Bus 1 / 2</text>
<rect x="202" y="222" width="150" height="34" rx="6" class="bx b6"/><text x="277" y="243" class="tx">Battery Bus / Hot Bat.</text>
<line x1="58" y1="200" x2="58" y2="220" class="ln" marker-end="url(#ar4)"/><line x1="200" y1="200" x2="240" y2="220" class="ln" marker-end="url(#ar4)"/>
<rect x="8" y="276" width="150" height="44" rx="6" class="bx b4"/><text x="83" y="294" class="tx">Batarya 24V</text><text x="83" y="308" class="ts">Ni-Cd, yedek güç</text>
<rect x="202" y="276" width="150" height="44" rx="6" class="bx b4"/><text x="277" y="294" class="tx">Static inverter</text><text x="277" y="308" class="ts">DC→115V AC Standby Bus</text>
<line x1="158" y1="298" x2="200" y2="298" class="ln" marker-end="url(#ar4)"/>
</svg>`,

fuel: `<svg viewBox="0 0 360 260" class="dg" role="img" aria-label="Yakıt sistemi şeması">
<defs><marker id="ar5" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" class="ah"/></marker></defs>
<text x="180" y="16" class="tt">Yakıt – üç tank, ön görünüş (basit)</text>
<polygon points="10,60 120,70 120,120 10,105" class="bx b2"/><text x="65" y="88" class="tx">Ana Tank 1</text><text x="65" y="101" class="ts">FWD + AFT pompa</text>
<rect x="130" y="65" width="100" height="60" rx="6" class="bx b5"/><text x="180" y="88" class="tx">Merkez Tank</text><text x="180" y="102" class="ts">L + R pompa</text><text x="180" y="115" class="ts">(önce kullanılır)</text>
<polygon points="240,70 350,60 350,105 240,120" class="bx b2"/><text x="295" y="88" class="tx">Ana Tank 2</text><text x="295" y="101" class="ts">FWD + AFT pompa</text>
<rect x="10" y="150" width="340" height="30" rx="6" class="bx b3"/><text x="180" y="169" class="tx">Motor besleme manifoldu ── Crossfeed valfi ──</text>
<line x1="65" y1="118" x2="65" y2="148" class="ln" marker-end="url(#ar5)"/><line x1="180" y1="125" x2="180" y2="148" class="ln" marker-end="url(#ar5)"/><line x1="295" y1="118" x2="295" y2="148" class="ln" marker-end="url(#ar5)"/>
<rect x="10" y="200" width="100" height="48" rx="6" class="bx b4"/><text x="60" y="218" class="tx">Motor 1</text><text x="60" y="232" class="ts">spar valf → EDP</text><text x="60" y="244" class="ts">pompa + filtre</text>
<rect x="130" y="200" width="100" height="48" rx="6" class="bx b6"/><text x="180" y="218" class="tx">APU</text><text x="180" y="232" class="ts">sol taraftan</text><text x="180" y="244" class="ts">beslenir</text>
<rect x="250" y="200" width="100" height="48" rx="6" class="bx b4"/><text x="300" y="218" class="tx">Motor 2</text><text x="300" y="232" class="ts">spar valf → EDP</text><text x="300" y="244" class="ts">pompa + filtre</text>
<line x1="60" y1="180" x2="60" y2="198" class="ln" marker-end="url(#ar5)"/><line x1="120" y1="180" x2="170" y2="198" class="ln" marker-end="url(#ar5)"/><line x1="300" y1="180" x2="300" y2="198" class="ln" marker-end="url(#ar5)"/>
<text x="180" y="44" class="ts">Tek nokta yakıt ikmali: sağ kanat</text>
</svg>`,

eng: `<svg viewBox="0 0 360 240" class="dg" role="img" aria-label="Motor kesit şeması">
<defs><marker id="ar6" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" class="ah"/></marker></defs>
<text x="180" y="16" class="tt">Turbofan modülleri (CFM56-7B / LEAP-1B)</text>
<rect x="10" y="40" width="50" height="150" rx="6" class="bx b2"/><text x="35" y="110" class="tx">Fan</text><text x="35" y="124" class="ts">N1</text>
<rect x="64" y="70" width="44" height="90" rx="4" class="bx b2"/><text x="86" y="110" class="ts">LPC</text><text x="86" y="122" class="ts">booster</text>
<rect x="112" y="80" width="70" height="70" rx="4" class="bx b3"/><text x="147" y="110" class="ts">HPC</text><text x="147" y="122" class="ts">N2</text>
<rect x="186" y="85" width="44" height="60" rx="4" class="bx b5"/><text x="208" y="112" class="ts">Yanma</text><text x="208" y="124" class="ts">odası</text>
<rect x="234" y="85" width="36" height="60" rx="4" class="bx b3"/><text x="252" y="112" class="ts">HPT</text><text x="252" y="124" class="ts">N2</text>
<rect x="274" y="75" width="76" height="80" rx="4" class="bx b2"/><text x="312" y="112" class="ts">LPT</text><text x="312" y="124" class="ts">N1</text>
<line x1="60" y1="55" x2="350" y2="55" class="ln" marker-end="url(#ar6)"/><text x="200" y="50" class="ts">Fan (bypass) havası</text>
<rect x="112" y="170" width="120" height="30" rx="4" class="bx b4"/><text x="172" y="189" class="ts">Aksesuar dişli kutusu (AGB)</text>
<line x1="147" y1="150" x2="160" y2="168" class="ln dash"/>
<text x="180" y="222" class="ts">AGB: IDG, EDP, yakıt pompası/HMU, yağ pompası, pnömatik marş</text>
</svg>`
};
