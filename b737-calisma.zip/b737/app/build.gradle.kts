plugins {
    id("com.android.application")
}

android {
    namespace = "com.b737.calisma"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.b737.calisma"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

}
