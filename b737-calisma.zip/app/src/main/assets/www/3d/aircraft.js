// "3D Sistemler" giriş sahnesi: saydam 737-800 ve içindeki sistem bölgeleri.
// Ölçüler yaklaşık (737-800: boy 39,5 m, gövde çapı 3,76 m, kanat açıklığı 35,8 m). İstasyonlar (STA) inçtir: x(m) = (STA-130)·0,0254.
import * as THREE from './three.module.js';
import { OrbitControls } from './OrbitControls.js';
import { RoomEnvironment } from './RoomEnvironment.js';
import { mergeGeometries } from './BufferGeometryUtils.js';

const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const sta = s => (s - 130) * 0.0254;
const FF = '"Roboto Condensed","Arial Narrow",sans-serif';

// gövde kesiti: x boyunca yarıçap (yatay/dikey) ve merkez yüksekliği
function prof(x) {
  const L = 39.5;
  if (x < 4.2) { const t = x / 4.2, k = Math.sqrt(1 - Math.pow(1 - t, 2.2)); return { rz: 1.88 * k, ry: 2.0 * k, cy: -0.55 * (1 - t) * (1 - t) }; }
  if (x < 28) return { rz: 1.88, ry: 2.0, cy: 0 };
  const t = (x - 28) / (L - 28), k = 1 - t * 0.82;
  return { rz: 1.88 * k, ry: 2.0 * k * (1 - t * 0.1), cy: t * t * 1.35 };
}
function fuselageGeo() {
  const nx = 90, nr = 40, pos = [], idx = [];
  for (let i = 0; i <= nx; i++) {
    const x = 39.5 * Math.pow(i / nx, 1.0), p = prof(x);
    for (let j = 0; j <= nr; j++) { const a = j / nr * Math.PI * 2; pos.push(x, p.cy + Math.cos(a) * p.ry, Math.sin(a) * p.rz); }
  }
  for (let i = 0; i < nx; i++) for (let j = 0; j < nr; j++) { const a = i * (nr + 1) + j, b = a + nr + 1; idx.push(a, b, a + 1, b, b + 1, a + 1); }
  const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals(); return g;
}
// kanat benzeri yüzey: kök (x0,chord,z0,y0) → uç (x1,chord1,z1,y1)
function surface(r, t, thick = 0.25) {
  const pts = [[r.x, r.y, r.z], [r.x + r.c, r.y, r.z], [t.x + t.c, t.y, t.z], [t.x, t.y, t.z]];
  const pos = [], idx = [];
  for (const s of [1, -1]) for (const [x, y, z] of pts) pos.push(x, y + s * thick / 2 * (z === r.z ? 1 : 0.35), z);
  const q = (a, b, c, d) => idx.push(a, b, c, a, c, d);
  q(0, 1, 2, 3); q(7, 6, 5, 4); q(0, 4, 5, 1); q(1, 5, 6, 2); q(2, 6, 7, 3); q(3, 7, 4, 0);
  const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals(); return g;
}
function labelSprite(txt, sub, col) {
  const c = document.createElement("canvas"); c.width = 512; c.height = 160; const g = c.getContext("2d");
  g.fillStyle = "rgba(14,22,32,.86)"; g.beginPath(); g.roundRect(4, 4, 504, 152, 30); g.fill(); g.strokeStyle = col; g.lineWidth = 6; g.stroke();
  g.fillStyle = "#fff"; g.textAlign = "center"; g.textBaseline = "middle"; g.font = `700 54px ${FF}`; g.fillText(txt, 256, sub ? 58 : 80);
  if (sub) { g.font = `500 34px ${FF}`; g.fillStyle = "#c9d6e2"; g.fillText(sub, 256, 116); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, depthTest: false, transparent: true })); s.scale.set(5.6, 1.75, 1); s.renderOrder = 10; return s;
}

export const ZONES = [
  { id: "ckpt", t: "Kokpit", s: "Paneller, anahtarlar, devreler", col: "#4fb3ff", at: [sta(230), 2.6, 0], go: "#/3d/kokpit",
    d: "Uçuş güvertesi (STA 178–ya. 260). İçine gir: overhead, glareshield, gösterge panelleri, orta konsol ve devre kesici panelleri." },
  { id: "ee", t: "E/E bölmesi", s: "E1–E6 rafları", col: "#ffae42", at: [sta(330), -2.6, 0], go: "#/3d/ee",
    d: "Kokpitin altındaki elektronik ekipman bölmesi (raflar STA 302–368). Aviyonik bilgisayarlar, TRU'lar, batarya, statik inverter." },
  { id: "apu", t: "APU", s: "Honeywell 131-9B", col: "#ff6b5a", at: [38.0, 2.9, 0], go: "#/3d/apu",
    d: "Kuyruk konisindeki yardımcı güç ünitesi: yerde elektrik ve bleed havası sağlar." },
  { id: "eng", t: "Motorlar", s: "CFM56-7B", col: "#b8c4cf", at: [13.6, -0.6, 7.5], go: "#/c/eng",
    d: "İki CFM56-7B turbofan; IDG, motor tahrikli hidrolik pompa ve bleed havası buradan gelir." },
  { id: "fuel", t: "Yakıt tankları", s: "Ana 1/2 ve merkez", col: "#ffd34d", at: [18.5, 0.6, -9], go: "#/c/fuel",
    d: "Kanat içi ana tanklar (1 ve 2) ve merkez kanat tankı; her tankta iki pompa." },
  { id: "pack", t: "Klima paketleri", s: "Sol/sağ pack", col: "#6be3c2", at: [17.5, -3.0, -1.6], go: "#/c/ac",
    d: "Merkez kanadın altındaki pack bölmeleri; bleed havasını şartlandırır." },
  { id: "lg", t: "İniş takımı", s: "Ana ve burun", col: "#c99cff", at: [20.5, -3.8, 3.6], go: "#/c/lg",
    d: "Burun takımı ve iki ana takım; hidrolik A sistemiyle toplanır." }
];

export async function mount(rootEl) {
  rootEl.innerHTML = `<div class="v3">
    <div class="v3-stage tall"><canvas></canvas><div class="v3-hint">Bir bölgeye dokun · iki parmakla yakınlaş</div><div class="v3-load">Uçak hazırlanıyor…</div>
      <div class="v3-tools"><button data-t="iso" class="on">Genel</button><button data-t="side">Yan</button><button data-t="top">Üst</button><button data-t="lbl">Etiketler</button></div></div>
    <div class="v3-info"></div>
    <div class="v3-chips">${ZONES.map(z => `<button data-z="${z.id}"><i style="background:${z.col}"></i>${esc(z.t)}</button>`).join("")}</div>
    <p class="v3-note">Gövde, kanat ve kuyruk ölçüleri 737-800 için yaklaşıktır (temsilî). Sistem bölgelerinin konumları WDM 91-01 istasyon (STA) bilgilerine göre yerleştirildi.</p></div>`;
  const stage = rootEl.querySelector(".v3-stage"), canvasEl = rootEl.querySelector("canvas"), info = rootEl.querySelector(".v3-info");
  let renderer;
  try { renderer = new THREE.WebGLRenderer({ canvas: canvasEl, antialias: true }); } catch (e) { stage.innerHTML = '<p style="padding:16px">Bu cihazda 3D (WebGL) desteklenmiyor.</p>'; return () => {}; }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2)); renderer.toneMapping = THREE.ACESFilmicToneMapping;
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0x0d1620);
  const pmrem = new THREE.PMREMGenerator(renderer); const env = pmrem.fromScene(new RoomEnvironment(), 0.04).texture; scene.environment = env; scene.environmentIntensity = 0.55;
  const dl = new THREE.DirectionalLight(0xffffff, 1.2); dl.position.set(-10, 20, 15); scene.add(dl);
  const cam = new THREE.PerspectiveCamera(38, 1, 0.1, 500), controls = new OrbitControls(cam, canvasEl);
  controls.enableDamping = true; controls.dampingFactor = 0.1; controls.minDistance = 4; controls.maxDistance = 120; controls.screenSpacePanning = true;
  rootEl.querySelector(".v3-load").remove();
  let dirty = true;
  const resize = () => { const w = stage.clientWidth, h = stage.clientHeight; if (!w || !h) return; renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); dirty = true; };
  const ro = new ResizeObserver(resize); ro.observe(stage); resize();
  controls.addEventListener("change", () => dirty = true);

  // --- saydam gövde ---
  const glass = new THREE.MeshPhysicalMaterial({ color: 0x9cc8ff, transparent: true, opacity: 0.1, roughness: 0.15, metalness: 0, side: THREE.DoubleSide, depthWrite: false });
  const lineM = new THREE.LineBasicMaterial({ color: 0x8fb8e6, transparent: true, opacity: 0.32 });
  const ac = new THREE.Group(); scene.add(ac);
  ac.add(new THREE.Mesh(fuselageGeo(), glass));
  const lines = [];
  for (let x = 0.3; x < 39.4; x += 0.9) { const p = prof(x); for (let j = 0; j < 48; j++) { const a0 = j / 48 * Math.PI * 2, a1 = (j + 1) / 48 * Math.PI * 2; lines.push(x, p.cy + Math.cos(a0) * p.ry, Math.sin(a0) * p.rz, x, p.cy + Math.cos(a1) * p.ry, Math.sin(a1) * p.rz); } }
  for (let j = 0; j < 12; j++) { const a = j / 12 * Math.PI * 2; for (let i = 0; i < 80; i++) { const x0 = i / 80 * 39.4, x1 = (i + 1) / 80 * 39.4, p0 = prof(x0), p1 = prof(x1); lines.push(x0, p0.cy + Math.cos(a) * p0.ry, Math.sin(a) * p0.rz, x1, p1.cy + Math.cos(a) * p1.ry, Math.sin(a) * p1.rz); } }
  { const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.Float32BufferAttribute(lines, 3)); ac.add(new THREE.LineSegments(g, lineM)); }
  // kanatlar, kuyruk
  const wing = s => surface({ x: 14.2, c: 7.4, z: 1.7 * s, y: -1.25 }, { x: 22.4, c: 1.3, z: 16.9 * s, y: 0.55 }, 0.55);
  const surfs = [wing(1), wing(-1),
    surface({ x: 34.6, c: 3.6, z: 0.6, y: 0.75 }, { x: 37.9, c: 1.2, z: 7.2, y: 1.2 }, 0.2), surface({ x: 34.6, c: 3.6, z: -0.6, y: 0.75 }, { x: 37.9, c: 1.2, z: -7.2, y: 1.2 }, 0.2)];
  const fin = new THREE.Shape([new THREE.Vector2(31.2, 1.6), new THREE.Vector2(37.6, 1.6), new THREE.Vector2(39.0, 7.6), new THREE.Vector2(36.8, 7.6)]);
  const finG = new THREE.ExtrudeGeometry(fin, { depth: 0.3, bevelEnabled: false }); finG.translate(0, 0, -0.15);
  const wl = s => new THREE.BoxGeometry(0.9, 2.4, 0.08).translate(23.1, 1.7, 17.0 * s);
  const plain = g => { g = g.index ? g.toNonIndexed() : g; for (const k of Object.keys(g.attributes)) if (k !== "position") g.deleteAttribute(k); return g; };
  const sm = mergeGeometries([...surfs, finG, wl(1), wl(-1)].map(plain)); sm.computeVertexNormals();
  ac.add(new THREE.Mesh(sm, glass)); ac.add(new THREE.LineSegments(new THREE.EdgesGeometry(sm, 20), lineM));
  // sistem bölgeleri (katı, renkli)
  const solid = col => new THREE.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: 0.25, roughness: 0.5, metalness: 0.2 });
  const zoneObjs = {};
  const add = (id, mesh) => { mesh.userData.zone = id; (zoneObjs[id] = zoneObjs[id] || []).push(mesh); ac.add(mesh); };
  // kokpit: zemin, paneller
  { const m = solid(0x4fb3ff), g = [];
    g.push(new THREE.BoxGeometry(2.0, 0.08, 2.6).translate(sta(215), -0.35, 0));          // zemin
    g.push(new THREE.BoxGeometry(0.25, 0.55, 1.9).translate(sta(180), 0.45, 0));          // ana gösterge paneli
    g.push(new THREE.BoxGeometry(0.9, 0.12, 1.1).translate(sta(200), 1.55, 0));           // overhead
    g.push(new THREE.BoxGeometry(1.1, 0.7, 0.45).translate(sta(200), 0.0, 0));            // orta konsol
    for (const s of [-1, 1]) g.push(new THREE.BoxGeometry(0.6, 1.0, 0.55).translate(sta(225), 0.15, 0.6 * s)); // koltuklar
    add("ckpt", new THREE.Mesh(mergeGeometries(g), m)); }
  { const m = solid(0xffae42), g = [];
    for (const [s, bl] of [[302, 0], [368, -0.5], [368, 0], [368, 0.42]]) g.push(new THREE.BoxGeometry(0.55, 0.9, 0.9).translate(sta(s), -1.35, bl));
    add("ee", new THREE.Mesh(mergeGeometries(g), m)); }
  { const m = solid(0xff6b5a);
    add("apu", new THREE.Mesh(mergeGeometries([new THREE.CylinderGeometry(0.42, 0.42, 1.5, 20).rotateZ(Math.PI / 2).translate(37.3, 1.05, 0), new THREE.CylinderGeometry(0.18, 0.22, 0.9, 16).rotateZ(Math.PI / 2).translate(38.6, 1.2, 0)]), m)); }
  { const m = new THREE.MeshStandardMaterial({ color: 0xb8c4cf, roughness: 0.35, metalness: 0.7, transparent: true, opacity: 0.85 });
    for (const s of [-1, 1]) { const g = mergeGeometries([new THREE.CylinderGeometry(1.03, 0.85, 3.9, 32, 1, true).rotateZ(Math.PI / 2).translate(13.4, -2.0, 4.95 * s), new THREE.CylinderGeometry(0.95, 0.95, 0.1, 32).rotateZ(Math.PI / 2).translate(11.5, -2.0, 4.95 * s), new THREE.BoxGeometry(2.6, 0.9, 0.25).translate(15.0, -1.1, 4.95 * s)]); add("eng", new THREE.Mesh(g, m)); } }
  { const m = new THREE.MeshStandardMaterial({ color: 0xffd34d, transparent: true, opacity: 0.38, emissive: 0xffd34d, emissiveIntensity: 0.2, depthWrite: false });
    for (const s of [-1, 1]) add("fuel", new THREE.Mesh(surface({ x: 15.0, c: 5.0, z: 2.2 * s, y: -1.15 }, { x: 21.0, c: 1.8, z: 13.5 * s, y: 0.25 }, 0.4), m));
    add("fuel", new THREE.Mesh(new THREE.BoxGeometry(5.0, 0.5, 3.4).translate(17.4, -1.3, 0), m)); }
  { const m = solid(0x6be3c2); for (const s of [-1, 1]) add("pack", new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.7, 0.9).translate(17.6, -1.95, 0.75 * s), m)); }
  { const m = solid(0xc99cff), g = [];
    const wheel = (x, z, r) => new THREE.CylinderGeometry(r, r, 0.3, 18).rotateX(Math.PI / 2).translate(x, -3.95 + 0.55 - r, z);
    for (const s of [-1, 1]) { g.push(wheel(20.6, 2.6 * s, 0.56), wheel(20.6, 3.15 * s, 0.56), new THREE.CylinderGeometry(0.1, 0.1, 1.8).translate(20.6, -2.6, 2.88 * s)); }
    g.push(wheel(3.6, 0.17, 0.35), wheel(3.6, -0.17, 0.35), new THREE.CylinderGeometry(0.07, 0.07, 1.6).translate(3.6, -2.9, 0));
    add("lg", new THREE.Mesh(mergeGeometries(g), m)); }
  // etiketler
  const labels = new THREE.Group(); ac.add(labels);
  for (const z of ZONES) { const s = labelSprite(z.t, z.s, z.col); s.position.set(...z.at); s.userData.zone = z.id; labels.add(s); }
  // zemin ızgarası
  const grid = new THREE.GridHelper(80, 40, 0x1f3346, 0x16283a); grid.position.set(19.75, -3.98, 0); scene.add(grid);

  const center = new THREE.Vector3(19.75, 0, 0);
  function view(k) {
    const f = Math.max(1, 1.25 / Math.max(0.45, cam.aspect));
    const P = { iso: [19.75 - 30 * f, 20 * f, 34 * f], side: [19.75, 2, 46 * f], top: [19.75, 52 * f, 0.1] }[k];
    camAnim = { from: cam.position.clone(), to: new THREE.Vector3(...P), tf: controls.target.clone(), tt: center.clone(), t: 0 };
    rootEl.querySelectorAll('[data-t="iso"],[data-t="side"],[data-t="top"]').forEach(b => b.classList.toggle("on", b.dataset.t === k));
  }
  let camAnim = null;
  { const f = Math.max(1, 1.25 / Math.max(0.45, cam.aspect)); cam.position.set(19.75 - 30 * f, 20 * f, 34 * f); } controls.target.copy(center); controls.update();
  function showInfo(z) {
    if (!z) { info.innerHTML = `<b>3D Sistemler</b><p>Saydam 737-800. Renkli bölgeler uçağın sistemleridir; birine dokun, ardından <b>İçeri gir</b> ile o sisteme geç. Kokpitten panellere, panellerden anahtarlara, devrelere ve E/E raflarına kadar inebilirsin.</p>`; return; }
    info.innerHTML = `<small>Sistem bölgesi</small><b>${esc(z.t)}</b><p>${esc(z.d)}</p><div class="row v3-row"><button class="v3-btn pri" data-go="${z.go}">İçeri gir ›</button></div>`;
    info.querySelector("[data-go]").onclick = () => { location.hash = z.go; };
  }
  let selId = null;
  function select(id, fly) {
    selId = id; const z = ZONES.find(q => q.id === id);
    for (const k in zoneObjs) for (const m of zoneObjs[k]) { if (m.material.emissive) m.material.emissiveIntensity = k === id ? 0.9 : 0.25; }
    rootEl.querySelectorAll("[data-z]").forEach(b => b.classList.toggle("on", b.dataset.z === id));
    showInfo(z);
    if (z && fly) { const t = new THREE.Vector3(...z.at); t.y -= 1.2; const dir = cam.position.clone().sub(controls.target).normalize(); camAnim = { from: cam.position.clone(), to: t.clone().addScaledVector(dir, id === "ckpt" || id === "ee" ? 11 : 16), tf: controls.target.clone(), tt: t, t: 0 }; }
    dirty = true;
  }
  rootEl.querySelectorAll("[data-z]").forEach(b => b.onclick = () => { if (selId === b.dataset.z) location.hash = ZONES.find(z => z.id === b.dataset.z).go; else select(b.dataset.z, true); });
  rootEl.querySelectorAll(".v3-tools button").forEach(b => b.onclick = () => { const t = b.dataset.t; if (t === "lbl") { labels.visible = !labels.visible; b.classList.toggle("on", !labels.visible); dirty = true; } else view(t); });
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(); let down = null, multi = false; const ptrs = new Set();
  canvasEl.addEventListener("pointerdown", e => { ptrs.add(e.pointerId); if (ptrs.size > 1) multi = true; if (ptrs.size === 1) { multi = false; down = [e.clientX, e.clientY]; } });
  canvasEl.addEventListener("pointercancel", e => { ptrs.delete(e.pointerId); down = null; });
  canvasEl.addEventListener("pointerup", e => {
    ptrs.delete(e.pointerId); if (!down || multi) { if (!ptrs.size) down = null; return; }
    const mv = Math.hypot(e.clientX - down[0], e.clientY - down[1]); down = null; if (mv > 14) return;
    const r = canvasEl.getBoundingClientRect(); ndc.set((e.clientX - r.left) / r.width * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); ray.setFromCamera(ndc, cam);
    const hits = ray.intersectObjects([...(labels.visible ? labels.children : []), ...Object.values(zoneObjs).flat()], false);
    const id = hits.length ? hits[0].object.userData.zone : null;
    if (!id) { select(null); return; }
    if (id === selId) { location.hash = ZONES.find(z => z.id === id).go; return; }
    select(id, true);
  });
  showInfo(null);
  let alive = true, t0 = performance.now();
  (function loop(now) {
    if (!alive) return; requestAnimationFrame(loop);
    if (camAnim) { camAnim.t = Math.min(1, camAnim.t + 0.04); const k = 1 - Math.pow(1 - camAnim.t, 3); cam.position.lerpVectors(camAnim.from, camAnim.to, k); controls.target.lerpVectors(camAnim.tf, camAnim.tt, k); if (camAnim.t >= 1) camAnim = null; dirty = true; }
    controls.update();
    // seçili bölge hafif nabız
    if (selId && zoneObjs[selId]) { const k = 0.6 + 0.35 * Math.sin((now - t0) / 260); for (const m of zoneObjs[selId]) if (m.material.emissive) m.material.emissiveIntensity = k; dirty = true; }
    if (dirty) { renderer.render(scene, cam); dirty = false; }
  })(t0);
  rootEl.__ac = { scene, cam, select };
  return () => { alive = false; ro.disconnect(); controls.dispose(); scene.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) { (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => { m.map?.dispose(); m.dispose(); }); } }); env.dispose(); pmrem.dispose(); renderer.dispose(); renderer.forceContextLoss?.(); };
}
