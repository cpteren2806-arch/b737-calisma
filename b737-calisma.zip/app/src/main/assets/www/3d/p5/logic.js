// Canlı lojik blok şemaları: bara → devre kesici → anahtar → röle/bilgisayar → çıkış/ikaz.
// Seçili uçağın WDM verisine (CB→bara, pin izleri) ve simülasyon durumuna göre canlı boyanır.
// Şemalar FCOM/WDM düzeyinde BASİTLEŞTİRİLMİŞTİR; bakım için daima ilgili WDM şemasına bakılır.
import * as FWD from "./layout.js";
import { AFT } from "./layout_aft.js";
import { P7, SIX_GROUPS } from "./layout_p7.js";
import { P8 } from "./layout_p8.js";
import { MIP } from "./layout_mip.js";

const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/* ---------- kontrol → panel / öğe haritası ---------- */
let ITEMS = null;
function items() {
  if (ITEMS) return ITEMS;
  ITEMS = {};
  const add = (mods, panel) => mods.forEach(m => m.items.forEach(o => { if (o.id && !ITEMS[o.id]) ITEMS[o.id] = { o, panel, m }; }));
  add([...FWD.MODULES, FWD.BOTTOM], "fwd"); add([...AFT.modules, AFT.bottom], "aft"); add(P7.modules, "p7"); add(P8.modules, "p8"); add(MIP.modules, "mip");
  return ITEMS;
}
const ROUTE = { fwd: "#/3d/p5", aft: "#/3d/p5aft", p7: "#/3d/p7", p8: "#/3d/p8", mip: "#/3d/mip" };
const ltName = id => { const it = items()[id]; if (!it) return id; const t = String(it.o.txt || "").replace(/\n/g, " ").trim(); return t || (it.o.d || id).split(/[:(.]/)[0].trim().slice(0, 28); };
const ltCol = id => ({ a: "#ffa424", b: "#55b8ff", g: "#5ee07a", w: "#f2f2f2", r: "#ff3b2e" }[(items()[id]?.o.c) || "a"]);

/* ---------- düğüm yardımcıları ---------- */
// k: bus | cb | sw | box | lt | out | and ; c: seviye (yukarıdan aşağı) ; f(E, ins): enerjili mi (yoksa: cond && herhangi bir giriş)
const bus = (id, key, c, o = {}) => ({ id, k: "bus", key, c, ...o });
const cb = (id, cid, c, o = {}) => ({ id, k: "cb", cid, c, ...o });
const sw = (id, ctl, c, onPos, o = {}) => ({ id, k: "sw", ctl, c, onPos, ...o });
const box = (id, c, L, o = {}) => ({ id, k: "box", c, L, ...o });
const out = (id, c, L, o = {}) => ({ id, k: "out", c, L, ...o });
const lt = (id, c, lid, o = {}) => ({ id, k: "lt", lid, c, ...o });
const any = ins => ins.some(Boolean), all = ins => ins.length > 0 && ins.every(Boolean);

/* ---------- hidrolik basınç (power.js ile aynı mantık) ---------- */
const sysA = E => (E.st("hydE1") === 1 && E.sim.eng[0]) || (E.st("hydEl2") === 1 && E.ac && E.cbOk("hydEl2"));
const sysB = E => (E.st("hydE2") === 1 && E.sim.eng[1]) || (E.st("hydEl1") === 1 && E.ac && E.cbOk("hydEl1"));

/* ============================ ŞEMALAR ============================ */
const SPEC = {};
const reg = (ids, fn) => ids.forEach(id => SPEC[id] = fn);

// Yakıt pompaları
const PUMP = { pF1: ["lpF1", "Ana tank 1 ön pompa", "sol (1) motor"], pA1: ["lpA1", "Ana tank 1 arka pompa", "sol (1) motor"], pF2: ["lpF2", "Ana tank 2 ön pompa", "sağ (2) motor"], pA2: ["lpA2", "Ana tank 2 arka pompa", "sağ (2) motor"], pCL: ["lpCL", "Merkez tank sol pompa", "sol manifold"], pCR: ["lpCR", "Merkez tank sağ pompa", "sağ manifold"] };
reg([...Object.keys(PUMP), ...Object.values(PUMP).map(v => v[0])], id => {
  const swId = PUMP[id] ? id : Object.keys(PUMP).find(k => PUMP[k][0] === id), [lid, name, feed] = PUMP[swId];
  return {
    t: `${name} – WDM 28-23-11 / 28-43-11`, dg: ["28-23-11", "28-43-11"],
    lv: ["Güç", "Koruma · kumanda", "", "Kontaktör", "Pompa", "Algılama", "İkaz / çıkış"],
    n: [
      ...cbNodes(swId, 1),
      sw("sw", swId, 1, [1], { L: "P5-2 pompa anahtarı" }),
      box("rel", 3, "Pompa güç rölesi (3 faz kontaklar)", { f: (E, ins) => E.dc && all(ins) }),
      box("pump", 4, name + " (115V AC motor)"),
      box("press", 5, "Pompa çıkış basıncı", { val: E => E.nodeOn("pump") ? "normal" : "düşük" }),
      box("ps", 5, "Düşük basınç anahtarı (basınç düşükse kapanır)", { f: (E, ins) => E.dc && !ins[0] }),
      lt("lt", 6, lid), out("eng", 6, `Yakıt → ${feed}`)
    ],
    e: [["cb*", "rel"], ["sw", "rel"], ["rel", "pump"], ["pump", "press"], ["press", "ps", { inv: true }], ["ps", "lt"], ["press", "eng"]],
    note: "Anahtar yalnızca rölenin bobinini sürer; pompanın 3 faz AC gücü devre kesiciden röle kontakları üzerinden gelir. Basınç düşünce (pompa kapalı/arızalı) basınç anahtarı kapanır ve LOW PRESSURE ışığı yanar. Bir pompa durunca aynı tanktaki diğer pompa ve emme (suction) beslemesi motoru beslemeye devam eder."
  };
});

// Crossfeed
reg(["xfeed", "xfOpen"], () => ({
  t: "Crossfeed valfi – WDM 28-22-11", dg: ["28-22-11"],
  lv: ["Güç", "Koruma · kumanda", "", "Aktüatör", "Valf", "İkaz / çıkış"],
  n: [...cbNodes("xfeed", 1), sw("sw", "xfeed", 1, [1], { L: "CROSSFEED seçici" }),
    box("mot", 3, "Valf motoru (28V DC, motorla çalışan)", { f: (E, ins) => all(ins) }),
    box("vlv", 4, "Crossfeed valfi", { f: (E) => E.st("xfeed") === 1 && E.cbOk("xfeed"), val: E => E.st("xfeed") === 1 && E.cbOk("xfeed") ? "AÇIK" : "KAPALI" }),
    lt("lt", 5, "xfOpen"), out("man", 5, "Sol ↔ sağ motor besleme manifoldu birleşir")],
  e: [["cb*", "mot"], ["sw", "mot"], ["mot", "vlv"], ["vlv", "lt"], ["vlv", "man"]],
  note: "VALVE OPEN ışığı: valf seçici konumla uyuşmazken (hareket hâlinde) parlak, valf açıkken sönük (dim) yanar. Devre kesici açıksa valf son konumunda kalır."
}));

// Hidrolik pompalar
const HYD = {
  hydEl1: { lid: "hlpEl1", sys: "B", el: true, name: "Elektrik motorlu pompa 1 (EMDP)" }, hydEl2: { lid: "hlpEl2", sys: "A", el: true, name: "Elektrik motorlu pompa 2 (EMDP)" },
  hydE1: { lid: "hlpE1", sys: "A", eng: 0, name: "Motor 1 tahrikli pompa (EDP)" }, hydE2: { lid: "hlpE2", sys: "B", eng: 1, name: "Motor 2 tahrikli pompa (EDP)" }
};
reg([...Object.keys(HYD), ...Object.values(HYD).map(v => v.lid)], id => {
  const swId = HYD[id] ? id : Object.keys(HYD).find(k => HYD[k].lid === id), h = HYD[swId], sysF = h.sys === "A" ? sysA : sysB;
  const common = [
    box("sys", 4, `Hidrolik sistem ${h.sys} basıncı (3000 psi)`, { f: E => sysF(E), val: E => sysF(E) ? "basınçlı" : "basınç yok" }),
    box("ps", 5, "Pompa çıkış basınç anahtarı", { f: (E, ins) => E.dc && !ins[0] }),
    lt("lt", 6, h.lid), out("use", 6, h.sys === "A" ? "Aileron, elevator, rudder, spoiler, A/P A, PTU, iniş takımı" : "Aileron, elevator, rudder, spoiler, yaw damper, A/P B, flap/slat")
  ];
  if (h.el) return {
    t: `${h.name} → sistem ${h.sys} – WDM 29-11-12`, dg: ["29-11-12", "29-33-11"],
    lv: ["Güç", "Koruma · kumanda", "", "Kontaktör", "Pompa / sistem", "Algılama", "İkaz / kullanıcılar"],
    n: [...cbNodes(swId, 1), sw("sw", swId, 1, [1], { L: "P5 ELEC pompa anahtarı" }),
      box("rel", 3, "Pompa güç rölesi (3 faz)", { f: (E, ins) => E.ac && all(ins) }),
      box("pump", 4, h.name, { f: (E, ins) => any(ins) }), ...common],
    e: [["cb*", "rel"], ["sw", "rel"], ["rel", "pump"], ["pump", "sys"], ["pump", "ps", { inv: true }], ["ps", "lt"], ["sys", "use"]],
    note: `Sistem A'yı motor 1 EDP + ELEC 2 EMDP, sistem B'yi motor 2 EDP + ELEC 1 EMDP besler. LOW PRESSURE ışığı pompanın kendi çıkış basıncı düşükken yanar; sistem basıncı diğer pompadan gelebilir.`
  };
  return {
    t: `${h.name} → sistem ${h.sys} – WDM 29-11-11`, dg: ["29-11-11", "29-33-11"],
    lv: ["", "", "Kumanda", "Tahrik · solenoid", "Pompa / sistem", "Algılama", "İkaz / kullanıcılar"],
    n: [box("engR", 3, `Motor ${h.eng + 1} (N2 dişli kutusu)`, { f: E => E.sim.eng[h.eng], val: E => E.sim.eng[h.eng] ? "çalışıyor" : "durmuş" }),
      sw("sw", swId, 2, [1], { L: "P5 ENG pompa anahtarı" }),
      box("sol", 3, "Depresurizasyon solenoidi (ON = enerjisiz)", { f: E => E.st(swId) === 1, val: E => E.st(swId) === 1 ? "enerjisiz → pompa basınçlar" : "enerjili → pompa boşta" }),
      box("pump", 4, h.name, { f: (E, ins) => all(ins) }), ...common],
    e: [["engR", "pump"], ["sw", "sol"], ["sol", "pump"], ["pump", "sys"], ["pump", "ps", { inv: true }], ["ps", "lt"], ["sys", "use"]],
    note: "EDP motor döndükçe döner; anahtar OFF iken solenoid enerjilenir ve pompa çıkışı sıfırlanır (depressurize). Solenoid enerjisiz konumda pompanın basınç vermesi, elektrik kaybında pompanın çalışmaya devam etmesini sağlar."
  };
});

// Yaw damper
reg(["yd", "ydLt"], () => ({
  t: "Yaw damper – WDM 22-23-11", dg: ["22-23-11"],
  lv: ["Güç", "Koruma · kumanda", "", "Hesaplayıcı", "Hidrolik", "Aktüatör", "İkaz / çıkış"],
  n: [...cbNodes("yd", 1), sw("sw", "yd", 1, [1], { L: "YAW DAMPER anahtarı (solenoid tutmalı)" }),
    box("smyd", 3, "SMYD 1 (stall management / yaw damper bilgisayarı)", { f: (E, ins) => any(ins.slice(0, -1)) }),
    box("hyd", 4, "Hidrolik sistem B basıncı", { f: E => sysB(E), val: E => sysB(E) ? "var" : "yok" }),
    box("eng", 5, "YD kavrama solenoidi + ana rudder PCU YD aktüatörü", { f: (E, ins) => all(ins) && E.st("yd") === 1 }),
    lt("lt", 6, "ydLt"), out("rud", 6, "Rudder: dutch-roll sönümleme, dönüş koordinasyonu")],
  e: [["cb*", "smyd"], ["sw", "smyd"], ["smyd", "eng"], ["hyd", "eng"], ["eng", "rud"], ["eng", "lt", { inv: true }]],
  note: "YD kavrandığında YAW DAMPER ışığı söner. B sistemi basıncı yoksa veya SMYD arıza bulursa anahtar OFF'a düşer ve ışık yanar. Rudder pedalları YD hareketiyle oynamaz."
}));

// Pencere ısıtma
const WH = { wLS: ["wOn1", "Sol yan cam (L SIDE)"], wLF: ["wOn2", "Sol ön cam (L FWD)"], wRF: ["wOn3", "Sağ ön cam (R FWD)"], wRS: ["wOn4", "Sağ yan cam (R SIDE)"] };
reg([...Object.keys(WH), ...Object.values(WH).map(v => v[0])], id => {
  const swId = WH[id] ? id : Object.keys(WH).find(k => WH[k][0] === id), [lid, name] = WH[swId];
  return {
    t: `${name} ısıtma – WDM 30-41-1x`, dg: ["30-41-11", "30-41-12"],
    lv: ["Güç", "Koruma · kumanda", "", "Kontrol ünitesi", "Isıtıcı", "İkaz / çıkış"],
    n: [...cbNodes(swId, 1), sw("sw", swId, 1, [1], { L: "WINDOW HEAT anahtarı" }),
      box("whcu", 3, "Pencere ısıtma kontrol ünitesi (WHCU)", { f: (E, ins) => E.ac && all(ins) }),
      box("film", 4, "Camdaki iletken ısıtıcı film + sıcaklık sensörü", { f: (E, ins) => any(ins), val: E => E.nodeOn("whcu") ? "ısıtılıyor" : "soğuk" }),
      lt("lt", 5, lid), out("o", 5, "Buğu/buz önleme, kuş çarpmasına dayanım (cam esnek kalır)")],
    e: [["cb*", "whcu"], ["sw", "whcu"], ["whcu", "film"], ["film", "lt"], ["film", "o"]],
    note: "WHCU sensörden sıcaklığı okuyup ısıtma gücünü açıp kapar; ON ışığı ısıtma uygulanırken yanar (hedef sıcaklıkta yanıp sönebilir). Aşırı ısınmada OVERHEAT yanar ve güç kesilir."
  };
});

// Prob ısıtma
const PRB = { prbA: [["pCapt", "Kaptan pitot"], ["pLel", "Sol elevator pitot"], ["pLav", "Sol alfa (AOA) vanası"], ["pTemp", "TAT probu"]], prbB: [["pFo", "F/O pitot"], ["pRel", "Sağ elevator pitot"], ["pRav", "Sağ alfa (AOA) vanası"], ["pAux", "Yardımcı pitot"]] };
reg([...Object.keys(PRB), ...Object.values(PRB).flat().map(v => v[0])], id => {
  const swId = PRB[id] ? id : Object.keys(PRB).find(k => PRB[k].some(v => v[0] === id)), list = PRB[swId];
  const pick = PRB[id] ? list : list.filter(v => v[0] === id);
  const n = [sw("sw", swId, 1, [1], { L: `PROBE HEAT ${swId === "prbA" ? "A" : "B"} anahtarı` }), box("rel", 2, "Prob ısıtma röleleri", { f: (E, ins) => E.ac && any(ins) })];
  const e = [["sw", "rel"]];
  pick.forEach(([lid, nm], i) => {
    const cid = (PW_SYS[lid] || [])[0];
    if (cid) { n.push(cb("cb" + i, cid, 2)); e.push(["cb" + i, "h" + i]); }
    n.push(box("h" + i, 3, nm + " ısıtıcısı", { f: (E, ins) => all(ins) }));
    n.push(lt("lt" + i, 4, lid));
    e.push(["rel", "h" + i], ["h" + i, "lt" + i, { inv: true }]);
  });
  return {
    t: `Prob ısıtma ${swId === "prbA" ? "A" : "B"} – WDM 30-31-1x`, dg: ["30-31-11", "30-31-12"],
    lv: ["", "Kumanda", "Koruma / röle", "Isıtıcı", "İkaz (akım yoksa yanar)"], n, e,
    note: "Her ısıtıcının devresinde akım algılayıcı vardır: ısıtıcıdan akım geçmiyorsa (anahtar OFF, CB açık, ısıtıcı kopuk) ilgili amber ışık yanar ve MASTER CAUTION'da ANTI-ICE çıkar."
  };
});
const PW_SYS = { pCapt: ["C00523"], pFo: ["C00525"], pLel: ["C00236"], pRel: ["C00237"], pAux: ["C00524"] };

// AC güç kaynakları
const SRC = ["grdPwr", "grdAvail", "gen1", "gen2", "apuGen1", "apuGen2", "gob1", "gob2", "apuGob", "busXfr", "tbo1", "tbo2", "so1", "so2", "drive1", "drive2", "disc1", "disc2"];
reg(SRC, id => ({
  t: "AC güç kaynakları ve transfer baralar – WDM 24-22 / 24-23 / 24-41", dg: ["24-22-11", "24-22-21", "24-22-31", "24-23-11", "24-41-11"],
  lv: ["Kaynak", "Kontaktör", "Bara bağlantısı", "Baralar", "İkaz ışıkları"],
  n: [
    box("gpu", 0, "Harici güç (GPU) 115V 400Hz", { f: E => E.sim.gpu, val: E => E.sim.gpu ? "bağlı" : "yok" }),
    box("apu", 0, "APU jeneratörü", { f: E => E.sim.apu === 2, val: E => E.sim.apu === 2 ? "hazır" : E.sim.apu === 1 ? "başlatılıyor" : "kapalı" }),
    box("idg1", 0, "IDG 1 (motor 1)", { f: E => E.sim.eng[0] }), box("idg2", 0, "IDG 2 (motor 2)", { f: E => E.sim.eng[1] }),
    box("epc", 1, "EPC – harici güç kontaktörü", { f: E => Object.values(E.sim.src).includes("grd"), go: { ctrl: "grdPwr" } }),
    box("apb", 1, "APB – APU breaker", { f: E => Object.values(E.sim.src).includes("apu"), go: { ctrl: "apuGen1" } }),
    box("gcb1", 1, "GCB 1", { f: E => E.sim.src[1] === "gen1", go: { ctrl: "gen1" } }), box("gcb2", 1, "GCB 2", { f: E => E.sim.src[2] === "gen2", go: { ctrl: "gen2" } }),
    box("btb1", 2, "BTB 1 (bus tie)", { f: E => ["grd", "apu"].includes(E.sim.src[1]) }), box("btb2", 2, "BTB 2 (bus tie)", { f: E => ["grd", "apu"].includes(E.sim.src[2]) }),
    bus("x1", "XFR1", 3, { val: E => srcName(E.sim.src[1]) }), bus("x2", "XFR2", 3, { val: E => srcName(E.sim.src[2]) }),
    lt("l1", 4, "grdAvail"), lt("l2", 4, "apuGob"), lt("l3", 4, "gob1", { L: "GEN 1 OFF BUS" }), lt("l4", 4, "gob2", { L: "GEN 2 OFF BUS" }), lt("l5", 4, "tbo1", { L: "TRANSFER BUS 1 OFF" }), lt("l6", 4, "tbo2", { L: "TRANSFER BUS 2 OFF" })
  ],
  e: [["gpu", "epc"], ["apu", "apb"], ["idg1", "gcb1"], ["idg2", "gcb2"],
    ["epc", "btb1", { c: E => E.sim.src[1] === "grd" }], ["epc", "btb2", { c: E => E.sim.src[2] === "grd" }],
    ["apb", "btb1", { c: E => E.sim.src[1] === "apu" }], ["apb", "btb2", { c: E => E.sim.src[2] === "apu" }],
    ["btb1", "x1"], ["btb2", "x2"], ["gcb1", "x1"], ["gcb2", "x2"]],
  note: "Bir transfer barayı aynı anda tek kaynak besler (paralel çalışma yok). GRD POWER / GEN / APU GEN anahtarı ON'a basılınca BPCU/GCU yeni kaynağın kontaktörünü kapatır, eski kaynağı otomatik ayırır. GEN OFF BUS / APU GEN OFF BUS (mavi): kaynak hazır ama barada değil. TRANSFER BUS OFF: baraya güç yok."
}));
const srcName = s => ({ grd: "GPU'dan", apu: "APU'dan", gen1: "IDG 1'den", gen2: "IDG 2'den" }[s] || "enerjisiz");

// Batarya ve standby
reg(["bat", "stbyPwr", "stbyOff", "batDis"], () => ({
  t: "Batarya ve standby güç – WDM 24-31 / 24-34", dg: ["24-31-11", "24-34-11"],
  lv: ["Kaynak", "Kumanda", "Baralar", "Dönüştürücü", "Standby baralar", "İkaz"],
  n: [
    box("batt", 0, "Ana batarya (24V Ni-Cd)", { f: () => true }), box("ac", 0, "AC transfer bara 1", { f: E => E.ac, val: E => E.ac ? "enerjili" : "enerjisiz" }),
    bus("hot", "HOTBAT", 1), sw("sw", "bat", 1, [1], { L: "BAT anahtarı" }), sw("sby", "stbyPwr", 1, [0, 2], { L: "STANDBY POWER" }),
    bus("swhot", "SWHOT", 2), bus("batb", "BAT", 2),
    box("inv", 3, "Statik inverter (DC → 115V AC)", { f: E => E.B.STBYAC && !E.ac, val: E => E.B.STBYAC && !E.ac ? "çalışıyor" : "devrede değil" }),
    box("tru", 3, "TRU'lar (AC → 28V DC)", { f: E => E.ac }),
    bus("sac", "STBYAC", 4), bus("sdc", "STBYDC", 4), lt("lt", 5, "stbyOff")
  ],
  e: [["batt", "hot"], ["batt", "sw"], ["sw", "swhot"], ["sw", "batb"],
    ["batb", "inv", { c: E => !E.ac }], ["inv", "sac"], ["ac", "sac", { c: E => E.B.STBYAC }], ["ac", "tru"], ["tru", "sdc", { c: E => E.B.STBYDC }], ["batb", "sdc", { c: E => !E.ac && E.B.STBYDC }], ["sby", "sac"], ["sby", "sdc"]],
  note: "Normalde (AUTO) standby AC, AC transfer bara 1'den; standby DC, TRU'lardan beslenir. AC kaybında otomatik olarak batarya: standby DC bataryadan, standby AC statik inverter üzerinden. OFF'ta iki standby bara da enerjisiz kalır ve STANDBY PWR OFF yanar. Hot battery bara her zaman bataryaya bağlıdır."
}));

// APU çalıştırma
reg(["apuSw", "apuLop", "apuFault", "apuOvs", "apuMaint", "apuEgt"], () => ({
  t: "APU çalıştırma ve kumanda – WDM 49-xx", dg: ["49-62-11", "49-94-21", "49-71-21"],
  lv: ["Güç", "Kumanda", "Kontrol", "Çalıştırma", "Motor", "Çıkışlar / ikaz"],
  n: [box("bat", 0, "Batarya / DC baralar", { f: E => E.sim.bat }), box("fuel", 0, "Yakıt – sol manifold", { f: () => true }),
    sw("sw", "apuSw", 1, [1, 2], { L: "APU anahtarı (OFF/ON/START)" }),
    box("ecu", 2, "APU kontrol ünitesi (ECU)", { f: (E, ins) => E.sim.bat && any(ins) }),
    box("door", 3, "Hava giriş kapağı açılır", { f: (E, ins) => any(ins) }), box("st", 3, "Marş motoru (starter)", { f: E => E.sim.apu === 1, val: E => E.sim.apu === 1 ? "çeviriyor" : "" }),
    box("ign", 3, "Yakıt solenoidi + ateşleme", { f: E => E.sim.apu >= 1 }),
    box("apu", 4, "APU (gaz türbini)", { f: E => E.sim.apu >= 1, val: E => E.sim.apu === 2 ? "%100 devir" : E.sim.apu === 1 ? "hızlanıyor" : "durmuş" }),
    box("gen", 5, "APU jeneratörü hazır", { f: E => E.sim.apu === 2, go: { ctrl: "apuGen1" } }), box("bl", 5, "APU bleed havası", { f: E => E.sim.apu === 2 && E.st("apuBl") === 1, go: { ctrl: "apuBl" } }),
    lt("lop", 5, "apuLop"), lt("gob", 5, "apuGob")],
  e: [["bat", "ecu"], ["sw", "ecu"], ["ecu", "door"], ["ecu", "st"], ["ecu", "ign"], ["fuel", "ign"], ["st", "apu"], ["ign", "apu"], ["apu", "gen"], ["apu", "bl"], ["ecu", "lop", { c: E => E.lit("apuLop") > 0 }], ["gen", "gob"]],
  note: "START'a alınıp bırakılır; ECU giriş kapağını açar, marş motoru APU'yu çevirir, uygun devirde yakıt ve ateşleme verilir. Çalıştırma sırasında yağ basıncı oluşana kadar LOW OIL PRESSURE yanar. Hazır olunca APU GEN OFF BUS (mavi) yanar: jeneratör baraya alınmaya hazır."
}));

// MCP / AFDS
const MCP_IDS = ["n1", "speed", "vnav", "lvlChg", "hdgSel", "lnav", "vorLoc", "app", "altHld", "vs", "cmdA", "cmdB", "cwsA", "cwsB", "fdL", "fdR", "atArm", "apDisc", "co", "spdIntv", "altIntv", "crsLK", "iasK", "hdgK", "altK", "vsK", "crsRK", "bank", "maL", "maR", "ias", "hdg", "alt", "vsD", "crsL", "crsR"];
const fma = E => {
  const c = k => !!E.ctl[k], at = E.st("atArm") === 0;
  const A = !at ? "" : c("n1") || c("lvlChg") ? "N1" : c("speed") ? "MCP SPD" : c("vnav") ? "FMC SPD" : "ARM";
  const R = c("lnav") ? "LNAV" : c("hdgSel") ? "HDG SEL" : c("vorLoc") || c("app") ? "VOR/LOC" : "";
  const P = c("vnav") ? "VNAV" : c("lvlChg") ? "MCP SPD" : c("altHld") ? "ALT HOLD" : c("vs") ? "V/S" : c("app") ? "G/S" : "";
  const S = c("cmdA") || c("cmdB") ? "CMD" : c("cwsA") || c("cwsB") ? "CWS" : E.st("fdL") === 0 || E.st("fdR") === 0 ? "FD" : "";
  return { A, R, P, S };
};
reg(MCP_IDS, () => ({
  t: "MCP → DFCS (FCC A/B) → FMA / otopilot / otomatik gaz – WDM 22-11", dg: ["22-11-11", "22-11-51"],
  lv: ["Panel", "Bilgisayarlar", "Çıkışlar", "Gösterge (PFD FMA)"],
  n: [box("mcp", 0, "MCP (M198) – mod ve değer seçimi", { f: E => E.dc, val: E => `IAS ${E.mcpMach ? "." + String(E.mcp.ias).slice(-2) : E.mcp.ias} · HDG ${String(E.mcp.hdg).padStart(3, "0")} · ALT ${E.mcp.alt}` }),
    box("fccA", 1, "FCC A (E1 rafı)", { f: E => E.dc && (!!E.ctl.cmdA || !!E.ctl.cwsA || E.st("fdL") === 0), val: E => E.ctl.cmdA ? "A/P CMD" : E.ctl.cwsA ? "A/P CWS" : E.st("fdL") === 0 ? "F/D" : "beklemede" }),
    box("fccB", 1, "FCC B (E1 rafı)", { f: E => E.dc && (!!E.ctl.cmdB || !!E.ctl.cwsB || E.st("fdR") === 0), val: E => E.ctl.cmdB ? "A/P CMD" : E.ctl.cwsB ? "A/P CWS" : E.st("fdR") === 0 ? "F/D" : "beklemede" }),
    box("atc", 1, "A/T bilgisayarı", { f: E => E.dc && E.st("atArm") === 0, val: E => E.st("atArm") === 0 ? "ARM" : "OFF" }),
    out("ap", 2, "A/P aktüatörleri (aileron, elevator)", { f: E => E.dc && !!(E.ctl.cmdA || E.ctl.cmdB || E.ctl.cwsA || E.ctl.cwsB) }),
    out("fd", 2, "F/D komut çubukları", { f: E => E.dc && (E.st("fdL") === 0 || E.st("fdR") === 0) }),
    out("ats", 2, "A/T servo → gaz kolları", { f: E => E.dc && E.st("atArm") === 0 && !!fma(E).A && fma(E).A !== "ARM" }),
    out("fma", 3, "FMA", { f: E => E.dc, val: E => { const m = fma(E); return [m.A || "—", m.R || "—", m.P || "—", m.S || "—"].join(" | "); } })],
  e: [["mcp", "fccA"], ["mcp", "fccB"], ["mcp", "atc"], ["fccA", "ap", { c: E => !!(E.ctl.cmdA || E.ctl.cwsA) }], ["fccB", "ap", { c: E => !!(E.ctl.cmdB || E.ctl.cwsB) }],
    ["fccA", "fd", { c: E => E.st("fdL") === 0 }], ["fccB", "fd", { c: E => E.st("fdR") === 0 }], ["atc", "ats"], ["fccA", "fma"], ["fccB", "fma"], ["atc", "fma"]],
  note: "MCP'deki düğmeler ve değerler ARINC 429 veri yoluyla iki FCC'ye ve A/T bilgisayarına gider. Mod düğmesinin ışığı, mod FCC tarafından kabul edilince yanar. FMA sütunları: A/T | yatay (roll) | dikey (pitch) | AFDS durumu. Tek otopilot normaldir; ikisi birden yalnızca APP modunda (otomatik iniş) devreye girer. MA ışığı hangi FCC'nin F/D'de usta (master) olduğunu gösterir."
}));

// MASTER CAUTION / six-pack
const SIX_NAME = { flt: "FLT CONT", irs: "IRS", fuel: "FUEL", elec: "ELEC", apu: "APU", ovht: "OVHT/DET", ice: "ANTI-ICE", hyd: "HYD", doors: "DOORS", eng: "ENG", ovhd: "OVERHEAD", air: "AIR COND" };
reg(["mcL", "mcR", ...Object.keys(SIX_GROUPS).map(g => "six_" + g)], id => {
  const focus = id.startsWith("six_") ? id.slice(4) : null;
  return {
    t: "MASTER CAUTION ve sistem ikaz (six-pack) – WDM 33-16", dg: ["33-16-11"],
    lv: ["Overhead amber ikazlar", "Sistem ikaz grubu", "Ana ikaz", "Pilot"], dyn: true,
    build: E => {
      const act = E.mcActive || new Set();
      const groups = Object.keys(SIX_GROUPS).filter(g => act.has(g) || g === focus).slice(0, 6);
      const n = [], e = [];
      groups.forEach((g, i) => {
        const lits = SIX_GROUPS[g].filter(l => E.lit(l) > 0), names = [...new Set(lits.map(ltName))];
        n.push(box("src" + i, 0, lits.length ? names.slice(0, 2).join(", ") : "(yanan ikaz yok)", { f: () => lits.length > 0, val: () => lits.length ? `${lits.length} ışık · ${SIX_NAME[g]}` : "", go: lits[0] ? { ctrl: lits[0] } : null }));
        n.push(lt("g" + i, 1, "six_" + g, { L: SIX_NAME[g] }));
        e.push(["src" + i, "g" + i]); e.push(["g" + i, "mc"]);
      });
      if (!groups.length) n.push(box("none", 0, "Yanan amber ikaz yok", { f: () => false }));
      n.push(lt("mc", 2, "mcL", { L: "MASTER CAUTION" }));
      n.push(out("pil", 3, "Basınca: MC ve six-pack söner (reset). Six-pack'e basınca: hatırlatma (recall)", { f: () => true }));
      e.push(["mc", "pil"]);
      return { n, e };
    },
    note: "Overhead'deki her amber ikaz ışığı bir sistem grubunu ve iki MASTER CAUTION ışığını yakar. MASTER CAUTION'a basmak ikisini de söndürür; yeni bir arıza yeniden yakar. Six-pack paneline basmak (RECALL) mevcut tüm ikazları yeniden gösterir. Mavi ve yeşil ışıklar MASTER CAUTION'ı tetiklemez."
  };
});

/* ============================ P8 ŞEMALARI ============================ */
const fT = E => E.st("fTest");
reg(["fTest", "ovhtDet1", "ovhtDet2", "ovht1", "ovht2", "fireFault", "apuDetInop", "wheelWell", "bellCut"], () => ({
  t: "Motor/APU yangın ve aşırı ısınma algılama – WDM 26-11 / 26-12", dg: ["26-11-11", "26-11-21", "26-11-31", "26-12-11"],
  lv: ["Test / seçim", "Algılama", "Devreler", "Panel ışıkları", "Uyarılar"],
  n: [sw("tf", "fTest", 0, [2], { L: "TEST: OVHT/FIRE" }), sw("tu", "fTest", 0, [0], { L: "TEST: FAULT/INOP" }), sw("d1", "ovhtDet1", 0, [0, 1, 2], { L: "OVHT DET 1 (A/NORM/B)" }),
    box("mod", 1, "Motor ve APU yangın algılama modülü (E/E rafı)", { f: E => E.dc, val: E => fT(E) === 2 ? "yangın testi" : fT(E) === 0 ? "arıza testi" : "izliyor" }),
    box("loop", 2, "Yangın / aşırı ısınma döngüleri (motor A+B, APU, tekerlek yuvası)", { f: E => E.dc && fT(E) === 2, val: E => fT(E) === 2 ? "test sinyali" : "normal" }),
    box("flt", 2, "Döngü arıza (fault) devresi", { f: E => E.dc && fT(E) === 0 }),
    lt("o1", 3, "ovht1"), lt("h1", 3, "fh1", { L: "Yangın kolu 1" }), lt("ha", 3, "fhApu", { L: "APU yangın kolu" }), lt("h2", 3, "fh2", { L: "Yangın kolu 2" }), lt("o2", 3, "ovht2"), lt("ww", 3, "wheelWell"), lt("ff", 3, "fireFault"), lt("ai", 3, "apuDetInop"),
    out("fw", 4, "FIRE WARN (P7) + yangın zili", { f: E => E.dc && fT(E) === 2 && !E.bellCut, val: E => E.bellCut ? "BELL CUTOUT ile susturuldu" : "" }), out("mc", 4, "MASTER CAUTION · OVHT/DET", { f: E => E.dc && (fT(E) === 0 || fT(E) === 2) })],
  e: [["tf", "mod"], ["tu", "mod"], ["d1", "mod"], ["mod", "loop", { c: E => fT(E) === 2 }], ["mod", "flt", { c: E => fT(E) === 0 }],
    ["loop", "o1"], ["loop", "h1"], ["loop", "ha"], ["loop", "h2"], ["loop", "o2"], ["loop", "ww"], ["flt", "ff"], ["flt", "ai"], ["loop", "fw"], ["loop", "mc"], ["flt", "mc"]],
  note: "Her motorda iki dedektör döngüsü (A ve B) vardır; NORMAL'de ikisi birlikte (AND) uyarı vermelidir, biri arızalanırsa modül diğerini tek başına kullanır. Gerçek yangında ilgili yangın kolu, FIRE WARN ve zil; aşırı ısınmada ENG OVERHEAT ve MASTER CAUTION. Test anahtarı, algılama modülüne sahte sinyal verip tüm ikaz zincirini sınar."
}));
const FH = { fh1: { n: "Motor 1", sys: ["Motor yakıt kesme + spar valfi", "Bleed valfi", "EDP hidrolik kesme valfi", "GEN 1 ayrılır", "Thrust reverser kilitlenir"], bottles: [["lBottle", "Sol şişe squib", 2], ["rBottle", "Sağ şişe squib", 3]] },
  fh2: { n: "Motor 2", sys: ["Motor yakıt kesme + spar valfi", "Bleed valfi", "EDP hidrolik kesme valfi", "GEN 2 ayrılır", "Thrust reverser kilitlenir"], bottles: [["lBottle", "Sol şişe squib", 2], ["rBottle", "Sağ şişe squib", 3]] },
  fhApu: { n: "APU", sys: ["APU yakıt valfi", "APU bleed valfi", "Hava giriş kapağı", "APU jeneratörü ayrılır", "APU durur"], bottles: [["apuBottle", "APU şişesi squib", 2]] } };
reg([...Object.keys(FH), "lBottle", "rBottle", "apuBottle"], id => {
  const hid = FH[id] ? id : id === "apuBottle" ? "fhApu" : "fh1", h = FH[hid], pos = E => E.ctl[hid] || 0;
  const n = [box("hd", 0, `${h.n} yangın kolu`, { f: E => pos(E) >= 1, val: E => ["içeride", "ÇEKİLİ", "SOLA ÇEVRİLİ", "SAĞA ÇEVRİLİ"][pos(E)], go: { ctrl: hid } }), lt("hl", 0, hid, { L: "Kol ışığı (yangın)" })];
  const e = [];
  h.sys.forEach((t, i) => { n.push(out("s" + i, 1, t, { f: E => pos(E) >= 1 })); e.push(["hd", "s" + i]); });
  h.bottles.forEach(([lid, t, p], i) => { n.push(box("q" + i, 2, t, { f: E => pos(E) === p || (hid === "fhApu" && pos(E) >= 2) || !!(E.disch[lid === "lBottle" ? "L" : lid === "rBottle" ? "R" : "APU"]), val: E => E.disch[lid === "lBottle" ? "L" : lid === "rBottle" ? "R" : "APU"] ? "ateşlendi" : "" })); n.push(lt("b" + i, 3, lid)); e.push(["hd", "q" + i, { c: E => pos(E) >= 2 }], ["q" + i, "b" + i]); });
  return {
    t: `${h.n} yangın kolu – söndürme – WDM 26-21-11`, dg: ["26-21-11"], lv: ["Kol", "Kolu çekince", "Çevirince (squib)", "Işık"], n, e,
    note: "Kol çekilince ilgili sistemler elektriksel olarak ayrılır ve söndürücü squib devresi hazırlanır; kol bir yöne çevrilince o şişenin squib'i (patlayıcı kartuş) ateşlenir ve halon motor/APU bölmesine boşalır; şişe basıncı düşünce BOTTLE DISCHARGED yanar. İki motor şişesi her iki motora da boşaltılabilir. Uygulamada sıfırlamak için güç ön ayarını yeniden seçin."
  };
});
reg(["exTest", "extL", "extR", "extA"], () => ({
  t: "Söndürücü squib devre testi – WDM 26-21-11", dg: ["26-21-11"], lv: ["Test", "Devre", "Squib'ler", "Işıklar"],
  n: [sw("sw", "exTest", 0, [0, 2], { L: "EXT TEST 1 / 2" }), box("c", 1, "Squib süreklilik test devresi (düşük akım)", { f: (E, ins) => E.dc && any(ins) }),
    box("sL", 2, "Sol şişe squib", { f: (E, ins) => any(ins) && !E.disch.L }), box("sR", 2, "Sağ şişe squib", { f: (E, ins) => any(ins) && !E.disch.R }), box("sA", 2, "APU şişe squib", { f: (E, ins) => any(ins) && !E.disch.APU }),
    lt("l1", 3, "extL"), lt("l2", 3, "extR"), lt("l3", 3, "extA")],
  e: [["sw", "c"], ["c", "sL"], ["c", "sR"], ["c", "sA"], ["sL", "l1"], ["sR", "l2"], ["sA", "l3"]],
  note: "Test, squib'leri ateşlemeyecek kadar küçük bir akımla devre sürekliliğini kontrol eder. 1 ve 2 konumları iki ayrı ateşleme devresini sınar; her konumda üç yeşil ışık yanmalıdır. Ateşlenmiş (boş) şişenin squib'i ışık vermez."
}));
const RADIO = n => ({
  t: `VHF ${n} haberleşme – WDM 23-12`, dg: ["23-12-11", "23-12-21", "23-12-31"], lv: ["Güç", "Kontrol", "Telsiz", "Ses / anten", "Kullanıcı"],
  n: [box("dc", 0, "28V DC (VHF CB'leri, P18/P6)", { f: E => E.dc }),
    box("rtp", 1, `Radyo ayar paneli ${n} (P8)`, { f: E => E.dc, val: E => `ayarlanan: VHF ${E.mcp["rtp" + n] || n}`, go: { ctrl: `rtp${n}K` } }),
    box("acp", 1, "Ses kontrol paneli (ACP) – MIC seçimi", { f: E => !!(E.ctl.acpL_mvhf1 || E.ctl.acpL_mvhf2 || E.ctl.acpL_mvhf3), val: E => { const k = ["vhf1", "vhf2", "vhf3", "hf1", "hf2", "flt", "svc", "pa"].find(k => E.ctl["acpL_m" + k]); return k ? "kaptan MIC: " + k.toUpperCase() : "MIC seçili değil"; }, go: { ctrl: "acpL_mvhf1" } }),
    box("xcvr", 2, `VHF ${n} alıcı-verici (E/E rafı)`, { f: E => E.dc, val: E => { const s = E.mcp["rtp" + n] || n; return `aktif ${(E.mcp["vhf" + s + "A"] / 1000).toFixed(3)} MHz`; } }),
    box("ant", 3, `VHF ${n} anteni`, { f: (E, ins) => any(ins) }), box("reu", 3, "REU – ses yönetim birimi (E/E)", { f: E => E.dc }),
    out("hs", 4, "Kulaklık / hoparlör", { f: E => E.dc && E.st("acpL_rvhf" + n) === 1, val: E => E.st("acpL_rvhf" + n) === 1 ? "dinleniyor" : "alıcı düğmesi kapalı", go: { ctrl: "acpL_rvhf" + n } })],
  e: [["dc", "rtp"], ["rtp", "xcvr", { c: E => (E.mcp["rtp" + n] || n) === n }], ["dc", "xcvr"], ["xcvr", "ant"], ["xcvr", "reu"], ["acp", "reu"], ["reu", "hs"], ["reu", "xcvr", { c: E => !!E.ctl["acpL_mvhf" + n] }]],
  note: "Radyo ayar paneli frekansı ARINC 429 ile alıcı-vericiye gönderir. Bas-konuş (PTT) basılınca REU, ACP'de seçili telsizi yayına (key) alır ve mikrofon sesini ona verir. Dinleme ACP'deki alıcı düğmesiyle açılır; tüm sesler REU'da karıştırılır."
});
reg(["rtp1K", "rtp1X", "rtp1A", "rtp1S", "rtp1v1", "rtp1v2", "rtp1v3", "rtp1T", "rtp1Off"], () => RADIO(1));
reg(["rtp2K", "rtp2X", "rtp2A", "rtp2S", "rtp2v1", "rtp2v2", "rtp2v3", "rtp2T", "rtp2Off"], () => RADIO(2));
reg(["rtp3K", "rtp3X", "rtp3A", "rtp3S", "rtp3v1", "rtp3v2", "rtp3v3", "rtp3T", "rtp3Off"], () => RADIO(3));
const NAVL = n => ({
  t: `VHF NAV ${n} (VOR/ILS/DME) – WDM 34-51 / 34-31`, dg: [n === 1 ? "34-51-11" : "34-51-21", n === 1 ? "34-31-11" : "34-31-21"], lv: ["Kontrol", "Alıcılar", "Antenler", "Kullanıcılar"],
  n: [box("p", 0, `NAV ${n} kontrol paneli (P8)`, { f: E => E.dc, val: E => `aktif ${(E.mcp["nav" + n + "A"] / 1000).toFixed(2)}`, go: { ctrl: `nav${n}K` } }),
    box("rx", 1, `VOR/ILS alıcısı (MMR ${n}) – E/E`, { f: E => E.dc, val: E => { const f = E.mcp["nav" + n + "A"] / 1000, ils = f < 112 && Math.round(f * 10) % 2 === 1; return ils ? "ILS (LOC+GS)" : "VOR"; } }), box("dme", 1, `DME ${n} (eşli frekans)`, { f: E => E.dc }),
    box("a1", 2, "VOR/LOC anteni (dikey stabilizer)", { f: (E, ins) => any(ins) }), box("a2", 2, "Glideslope anteni (burun)", { f: E => { const f = E.mcp["nav" + n + "A"] / 1000; return E.dc && f < 112 && Math.round(f * 10) % 2 === 1; } }),
    out("nd", 3, "PFD / ND (DEU)", { f: E => E.dc }), out("fcc", 3, "FCC (VOR/LOC, APP modu)", { f: E => E.dc })],
  e: [["p", "rx"], ["p", "dme"], ["rx", "a1"], ["rx", "a2"], ["rx", "nd"], ["rx", "fcc"], ["dme", "nd"]],
  note: "108,10–111,95 MHz arasındaki tek ondalıklı (x.10, x.30 …) frekanslar ILS'tir: localizer ile birlikte glideslope ve DME frekansı otomatik eşlenir. Diğerleri VOR'dur. Alıcı çıkışı ND/PFD'ye ve otopilot (FCC) VOR/LOC – APP modlarına gider."
});
reg(["nav1K", "nav1X", "nav1A", "nav1S", "nav1T"], () => NAVL(1));
reg(["nav2K", "nav2X", "nav2A", "nav2S", "nav2T"], () => NAVL(2));
reg(["atcMode", "atcAlt", "atcSel", "atcK1", "atcK2", "atcId", "atcCode", "atcFail"], () => ({
  t: "Transponder ve TCAS – WDM 34-53 / 34-45", dg: ["34-53-11", "34-53-21", "34-45-11"], lv: ["Kontrol", "Bilgisayarlar", "Antenler", "Göstergeler"],
  n: [box("p", 0, "ATC/TCAS kontrol paneli (P8-29)", { f: E => E.dc, val: E => `kod ${E.mcp.atcCode || "2000"} · ${["TEST", "STBY", "TA", "TA/RA"][E.st("atcMode")]}` }),
    box("x1", 1, "ATC 1 transponder (Mode S)", { f: E => E.dc && E.st("atcMode") !== 1 && E.st("atcSel") === 0 }), box("x2", 1, "ATC 2 transponder (Mode S)", { f: E => E.dc && E.st("atcMode") !== 1 && E.st("atcSel") === 1 }),
    box("tc", 1, "TCAS bilgisayarı (E/E)", { f: E => E.dc && E.st("atcMode") >= 2, val: E => ["test", "beklemede", "yalnız TA", "TA + RA"][E.st("atcMode")] }),
    box("an", 2, "Üst/alt transponder ve TCAS antenleri", { f: (E, ins) => any(ins) }),
    out("rad", 3, "Yer radarı: kod + irtifa (ALT ON)", { f: E => E.dc && E.st("atcMode") >= 2 && E.st("atcAlt") === 1 }), out("nd", 3, "ND trafik + PFD RA komutu", { f: E => E.dc && E.st("atcMode") === 3 }), lt("fl", 3, "atcFail")],
  e: [["p", "x1"], ["p", "x2"], ["p", "tc"], ["x1", "an"], ["x2", "an"], ["tc", "an"], ["x1", "rad"], ["x2", "rad"], ["tc", "nd"], ["p", "fl", { c: E => E.st("atcMode") === 0 }]],
  note: "STBY'de transponder yayın yapmaz (yerde, park). TA ONLY'de TCAS yalnız trafik uyarısı (TA) verir; TA/RA'da çözüm uyarısı (RA: tırman/alçal) da verir ve diğer TCAS'lı uçakla Mode S üzerinden koordine olur. Kod 4 sekizlik hane: 7500 kaçırılma, 7600 haberleşme kaybı, 7700 acil durum."
}));
reg(["fdDoor", "lockFail", "autoUnlk"], () => ({
  t: "Kokpit kapısı kilit sistemi – WDM 52-51-11", dg: ["52-51-11"], lv: ["Girdi", "Kontrol", "Kilit", "Gösterge"],
  n: [sw("sw", "fdDoor", 0, [0, 1, 2], { L: "FLT DK DOOR seçici" }), box("kp", 0, "Kabin tuş takımı (acil erişim kodu)", { f: () => false, val: () => "kod girilmedi" }),
    box("ctl", 1, "Kapı kilit kontrol modülü", { f: E => E.dc, val: E => ["açma komutu", "normal (AUTO)", "erişim reddi"][E.st("fdDoor")] }),
    box("sol", 2, "Elektrikli kilit solenoidleri", { f: E => E.dc && E.st("fdDoor") !== 0, val: E => !E.dc ? "güç yok → açık" : E.st("fdDoor") === 0 ? "AÇIK (UNLKD)" : "KİLİTLİ" }),
    lt("l1", 3, "lockFail"), lt("l2", 3, "autoUnlk"), out("chime", 3, "Kokpit zili / kamera", { f: () => false })],
  e: [["sw", "ctl"], ["kp", "ctl"], ["ctl", "sol"], ["ctl", "l1"], ["ctl", "l2"], ["kp", "chime"]],
  note: "Kapı normalde kilitli (AUTO). UNLKD: kilit solenoidlerinin enerjisini keser, kapı açılabilir. Kabinden acil erişim kodu girilince zil çalar ve AUTO UNLK yanar; pilot DENY seçmezse süre sonunda kapı açılır. Kilit güç kaybında açık konuma geçer (fail-safe)."
}));
reg(["stabOvrd"], () => ({
  t: "Stabilizer trim kolon kesme bypass – WDM 27-41-11", dg: ["27-41-11"], lv: ["Kontrol", "Kesme mantığı", "Aktüatör"],
  n: [sw("sw", "stabOvrd", 0, [0], { L: "STAB TRIM OVRD" }), box("col", 0, "Kolon trim kesme anahtarları (ters kolon hareketi)", { f: () => true }),
    box("rel", 1, "Stab trim kesme rölesi", { f: E => E.st("stabOvrd") === 1, val: E => E.st("stabOvrd") === 0 ? "BYPASS" : "devrede" }),
    box("mot", 2, "Stabilizer trim motoru (elektrik / otopilot)", { f: E => E.ac, val: () => "trim komutu bekliyor" })],
  e: [["col", "rel"], ["sw", "rel"], ["rel", "mot"], ["sw", "mot"]],
  note: "NORM: pilot kolonu trim yönünün tersine hareket ettirirse kesme anahtarları elektrikli trimi durdurur. OVRD: bu kesmeyi devre dışı bırakır (kesme arızasında elektrikli trime devam etmek için)."
}));
reg(["rudTrimK", "rudInd"], () => ({
  t: "Rudder trim – WDM 27-21-11 / 27-28-11", dg: ["27-21-11", "27-28-11"], lv: ["Kontrol", "Aktüatör", "Gösterge"],
  n: [sw("sw", "rudTrimK", 0, [0, 2], { L: "RUDDER TRIM düğmesi" }), box("act", 1, "Rudder trim aktüatörü (feel & centering ünitesi)", { f: (E, ins) => E.dc && any(ins) }),
    out("ind", 2, "Rudder trim göstergesi (N159)", { f: E => E.dc, val: E => { const x = E.mcp.rudTrim || 0; return Math.abs(x).toFixed(1) + (x < 0 ? " sol" : x > 0 ? " sağ" : ""); } }), out("rud", 2, "Rudder nötr konumu kayar", { f: E => (E.mcp.rudTrim || 0) !== 0 })],
  e: [["sw", "act"], ["act", "ind"], ["act", "rud"]],
  note: "Trim motoru rudder feel ve merkezleme ünitesinin nötr noktasını kaydırır; rudder pedalları da birlikte hareket eder. Gösterge 0–16 birim (yaklaşık rudder sapma derecesi değildir)."
}));
reg(["cgTest", "cgFwd", "cgAft", "cgDisch", "cgDetF", "cgDetA", "cgFault", "cgExtF", "cgExtA", "cgDiscLt"], () => ({
  t: "Kargo duman algılama ve söndürme – WDM 26-16 / 26-23", dg: ["26-16-21", "26-23-11"], lv: ["Algılama", "Kontrol", "Seçim", "Söndürme", "Işıklar"],
  n: [box("det", 0, "Ön/arka kargo duman dedektörleri (döngü A/B)", { f: E => E.cgTest }), sw("t", "cgTest", 0, [], { L: "TEST düğmesi", f: E => E.cgTest }),
    box("cdm", 1, "Kargo yangın kontrol modülü", { f: E => E.dc }),
    box("arm", 2, "ARMED seçimi (FWD/AFT)", { f: E => !!(E.ctl.cgFwd || E.ctl.cgAft), val: E => E.ctl.cgFwd ? "FWD" : E.ctl.cgAft ? "AFT" : "seçili değil" }), sw("d", "cgDisch", 2, [1], { L: "DISCH (kapaklı)" }),
    box("bot", 3, "Kargo halon şişesi + yönlendirme valfi", { f: E => E.st("cgDisch") === 1 && !!(E.ctl.cgFwd || E.ctl.cgAft) }),
    lt("l1", 4, "cgFwd"), lt("l2", 4, "cgAft"), lt("l3", 4, "cgExtF"), lt("l4", 4, "cgDiscLt"), out("fw", 4, "FIRE WARN + zil", { f: E => E.cgTest })],
  e: [["det", "cdm"], ["t", "cdm"], ["cdm", "l1"], ["cdm", "l2"], ["cdm", "l3"], ["cdm", "fw"], ["arm", "bot"], ["d", "bot"], ["bot", "l4"]],
  note: "Bir bölmede duman algılanınca o bölmenin kırmızı ışığı, FIRE WARN ve zil çalışır. Pilot bölmeyi ARMED yapar, DISCH ile halonu o bölmeye boşaltır; bölmede ilk boşaltmadan sonra metered (sürekli düşük debili) boşaltma devam eder."
}));

/* ============================ ANA PANEL ŞEMALARI ============================ */
const DUSRC = side => ({
  t: "Ekran sistemi (CDS): IRS/ADIRU → DEU → DU – WDM 31-62", dg: ["31-62-11", "31-62-21", "31-62-13", "31-62-23"], lv: ["Kaynaklar", "Görüntü bilgisayarları", "Seçici", "Ekranlar"],
  n: [box("irs", 0, `ADIRU ${side === "L" ? "sol" : "sağ"} (IRS ${side})`, { f: E => E.st("irs" + side) > 0, val: E => E.sim.irs[side] === -1 ? "hizalı (NAV)" : E.sim.irs[side] > 0 ? "hizalanıyor" : "kapalı" }), box("fcc", 0, "FCC / FMC / radyo verileri", { f: E => E.dc }),
    box("deu1", 1, "DEU 1 (E/E rafı)", { f: E => E.B.STBYAC || E.B.XFR1 }), box("deu2", 1, "DEU 2 (E/E rafı)", { f: E => E.B.XFR2 }),
    sw("sel", side === "L" ? "duMainL" : "duMainR", 2, [0, 1, 2, 3, 4], { L: "MAIN PANEL DUs seçici" }),
    box("o", 3, side === "L" ? "Dış DU (N187)" : "Dış DU (N191)", { f: E => side === "L" ? (E.B.STBYAC || E.B.XFR1) : E.B.XFR2, val: E => ["PFD", "PFD", "PFD", "boş", "PFD"][E.st(side === "L" ? "duMainL" : "duMainR")] }),
    box("i", 3, side === "L" ? "İç DU (N188)" : "İç DU (N192)", { f: E => side === "L" ? (E.B.STBYAC || E.B.XFR1) : E.B.XFR2, val: E => ["boş", "ND", "motor", "PFD", "MFD"][E.st(side === "L" ? "duMainL" : "duMainR")] }),
    box("u", 3, "Üst orta DU (N189)", { f: E => E.B.STBYAC || E.B.XFR1, val: E => (E.st("duMainL") === 2 || E.st("duMainR") === 2) ? "ND" : "motor" })],
  e: [["irs", "deu1"], ["irs", "deu2"], ["fcc", "deu1"], ["fcc", "deu2"], ["deu1", "sel"], ["deu2", "sel"], ["sel", "o"], ["sel", "i"], ["deu1", "u"]],
  note: "İki DEU, ADIRU (hava verisi + atalet referansı), FCC, FMC ve radyolardan veri alır ve altı ekranın görüntüsünü üretir; biri arızalanırsa diğeri tüm ekranları besleyebilir (DISPLAYS SOURCE seçici, P5). IRS hizalanmadıkça PFD'de ATT/HDG, ND'de HDG/MAP bayrakları görünür. Kaptan DU'ları yalnız bataryada da (AC standby) çalışır."
});
reg(["duMainL", "duLowerL", "brtLO", "brtLI", "brtUp", "brtLow", "duLO", "duLI", "duC"], () => DUSRC("L"));
reg(["duMainR", "duLowerR", "brtRI", "brtRO", "duRI", "duRO"], () => DUSRC("R"));
reg(["gearLever", "ngGrn", "ngRed", "lgGrn", "lgRed", "rgGrn", "rgRed"], () => ({
  t: "İniş takımı kumandası ve göstergesi – WDM 32-61 / 32-64", dg: ["32-61-11", "32-64-11"], lv: ["Kumanda", "Kilit / mantık", "Hidrolik", "Takımlar", "Algılama", "Işıklar"],
  n: [sw("lev", "gearLever", 0, [0, 1, 2], { L: "İniş takımı kolu (M1952)" }), box("ag", 0, "Hava/yer (air/ground) – PSEU", { f: () => true, val: () => "YERDE" }),
    box("lock", 1, "Kol kilit solenoidi", { f: () => true, val: () => "kilitli (yerde UP engelli)" }),
    box("sv", 2, "Takım seçici valfi (A sistemi)", { f: E => E.st("gearLever") !== 1, val: E => ["UP", "OFF – basınçsız", "DN"][E.st("gearLever")] }),
    box("act", 3, "Burun ve ana takım aktüatörleri + kilitler", { f: () => true, val: () => "aşağıda kilitli" }),
    box("prox", 4, "Yakınlık sensörleri → PSEU", { f: E => E.dc }),
    lt("g1", 5, "ngGrn"), lt("g2", 5, "lgGrn"), lt("g3", 5, "rgGrn")],
  e: [["ag", "lock"], ["lev", "lock"], ["lev", "sv"], ["sv", "act"], ["act", "prox"], ["prox", "g1"], ["prox", "g2"], ["prox", "g3"]],
  note: "Yerdeyken PSEU kol kilit solenoidini enerjisiz bırakır: kol UP'a alınamaz. DN: A sistemi basıncı takımları indirir ve kilitler; kilit sensörleri yeşil ışıkları yakar. Takım kolla uyumsuzken (hareket hâlinde) kırmızı yanar. OFF: hat basıncı alınır, takımlar mekanik kilitlerinde kalır. A sistemi yoksa el ile serbest bırakma (manual extension) vardır."
}));
reg(["autoBrake", "abDisarm", "antiSkidInop", "brakeP"], () => ({
  t: "Otomatik fren ve anti-skid – WDM 32-42", dg: ["32-42-11", "32-42-21"], lv: ["Seçim", "Kontrol", "Hidrolik", "Frenler", "Gösterge"],
  n: [sw("sel", "autoBrake", 0, [0, 2, 3, 4, 5], { L: "AUTO BRAKE seçici" }),
    box("acu", 1, "Anti-skid / autobrake kontrol ünitesi (E/E)", { f: E => E.dc, val: E => ["RTO kurulu", "kapalı", "1", "2", "3", "MAX"][E.st("autoBrake")] }),
    box("hyd", 2, "B sistemi (normal fren) / akümülatör", { f: E => E.sysB, val: E => E.sysB ? "3000 psi" : "akümülatör" }),
    box("abv", 2, "Otomatik fren basınç modülü", { f: (E, ins) => all(ins) && E.st("autoBrake") !== 1 }),
    box("brk", 3, "Ana tekerlek frenleri (anti-skid valfleri)", { f: E => true }),
    lt("l1", 4, "abDisarm"), lt("l2", 4, "antiSkidInop"), out("bp", 4, "Fren basınç göstergesi (P3)", { f: () => true, val: E => E.sysB ? "3000" : "~1000" })],
  e: [["sel", "acu"], ["acu", "abv"], ["hyd", "abv"], ["hyd", "brk"], ["abv", "brk"], ["acu", "l1"], ["acu", "l2"], ["hyd", "bp"]],
  note: "RTO: kalkışta 90 kt üstünde gaz kolları rölantiye çekilirse tam fren uygular; yerde seçilince AUTO BRAKE DISARM 1–2 sn yanar (test). İnişte 1/2/3/MAX tekerlekler dönmeye başlayınca seçilen yavaşlama oranını tutar; fren pedalına basmak veya gaz vermek devreden çıkarır (DISARM yanar). Anti-skid her tekerleğin kaymasını önler."
}));
reg(["lightsSw"], () => ({
  t: "Ana ışık anahtarı (LIGHTS TEST/BRT/DIM) – WDM 33-16", dg: ["33-16-11"], lv: ["Anahtar", "Röleler", "Işıklar"],
  n: [sw("sw", "lightsSw", 0, [0, 2], { L: "LIGHTS anahtarı" }), box("t", 1, "Test rölesi (tüm ikaz lambaları toprağa)", { f: E => E.st("lightsSw") === 0 }), box("d", 1, "Dim rölesi (lamba gerilimi düşürülür)", { f: E => E.st("lightsSw") === 2 }),
    out("all", 2, "Kokpitteki tüm ikaz/uyarı ışıkları", { f: E => E.st("lightsSw") !== 1, val: E => ["TEST – hepsi yanar", "BRT – normal", "DIM – kısık"][E.st("lightsSw")] })],
  e: [["sw", "t"], ["sw", "d"], ["t", "all"], ["d", "all"]],
  note: "TEST: her ikaz lambasının test hattı topraklanır; yanmayan lamba yanık ampulü gösterir. DIM: gece için ikaz ışıklarının parlaklığı düşer (kırmızı uyarı ışıkları ve bazı ışıklar etkilenmez)."
}));
reg(["nws"], () => ({
  t: "Burun tekerleği yönlendirme hidroliği – WDM 32-51 / 29-23", dg: ["29-23-11", "32-51-11"], lv: ["Anahtar", "Valf", "Kaynak", "Aktüatör"],
  n: [sw("sw", "nws", 0, [0, 1], { L: "NOSE WHEEL STEERING" }), box("v", 1, "Alternatif yönlendirme seçici valfi", { f: E => E.st("nws") === 0, val: E => E.st("nws") === 0 ? "ALT (B sistemi)" : "NORM (A sistemi)" }),
    box("a", 2, "Hidrolik sistem A", { f: E => (E.st("hydE1") === 1 && E.sim.eng[0]) || (E.st("hydEl2") === 1 && E.ac) }), box("b", 2, "Hidrolik sistem B", { f: E => E.sysB }),
    out("s", 3, "Burun tekerleği yönlendirme aktüatörleri (tiller / pedal)", { f: (E, ins) => any(ins) })],
  e: [["sw", "v"], ["a", "s", { c: E => E.st("nws") === 1 }], ["b", "s", { c: E => E.st("nws") === 0 }]],
  note: "NORM: burun tekerleği yönlendirmesine A sistemi basıncı gider. ALT: A sistemi kaybında alternatif valf B sistemi basıncını verir. Kumanda tiller (el çarkı, ±78°) veya rudder pedallarıyla (±7°) yapılır."
}));

/* ---------- CB düğümleri: SYS_CB'den ---------- */
let SYS_CB_REF = {};
function cbNodes(sys, c) { return (SYS_CB_REF[sys] || []).map((cid, i) => cb("cb" + i, cid, c)); }

/* ============================ GENEL (WDM pin izi) ============================ */
function genericSpec(ctx, c, dgs) {
  const d = ctx.data; if (!d || !dgs) return null;
  const rows = [];
  for (const cn of c.mod.conns || []) for (const q of d.pins[cn.D] || []) if (dgs.includes(q.dg)) rows.push({ cn, q });
  if (!rows.length) return null;
  const ends = new Map(), mids = new Map();
  for (const { cn, q } of rows) for (const path of q.paths.slice(0, 1)) {
    const hops = path.filter(h => h[0] === "w"); if (!hops.length) continue;
    const last = hops[hops.length - 1];
    const mid = hops.slice(0, -1).find(h => ["relay", "tb", "splice"].includes(h[8]));
    const key = last[6];
    if (!ends.has(key)) ends.set(key, { id: key, kind: last[8], conn: cn.cd.d, wires: [], mid: mid ? mid[6] : null, midK: mid ? mid[8] : null });
    ends.get(key).wires.push(q.w);
    if (mid && !mids.has(mid[6])) mids.set(mid[6], mid[8]);
  }
  const list = [...ends.values()].sort((a, b) => (a.kind === "cb" ? 0 : a.kind === "ground" ? 2 : 1) - (b.kind === "cb" ? 0 : b.kind === "ground" ? 2 : 1)).slice(0, 8);
  const KIND = { cb: "devre kesici", relay: "röle", ground: "toprak", tb: "terminal blok", splice: "ek", conn: "konnektör" };
  const Ds = [...new Set(rows.map(r => r.cn.cd.d))], D0 = rows[0].cn.D;
  const n = [box("D", 2, `Seçili kontrol → ${Ds.join(", ")} (modül konnektörü)`, { f: (E, ins) => !E.disc(D0) && (ins.length ? any(ins) : true), go: { ctrl: c.o.id } })];
  const e = [];
  const midIds = {};
  [...mids.entries()].slice(0, 3).forEach(([m, k], i) => { midIds[m] = "m" + i; n.push(box("m" + i, 3, `${m} (${KIND[k] || k})`, { sub: ctx.DATA.eqDesc(d.eq, m), f: (E, ins) => any(ins) })); });
  list.forEach((x, i) => {
    const nid = "e" + i, from = x.mid && midIds[x.mid] ? midIds[x.mid] : "D";
    if (x.kind === "cb") { n.push(cb(nid, x.id, 1)); e.push([nid, "D"]); return; }
    if (from !== "D" && !e.some(([a, b]) => a === "D" && b === from)) e.push(["D", from]);
    n.push(box(nid, 4, `${x.id} (${KIND[x.kind] || x.kind})`, { sub: ctx.DATA.eqDesc(d.eq, x.id), f: (E, ins) => any(ins) })); e.push([from, nid]);
  });
  return {
    t: `WDM devre izi – ${dgs.join(", ")}`, dg: dgs, generic: true,
    lv: ["Bara", "Devre kesici", "Kontrol / konnektör", "Ara bağlantı", "Uç birimler"], n, e,
    note: `Seçili uçağın (${ctx.DATA.tailLabel(ctx.ST.tail)}) WDM Wire List izlerinden otomatik çıkarıldı: modül konnektöründeki bu şemaya ait ${rows.length} pinin vardığı uçlar. Devre kesiciler bağlı oldukları baradan beslenir; ok yönü güç akışını gösterir.`
  };
}

/* ============================ ÇİZİM ============================ */
export function hasLogic(id) { return !!SPEC[id]; }
export function renderLogic(ctx, c, el, dgs) {
  SYS_CB_REF = ctx.PW.SYS_CB;
  const id = c.o.id;
  let spec = SPEC[id] ? SPEC[id](id) : null;
  const draw = () => {
    if (!spec && ctx.data) spec = genericSpec(ctx, c, dgs);
    if (!spec) { el.innerHTML = ""; return false; }
    const E = env(ctx);
    let { n, e } = spec.build ? spec.build(E) : spec;
    n = n.map(x => ({ ...x })); e = e.slice();
    // CB'lere bara düğümü ekle (WDM 24-5x/6x)
    const cbs = n.filter(x => x.k === "cb");
    if (e.some(([a]) => a === "cb*")) e = e.flatMap(([a, b, o]) => a === "cb*" ? cbs.map(x => [x.id, b, o]) : [[a, b, o]]);
    cbs.forEach(x => {
      const keys = ctx.PW.cbBuses(ctx.ST.busMap, ctx.DATA.effOk, ctx.ST.tail, x.cid).slice(0, 2);
      keys.forEach(k => { const bid = "bus_" + k; if (!n.some(y => y.id === bid)) n.push(bus(bid, k, Math.max(0, x.c - 1))); e.push([bid, x.id]); });
    });
    return solveDraw(ctx, el, spec, n, e, E, id);
  };
  if (!draw() && !spec) {
    if (ctx.dataP) ctx.dataP.then(() => { if (el.isConnected) draw(); });
  }
  return () => { if (el.isConnected && spec) draw(); };
}

function env(ctx) {
  const ST = ctx.ST, st = ctx.stOf, sim = ST.sim;
  const B = ctx.PW.busesPowered(sim, st), P = ctx.PW.computeLights(sim, st, ctx.cbOk);
  const E = {
    st, sim, B, ctl: ST.ctl, mcp: ST.mcp || {}, mcpMach: ST.mcpMach, mcActive: ST.mcActive, bellCut: !!ST.bellCut, disch: ST.disch || {}, cgTest: !!ST.cgTestT && performance.now() - ST.cgTestT < 3000, dc: P.dc, ac: P.ac, cbOk: ctx.cbOk,
    cb: id => ctx.cbLiveOf(id), pulled: id => ST.pulled.has(id), disc: D => ST.disc.has(D),
    lit: id => { const l = ctx.S.lightsById[id]; return l ? (l.lit || 0) : (P.L[id] || 0); },
    nodeOn: () => false
  };
  E.sysB = sysB(E);
  return E;
}

const LVL_H = 74, NODE_H = 50, W = 360;
function wrap(t, max) {
  const words = String(t).split(/\s+/), lines = []; let cur = "";
  for (const w of words) { if ((cur + " " + w).trim().length > max && cur) { lines.push(cur); cur = w; } else cur = (cur + " " + w).trim(); }
  if (cur) lines.push(cur);
  if (lines.length > 3) { lines.length = 3; lines[2] = lines[2].replace(/.{0,2}$/, "…"); }
  return lines;
}
function solveDraw(ctx, el, spec, n, e, E, selId) {
  const byId = Object.fromEntries(n.map(x => [x.id, x]));
  e = e.filter(([a, b]) => byId[a] && byId[b]);
  const inc = {}; e.forEach(([a, b, o]) => (inc[b] = inc[b] || []).push([a, o]));
  // durum çözümü (girişler önce: seviye sırasına göre, birkaç tur)
  const on = {};
  const evalNode = x => {
    const ins = (inc[x.id] || []).map(([a, o]) => { const v = !!on[a] && (!o || !o.c || o.c(E)); return o && o.inv ? v : v; });
    if (x.k === "lt") return E.lit(x.lid) > 0;
    if (x.k === "bus") return !!E.B[x.key];
    if (x.k === "cb") return !E.pulled(x.cid) && (ins.length ? any(ins) : E.cb(x.cid));
    if (x.k === "sw") return x.f ? !!x.f(E, ins) : x.onPos.includes(E.st(x.ctl));
    if (x.f) return !!x.f(E, ins);
    return ins.length ? any(ins) : true;
  };
  E.nodeOn = id => !!on[id];
  const order = [...n].sort((a, b) => a.c - b.c);
  for (let k = 0; k < 3; k++) order.forEach(x => on[x.id] = evalNode(x));
  // yerleşim
  const levels = [...new Set(n.map(x => x.c))].sort((a, b) => a - b);
  const pos = {}; let y = 6; const lvY = [];
  for (const lv of levels) {
    const row = n.filter(x => x.c === lv); const per = row.length > 4 ? 3 : row.length;
    for (let r = 0; r * per < row.length; r++) {
      const part = row.slice(r * per, r * per + per), gap = 8, w = Math.min(172, (W - 12 - gap * (part.length - 1)) / part.length);
      const x0 = (W - (w * part.length + gap * (part.length - 1))) / 2;
      lvY.push([lv, y, r === 0]);
      part.forEach((x, i) => { pos[x.id] = { x: x0 + i * (w + gap), y: y + 14, w, h: NODE_H }; });
      y += LVL_H;
    }
  }
  const H = y;
  const edgeLive = (a, b, o) => !!on[a] && !!on[b] && (!o || !o.c || o.c(E)) || (o && o.inv && !on[a] && on[b]);
  const paths = e.map(([a, b, o]) => {
    const A = pos[a], Bp = pos[b];
    if (!A || !Bp) return "";
    const x1 = A.x + A.w / 2, y1 = A.y + A.h, x2 = Bp.x + Bp.w / 2, y2 = Bp.y;
    const live = edgeLive(a, b, o);
    const inv = o && o.inv;
    const same = Math.abs(A.y - Bp.y) < 1;
    const d = same ? (A.x < Bp.x ? `M${A.x + A.w},${A.y + A.h / 2} L${Bp.x},${Bp.y + Bp.h / 2}` : `M${A.x},${A.y + A.h / 2} L${Bp.x + Bp.w},${Bp.y + Bp.h / 2}`) : y2 > y1 ? `M${x1},${y1} C${x1},${(y1 + y2) / 2} ${x2},${(y1 + y2) / 2} ${x2},${y2}` : `M${x1},${y1} C${x1},${y1 + 30} ${x2},${y2 - 30} ${x2},${y2}`;
    return `<path class="lg-e${live ? " on" : ""}${inv ? " inv" : ""}" d="${d}"/>${inv ? `<text class="lg-inv" x="${((x1 + x2) / 2 + 4).toFixed(0)}" y="${((y1 + y2) / 2 + 3).toFixed(0)}">DEĞİL</text>` : ""}`;
  }).join("");
  const label = x => {
    if (x.L) return x.L;
    if (x.k === "bus") return ctx.PW.BUS_LABEL[x.key] || x.key;
    if (x.k === "cb") { const r = ctx.data && ctx.data.cbs.byId[x.cid]; return r ? `CB ${r.name.replace(/^CB-/, "")}` : "CB " + x.cid; }
    if (x.k === "lt") return ltName(x.lid);
    return x.id;
  };
  const sub = x => {
    if (x.val) return x.val(E);
    if (x.k === "sw") { const it = items()[x.ctl]; const p = it && it.o.pos ? it.o.pos[E.st(x.ctl)] : null; return p != null ? "konum: " + (p || "orta") : ""; }
    if (x.k === "cb") { const r = ctx.data && ctx.data.cbs.byId[x.cid]; return (r ? `${r.pn} ${r.g}` : x.cid) + (E.pulled(x.cid) ? " · AÇIK" : ""); }
    if (x.k === "bus") return on[x.id] ? "enerjili" : "enerjisiz";
    if (x.k === "lt") return on[x.id] ? "YANIYOR" : "sönük";
    return x.sub || "";
  };
  const nodes = n.map(x => {
    const p = pos[x.id], live = on[x.id], sel = x.ctl === selId || x.lid === selId || (x.go && x.go.ctrl === selId);
    const max = Math.max(9, Math.floor(p.w / 6.3)), lines = wrap(label(x), max), s = sub(x);
    const go = x.go || (x.k === "cb" ? { cb: x.cid } : x.k === "sw" ? { ctrl: x.ctl } : x.k === "lt" ? { ctrl: x.lid } : null);
    const avail = p.h - (s ? 13 : 0), ty = p.y + (avail - lines.length * 10.5) / 2 + 8.5;
    const lamp = x.k === "lt" ? `<circle cx="${(p.x + 9).toFixed(1)}" cy="${(p.y + 10).toFixed(1)}" r="5" fill="${live ? ltCol(x.lid) : "#3a3f45"}" stroke="#0006"/>` : "";
    return `<g class="lg-n k-${x.k}${live ? " on" : ""}${sel ? " sel" : ""}${go ? " go" : ""}" ${go ? `data-go='${esc(JSON.stringify(go))}'` : ""}>
      <rect x="${p.x.toFixed(1)}" y="${p.y}" width="${p.w.toFixed(1)}" height="${p.h}" rx="${x.k === "bus" ? 14 : x.k === "out" ? 3 : 7}"${x.k === "lt" && live ? ` style="stroke:${ltCol(x.lid)};fill:${ltCol(x.lid)}2e"` : ""}/>${lamp}
      ${lines.map((l, i) => `<text x="${(p.x + p.w / 2).toFixed(1)}" y="${(ty + i * 11).toFixed(1)}" class="lg-t">${esc(l)}</text>`).join("")}
      ${s ? `<text x="${(p.x + p.w / 2).toFixed(1)}" y="${p.y + p.h - 6}" class="lg-s">${esc(String(s).slice(0, Math.floor(p.w / 5.2)))}</text>` : ""}</g>`;
  }).join("");
  const lvLabels = lvY.filter(([, , first]) => first).map(([lv, yy]) => spec.lv && spec.lv[lv] ? `<text class="lg-l" x="6" y="${yy + 9}">${esc(spec.lv[lv].toLocaleUpperCase("tr-TR"))}</text>` : "").join("");
  const html = `<div class="lg-head"><b>Nasıl çalışır – lojik şema</b><small>${esc(spec.t)}</small></div>
    <svg class="lg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMin meet">${lvLabels}${paths}${nodes}</svg>
    <div class="lg-leg"><span><i class="on"></i>enerjili / aktif</span><span><i></i>enerjisiz / pasif</span><span><i class="sel"></i>seçili kontrol</span><span>Kutulara dokun: CB'ye / kontrole git</span></div>
    <p class="v3-sub">${esc(spec.note)}${spec.generic ? "" : " <i>Basitleştirilmiş eğitim şeması; ayrıntı için WDM " + esc((spec.dg || []).join(", ")) + ".</i>"}</p>`;
  if (el.__html === html) return true; // değişiklik yoksa yeniden çizme (akış animasyonu kesintisiz sürsün)
  el.__html = html; el.innerHTML = html;
  el.querySelectorAll("[data-go]").forEach(g => g.onclick = () => go(ctx, JSON.parse(g.dataset.go)));
  return true;
}

function go(ctx, g) {
  if (g.cb) { ctx.ST.cbFocus = { ids: [g.cb], back: { panel: ctx.cfg.key } }; ctx.nav("#/3d/cb"); return; }
  if (g.ctrl) {
    const here = ctx.S.ctrls.find(c => c.o.id === g.ctrl) || ctx.S.lightsById[g.ctrl];
    if (here) { ctx.select(here.mod, here); ctx.flyToCtrl && ctx.flyToCtrl(here); return; }
    const it = items()[g.ctrl]; if (!it) return;
    ctx.ST.p5Focus = { panel: it.panel, ctrl: g.ctrl }; ctx.nav(ROUTE[it.panel]);
  }
}
