// P5 görüntüleyici araçları: pin görünümü, devre izleme, AMM adımları, arıza senaryoları, WDM quiz.
import { CLAMP, parsePN } from "./overhead.js";
import { pullCB } from "./state.js";

const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const KIND = { cb: "devre kesici", relay: "röle", ground: "toprak", tb: "terminal blok", splice: "ek (splice)", conn: "konnektör", end: "uç" };
const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const pick = a => a[Math.floor(Math.random() * a.length)];
const busy = (el, txt = "Veriler yükleniyor…") => { el.innerHTML = `<p class="v3-sub">${txt}</p>`; };
const dataErr = (ctx, el) => { el.innerHTML = `<p class="v3-sub">WDM verileri yüklenemedi${ctx.dataErr ? ": " + esc(ctx.dataErr.message) : ""}.</p>`; };
const title = (ctx, dg) => (ctx.data?.meta?.titles?.[dg] || "").trim();
function resumeBtn(ctx, el) {
  const A = ctx.ST.amm; if (!A || A.on) return;
  const d = document.createElement("div"); d.className = "v3-resume";
  d.innerHTML = `<button class="v3-btn pri">AMM görevine dön (${esc(A.tid || "")} · adım ${A.si + 1})</button>`;
  d.querySelector("button").onclick = () => { if (A.panel !== ctx.cfg.key) { ctx.nav(A.panel === "aft" ? "#/3d/p5aft" : "#/3d/p5"); return; } A.on = true; ammRender(ctx); };
  el.prepend(d);
}

/* ============================ KONNEKTÖR / PİN ============================ */
function connTable(ctx, cn, mp) {
  const cd = cn.cd, i = cn.info, pd = ctx.cfg.connPN[cd.d];
  const dec = i ? `<tr><td>Tip</td><td>BACC45F${i.plug ? "T – bayonet kilitli fiş" : "N – bayonet kilitli priz"} (MIL-C-26500, ön taraftan sökülen kontak)</td></tr>
    <tr><td>Gövde boyu</td><td>${i.shell}</td></tr><tr><td>Kelepçe</td><td>${CLAMP[i.clamp] || "—"}</td></tr><tr><td>Insert</td><td>${i.insert} düzeni</td></tr>
    <tr><td>Kontak</td><td>${i.contact === "S" ? "S – soket (dişi)" : "P – pin (erkek)"}</td></tr><tr><td>Kama</td><td>${i.key === "N" ? "normal" : i.key + " – alternatif kama konumu"}</td></tr>` : "";
  return `<small>${esc(mp.m.pn)} · ${esc(mp.m.name)}</small><b>${esc(cd.d)}</b>${cd.note ? ` <span class="v3-st">${esc(cd.note)}</span>` : ""}${ctx.ST.disc.has(cn.D) ? ' <span class="v3-st v3-bad">AYRILMIŞ</span>' : ""}
    <table class="v3-tbl"><tr><td>Parça no</td><td>${esc(cn.pn || "—")}</td></tr>${dec}
    <tr><td>Demet</td><td>${esc(cd.w)} – ${esc(ctx.cfg.bundles[cd.w] || "")}</td></tr>${cd.mw ? `<tr><td>M/W</td><td>${esc(cd.mw)}</td></tr>` : ""}
    <tr><td>WDM şema</td><td>${esc(pd ? pd[1] : "—")}${pd && title(ctx, pd[1]) ? " · " + esc(title(ctx, pd[1])) : ""}</td></tr></table>`;
}
const isContact = t => !/^(DED|SPARE|SPR|-+)$/i.test(t);
function contactIds(cn, pins) {
  const terms = pins.map(p => p.t).filter(isContact);
  const n = cn.nIns || 0;
  if (n && terms.every(t => /^\d+$/.test(t) && +t <= n)) return Array.from({ length: n }, (_, i) => String(i + 1));
  const letters = "ABCDEFGHJKLMNPRSTUVWXYZ".split("");
  if (n && n <= letters.length && terms.every(t => letters.indexOf(t) >= 0 && letters.indexOf(t) < n)) return letters.slice(0, n);
  return [...new Set([...(n ? Array.from({ length: n }, (_, i) => String(i + 1)) : []), ...terms])].sort((a, b) => (+a || 999) - (+b || 999) || a.localeCompare(b));
}
const BCOL = ["#2f7de1", "#e08a1f", "#2aa35a", "#c0392b", "#8e44ad", "#16a085", "#7f8c8d"];
function faceSVG(ids, used, bcol) {
  const n = ids.length, pts = []; if (n % 2) pts.push([0, 0]);
  const rings = Math.max(1, Math.ceil((Math.sqrt(12 * n - 3) - 3) / 6)); let ring = 0;
  while (pts.length < n) { ring++; const cnt = Math.min(n - pts.length, ring * 6 + (ring === rings ? 999 : 0)); const rr = ring / (rings + 0.5); for (let i = 0; i < cnt; i++) { const a = -Math.PI / 2 + i / cnt * Math.PI * 2; pts.push([Math.cos(a) * rr, Math.sin(a) * rr]); } }
  const R = 100, dot = Math.max(5, Math.min(13, 70 / Math.sqrt(n + 2)));
  const circ = ids.map((id, i) => {
    const [x, y] = pts[i], u = used[id], cx = R + x * R * 0.84, cy = R + y * R * 0.84;
    return `<g class="v3-pinG${u ? " used" : ""}" data-pin="${esc(id)}"><circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="${dot}" fill="${u ? bcol[u.b] || "#2f7de1" : "#30343a"}" stroke="#9aa0a6" stroke-width="1"/><text x="${cx.toFixed(1)}" y="${(cy + dot * 0.36).toFixed(1)}" font-size="${(dot * 0.95).toFixed(1)}" text-anchor="middle" fill="${u ? "#fff" : "#9aa0a6"}">${esc(id)}</text></g>`;
  }).join("");
  return `<svg viewBox="-8 -8 216 216" class="v3-face"><circle cx="100" cy="100" r="106" fill="#1d2023" stroke="#5f6a4c" stroke-width="6"/><rect x="94" y="-7" width="12" height="9" fill="#5f6a4c"/>${circ}</svg>`;
}
export function plugInfo(ctx, p, info) {
  const cn = p.cn, mp = p.mod, disc = ctx.ST.disc.has(cn.D);
  info.innerHTML = connTable(ctx, cn, mp) + `<div class="row v3-row"><button class="v3-btn" data-a="disc">${disc ? "Fişi tak" : "Fişi ayır"}</button><button class="v3-btn" data-a="trace">Demeti vurgula</button></div><div class="v3-pins"></div><p class="v3-sub">Modül önden çekildiğinde bu fiş yerinde kalır ve modülün arkasındaki prizden ayrılır. Ayırmadan önce ilgili devre kesicilerini açıp etiketleyin. Aynı boyutlu komşu konnektörlerin farklı kama konumları (6/7/8/9) yanlış takılmayı önler.</p>`;
  resumeBtn(ctx, info);
  info.querySelector('[data-a="disc"]').onclick = () => { ctx.setDisc(cn.D, !disc); plugInfo(ctx, p, info); };
  info.querySelector('[data-a="trace"]').onclick = () => ctx.focusParts([p, ctx.bundle(cn.cd.w)]);
  const box = info.querySelector(".v3-pins"); busy(box);
  ctx.dataP.then(d => {
    if (!d) return dataErr(ctx, box);
    const pins = d.pins[cn.D] || [];
    if (!pins.length) { box.innerHTML = `<p class="v3-sub">Bu konnektör için seçili uçakta (${esc(ctx.DATA.tailLabel(ctx.ST.tail))}) Hookup List kaydı yok.</p>`; return; }
    const ids = contactIds(cn, pins), bundles = [...new Set(pins.map(q => q.b))], bcol = {}; bundles.forEach((b, i) => bcol[b] = BCOL[i % BCOL.length]);
    const used = {}; for (const q of pins) if (isContact(q.t)) used[q.t] = used[q.t] || q;
    box.innerHTML = `<p class="v3-sub">Kontak yüzü (fişin arkasından değil, eşleşme yüzünden bakış; dizilim şematiktir – gerçek insert yerleşimi için MIL-C-26500 / SWPM 20-61-11 insert şemasına bakın). Kullanılan ${Object.keys(used).length} / ${ids.length} kontak:</p>
      <div class="v3-facewrap">${faceSVG(ids, used, bcol)}<div class="v3-legend">${bundles.map(b => `<span><i style="background:${bcol[b]}"></i>${esc(b)}</span>`).join("")}<span><i style="background:#30343a"></i>boş / yedek</span></div></div>
      <div class="v3-pin"></div>
      <div class="v3-scroll"><table class="v3-ptbl"><thead><tr><th>Pin</th><th>Tel</th><th>Demet</th><th>AWG</th><th>Şema</th><th>Uç</th></tr></thead><tbody>${pins.map((q, i) => {
        const last = q.paths[0] && q.paths[0][q.paths[0].length - 1];
        const end = last && last[0] === "w" ? `${last[6]}${last[7] && last[7] !== "=L" ? "-" + last[7] : ""}` : "";
        return `<tr data-pin="${esc(q.t)}" data-i="${i}"><td><b>${esc(q.t)}</b>${q.t === "DED" ? '<br><small>uç kapatılmış</small>' : ""}</td><td>${esc(q.w)}</td><td>${esc(q.b)}</td><td>${esc(q.ga)}</td><td>${esc(q.dg)}</td><td>${esc(end)}</td></tr>`;
      }).join("")}</tbody></table></div>`;
    box.querySelectorAll("[data-pin]").forEach(el => el.onclick = () => showPin(ctx, p, el.dataset.pin, +el.dataset.i));
  });
}
function endHTML(ctx, s) {
  const [, w, b, ga, co, len, to, tt, k] = s, d = ctx.data;
  let desc = ctx.DATA.eqDesc(d.eq, to), extra = "";
  if (k === "cb") {
    const cb = d.cbs.byId[to];
    if (cb) { desc = cb.name.replace(/^CB-/, ""); extra = ` <span class="v3-st">${esc(cb.pn)} ${esc(cb.g)}${ctx.ST.pulled.has(to) ? " · AÇIK" : ""}</span>${busTxt(ctx, to)} <button class="v3-link" data-cb="${esc(to)}">CB panelinde göster</button>`; }
  }
  if (d.eeD && d.eeD.has(to)) extra += ` <button class="v3-link" data-ee="${esc(to)}">E/E rafında göster</button>`;
  const plug = ctx.plugOf(to);
  if (k === "conn" && plug) extra += ` <button class="v3-link" data-plug="${esc(to)}" data-pin="${esc(tt)}">P5'te göster</button>`;
  return `<li><span class="v3-w">tel ${esc(w)} · ${esc(b)} · ${esc(ga)} AWG${co ? " · tip " + esc(co) : ""}${len ? " · " + esc(len) + " ft-in" : ""}</span><br>→ <b>${esc(to)}</b>${tt && tt !== "=L" ? " kontak " + esc(tt) : ""} <i>${esc(KIND[k] || "")}</i>${desc ? " – " + esc(desc) : ""}${extra}</li>`;
}
export function showPin(ctx, p, term, idx) {
  const d = ctx.data; if (!d) return;
  const el = ctx.info.querySelector(".v3-pin"); if (!el) return;
  const list = (d.pins[p.cn.D] || []).filter(q => q.t === term);
  ctx.info.querySelectorAll(".v3-pinG").forEach(g => g.classList.toggle("sel", g.dataset.pin === term));
  ctx.info.querySelectorAll(".v3-ptbl tr").forEach(r => r.classList.toggle("sel", r.dataset.pin === term));
  if (!list.length) { el.innerHTML = `<div class="v3-card"><b>${esc(p.cn.cd.d)} kontak ${esc(term)}</b><p>Bu kontakta tel yok (boş / yedek kontak). Boş kontaklara sızdırmazlık tapası (sealing plug) takılı olmalıdır.</p></div>`; return; }
  el.innerHTML = list.map(q => `<div class="v3-card"><b>${esc(p.cn.cd.d)} kontak ${esc(q.t)}</b> <span class="v3-st">${esc(q.w)} · ${esc(q.b)} · ${esc(q.ga)} AWG</span>
    <p>WDM şema <b>${esc(q.dg)}</b>${title(ctx, q.dg) ? " – " + esc(title(ctx, q.dg)) : ""}</p>
    ${q.paths.length ? q.paths.map((path, i) => `<p class="v3-sub">Devre izi ${q.paths.length > 1 ? i + 1 : ""} (WDM Wire List, ${esc(ctx.DATA.tailLabel(ctx.ST.tail))}):</p><ol class="v3-trace"><li><b>${esc(p.cn.D)}</b> kontak ${esc(q.t)} – ${esc(p.mod.m.pn)} ${esc(p.mod.m.name)}</li>${path.map(s => s[0] === "m" ? `<li class="v3-mate">⇄ ayrılabilir bağlantı: <b>${esc(s[1])}</b> ${esc(ctx.DATA.eqDesc(d.eq, s[1]))}</li>` : endHTML(ctx, s)).join("")}</ol>`).join("") : '<p class="v3-sub">Wire List\'te bu telin karşı ucu bulunamadı.</p>'}
    <div class="row v3-row"><button class="v3-btn" data-tr="${esc(q.b)}">3D'de izle</button></div></div>`).join("") + `<p class="v3-sub">Not: iz, sayfa kenarındaki ayrılabilir bağlantılardan (D4xxxxP/J) geçerek devam ettirildi. Bazı izler E/E bölmesindeki bir rafta veya başka bir şemada sürer; orada uç "konnektör" olarak görünür.</p>`;
  el.querySelectorAll("[data-tr]").forEach(b => b.onclick = () => ctx.focusParts([p, ctx.bundle(b.dataset.tr)]));
  el.querySelectorAll("[data-cb]").forEach(b => b.onclick = () => { ctx.ST.cbFocus = { ids: [b.dataset.cb], back: { panel: ctx.cfg.key, D: p.cn.D, pin: term } }; ctx.nav("#/3d/cb"); });
  el.querySelectorAll("[data-ee]").forEach(b => b.onclick = () => { ctx.ST.eeFocus = { D: b.dataset.ee, back: { panel: ctx.cfg.key, D: p.cn.D, pin: term } }; ctx.nav("#/3d/ee"); });
  el.querySelectorAll("[data-plug]").forEach(b => b.onclick = () => { const pp = ctx.plugOf(b.dataset.plug); if (pp) { ctx.selectAndFly(pp); setTimeout(() => showPin(ctx, pp, b.dataset.pin), 50); } });
  el.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

const busTxt = (ctx, id) => { const b = ctx.PW.cbBuses(ctx.ST.busMap, ctx.DATA.effOk, ctx.ST.tail, id); if (!b.length) return ""; const live = ctx.PW.cbBusOn(ctx.ST.sim, ctx.stOf, ctx.ST.busMap, ctx.DATA.effOk, ctx.ST.tail, id); return ` · <span class="v3-st${live ? "" : " v3-bad"}">${esc(b.map(k => ctx.PW.BUS_LABEL[k]).join(" / "))}: bara ${live ? "enerjili" : "enerjisiz"}</span>`; };

/* ============================ DEVRELER ============================ */
function circuitList(ctx, mp, dgs, el) {
  const d = ctx.data; const rows = [];
  for (const cn of mp.conns) for (const q of d.pins[cn.D] || []) if (!dgs || dgs.includes(q.dg)) rows.push({ cn, q });
  if (!rows.length) { el.innerHTML = `<p class="v3-sub">Bu modülün konnektörlerinde ${dgs ? esc(dgs.join(", ")) + " şemasına ait pin" : "pin"} bulunamadı (seçili uçak: ${esc(ctx.DATA.tailLabel(ctx.ST.tail))}).</p>`; return; }
  const by = {}; for (const r of rows) (by[r.q.dg] = by[r.q.dg] || []).push(r);
  el.innerHTML = Object.keys(by).sort().map(dg => `<details${dgs ? " open" : ""}><summary><b>${esc(dg)}</b> ${esc(title(ctx, dg))} <small>(${by[dg].length} pin)</small></summary><ul class="v3-ul">${by[dg].map(r => {
    const last = r.q.paths[0] && r.q.paths[0][r.q.paths[0].length - 1];
    const cb = last && last[8] === "cb" ? d.cbs.byId[last[6]] : null;
    return `<li><button class="v3-link" data-D="${r.cn.D}" data-pin="${esc(r.q.t)}">${esc(r.cn.cd.d)}-${esc(r.q.t)}</button> tel ${esc(r.q.w)} → ${last ? esc(last[6]) : "?"}${cb ? " (" + esc(cb.name.replace(/^CB-/, "")) + ", " + esc(cb.pn + " " + cb.g) + ")" : ""}</li>`;
  }).join("")}</ul></details>`).join("");
  el.querySelectorAll("[data-D]").forEach(b => b.onclick = () => { const pp = ctx.plugOf(b.dataset.D); if (pp) { ctx.selectAndFly(pp); setTimeout(() => showPin(ctx, pp, b.dataset.pin), 60); } });
}
export function moduleExtras(ctx, mp, el) {
  resumeBtn(ctx, el.parentElement);
  if (mp.m.blank) return;
  const keys = ammKeysFor(ctx, mp.id);
  el.innerHTML = `${keys.length ? `<p class="v3-sub">AMM görevleri (adım adım, 3D eylemlerle):</p><div class="v3-ammlist"></div>` : ""}<p class="v3-sub">Bu modülün WDM devreleri:</p><div class="v3-circ"></div>`;
  const circ = el.querySelector(".v3-circ"); busy(circ);
  ctx.dataP.then(d => {
    if (!d) return dataErr(ctx, circ);
    const al = el.querySelector(".v3-ammlist");
    if (al) al.innerHTML = keys.map(k => d.amm[k].tasks.map((t, i) => `<button class="v3-btn" data-k="${k}" data-i="${i}">${esc(t.id)} · ${esc(/Removal/i.test(t.name) ? "Söküm" : /Install/i.test(t.name) ? "Takma" : t.name)}<small>${esc(d.amm[k].title)}</small></button>`).join("")).join("");
    al && al.querySelectorAll("button").forEach(b => b.onclick = () => ammStart(ctx, b.dataset.k, +b.dataset.i, mp.id));
    if (!mp.conns.length) { circ.innerHTML = '<p class="v3-sub">Bu yapı parçasının modül konnektörü yok (anahtarlar doğrudan kablolanır).</p>'; return; }
    circuitList(ctx, mp, null, circ);
  });
}
export function ctrlExtras(ctx, c, el) {
  resumeBtn(ctx, el.parentElement);
  const id = c.o.id, dgs = ctx.PW.CTRL_DG[id], sys = ctx.PW.SYS_CB[id] || ctx.PW.SYS_CB[(c.o.lights || [])[0]?.id];
  let h = "";
  if (c.kind === "L" && !c.o.key) h += `<div class="row v3-row">${ctx.ST.bulbs.has(id) ? `<button class="v3-btn pri" data-a="bulb">Ampulü değiştir</button>` : ""}<button class="v3-btn" data-a="test">Lamba testi (basılı tut)</button></div>`;
  const own = ctx.lightCBs && ctx.lightCBs[id];
  if (own && !sys) h += `<p class="v3-sub">Bu ışığın devresindeki devre kesiciler (WDM pin izinden):</p><ul class="v3-ul v3-cbs"></ul>`;
  if (sys) h += `<p class="v3-sub">İlgili devre kesiciler:</p><ul class="v3-ul v3-cbs"></ul>`;
  if (dgs) h += `<p class="v3-sub">İlgili WDM devresi: ${dgs.map(esc).join(", ")}</p><div class="v3-circ"></div>`;
  el.innerHTML = h;
  const bb = el.querySelector('[data-a="bulb"]'); if (bb) bb.onclick = () => { ctx.ST.bulbs.delete(id); ctx.computeLights(); ctx.showInfo(); };
  const tb = el.querySelector('[data-a="test"]'); if (tb) { const on = () => ctx.setLampTest(true), off = () => ctx.setLampTest(false); tb.onpointerdown = on; tb.onpointerup = off; tb.onpointerleave = off; }
  if (!sys && !dgs && !own) return;
  ctx.dataP.then(d => {
    if (!d) return;
    const ul = el.querySelector(".v3-cbs");
    if (ul) {
      const list = (sys || own).map(cid => d.cbs.byId[cid]).filter(Boolean);
      ul.innerHTML = list.length ? list.map(cb => `<li>${esc(cb.name.replace(/^CB-/, ""))} – <b>${esc(cb.pn)} ${esc(cb.g)}</b> (${esc(cb.cb)})${busTxt(ctx, cb.cb)}${ctx.ST.pulled.has(cb.cb) ? ' <span class="v3-st v3-bad">AÇIK</span>' : ""} <button class="v3-link" data-cb="${cb.cb}">göster</button></li>`).join("") : "<li>Bu uçakta listede yok.</li>";
      ul.querySelectorAll("[data-cb]").forEach(b => b.onclick = () => { ctx.ST.cbFocus = { ids: [b.dataset.cb], back: { panel: ctx.cfg.key } }; ctx.nav("#/3d/cb"); });
    }
    const circ = el.querySelector(".v3-circ"); if (circ) circuitList(ctx, c.mod, dgs, circ);
  });
}

/* ============================ AMM ============================ */
function ammKeysFor(ctx, modId) {
  const keys = ["", "t", "d", "a", "b"].map(s => modId + s);
  if (!ctx.data) return keys.filter(k => ["p5_2", "p5_3", "p5_4", "p5_5", "p5_6", "p5_8", "p5_9", "p5_10", "p5_11", "p5_12", "p5_13", "p5_14", "p5_16a", "p5_16b", "p5_17", "p5_18", "p5_19", "p5_28", "p5_68", "p5_69", "p5_70", "p5_80", "p5_2t", "p5_10d"].includes(k));
  return keys.filter(k => ctx.data.amm[k]);
}
export function ammStart(ctx, key, ti, modId) {
  const t = ctx.data.amm[key].tasks[ti];
  ctx.ST.amm = { panel: ctx.cfg.key, key, ti, si: 0, on: true, mod: modId, tid: t.id, opened: [] };
  ammRender(ctx);
}
export function ammStop(ctx, keep) { if (!ctx.ST.amm) return; if (keep) ctx.ST.amm.on = false; else ctx.ST.amm = null; }
const ACT = {
  power_off: "Elektrik gücünü kes", power_on: "Elektrik gücünü ver", hinge_open: "P5 panelini menteşeden aç", hinge_close: "Paneli kapat",
  cb_open: "CB'leri aç ve etiketle", cb_close: "CB'leri kapat, etiketleri sök", cb_check: "CB'leri kontrol et", disconnect: "Konnektörleri ayır", connect: "Konnektörleri tak",
  covers: "Koruyucu kapakları tak", dzus_loose: "Dzus bağlantılarını gevşet", dzus_tight: "Dzus bağlantılarını sık", inspect: "Muayene et", pull: "Modülü çıkar", install: "Modülü yerine yerleştir"
};
export function ammRender(ctx) {
  const A = ctx.ST.amm, info = ctx.info;
  if (!ctx.data) { busy(info); ctx.dataP.then(() => ammRender(ctx)); return; }
  const doc = ctx.data.amm[A.key], task = doc.tasks[A.ti], steps = task.steps, s0 = steps[A.si];
  const s = s0.a ? s0 : { ...s0, a: /^Open the P5 overhead panel/i.test(s0.t) ? "hinge_open" : /^Close the P5 overhead panel/i.test(s0.t) ? "hinge_close" : "" };
  const mp = ctx.modById(A.mod);
  const cbs = (s.cbs || []).map(([panel, grid, cb, name]) => ({ panel, grid, cb, name }));
  const cbRows = cbs.length ? `<ul class="v3-ul v3-cbs">${cbs.map(c => `<li><b>${esc(c.panel)} ${esc(c.grid)}</b> ${esc(c.cb)} – ${esc(c.name)} ${ctx.ST.pulled.has(c.cb) ? `<span class="v3-st v3-bad">AÇIK${ctx.ST.tagged.has(c.cb) ? " · etiketli" : ""}</span>` : '<span class="v3-st">kapalı</span>'}</li>`).join("")}</ul>` : "";
  const act = s.a && ACT[s.a] ? `<button class="v3-btn pri" data-a="do">${esc(ACT[s.a])}</button>` : "";
  const cbBtn = cbs.length || (s.a === "cb_close" && A.opened.length) ? `<button class="v3-btn" data-a="cbv">CB panelinde göster</button>` : "";
  info.innerHTML = `<small>AMM ${esc(task.id)} · ${esc(doc.title)}</small><b>${esc(task.name)}</b>
    <div class="v3-prog"><i style="width:${((A.si + 1) / steps.length * 100).toFixed(1)}%"></i></div>
    <div class="v3-step"><small>${esc(s.sec || "")} · adım ${esc(s.n)} (${A.si + 1}/${steps.length})</small>${s.head ? `<p class="v3-sub">${esc(s.head)}</p>` : ""}<p class="v3-amm">${esc(s.t).replace(/\n/g, "<br>").replace(/(WARNING:[^<]*)/g, '<span class="v3-warn">$1</span>').replace(/(CAUTION:[^<]*)/g, '<span class="v3-caut">$1</span>')}</p>${cbRows}</div>
    <div class="row v3-row">${act}${cbBtn}</div>
    <div class="row v3-row"><button class="v3-btn" data-a="prev"${A.si ? "" : " disabled"}>‹ Önceki</button><button class="v3-btn" data-a="next">${A.si < steps.length - 1 ? "Sonraki ›" : "Görevi bitir"}</button><button class="v3-btn" data-a="stop">Kapat</button></div>
    <p class="v3-sub">Metin AMM'den (İngilizce, özgün). ${mp ? "Eylemler 3D modelde " + esc(mp.m.pn) + " üzerinde gösterilir." : "Bu modül diğer panel görünümündedir."} Görevi yapmadan önce her zaman uçağa ait güncel AMM revizyonunu kullanın.</p>`;
  const go = d => { A.si = Math.max(0, Math.min(steps.length - 1, A.si + d)); ammRender(ctx); };
  info.querySelector('[data-a="prev"]').onclick = () => go(-1);
  info.querySelector('[data-a="next"]').onclick = () => { if (A.si < steps.length - 1) go(1); else { ctx.ST.amm = null; ctx.select(mp || null); } };
  info.querySelector('[data-a="stop"]').onclick = () => { ctx.ST.amm = null; ctx.select(mp || null); };
  const cbv = info.querySelector('[data-a="cbv"]'); if (cbv) cbv.onclick = () => { ctx.ST.cbFocus = { ids: cbs.length ? cbs.map(c => c.cb) : A.opened, back: { panel: ctx.cfg.key, amm: true } }; ctx.nav("#/3d/cb"); };
  const doB = info.querySelector('[data-a="do"]'); if (doB) doB.onclick = () => { ammAct(ctx, s, cbs, mp); ammRender(ctx); };
  if (mp && s.a && ["dzus_loose", "dzus_tight", "pull", "install", "disconnect", "connect", "inspect", "covers"].includes(s.a))
    ctx.focusParts([mp], ctx.hingeOpen ? null : ["disconnect", "connect"].includes(s.a) ? { x: 0.25, y: 0.35, z: -1 } : { x: 0.12, y: -0.1, z: 1 });
}
function ammAct(ctx, s, cbs, mp) {
  const A = ctx.ST.amm;
  switch (s.a) {
    case "power_off": ctx.setPower("cold"); break;
    case "power_on": ctx.setPower("gpu"); break;
    case "hinge_open": ctx.setHinge(true); break;
    case "hinge_close": ctx.setHinge(false); break;
    case "cb_open": for (const c of cbs) { pullCB(c.cb, true, true); if (!A.opened.includes(c.cb)) A.opened.push(c.cb); } break;
    case "cb_close": for (const id of (cbs.length ? cbs.map(c => c.cb) : A.opened)) pullCB(id, false, false); break;
    case "dzus_loose": if (mp) ctx.spinDzus(mp, true); break;
    case "dzus_tight": if (mp) { ctx.spinDzus(mp, false); ctx.setPull(mp, 0); } break;
    case "pull": if (mp) ctx.setPull(mp, 1); break;
    case "install": if (mp) ctx.setPull(mp, mp.conns.some(cn => ctx.ST.disc.has(cn.D)) ? 0.3 : 0); break;
    case "disconnect": if (mp) { if (!mp.pull) ctx.setPull(mp, 0.3); mp.conns.forEach(cn => ctx.setDisc(cn.D, true)); } break;
    case "connect": if (mp) { mp.conns.forEach(cn => ctx.setDisc(cn.D, false)); } break;
  }
  ctx.computeLights();
}

/* ============================ ARIZA SENARYOLARI ============================ */
const SCEN = [
  { id: "xfeed", t: "Crossfeed valfi açılmıyor", power: "gpu", ctl: { xfeed: 1 }, cb: "C00361", lt: "xfOpen",
    sym: "Yer gücü var. FUEL CROSSFEED seçicisi OPEN konumunda, fakat VALVE OPEN ışığı hiç yanmıyor. Lamba testinde ışık yanıyor.",
    hint: "Lamba sağlam → sorun valfte veya valfin beslemesinde. P5-2'nin crossfeed devresini (WDM 28-22-11) izle: seçicinin teli nereye gidiyor?" },
  { id: "elec2", t: "ELEC 2 pompası basınç vermiyor", power: "gpu", ctl: { hydEl2: 1 }, cb: "C00881", lt: "hlpEl2",
    sym: "Yer gücü var, ELEC 2 hidrolik pompa anahtarı ON. ELEC 2 LOW PRESSURE ışığı sönmüyor; ELEC 1 açılınca onun ışığı sönüyor.",
    hint: "ELEC 2 pompası A sistemine basınç verir ve AC motorludur. Pompa motorunun güç devre kesicisi kokpitte değil, E/E bölmesindeki güç dağıtım panellerindedir (P91/P92)." },
  { id: "yd", t: "Yaw damper devreye girmiyor", power: "gpu", ctl: { hydEl1: 1, yd: 1 }, cb: "C00285", lt: "ydLt",
    sym: "B sistemi basınçlı (ELEC 1 ON), YAW DAMPER anahtarı ON; YAW DAMPER ışığı sönmüyor.",
    hint: "Hidrolik koşul sağlanmış → yaw damper elektrik beslemesine bak. Uçuş kontrol beslemeleri kaptan tarafındaki P18-1'dedir." },
  { id: "pitot", t: "Kaptan pitot ısıtması çalışmıyor", power: "gpu", ctl: { prbA: 1 }, cb: "C00523", lt: "pCapt",
    sym: "PROBE HEAT A ON. CAPT PITOT ışığı sönmüyor; L ELEV PITOT, L ALPHA VANE ve TEMP PROBE ışıkları söndü.",
    hint: "Yalnız bir prob etkileniyor → o probun ısıtıcı beslemesi. P18-3'teki HEATERS sırasına bak." },
  { id: "wheat", t: "Sol yan cam ısıtması", power: "gpu", ctl: { wLS: 1, wLF: 1, wRF: 1, wRS: 1 }, cb: "C00225", lt: "wOn1",
    sym: "Tüm WINDOW HEAT anahtarları ON. L SIDE'ın ON ışığı yanmıyor, diğer üçü yanıyor. OVERHEAT ışığı yok.",
    hint: "Her camın ayrı bir kontrol ünitesi ve AC kontrol beslemesi vardır (P18-3 WINDOW HEAT CONTROL)." },
  { id: "apugen", t: "APU jeneratörü baraya bağlanmıyor", power: "apu", unbus: true, cb: "C01285", lt: "apuGob",
    sym: "APU çalışıyor (APU GEN OFF BUS yanık). APU GEN anahtarları ON'a basılıyor ama transfer baralar beslenmiyor, APU GEN OFF BUS sönmüyor.",
    hint: "APU çalışıyor ama kontaktör kapanmıyor → APU jeneratör kontrol ünitesinin (AGCU) beslemesi. P6-4'ün alt sıralarına bak." },
  { id: "conn", t: "Yakıt panelinin yarısı ölü", power: "gpu", ctl: { xfeed: 1 }, disc: "D00628", lt: "lpF1",
    sym: "Yer gücü var. P5-2 yakıt panelinde LOW PRESSURE ve VALVE OPEN ışıkları hiç yanmıyor, lamba testinde de yanmıyor. Diğer modüller normal.",
    hint: "Tek bir modülün çok sayıda ışığı birden etkileniyor → ortak nokta modülün arka konnektörleridir. Arkadan bak (Arka / Paneli aç)." },
  { id: "bulb", t: "GRD POWER AVAILABLE yanmıyor", power: "gpu", bulb: "grdAvail", lt: "grdAvail",
    sym: "Yer gücü bağlı ve GRD POWER anahtarıyla baralar besleniyor (TRANSFER BUS OFF sönük). Fakat GRD POWER AVAILABLE ışığı yanmıyor, lamba testinde de yanmıyor.",
    hint: "Sistem çalışıyor, yalnız gösterge sönük ve lamba testi de yakamıyor → arıza ışığın kendisinde." }
];
function scenFixed(ctx, sc) { if (sc.cb) return !ctx.ST.pulled.has(sc.cb); if (sc.disc) return !ctx.ST.disc.has(sc.disc); if (sc.bulb) return !ctx.ST.bulbs.has(sc.bulb); return true; }
export function scenarios(ctx) {
  const ST = ctx.ST, info = ctx.info, sc = ST.scen && SCEN.find(x => x.id === ST.scen.id);
  if (sc && ST.scen.panel === ctx.cfg.key) return scenView(ctx, sc);
  info.innerHTML = `<b>Arıza senaryoları</b><p>Bir senaryo seç: panelde gizli bir arıza oluşturulur. Belirtiyi panelde gör, devreyi pin/tel izinden takip et, arızayı CB panelinde, konnektörde veya ışıkta bul ve gider. Devre kesici ve konnektör bilgileri seçili uçağın WDM verisinden gelir.</p>
    <div class="v3-scen">${SCEN.filter(x => ctx.cfg.key === "fwd").map(x => `<button class="v3-btn" data-s="${x.id}"><b>${esc(x.t)}</b><small>${esc(x.sym.slice(0, 90))}…</small></button>`).join("") || "<p>Senaryolar ön panel görünümündedir.</p>"}</div>`;
  info.querySelectorAll("[data-s]").forEach(b => b.onclick = () => startScen(ctx, SCEN.find(x => x.id === b.dataset.s)));
}
function startScen(ctx, sc) {
  const ST = ctx.ST;
  ST.bulbs.clear(); ST.disc.clear(); for (const s of SCEN) if (s.cb) { ST.pulled.delete(s.cb); ST.tagged.delete(s.cb); }
  ctx.setPower(sc.power);
  for (const [k, v] of Object.entries(sc.ctl || {})) ctx.setCtl(k, v);
  if (sc.unbus) { ST.sim.src[1] = null; ST.sim.src[2] = null; }
  if (sc.cb) ST.pulled.add(sc.cb);
  if (sc.disc) ST.disc.add(sc.disc);
  if (sc.bulb) ST.bulbs.add(sc.bulb);
  ST.scen = { id: sc.id, panel: ctx.cfg.key, t0: Date.now(), hint: false };
  ctx.computeLights(); ctx.goView("front");
  scenView(ctx, sc);
}
function scenView(ctx, sc, msg) {
  const ST = ctx.ST, info = ctx.info;
  info.innerHTML = `<small>Arıza senaryosu</small><b>${esc(sc.t)}</b><div class="v3-card"><p>${esc(sc.sym)}</p></div>
    ${ST.scen.hint ? `<p class="v3-sub">İpucu: ${esc(sc.hint)}</p>` : ""}${msg || ""}
    <div class="row v3-row"><button class="v3-btn pri" data-a="check">Arıza giderildi mi? Kontrol et</button>${ST.scen.hint ? "" : '<button class="v3-btn" data-a="hint">İpucu</button>'}<button class="v3-btn" data-a="sym">Belirtiyi göster</button><button class="v3-btn" data-a="quit">Vazgeç</button></div>
    <p class="v3-sub">Araçlar: anahtar/ışık seç → "İlgili WDM devresi"; konnektöre dokun → pin izi → "CB panelinde göster"; CB panelinde dokunarak CB'yi kapat; ayrılmış fişi "Fişi tak" ile tak; yanık ampulü ışığı seçip değiştir.</p>`;
  info.querySelector('[data-a="hint"]')?.addEventListener("click", () => { ST.scen.hint = true; scenView(ctx, sc); });
  info.querySelector('[data-a="sym"]').onclick = () => { const c = ctx.S.lightsById[sc.lt]; if (c) ctx.focusParts([{ obj: c.mesh }], { x: 0, y: -0.05, z: 1 }); };
  info.querySelector('[data-a="quit"]').onclick = () => { if (sc.cb) ST.pulled.delete(sc.cb); if (sc.disc) ST.disc.delete(sc.disc); if (sc.bulb) ST.bulbs.delete(sc.bulb); ST.scen = null; ctx.computeLights(); scenarios(ctx); };
  info.querySelector('[data-a="check"]').onclick = () => {
    if (!scenFixed(ctx, sc)) { scenView(ctx, sc, '<p class="v3-bad">Arıza hâlâ mevcut. Belirti devam ediyor.</p>'); return; }
    const done = () => {
      const d = ctx.data, cb = sc.cb && d && d.cbs.byId[sc.cb];
      let ex = "";
      if (cb) {
        const hits = []; for (const D in d.pins) for (const q of d.pins[D]) for (const p of q.paths) { const l = p[p.length - 1]; if (l && l[6] === sc.cb) hits.push(`${D}-${q.t} (tel ${q.w}, ${q.b})`); }
        ex = `<p>Neden: <b>${esc(cb.name)}</b> (${esc(cb.cb)}) açıktı. Konumu: <b>${esc(cb.pn)} ${esc(cb.g)}</b>${ctx.DATA.PANEL_DESC[cb.pn.split("-")[0]] ? " – " + esc(ctx.DATA.PANEL_DESC[cb.pn.split("-")[0]]) : ""}. WDM şeması ${esc(cb.dg)}${title(ctx, cb.dg) ? " (" + esc(title(ctx, cb.dg)) + ")" : ""}.</p>${hits.length ? `<p class="v3-sub">P5 konnektörlerinden bu CB'ye giden teller: ${hits.slice(0, 6).map(esc).join(", ")}</p>` : `<p class="v3-sub">Bu CB'nin devresi P5 konnektörlerine doğrudan değil, röle/kontrol ünitesi üzerinden bağlanır.</p>`}`;
      } else if (sc.disc) ex = `<p>Neden: <b>${esc(ctx.DATA.shortD(sc.disc))}</b> fişi modülün arkasından ayrılmıştı (örneğin modül değişiminden sonra takılmamış). Bakım sonrası konnektörlerin tam oturduğu ve bayonet kilidinin "klik" ile kilitlendiği kontrol edilmelidir.</p>`;
      else if (sc.bulb) ex = `<p>Neden: ışık modülündeki ampul yanmıştı. Lamba testinin de yakamaması ampul/ışık modülü arızasını gösterir; sistem (baraların beslenmesi) sağlamdı.</p>`;
      info.innerHTML = `<small>Arıza senaryosu</small><b>✓ ${esc(sc.t)} – giderildi</b>${ex}<p class="v3-sub">Süre: ${Math.round((Date.now() - ST.scen.t0) / 1000)} sn${ST.scen.hint ? " (ipucu kullanıldı)" : ""}</p><div class="row v3-row"><button class="v3-btn pri" data-a="more">Başka senaryo</button></div>`;
      ST.scen = null; info.querySelector('[data-a="more"]').onclick = () => scenarios(ctx);
    };
    ctx.dataP.then(done);
  };
}

/* ============================ WDM QUIZ ============================ */
export function quiz(ctx) {
  const info = ctx.info; busy(info, "Sorular WDM verisinden hazırlanıyor…");
  ctx.dataP.then(d => {
    if (!d) return dataErr(ctx, info);
    const Q = makeQuestions(ctx, d, 10); let i = 0, score = 0;
    const show = () => {
      if (i >= Q.length) { info.innerHTML = `<b>WDM quiz bitti</b><p>Skor: <b>${score} / ${Q.length}</b></p><div class="row v3-row"><button class="v3-btn pri" data-a="again">Yeni sorular</button></div>`; info.querySelector("button").onclick = () => quiz(ctx); return; }
      const q = Q[i];
      info.innerHTML = `<small>WDM quiz · ${i + 1}/${Q.length} · ${esc(ctx.DATA.tailLabel(ctx.ST.tail))}</small><b>${esc(q.q)}</b><div class="v3-opts">${q.opts.map((o, k) => `<button class="v3-btn" data-k="${k}">${esc(o)}</button>`).join("")}</div><div class="v3-fb"></div>`;
      info.querySelectorAll("[data-k]").forEach(b => b.onclick = () => {
        const k = +b.dataset.k, ok = k === q.a; if (ok) score++;
        info.querySelectorAll("[data-k]").forEach(x => { x.disabled = true; x.classList.toggle("ok", +x.dataset.k === q.a); x.classList.toggle("no", +x.dataset.k === k && !ok); });
        info.querySelector(".v3-fb").innerHTML = `<p>${ok ? "✓ Doğru." : "✗ Yanlış."} ${esc(q.ex || "")}</p><div class="row v3-row">${q.plug ? '<button class="v3-btn" data-a="see">3D\'de gör</button>' : ""}<button class="v3-btn pri" data-a="nx">${i < Q.length - 1 ? "Sonraki" : "Sonuç"}</button></div>`;
        info.querySelector('[data-a="nx"]').onclick = () => { i++; show(); };
        const see = info.querySelector('[data-a="see"]'); if (see) see.onclick = () => { const p = ctx.plugOf(q.plug); if (p) { ctx.selectAndFly(p); setTimeout(() => showPin(ctx, p, q.pin), 60); } };
      });
    };
    show();
  });
}
function opts4(correct, pool) { const o = shuffle([...new Set(pool.filter(x => x && x !== correct))]).slice(0, 3); o.push(correct); shuffle(o); return { opts: o, a: o.indexOf(correct) }; }
function makeQuestions(ctx, d, n) {
  const conns = ctx.S.mods.flatMap(mp => mp.conns.map(cn => ({ mp, cn })));
  const pinRecs = []; for (const { mp, cn } of conns) for (const q of d.pins[cn.D] || []) pinRecs.push({ mp, cn, q });
  const cbEnds = pinRecs.map(r => { const p = r.q.paths[0]; const l = p && p[p.length - 1]; return l && l[8] === "cb" && d.cbs.byId[l[6]] ? { ...r, cb: d.cbs.byId[l[6]] } : null; }).filter(Boolean);
  const cbNames = d.cbs.list.map(c => c.name.replace(/^CB-/, "")), locs = d.cbs.list.map(c => c.pn + " " + c.g), mpns = ctx.S.mods.filter(m => !m.m.blank && !m.m.struct).map(m => m.m.pn);
  const gen = [
    () => { if (!conns.length) return null; const { mp, cn } = pick(conns); return { q: `${cn.cd.d} konnektörü hangi modülün arkasındadır?`, ...opts4(mp.m.pn, mpns), ex: `${cn.cd.d}: ${mp.m.pn} ${mp.m.name}, demet ${cn.cd.w}.`, plug: cn.D }; },
    () => { if (!cbEnds.length) return null; const r = pick(cbEnds), nm = r.cb.name.replace(/^CB-/, ""); return { q: `${r.cn.cd.d} kontak ${r.q.t} (tel ${r.q.w}) hangi devre kesiciye gider?`, ...opts4(nm, cbNames), ex: `${nm}: ${r.cb.pn} ${r.cb.g} (${r.cb.cb}). Şema ${r.q.dg}.`, plug: r.cn.D, pin: r.q.t }; },
    () => { if (!cbEnds.length) return null; const r = pick(cbEnds), c = r.cb, loc = c.pn + " " + c.g; return { q: `"${c.name.replace(/^CB-/, "")}" devre kesicisi nerededir?`, ...opts4(loc, locs), ex: `${loc}${ctx.DATA.PANEL_DESC[c.pn.split("-")[0]] ? " – " + ctx.DATA.PANEL_DESC[c.pn.split("-")[0]] : ""}.` }; },
    () => { const ws = Object.keys(ctx.cfg.bundles).filter(w => ctx.cfg.bundles[w] && !/Bkz/.test(ctx.cfg.bundles[w])); if (ws.length < 4) return null; const w = pick(ws); return { q: `${w} demetinin WDM Master Bundle List tanımı hangisidir?`, ...opts4(ctx.cfg.bundles[w], ws.map(x => ctx.cfg.bundles[x])), ex: `${w}: ${ctx.cfg.bundles[w]}` }; },
    () => { const r = pick(pinRecs); if (!r) return null; const t = title(ctx, r.q.dg); const corr = r.q.dg + (t ? " " + t : ""); return { q: `${r.cn.cd.d} kontak ${r.q.t} hangi WDM şemasına aittir?`, ...opts4(corr, pinRecs.map(x => x.q.dg + (title(ctx, x.q.dg) ? " " + title(ctx, x.q.dg) : ""))), ex: `Hookup List: ${r.cn.cd.d}-${r.q.t}, tel ${r.q.w}, ${r.q.b}, şema ${r.q.dg}.`, plug: r.cn.D, pin: r.q.t }; },
    () => { const r = pick(pinRecs.filter(x => /^\d+$/.test(x.q.ga))); if (!r) return null; return { q: `${r.cn.cd.d} kontak ${r.q.t} telinin (${r.q.w}) kesiti kaç AWG'dir?`, ...opts4(r.q.ga + " AWG", ["12", "14", "16", "18", "20", "22", "24", "26"].map(x => x + " AWG")), ex: `Hookup List: ${r.q.ga} AWG. Küçük AWG numarası daha kalın tel demektir.`, plug: r.cn.D, pin: r.q.t }; }
  ];
  const out = []; let guard = 0;
  while (out.length < n && guard++ < 200) { const q = gen[out.length % gen.length](); if (q && q.opts.length >= 2 && !out.some(x => x.q === q.q)) out.push(q); }
  return out;
}
