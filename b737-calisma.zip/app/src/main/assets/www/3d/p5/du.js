// Ekran birimleri (DU) ve yedek göstergeler: PFD, ND, motor göstergesi (EICAS), MFD, yedek ufuk, hız/irtifa, RMI, saat, flap, fren basıncı.
// Eğitim amaçlı, basitleştirilmiş çizimler; değerler uygulamanın simülasyon durumundan gelir (yerde, park hâlinde uçak).
const FF = '"RC", "Roboto Condensed", "Arial Narrow", sans-serif';
const C = { w: "#f4f4f4", g: "#36e05a", m: "#ff5cf0", c: "#3ee6ff", a: "#ffb020", r: "#ff3b30", sky: "#2f7fd1", gnd: "#8a5a2b", gray: "#4a4f56", dk: "#1c1f24" };
const HDG0 = 352, ELEV = 160; // park hâli: manyetik yön ve meydan irtifası (temsilî)

/* ---------- ortam: hangi DU hangi formatı gösterir, güç ve IRS ---------- */
export function env(ST, power, st) {
  const B = power.B || {}, sim = ST.sim, ctl = ST.ctl, mcp = ST.mcp || {};
  const irs = k => { const sw = st("irs" + k) ?? 0; return { on: sw > 0, ok: sw > 0 && sim.irs[k] === -1, adr: sw > 0 }; };
  const c = k => !!ctl[k], at = st("atArm") === 0;
  const fma = {
    A: !at ? "" : c("n1") || c("lvlChg") ? "N1" : c("speed") ? "MCP SPD" : c("vnav") ? "FMC SPD" : "ARM",
    R: c("lnav") ? "LNAV" : c("hdgSel") ? "HDG SEL" : c("vorLoc") || c("app") ? "VOR/LOC" : "",
    P: c("vnav") ? "VNAV PTH" : c("lvlChg") ? "MCP SPD" : c("altHld") ? "ALT HOLD" : c("vs") ? "V/S" : c("app") ? "G/S" : "",
    S: c("cmdA") || c("cmdB") ? "CMD" : c("cwsA") || c("cwsB") ? "CWS" : st("fdL") === 0 || st("fdR") === 0 ? "FD" : ""
  };
  const sysB = (st("hydE2") === 1 && sim.eng[1]) || (st("hydEl1") === 1 && power.ac);
  return { ST, st, sim, ctl, mcp, B, dc: power.dc, ac: power.ac, irsL: irs("L"), irsR: irs("R"), fma, sysB, t: new Date() };
}
const MAINP = ["OUTBD PFD", "NORM", "ENG PRI", "PFD", "MFD"];
// DU kimliği → format (null = boş). Güç: kaptan DU'ları ve üst orta DU AC standby/transfer 1, F/O DU'ları transfer 2.
export function format(id, E) {
  const L = E.st("duMainL") ?? 1, R = E.st("duMainR") ?? 1, cap = E.B.STBYAC || E.B.XFR1, fo = E.B.XFR2;
  const brt = k => (E.st(k) ?? 3) > 0;
  if (id === "duLO") return cap && brt("brtLO") ? [{ f: "pfd", s: "L" }, { f: "pfd", s: "L" }, { f: "pfd", s: "L" }, null, { f: "pfd", s: "L" }][L] : null;
  if (id === "duLI") return cap && brt("brtLI") ? [null, { f: "nd", s: "L" }, { f: "eng" }, { f: "pfd", s: "L" }, { f: "mfd" }][L] : null;
  if (id === "duC") return cap && brt("brtUp") ? (L === 2 || R === 2 ? { f: "nd", s: L === 2 ? "L" : "R" } : { f: "eng" }) : null;
  if (id === "duRI") return fo && brt("brtRI") ? [null, { f: "nd", s: "R" }, { f: "eng" }, { f: "pfd", s: "R" }, { f: "mfd" }][R] : null;
  if (id === "duRO") return fo && brt("brtRO") ? [{ f: "pfd", s: "R" }, { f: "pfd", s: "R" }, { f: "pfd", s: "R" }, null, { f: "pfd", s: "R" }][R] : null;
  if (id === "sbAtt") return E.B.STBYDC ? { f: "sbAtt" } : { f: "sbAtt", off: true };
  if (id === "sbAsi") return { f: "sbAsi" };
  if (id === "rmi") return { f: "rmi", off: !E.B.STBYAC && !E.B.XFR1 };
  if (id === "clockL" || id === "clockR") return E.B.HOTBAT ? { f: "clock" } : null;
  if (id === "flapInd") return { f: "flap", off: !E.dc };
  if (id === "brakeP") return { f: "brake" };
  return null;
}
export function sig(id, fmt, E) {
  if (!fmt) return "0";
  const m = E.mcp, base = [fmt.f, fmt.s, fmt.off];
  if (fmt.f === "clock") return base + E.t.getUTCHours() + ":" + E.t.getUTCMinutes();
  if (fmt.f === "pfd" || fmt.f === "nd") return JSON.stringify([base, m.ias, m.hdg, m.alt, m.vs, m.crs1, m.crs2, m.nav1A, m.nav2A, E.ST.mcpMach, E.fma, E.irsL, E.irsR, E.st("fdL"), E.st("fdR"),
    ["L", "R"].map(s => ["mode", "rng", "vor1", "vor2", "baro", "mins"].map(k => E.st(k + s))), ["WXR", "STA", "WPT", "ARPT", "DATA", "POS", "TERR"].map(k => E.ctl["k" + k + "L"] + "" + E.ctl["k" + k + "R"])]);
  return JSON.stringify([base, E.sim.eng, E.sim.apu, E.dc, E.ac, E.sysB, E.ST.mfdPage, E.irsL, m.rudTrim]);
}

/* ---------- yardımcılar ---------- */
const T = (g, s, x, y, size, col = C.w, align = "center", weight = 700) => { g.font = `${weight} ${size}px ${FF}`; g.textAlign = align; g.textBaseline = "middle"; g.fillStyle = col; g.fillText(s, x, y); };
const box = (g, x, y, w, h, col, lw = 2) => { g.strokeStyle = col; g.lineWidth = lw; g.strokeRect(x, y, w, h); };
const flag = (g, s, x, y, k, col = C.a) => { g.font = `700 ${k}px ${FF}`; const w = g.measureText(s).width + k * 0.6; g.fillStyle = "#000"; g.fillRect(x - w / 2, y - k * 0.7, w, k * 1.4); box(g, x - w / 2, y - k * 0.7, w, k * 1.4, col, Math.max(2, k / 10)); T(g, s, x, y, k, col); };
const pad = (n, l) => String(Math.round(n)).padStart(l, "0");

/* ---------- PFD ---------- */
function pfd(g, W, H, E, side) {
  const u = W / 100, ir = side === "L" ? E.irsL : E.irsR, m = E.mcp, fdOn = E.st(side === "L" ? "fdL" : "fdR") === 0;
  const cx = 47 * u, cy = 50 * u, aw = 23 * u;
  // tutum
  if (ir.ok) {
    g.save(); g.beginPath(); g.rect(cx - aw, cy - aw, aw * 2, aw * 2); g.clip();
    g.fillStyle = C.sky; g.fillRect(cx - aw, cy - aw, aw * 2, aw); g.fillStyle = C.gnd; g.fillRect(cx - aw, cy, aw * 2, aw);
    g.strokeStyle = C.w; g.lineWidth = 0.35 * u; g.beginPath(); g.moveTo(cx - aw, cy); g.lineTo(cx + aw, cy); g.stroke();
    for (const p of [-20, -10, -5, 5, 10, 20]) { const y = cy - p * 0.9 * u, l = (Math.abs(p) % 10 ? 4 : 8) * u; g.beginPath(); g.moveTo(cx - l, y); g.lineTo(cx + l, y); g.stroke(); if (!(p % 10)) { T(g, String(Math.abs(p)), cx - l - 3 * u, y, 2.6 * u); T(g, String(Math.abs(p)), cx + l + 3 * u, y, 2.6 * u); } }
    g.restore();
    // yatış ölçeği
    g.strokeStyle = C.w; g.lineWidth = 0.35 * u; g.beginPath(); g.arc(cx, cy, aw * 0.92, Math.PI * 1.25, Math.PI * 1.75); g.stroke();
    for (const a of [-60, -45, -30, -20, -10, 10, 20, 30, 45, 60]) { const r = (a - 90) * Math.PI / 180, r1 = aw * 0.92, r2 = aw * (Math.abs(a) % 30 ? 0.97 : 1.0); g.beginPath(); g.moveTo(cx + r1 * Math.cos(r), cy + r1 * Math.sin(r)); g.lineTo(cx + r2 * Math.cos(r), cy + r2 * Math.sin(r)); g.stroke(); }
    g.fillStyle = C.w; g.beginPath(); g.moveTo(cx, cy - aw * 0.9); g.lineTo(cx - 1.4 * u, cy - aw * 0.83); g.lineTo(cx + 1.4 * u, cy - aw * 0.83); g.fill();
    if (fdOn) { g.strokeStyle = C.m; g.lineWidth = 0.7 * u; g.beginPath(); g.moveTo(cx - 14 * u, cy); g.lineTo(cx + 14 * u, cy); g.moveTo(cx, cy - 14 * u); g.lineTo(cx, cy + 14 * u); g.stroke(); }
  } else { g.fillStyle = "#000"; g.fillRect(cx - aw, cy - aw, aw * 2, aw * 2); flag(g, "ATT", cx, cy - 8 * u, 4 * u); }
  // uçak sembolü
  g.fillStyle = "#000"; g.strokeStyle = C.w; g.lineWidth = 0.4 * u;
  for (const sgn of [-1, 1]) { g.beginPath(); g.rect(cx + sgn * 6 * u - (sgn > 0 ? 0 : 9 * u), cy - 0.8 * u, 9 * u, 1.6 * u); g.fill(); g.stroke(); g.beginPath(); g.rect(cx + sgn * 6 * u - (sgn > 0 ? 0 : 1.6 * u), cy - 0.8 * u, 1.6 * u, 4 * u); g.fill(); g.stroke(); }
  g.fillRect(cx - 0.9 * u, cy - 0.9 * u, 1.8 * u, 1.8 * u); g.strokeRect(cx - 0.9 * u, cy - 0.9 * u, 1.8 * u, 1.8 * u);
  // hız bandı
  const sx = 6 * u, sw = 13 * u, sy0 = cy - 30 * u, sh = 60 * u;
  g.fillStyle = C.gray; g.fillRect(sx, sy0, sw, sh);
  if (ir.adr) {
    g.save(); g.beginPath(); g.rect(sx, sy0, sw, sh); g.clip();
    const spd = 45, k = 0.75 * u; // yerde: bant alt sınırda (45 kt)
    for (let v = 40; v <= 140; v += 10) { const y = cy - (v - spd) * k; g.strokeStyle = C.w; g.lineWidth = 0.3 * u; g.beginPath(); g.moveTo(sx + sw - 2.5 * u, y); g.lineTo(sx + sw, y); g.stroke(); if (!(v % 20)) T(g, String(v), sx + sw - 4 * u, y, 3 * u, C.w, "right"); }
    g.restore();
    g.fillStyle = "#000"; g.fillRect(sx, cy - 3 * u, sw - 1 * u, 6 * u); box(g, sx, cy - 3 * u, sw - 1 * u, 6 * u, C.w, 0.3 * u); T(g, "45", sx + sw - 3 * u, cy, 4 * u, C.w, "right");
    T(g, E.ST.mcpMach ? "." + pad(m.ias / 3.2, 2) : String(m.ias), sx + sw / 2, sy0 - 3 * u, 4 * u, C.m);
  } else flag(g, "SPD", sx + sw / 2, cy, 3.6 * u);
  // irtifa bandı
  const ax = 76 * u, awd = 14 * u;
  g.fillStyle = C.gray; g.fillRect(ax, sy0, awd, sh);
  if (ir.adr) {
    g.save(); g.beginPath(); g.rect(ax, sy0, awd, sh); g.clip();
    const k = 0.06 * u;
    for (let v = Math.floor((ELEV - 500) / 100) * 100; v <= ELEV + 600; v += 100) { const y = cy - (v - ELEV) * k; g.strokeStyle = C.w; g.lineWidth = 0.3 * u; g.beginPath(); g.moveTo(ax, y); g.lineTo(ax + 2 * u, y); g.stroke(); if (!(v % 200)) T(g, String(v), ax + 3 * u, y, 3 * u, C.w, "left"); }
    g.restore();
    g.fillStyle = "#000"; g.fillRect(ax + 1 * u, cy - 3 * u, awd, 6 * u); box(g, ax + 1 * u, cy - 3 * u, awd, 6 * u, C.w, 0.3 * u); T(g, String(ELEV), ax + awd - 1 * u, cy, 4 * u, C.w, "right");
    T(g, String(m.alt), ax + awd / 2, sy0 - 3 * u, 4 * u, C.m);
    const baro = E.st("baro" + side) === 0 ? "29.92 IN" : "1013 HPA";
    T(g, baro, ax + awd / 2, sy0 + sh + 3.5 * u, 3.2 * u, C.g);
    // dikey hız
    g.fillStyle = C.gray; g.fillRect(92 * u, cy - 20 * u, 5 * u, 40 * u); g.strokeStyle = C.w; g.lineWidth = 0.6 * u; g.beginPath(); g.moveTo(97 * u, cy); g.lineTo(92 * u, cy); g.stroke();
    if (E.fma.P === "V/S" && m.vs) T(g, (m.vs > 0 ? "+" : "") + m.vs, 94.5 * u, cy - 23 * u, 2.6 * u, C.m);
  } else { flag(g, "ALT", ax + awd / 2, cy, 3.6 * u); flag(g, "VERT", 94.5 * u, cy, 2.6 * u); }
  // FMA
  g.strokeStyle = C.w; g.lineWidth = 0.25 * u; for (const x of [27, 47, 67]) { g.beginPath(); g.moveTo(x * u, 2 * u); g.lineTo(x * u, 10 * u); g.stroke(); }
  T(g, E.fma.A, 17 * u, 5 * u, 3.4 * u, C.g); T(g, E.fma.R, 37 * u, 5 * u, 3.4 * u, C.g); T(g, E.fma.P, 57 * u, 5 * u, 3.4 * u, C.g);
  if (E.fma.S) T(g, E.fma.S, cx, 14 * u, 4.4 * u, C.g);
  // ILS / yön
  const nf = (m["nav" + (side === "L" ? 1 : 2) + "A"] || 0) / 1000; if (nf && nf < 112 && Math.round(nf * 10) % 2 === 1) T(g, "ILS " + nf.toFixed(2), 25 * u, 21.5 * u, 2.8 * u, C.w, "left");
  const hy = 92 * u;
  if (ir.ok) {
    g.save(); g.beginPath(); g.rect(cx - 30 * u, hy - 8 * u, 60 * u, 16 * u); g.clip();
    g.fillStyle = C.gray; g.beginPath(); g.arc(cx, hy + 30 * u, 37 * u, 0, Math.PI * 2); g.fill();
    for (let d = -40 - HDG0 % 5; d <= 40; d += 5) { const hd = HDG0 + d, a = (d - 90) * Math.PI / 180 * 0.9; const x1 = cx + 37 * u * Math.cos(a), y1 = hy + 30 * u + 37 * u * Math.sin(a), x2 = cx + 35 * u * Math.cos(a), y2 = hy + 30 * u + 35 * u * Math.sin(a); g.strokeStyle = C.w; g.lineWidth = 0.3 * u; g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); if (!(((hd % 360) + 360) % 10)) T(g, String((((hd % 360) + 360) % 360) / 10 | 0), cx + 32 * u * Math.cos(a), hy + 30 * u + 32 * u * Math.sin(a), 2.6 * u); }
    const bd = ((((m.hdg - HDG0) % 360) + 540) % 360) - 180; if (Math.abs(bd) < 45) { const a = (bd - 90) * Math.PI / 180 * 0.9; g.fillStyle = C.m; g.fillRect(cx + 37 * u * Math.cos(a) - 1.2 * u, hy + 30 * u + 37 * u * Math.sin(a) - 0.6 * u, 2.4 * u, 1.4 * u); }
    g.restore(); T(g, pad(HDG0, 3), cx, hy - 5.5 * u, 3.2 * u); T(g, "MAG", cx + 7 * u, hy - 5.5 * u, 2.4 * u, C.g);
  } else flag(g, "HDG", cx, hy, 3.6 * u);
}

/* ---------- ND ---------- */
function nd(g, W, H, E, side) {
  const u = W / 100, ir = side === "L" ? E.irsL : E.irsR, mode = ["APP", "VOR", "MAP", "PLN"][E.st("mode" + side) ?? 2], rng = [5, 10, 20, 40, 80, 160, 320, 640][E.st("rng" + side) ?? 3];
  const cx = 50 * u, cy = 80 * u, R = 62 * u;
  T(g, "GS", 3 * u, 4 * u, 3 * u, C.w, "left"); T(g, "0", 9 * u, 4 * u, 3.6 * u, C.w, "left"); T(g, "TAS", 14 * u, 4 * u, 3 * u, C.w, "left"); T(g, "---", 21 * u, 4 * u, 3.6 * u, C.w, "left");
  if (!ir.ok) { flag(g, "HDG", cx, 12 * u, 4 * u); flag(g, mode === "PLN" ? "PLAN" : mode === "MAP" ? "MAP" : mode, cx, 45 * u, 4 * u); if (ir.on && !ir.ok) T(g, "IRS ALIGN", cx, 55 * u, 3.4 * u, C.a); }
  else if (mode === "PLN") {
    g.strokeStyle = C.w; g.lineWidth = 0.35 * u; g.beginPath(); g.arc(cx, 50 * u, 30 * u, 0, Math.PI * 2); g.stroke(); T(g, "N", cx, 16 * u, 4 * u, C.g); T(g, "PLAN", cx, 95 * u, 3 * u, C.g);
    T(g, String(rng / 2), cx + 22 * u, 50 * u - 22 * u, 2.6 * u);
  } else {
    T(g, mode === "MAP" ? "TRK" : "HDG", cx - 9 * u, 4 * u, 3 * u, C.g); g.fillStyle = "#000"; box(g, cx - 5 * u, 1 * u, 10 * u, 6 * u, C.w, 0.3 * u); T(g, pad(HDG0, 3), cx, 4 * u, 3.8 * u); T(g, "MAG", cx + 9 * u, 4 * u, 3 * u, C.g);
    g.save(); g.beginPath(); g.rect(0, 8 * u, W, H); g.clip();
    g.strokeStyle = C.w; g.lineWidth = 0.35 * u; g.beginPath(); g.arc(cx, cy, R, Math.PI * 1.17, Math.PI * 1.83); g.stroke();
    for (let d = -60 - HDG0 % 5; d <= 60; d += 5) { const hd = ((HDG0 + d) % 360 + 360) % 360, a = (d - 90) * Math.PI / 180, l = hd % 10 ? 1.5 * u : 3 * u; g.beginPath(); g.moveTo(cx + R * Math.cos(a), cy + R * Math.sin(a)); g.lineTo(cx + (R - l) * Math.cos(a), cy + (R - l) * Math.sin(a)); g.stroke(); if (!(hd % 30)) T(g, String(hd / 10), cx + (R - 5 * u) * Math.cos(a), cy + (R - 5 * u) * Math.sin(a), 3.2 * u); }
    g.setLineDash([1.2 * u, 1.2 * u]); g.beginPath(); g.arc(cx, cy, R / 2, Math.PI * 1.2, Math.PI * 1.8); g.stroke(); g.setLineDash([]);
    T(g, String(rng / 2), cx - R / 2 * 0.62 - 3 * u, cy - R / 2 * 0.78, 2.8 * u);
    const bd = ((((E.mcp.hdg - HDG0) % 360) + 540) % 360) - 180; if (Math.abs(bd) <= 60) { const a = (bd - 90) * Math.PI / 180; g.save(); g.translate(cx + R * Math.cos(a), cy + R * Math.sin(a)); g.rotate(a + Math.PI / 2); g.strokeStyle = C.m; g.lineWidth = 0.5 * u; g.strokeRect(-1.6 * u, -1 * u, 3.2 * u, 2 * u); g.restore(); g.setLineDash([1.5 * u, 1.5 * u]); g.strokeStyle = C.m; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + R * Math.cos(a), cy + R * Math.sin(a)); g.stroke(); g.setLineDash([]); }
    if (mode === "VOR" || mode === "APP") { const crs = side === "L" ? E.mcp.crs1 : E.mcp.crs2, d = ((((crs - HDG0) % 360) + 540) % 360) - 180, a = (d - 90) * Math.PI / 180; g.strokeStyle = C.m; g.lineWidth = 0.5 * u; g.beginPath(); g.moveTo(cx - R * 0.7 * Math.cos(a), cy - R * 0.7 * Math.sin(a)); g.lineTo(cx + R * 0.7 * Math.cos(a), cy + R * 0.7 * Math.sin(a)); g.stroke(); }
    g.restore();
    // uçak sembolü
    g.strokeStyle = C.w; g.lineWidth = 0.5 * u; g.beginPath(); g.moveTo(cx, cy - 3 * u); g.lineTo(cx - 2 * u, cy + 2 * u); g.lineTo(cx + 2 * u, cy + 2 * u); g.closePath(); g.stroke();
    if (mode === "MAP") { const keys = ["WXR", "STA", "WPT", "ARPT", "DATA", "POS", "TERR"].filter(k => E.ctl["k" + k + side]); if (keys.length) T(g, keys.join(" "), 97 * u, 93 * u, 2.6 * u, C.c, "right"); if (E.ctl["kTERR" + side]) T(g, "TERR", 3 * u, 88 * u, 3 * u, C.c, "left"); if (E.ctl["kWXR" + side]) T(g, "WXR", 3 * u, 92 * u, 3 * u, C.g, "left"); }
    else { const n = side === "L" ? 1 : 2, f = ((E.mcp["nav" + n + "A"] || 0) / 1000).toFixed(2); T(g, (mode === "APP" ? "ILS " : "VOR ") + n, 3 * u, 88 * u, 3 * u, C.g, "left"); T(g, f, 3 * u, 92.5 * u, 3 * u, C.w, "left"); T(g, mode, cx, 95 * u, 3 * u, C.g); }
    T(g, String(rng), 97 * u, 4 * u, 2.6 * u, C.w, "right");
  }
  // VOR/ADF iğne seçimleri
  const v1 = E.st("vor1" + side), v2 = E.st("vor2" + side);
  if (v1 === 0 || v1 === 2) T(g, v1 === 0 ? "VOR 1" : "ADF 1", 3 * u, 96.5 * u, 2.6 * u, C.g, "left");
  if (v2 === 0 || v2 === 2) T(g, v2 === 0 ? "VOR 2" : "ADF 2", 97 * u, 96.5 * u, 2.6 * u, C.g, "right");
}

/* ---------- motor göstergesi (üst orta DU) ---------- */
function dial(g, x, y, r, frac, val, u, lim) {
  g.strokeStyle = C.w; g.lineWidth = 0.35 * u; g.beginPath(); g.arc(x, y, r, Math.PI, Math.PI * 2.1); g.stroke();
  g.fillStyle = "#3a3f46"; g.beginPath(); g.moveTo(x, y); g.arc(x, y, r, Math.PI, Math.PI + Math.PI * 1.1 * frac); g.closePath(); g.fill();
  if (lim) { const a = Math.PI + Math.PI * 1.1 * lim; g.strokeStyle = C.r; g.lineWidth = 0.6 * u; g.beginPath(); g.moveTo(x + r * Math.cos(a), y + r * Math.sin(a)); g.lineTo(x + (r + 2 * u) * Math.cos(a), y + (r + 2 * u) * Math.sin(a)); g.stroke(); }
  const a = Math.PI + Math.PI * 1.1 * frac; g.strokeStyle = C.w; g.lineWidth = 0.6 * u; g.beginPath(); g.moveTo(x, y); g.lineTo(x + r * Math.cos(a), y + r * Math.sin(a)); g.stroke();
  g.fillStyle = "#000"; g.fillRect(x + 1 * u, y - r * 0.55 - 3 * u, r * 1.05, 5.4 * u); box(g, x + 1 * u, y - r * 0.55 - 3 * u, r * 1.05, 5.4 * u, C.w, 0.25 * u); T(g, val, x + 1 * u + r * 1.0, y - r * 0.55 - 0.3 * u, 4 * u, C.w, "right");
}
function eng(g, W, H, E) {
  const u = W / 100, run = E.sim.eng;
  T(g, "TAT +12c", 4 * u, 4 * u, 3 * u, C.w, "left");
  for (const [i, x] of [[0, 25], [1, 68]]) {
    const r = run[i];
    dial(g, x * u, 22 * u, 11 * u, r ? 0.21 : 0, r ? "21.3" : "0.0", u, 1.04);
    dial(g, x * u, 44 * u, 10 * u, r ? 0.42 : 0.05, r ? "418" : "12", u, 0.95);
  }
  T(g, "N1", 46.5 * u, 22 * u, 3.4 * u, C.c); T(g, "EGT", 46.5 * u, 44 * u, 3.4 * u, C.c);
  for (const [i, x] of [[0, 25], [1, 68]]) {
    const r = run[i];
    T(g, r ? "59.9" : "0.0", x * u + 6 * u, 58 * u, 4 * u, C.w, "right"); T(g, r ? "0.31" : "0.00", x * u + 6 * u, 64 * u, 4 * u, C.w, "right");
  }
  T(g, "N2", 46.5 * u, 58 * u, 3.2 * u, C.c); T(g, "FF/FU", 46.5 * u, 64 * u, 3.2 * u, C.c);
  // yakıt
  const tank = (xp, lbl, v) => { const x = xp * u; box(g, x - 9 * u, 76 * u, 18 * u, 7 * u, C.w, 0.25 * u); T(g, v, x + 7 * u, 79.5 * u, 4 * u, C.w, "right"); T(g, lbl, x, 87 * u, 3 * u, C.c); };
  if (E.dc) { tank(18, "1", "5000"); tank(50, "CTR", "0"); tank(82, "2", "5000"); T(g, "FUEL  KG X 1", 50 * u, 72 * u, 3 * u, C.c); }
  const mx = 50 * u; if (!run[0] && !run[1] && E.sim.apu === 2) T(g, "APU", mx, 95 * u, 3 * u, C.g);
}
function mfd(g, W, H, E) {
  const u = W / 100, page = E.ST.mfdPage || "sys";
  if (page === "eng") {
    T(g, "ENG (ikincil)", 50 * u, 6 * u, 3.4 * u, C.c);
    for (const [i, x] of [[0, 25], [1, 75]]) { const r = E.sim.eng[i]; T(g, "OIL PRESS " + (r ? "45" : "0"), x * u, 30 * u, 3.4 * u); T(g, "OIL TEMP " + (r ? "60" : "15"), x * u, 40 * u, 3.4 * u); T(g, "OIL QTY 18", x * u, 50 * u, 3.4 * u); T(g, "VIB " + (r ? "0.3" : "0.0"), x * u, 60 * u, 3.4 * u); }
    return;
  }
  T(g, "HYDRAULIC", 50 * u, 6 * u, 3.6 * u, C.c);
  const sa = (E.st("hydE1") === 1 && E.sim.eng[0]) || (E.st("hydEl2") === 1 && E.ac), sb = E.sysB;
  for (const [x, l, p] of [[30, "A", sa], [70, "B", sb]]) { T(g, l, x * u, 18 * u, 4.4 * u, C.w); T(g, "QTY", x * u, 30 * u, 3 * u, C.c); T(g, "100", x * u, 37 * u, 4 * u); T(g, "PRESS", x * u, 50 * u, 3 * u, C.c); T(g, p ? "3000" : "0", x * u, 57 * u, 4 * u, p ? C.w : C.a); }
  T(g, "RUDDER TRIM " + (E.mcp.rudTrim || 0).toFixed(1), 50 * u, 80 * u, 3.2 * u, C.w);
}

/* ---------- yedek ve elektromekanik göstergeler ---------- */
function roundBg(g, W, H) { g.fillStyle = "#0b0c0d"; g.fillRect(0, 0, W, H); g.fillStyle = "#121416"; g.beginPath(); g.arc(W / 2, H / 2, W * 0.48, 0, 7); g.fill(); }
function sbAtt(g, W, H, E, off) {
  const u = W / 100, cx = 50 * u, cy = 50 * u, r = 44 * u; roundBg(g, W, H);
  g.save(); g.beginPath(); g.arc(cx, cy, r, 0, 7); g.clip(); g.fillStyle = "#3a8ad6"; g.fillRect(0, 0, W, cy); g.fillStyle = "#3a2a1a"; g.fillRect(0, cy, W, H);
  g.strokeStyle = C.w; g.lineWidth = 0.6 * u; g.beginPath(); g.moveTo(0, cy); g.lineTo(W, cy); g.stroke(); for (const p of [-10, 10]) { g.beginPath(); g.moveTo(cx - 10 * u, cy - p * 1.6 * u); g.lineTo(cx + 10 * u, cy - p * 1.6 * u); g.stroke(); }
  g.restore();
  g.strokeStyle = "#ffcc33"; g.lineWidth = 1.2 * u; g.beginPath(); g.moveTo(cx - 22 * u, cy); g.lineTo(cx - 8 * u, cy); g.lineTo(cx - 4 * u, cy + 4 * u); g.moveTo(cx + 22 * u, cy); g.lineTo(cx + 8 * u, cy); g.lineTo(cx + 4 * u, cy + 4 * u); g.stroke();
  if (off) { g.fillStyle = "#d43a2a"; g.fillRect(cx + 12 * u, cy - 30 * u, 18 * u, 10 * u); T(g, "OFF", cx + 21 * u, cy - 25 * u, 6 * u, C.w); }
  T(g, "PULL TO CAGE", cx, 92 * u, 3.4 * u, "#bbb");
}
function sbAsi(g, W, H, E) {
  const u = W / 100, cx = 50 * u, cy = 50 * u, r = 44 * u; roundBg(g, W, H);
  g.strokeStyle = C.w; g.lineWidth = 0.5 * u;
  for (let v = 40; v <= 400; v += 10) { const a = (-90 + (v - 40) / 360 * 300) * Math.PI / 180, l = v % 50 ? 3 * u : 6 * u; g.beginPath(); g.moveTo(cx + r * Math.cos(a), cy + r * Math.sin(a)); g.lineTo(cx + (r - l) * Math.cos(a), cy + (r - l) * Math.sin(a)); g.stroke(); if (!(v % 50)) T(g, String(v), cx + (r - 11 * u) * Math.cos(a), cy + (r - 11 * u) * Math.sin(a), 5 * u); }
  g.fillStyle = "#000"; g.fillRect(cx - 20 * u, cy + 8 * u, 40 * u, 11 * u); box(g, cx - 20 * u, cy + 8 * u, 40 * u, 11 * u, "#888", 0.4 * u); T(g, pad(ELEV, 5), cx, cy + 13.5 * u, 7 * u); T(g, "ALT", cx, cy + 23 * u, 3.6 * u, "#bbb"); T(g, "KNOTS", cx, cy - 12 * u, 3.6 * u, "#bbb");
  const a = -90 * Math.PI / 180; g.strokeStyle = C.w; g.lineWidth = 1.4 * u; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + r * 0.85 * Math.cos(a), cy + r * 0.85 * Math.sin(a)); g.stroke();
}
function rmi(g, W, H, E, off) {
  const u = W / 100, cx = 50 * u, cy = 50 * u, r = 42 * u; roundBg(g, W, H);
  const hd = E.irsL.ok ? HDG0 : 0;
  g.save(); g.translate(cx, cy); g.rotate(-hd * Math.PI / 180);
  for (let d = 0; d < 360; d += 5) { const a = (d - 90) * Math.PI / 180, l = d % 10 ? 2.5 * u : 4.5 * u; g.strokeStyle = C.w; g.lineWidth = 0.5 * u; g.beginPath(); g.moveTo(r * Math.cos(a), r * Math.sin(a)); g.lineTo((r - l) * Math.cos(a), (r - l) * Math.sin(a)); g.stroke(); if (!(d % 30)) { g.save(); g.rotate(d * Math.PI / 180); T(g, d === 0 ? "N" : d === 90 ? "E" : d === 180 ? "S" : d === 270 ? "W" : String(d / 10), 0, -r + 10 * u, 6 * u); g.restore(); } }
  g.restore();
  g.fillStyle = C.w; g.beginPath(); g.moveTo(cx, cy - r - 1 * u); g.lineTo(cx - 2.5 * u, cy - r - 6 * u); g.lineTo(cx + 2.5 * u, cy - r - 6 * u); g.fill();
  g.strokeStyle = "#e0e0e0"; g.lineWidth = 1.2 * u; g.beginPath(); g.moveTo(cx, cy + r * 0.8); g.lineTo(cx, cy - r * 0.8); g.stroke();
  g.strokeStyle = "#5ab0ff"; g.lineWidth = 2 * u; g.beginPath(); g.moveTo(cx + r * 0.5, cy + r * 0.55); g.lineTo(cx - r * 0.5, cy - r * 0.55); g.stroke();
  if (!E.irsL.ok || off) { g.fillStyle = "#d43a2a"; g.fillRect(cx - 34 * u, cy - 6 * u, 16 * u, 8 * u); T(g, "HDG", cx - 26 * u, cy - 2 * u, 5 * u, C.w); }
  T(g, "VOR  ADF", cx, 93 * u, 3.4 * u, "#bbb");
}
function clock(g, W, H, E) {
  const u = W / 100, cx = 50 * u, cy = 50 * u, r = 44 * u, t = E.t; roundBg(g, W, H);
  g.strokeStyle = C.w; for (let s = 0; s < 60; s++) { const a = (s * 6 - 90) * Math.PI / 180, l = s % 5 ? 2 * u : 4 * u; g.lineWidth = (s % 5 ? 0.4 : 0.8) * u; g.beginPath(); g.moveTo(cx + r * Math.cos(a), cy + r * Math.sin(a)); g.lineTo(cx + (r - l) * Math.cos(a), cy + (r - l) * Math.sin(a)); g.stroke(); }
  for (const s of [10, 20, 30, 40, 50, 60]) { const a = (s * 6 - 90) * Math.PI / 180; T(g, String(s), cx + (r - 9 * u) * Math.cos(a), cy + (r - 9 * u) * Math.sin(a), 5 * u); }
  g.fillStyle = "#000"; g.fillRect(cx - 18 * u, cy - 15 * u, 36 * u, 12 * u); g.fillRect(cx - 18 * u, cy + 3 * u, 36 * u, 12 * u);
  T(g, pad(t.getUTCHours(), 2) + ":" + pad(t.getUTCMinutes(), 2), cx, cy - 9 * u, 9 * u, "#e7f7ff"); T(g, pad(t.getUTCDate(), 2) + " " + pad(t.getUTCMonth() + 1, 2) + " " + String(t.getUTCFullYear()).slice(2), cx, cy + 9 * u, 7 * u, "#e7f7ff");
  T(g, "UTC", cx, cy - 20 * u, 3.6 * u, "#bbb");
}
function flap(g, W, H, E, off) {
  const u = W / 100, cx = 50 * u, cy = 50 * u, r = 42 * u; roundBg(g, W, H);
  const marks = [[0, "UP"], [1, "1"], [2, "2"], [5, "5"], [10, "10"], [15, "15"], [25, "25"], [30, "30"], [40, "40"]];
  marks.forEach(([v, l], i) => { const a = (-120 + i * 30) * Math.PI / 180; g.strokeStyle = C.w; g.lineWidth = 0.8 * u; g.beginPath(); g.moveTo(cx + r * Math.cos(a), cy + r * Math.sin(a)); g.lineTo(cx + (r - 5 * u) * Math.cos(a), cy + (r - 5 * u) * Math.sin(a)); g.stroke(); T(g, l, cx + (r - 12 * u) * Math.cos(a), cy + (r - 12 * u) * Math.sin(a), 6 * u); });
  const a = -120 * Math.PI / 180; for (const [c, o] of [["#ffcc33", 1.5], ["#e8e8e8", -1.5]]) { g.strokeStyle = c; g.lineWidth = 2 * u; g.beginPath(); g.moveTo(cx + o * u, cy); g.lineTo(cx + r * 0.75 * Math.cos(a) + o * u, cy + r * 0.75 * Math.sin(a)); g.stroke(); }
  g.fillStyle = "#222"; g.beginPath(); g.arc(cx, cy, 7 * u, 0, 7); g.fill(); T(g, "FLAPS", cx - 14 * u, cy + 14 * u, 4.4 * u, "#bbb");
  if (off) T(g, "", cx, cy, 1);
}
function brake(g, W, H, E) {
  const u = W / 100, cx = 50 * u, cy = 50 * u, r = 42 * u; roundBg(g, W, H);
  for (let v = 0; v <= 4; v++) { const a = (150 + v * 60) * Math.PI / 180; g.strokeStyle = C.w; g.lineWidth = 1 * u; g.beginPath(); g.moveTo(cx + r * Math.cos(a), cy + r * Math.sin(a)); g.lineTo(cx + (r - 6 * u) * Math.cos(a), cy + (r - 6 * u) * Math.sin(a)); g.stroke(); T(g, String(v), cx + (r - 14 * u) * Math.cos(a), cy + (r - 14 * u) * Math.sin(a), 8 * u); }
  const p = E.sysB ? 3.0 : 1.0, a = (150 + p * 60) * Math.PI / 180;
  g.strokeStyle = C.w; g.lineWidth = 2 * u; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + r * 0.8 * Math.cos(a), cy + r * 0.8 * Math.sin(a)); g.stroke();
  T(g, "BRAKE", cx + 14 * u, cy + 20 * u, 5 * u, "#bbb"); T(g, "PRESS", cx + 14 * u, cy + 27 * u, 5 * u, "#bbb"); T(g, "PSI x1000", cx, 88 * u, 4 * u, "#888");
}

export function draw(g, W, H, fmt, E) {
  g.fillStyle = "#000"; g.fillRect(0, 0, W, H);
  if (!fmt) return;
  if (fmt.f === "pfd") pfd(g, W, H, E, fmt.s);
  else if (fmt.f === "nd") nd(g, W, H, E, fmt.s);
  else if (fmt.f === "eng") eng(g, W, H, E);
  else if (fmt.f === "mfd") mfd(g, W, H, E);
  else if (fmt.f === "sbAtt") sbAtt(g, W, H, E, fmt.off);
  else if (fmt.f === "sbAsi") sbAsi(g, W, H, E);
  else if (fmt.f === "rmi") rmi(g, W, H, E, fmt.off);
  else if (fmt.f === "clock") clock(g, W, H, E);
  else if (fmt.f === "flap") flap(g, W, H, E, fmt.off);
  else if (fmt.f === "brake") brake(g, W, H, E);
}
export const FORMAT_NAME = { pfd: "PFD (birincil uçuş ekranı)", nd: "ND (navigasyon ekranı)", eng: "Motor göstergesi (engine primary)", mfd: "MFD (çok fonksiyonlu: sistem/ikincil motor)" };
