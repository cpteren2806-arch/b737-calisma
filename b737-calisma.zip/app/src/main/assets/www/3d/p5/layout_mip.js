// 737NG ana gösterge paneli: P1 (kaptan), P2 (orta), P3 (F/O).
// KAYNAK: AMM 31-11-21 / 31-11-31 / 31-11-51 Fig. 101 (bileşen yerleşimi), WDM 91-02-01 / 91-02-02 (YC501–YC570) / 91-02-03 (modüller, konnektörler, demetler),
//         WDM Equipment List D280A117. Ölçek 100 px = 1 inç; konumlar AMM şekillerinden ölçülmüştür (yaklaşık).
const U = 100, I = (x, y) => [Math.round(x * U), Math.round(y * U)], S = v => Math.round(v * U);
const T = (id, at, pos, st, o = {}) => ({ t: "T", id, at: I(...at), pos, st, ...o });
const R = (id, at, pos, ang, st, o = {}) => ({ t: "R", id, at: I(...at), pos, ang, st, ...o });
const L = (id, at, txt, c = "a", o = {}) => ({ t: "L", id, at: I(...at), txt, c, w: S(o.wi || 0.95), h: S(o.hi || 0.46), ...o });
const B = (id, at, o = {}) => ({ t: "B", id, at: I(...at), r: S(o.ri || 0.2), ...o });
const SCR = (id, at, w, h, o = {}) => ({ t: "D", id, at: I(...at), kind: "screen", screen: id, w: S(w), h: S(h), ...o });
const tx = (s, x, y, size = 11, align = "center", deco) => [s, ...I(x, y), size, align, deco];
const mod = (id, pn, name, en, ata, r, o) => ({ id, pn, name, en, ata, rect: [S(r[0]), S(r[1]), S(r[2]), S(r[3])], conns: [], texts: [], rects: [], lines: [], items: [], ...o });
const BRT = ["OFF", "DIM", "MED", "BRT"], BRA = [-130, -45, 45, 130];

/* ============================ P1 – KAPTAN ============================ */
const DU = (id, pn, name, side, x0, scr, D, W, desc) => mod("du_" + id, pn, name, "Display Unit", "31", [x0, 6.0, x0 + 8.3, 14.2], {
  dg: [side === "L" ? "31-62-11" : "31-62-21"], conns: [{ d: D, w: W, at: [0.5, 0.5] }], desc,
  items: [SCR(scr, [x0 + 4.15, 10.05], 6.85, 6.65, { d: "Ekran: seçili formata göre PFD, ND, motor göstergesi veya MFD gösterir. Görüntü DEU'lardan (display electronics unit, E/E bölmesi) gelir." })]
});
const P1_1 = mod("p1_1", "P1-1", "Kaptan saati ve burun tekerleği yönlendirme", "Captain Clock / Nose Wheel Steering", "31/32", [0, 3.95, 5.4, 14.2], { shape: [[0, 1.15], [5.4, 0], [5.4, 10.25], [0, 10.25]],
  dg: ["31-22-11", "29-23-11"], conns: [{ d: "D714", w: "W0001", at: [0.4, 0.35] }, { d: "D903", w: "W0001", at: [0.4, 0.62] }],
  desc: "N145 kaptan saati (UTC zaman, tarih, kronometre, geçen süre – GPS'ten senkron), NOSE WHEEL STEERING seçici (NORM: A sistemi; ALT: B sistemi ile yönlendirme).",
  texts: [tx("DO NOT EXTEND THE SPEEDBRAKE LEVER\nBEYOND THE FLIGHT DETENT IN FLIGHT", 3.3, 6.32, 6.5), tx("CHR", 1.6, 6.85, 8), tx("TIME/DATE", 4.6, 6.85, 8), tx("NOSE WHEEL STEERING", 3.3, 10.42, 8.5), tx("ALT", 1.55, 11.04, 9), tx("NORM", 5.0, 11.04, 9), tx("REGISTRATION\nSELCAL", 3.3, 12.5, 9)],
  rects: [[...I(1.55, 10.25), ...I(5.1, 11.65), 4], [...I(2.08, 12.1), ...I(4.55, 12.85), 3]],
  items: [SCR("clockL", [3.3, 8.36], 3.0, 3.0, { d: "Saat: UTC zaman ve tarih (kronometre/ET düğmeleri)." }), B("chrL", [1.75, 7.0], { ri: 0.13, d: "CHR: kronometre başlat/durdur/sıfırla." }), B("etL", [1.75, 9.7], { ri: 0.13, d: "ET: geçen süre (elapsed time) başlat/tut/sıfırla." }),
    T("nws", [3.3, 11.04], ["ALT", "NORM"], 1, { horiz: true, guard: "yellow", gst: 1, gw: 60, gh: 34, gHoriz: true, d: "NOSE WHEEL STEERING: NORM – yönlendirme A sistemi basıncıyla; ALT – B sistemi basıncıyla (kapaklı)." })]
});
const P1_3 = mod("p1_3", "P1-3", "Kaptan üst şerit: DU seçiciler, otomatik uçuş durum ışıkları, ikazlar", "Captain Instrument Panel (upper)", "31/22", [5.4, 0.55, 22.17, 6.0], { shape: [[0, 3.4], [16.77, 0], [16.77, 5.45], [0, 5.45]],
  dg: ["31-62-13", "31-62-23", "22-14-11"], conns: [{ d: "D895", w: "W0003", at: [0.85, 0.5] }, { d: "D423", w: "W0001", at: [0.72, 0.5] }, { d: "D2437", w: "W0001", at: [0.22, 0.4] }],
  desc: "MAIN PANEL DUs ve LOWER DU seçicileri (ekran formatlarını yeniden dağıtır), A/P – A/T – FMC P/RST (otomatik uçuş durum) ışıkları ve test anahtarı, LIGHTS TEST/BRT/DIM ana ışık anahtarı, TAKEOFF CONFIG, CABIN ALTITUDE, SPEED BRAKE ARMED / DO NOT ARM, STAB OUT OF TRIM, BELOW G/S.",
  texts: [tx("MAIN PANEL DUs", 12.64, 3.55, 10), tx("LOWER DU", 14.95, 3.55, 10), tx("OUTBD\nPFD", 11.55, 4.3, 8), tx("NORM", 12.64, 3.88, 8), tx("ENG\nPRI", 13.55, 4.3, 8), tx("PFD", 13.6, 4.85, 8), tx("MFD", 13.2, 5.35, 8),
    tx("ENG\nPRI", 14.15, 4.4, 8), tx("NORM", 14.85, 3.88, 8), tx("ND", 15.55, 4.4, 8), tx("TEST", 19.9, 4.35, 8), tx("1", 20.15, 3.5, 8), tx("2", 20.15, 4.05, 8), tx("LIGHTS", 21.3, 3.25, 10), tx("TEST", 21.3, 3.55, 8), tx("BRT", 21.85, 3.98, 8), tx("DIM", 21.3, 4.45, 8)],
  rects: [[...I(11.3, 3.32), ...I(15.95, 5.6), 6], [...I(17.4, 3.35), ...I(20.4, 4.4), 10], [...I(20.75, 3.05), ...I(21.95, 4.62), 6]],
  items: [
    L("belowGsL", [7.32, 5.38], "BELOW G/S\nP-INHIBIT", "a", { press: true, d: "BELOW G/S: ILS süzülme yolunun altında (GPWS ‘GLIDESLOPE’ uyarısı). Basınca uyarı bastırılır (P-INHIBIT)." }),
    R("duMainL", [12.64, 4.62], ["OUTBD PFD", "NORM", "ENG PRI", "PFD", "MFD"], [-50, 0, 40, 80, 120], 1, { knob: "bar", r: 42, noLabels: true, d: "MAIN PANEL DUs: NORM – dış DU'da PFD, iç DU'da ND. OUTBD PFD – PFD dışta, iç DU boş. ENG PRI – iç DU'da motor göstergesi. PFD – PFD iç DU'ya alınır. MFD – iç DU'da MFD formatı." }),
    R("duLowerL", [14.85, 4.62], ["ENG PRI", "NORM", "ND"], [-45, 0, 45], 1, { knob: "bar", r: 42, noLabels: true, d: "LOWER DU: alt orta DU'ya (P9) motor göstergesi veya kaptan ND'sini alır; NORM – MFD." }),
    L("apRstL", [17.85, 3.85], "A/P\nP/RST", "r", { wi: 0.62, hi: 0.62, press: true, d: "A/P: kırmızı yanıp sönme = otopilot kesildi; amber = A/P çalışma kısıtlaması. Basınca sıfırlanır." }),
    L("atRstL", [18.55, 3.85], "A/T\nP/RST", "r", { wi: 0.62, hi: 0.62, press: true, d: "A/T: kırmızı = otomatik gaz kesildi; amber = hız sapması." }),
    L("fmcRstL", [19.26, 3.85], "FMC\nP/RST", "a", { wi: 0.62, hi: 0.62, press: true, d: "FMC: amber = FMC uyarı mesajı (CDU'da)." }),
    T("afsTestL", [19.87, 3.78], ["1", "", "2"], 1, { spring: [0, 2], springMs: 1500, d: "Otomatik uçuş durum ışıkları testi: 1 – amber, 2 – kırmızı." }),
    T("lightsSw", [21.3, 3.98], ["TEST", "BRT", "DIM"], 1, { d: "LIGHTS: TEST – tüm kokpit ikaz ışıklarını yakar (lamba testi); BRT – normal parlaklık; DIM – ikaz ışıkları kısık (gece)." }),
    L("tocL", [17.13, 5.42], "TAKEOFF\nCONFIG", "r", { d: "TAKEOFF CONFIG: kalkış konfigürasyonu hatalı (flap, stab trim, spoiler, park freni) ve gaz kolları ileri." }),
    L("cabAltL", [18.17, 5.42], "CABIN\nALTITUDE", "r", { d: "CABIN ALTITUDE: kabin irtifası 10.000 ft'i aştı." }),
    L("sbArm", [19.17, 4.92], "SPEED BRAKE\nARMED", "g", { d: "SPEED BRAKE ARMED: hava freni kolu ARM konumunda ve sistem sağlam." }),
    L("sbDna", [19.17, 5.42], "SPEED BRAKE\nDO NOT ARM", "a", { d: "SPEED BRAKE DO NOT ARM: otomatik hava freni sistemi arızalı." }),
    L("stabOot", [20.26, 5.17], "STAB\nOUT OF\nTRIM", "a", { wi: 0.62, hi: 0.62, d: "STAB OUT OF TRIM: otopilot stabilizer trimini doğru ayarlayamıyor." })
  ]
});
const DU_LO = DU("lo", "N187", "Kaptan dış DU (PFD)", "L", 5.4, "duLO", "D3977", "W0001", "N187 kaptan birincil uçuş ekranı (dış DU). Normalde PFD: tutum, hız/irtifa bantları, FMA, yön. Kaptan DU'ları AC standby barasından da beslenebilir (yalnız bataryada çalışır).");
const DU_LI = DU("li", "N188", "Kaptan iç DU (ND)", "L", 13.81, "duLI", "D3979", "W0001", "N188 kaptan iç ekranı. Normalde ND (navigasyon ekranı): pusula, rota, menzil halkaları, EFIS katmanları.");
const P1_9 = mod("p1_9", "P1-9", "Kaptan aydınlatma paneli (DU parlaklık)", "Lighting Control Panel", "33", [6.5, 14.2, 12.4, 18.0], {
  dg: ["33-11-11"], conns: [{ d: "D2650", w: "W0001", at: [0.5, 0.45] }],
  desc: "MAIN PANEL: ana panel arka aydınlatması. UPPER DU / OUTBD DU / INBD DU / LOWER DU BRT: ekran parlaklıkları (OFF'ta ekran kararır).",
  texts: [tx("MAIN PANEL", 8.74, 14.45, 9), tx("UPPER DU\nBRT", 11.3, 14.55, 8), tx("OUTBD DU\nBRT", 7.6, 16.35, 8), tx("INBD DU\nBRT", 9.45, 16.35, 8), tx("LOWER DU\nBRT", 11.3, 16.35, 8)],
  items: [R("mainPnlL", [8.74, 15.3], BRT, BRA, 2, { knob: "bar", r: 44, d: "Ana panel aydınlatması." }), R("brtUp", [11.3, 15.3], BRT, BRA, 3, { knob: "grip", r: 26, d: "Üst orta DU parlaklığı (OFF: ekran kapalı)." }),
    R("brtLO", [7.6, 17.2], BRT, BRA, 3, { knob: "grip", r: 26, d: "Kaptan dış DU parlaklığı." }), R("brtLI", [9.45, 17.2], BRT, BRA, 3, { knob: "grip", r: 26, d: "Kaptan iç DU parlaklığı." }), R("brtLow", [11.3, 17.2], BRT, BRA, 3, { knob: "grip", r: 26, d: "Alt orta DU parlaklığı." })]
});
const P1_5 = mod("p1_5", "P1-5", "Kaptan aydınlatma paneli (arka plan / AFDS)", "Lighting Control Panel", "33", [12.4, 14.2, 18.2, 18.0], {
  dg: ["33-11-11"], conns: [{ d: "D1036", w: "W0001", at: [0.5, 0.45] }],
  desc: "BACKGROUND: panel arka plan (taşkın) aydınlatması. AFDS FLOOD: MCP üzerindeki taşkın ışığı.",
  texts: [tx("BACKGROUND", 14.34, 14.45, 9), tx("AFDS FLOOD", 17.0, 14.45, 9)],
  items: [R("bgL", [14.34, 15.5], BRT, BRA, 0, { knob: "bar", r: 44, d: "Arka plan aydınlatması." }), R("afdsFl", [17.0, 15.5], BRT, BRA, 0, { knob: "bar", r: 44, d: "AFDS taşkın ışığı." })]
});
const P1_L = mod("p1_l", "P1", "Kaptan alt panel: hoparlör, ayak ve cam havası", "Foot / Windshield Air", "21", [0, 14.2, 6.5, 18.0], {
  struct: false, desc: "Kaptan hoparlörü; FOOT AIR ve WINDSHIELD AIR (çekme düğmeleri): kokpit şartlandırılmış havasını ayak hizasına veya ön camlara (buğu giderme) yönlendirir.",
  texts: [tx("FOOT\nAIR", 5.04, 15.3, 8), tx("WIND-\nSHIELD\nAIR", 6.0, 16.6, 7)],
  items: [B("footL", [5.04, 16.1], { ri: 0.3, d: "FOOT AIR: çekince kokpit havası ayak altına." }), B("wsL", [6.0, 17.5], { ri: 0.25, d: "WINDSHIELD AIR: çekince hava ön camlara." })]
});

/* ============================ P2 – ORTA ============================ */
const X2 = 22.5;
const P2_1 = mod("p2_1", "P2-1", "Yedek uçuş göstergeleri", "Standby Instruments", "34", [X2, 0, X2 + 4.3, 14.2], {
  dg: ["34-24-11", "34-21-11", "34-22-11"], conns: [{ d: "D3681", w: "W2205", at: [0.5, 0.25] }, { d: "D849", w: "W2205", at: [0.5, 0.55] }, { d: "D3679", w: "W2205", at: [0.5, 0.82] }],
  desc: "N186 yedek ufuk (standby attitude, cayrolu – DC standby barası), N85 yedek hız/irtifa göstergesi (pitot-statik, yedek pitot ve statik portlarından doğrudan), N185 RMI (radyo manyetik gösterge: pusula kartı IRS'den, iğneler VOR/ADF). Ana ekranlar kaybolunca kullanılır.",
  texts: [tx("STANDBY ATTITUDE", X2 + 2.15, 1.0, 8), tx("ALT / AIRSPEED", X2 + 2.15, 5.55, 8), tx("RMI", X2 + 2.15, 10.0, 8)],
  items: [SCR("sbAtt", [X2 + 2.15, 3.15], 3.4, 3.4, { d: "Yedek ufuk: kendi cayrosu vardır; güç kesilirse OFF bayrağı görünür. Kafes (cage) düğmesiyle sabitlenebilir." }),
    SCR("sbAsi", [X2 + 2.15, 7.7], 3.4, 3.4, { d: "Yedek hız ve irtifa: tamamen pnömatik (yedek pitot + statik)." }),
    SCR("rmi", [X2 + 2.15, 12.1], 3.4, 3.4, { d: "RMI: pusula kartı sol IRS'ten; ince iğne VOR/ADF 1, kalın iğne VOR/ADF 2." })]
});
const P2_2 = mod("p2_2", "P2-2", "Orta panel: motor kontrol, otomatik fren, flap göstergesi", "Center Instrument Panel", "22/32/27", [X2 + 4.3, 0, X2 + 13.0, 6.0], {
  dg: ["31-62-13", "32-42-11", "27-52-11"], conns: [{ d: "D333", w: "W0003", at: [0.2, 0.3] }, { d: "D331", w: "W0001", at: [0.5, 0.3] }, { d: "D339", w: "W0001", at: [0.8, 0.3] }, { d: "D686", w: "W0001", at: [0.8, 0.65] }],
  desc: "N1 SET ve SPD REF (motor N1 ve hız referans imleçleri – FMC yerine el ile), FUEL FLOW (RATE/USED/RESET), MFD tuşları (alt DU: ENG/SYS/C/R), AUTO BRAKE seçici (RTO/OFF/1/2/3/MAX) ve DISARM ışığı, ANTI SKID INOP, flap konum göstergesi (N54, sol/sağ iğne), LE FLAPS TRANSIT/EXT ışıkları.",
  texts: [tx("N1 SET", X2 + 5.4, 2.0, 9.5), tx("AUTO", X2 + 5.4, 2.28, 7.5), tx("1", X2 + 4.75, 2.35, 7.5), tx("BOTH", X2 + 6.05, 2.35, 7.5), tx("2", X2 + 4.75, 3.1, 7.5),
    tx("SPD REF", X2 + 7.25, 2.0, 9.5), tx("FUEL FLOW", X2 + 5.4, 4.05, 9), tx("RESET", X2 + 5.4, 4.3, 7.5), tx("RATE", X2 + 4.7, 4.75, 7.5), tx("USED", X2 + 5.4, 5.3, 7.5), tx("MFD", X2 + 7.27, 4.2, 8),
    tx("AUTO BRAKE", X2 + 9.24, 1.4, 9.5), tx("OFF", X2 + 8.25, 3.82, 7.5), tx("RTO", X2 + 8.35, 4.3, 7.5), tx("1", X2 + 8.55, 3.25, 7.5), tx("2", X2 + 9.24, 3.0, 7.5), tx("3", X2 + 9.9, 3.25, 7.5), tx("MAX", X2 + 10.15, 3.82, 7.5), tx("ANTI SKID", X2 + 9.24, 4.55, 9)],
  rects: [[...I(X2 + 6.45, 4.1), ...I(X2 + 8.05, 5.65), 5]],
  items: [R("n1Set", [X2 + 5.4, 2.85], ["2", "1", "AUTO", "BOTH"], [-90, -45, 0, 45], 2, { knob: "round", r: 38, noLabels: true, d: "N1 SET: AUTO – N1 imleçleri FMC'den; 1/2/BOTH – dış halkayla el ile ayar." }),
    R("spdRef", [X2 + 7.25, 2.85], ["SET", "AUTO", "V1", "VR", "WT", "VREF", "80"], [-90, -30, 15, 45, 90, 135, 165], 1, { knob: "round", r: 38, noLabels: true, d: "SPD REF: hız imleçleri (V1, VR, ağırlık, VREF) – AUTO'da FMC'den." }),
    T("ffSw", [X2 + 5.4, 4.75], ["RESET", "RATE", "USED"], 1, { spring: [0, 2], d: "FUEL FLOW: RATE – anlık yakıt akışı; USED – harcanan yakıt (bırakınca RATE); RESET – sayacı sıfırla." }),
    { t: "L", id: "mfdEng", at: I(X2 + 6.95, 4.75), txt: "ENG", c: "w", key: true, w: S(0.55), h: S(0.4), act: ST => { ST.mfdPage = "eng"; }, d: "MFD ENG: alt DU'da ikincil motor göstergesi." },
    { t: "L", id: "mfdSys", at: I(X2 + 7.6, 4.75), txt: "SYS", c: "w", key: true, w: S(0.55), h: S(0.4), act: ST => { ST.mfdPage = "sys"; }, d: "MFD SYS: sistem sayfası (hidrolik, kumanda yüzeyleri)." },
    { t: "L", id: "mfdCR", at: I(X2 + 7.6, 5.3), txt: "C/R", c: "w", key: true, w: S(0.55), h: S(0.4), d: "MFD C/R: bakım mesajlarını iptal et / geri çağır." },
    L("abDisarm", [X2 + 9.24, 1.85], "AUTO BRAKE\nDISARM", "a", { d: "AUTO BRAKE DISARM: otomatik fren devre dışı kaldı (pedala basma, gaz verme, arıza) veya RTO yerde kendini test ediyor." }),
    R("autoBrake", [X2 + 9.24, 3.82], ["RTO", "OFF", "1", "2", "3", "MAX"], [-120, -90, -45, 0, 45, 90], 1, { knob: "bar", r: 44, noLabels: true, d: "AUTO BRAKE: RTO – kalkıştan vazgeçmede (90 kt üstü gaz kesilince) tam fren; 1/2/3/MAX – inişte artan yavaşlama oranı." }),
    L("antiSkidInop", [X2 + 9.24, 5.05], "ANTI SKID\nINOP", "a", { d: "ANTI SKID INOP: kaymayı önleyici sistemde arıza." }),
    SCR("flapInd", [X2 + 11.6, 2.75], 2.1, 2.1, { d: "Flap konum göstergesi (N54): sol ve sağ arka kenar flap konumu (iki iğne)." }),
    L("leTransit", [X2 + 11.05, 5.05], "LE FLAPS\nTRANSIT", "a", { d: "LE FLAPS TRANSIT: hücum kenarı slat/flaplar hareket hâlinde veya uyumsuz." }),
    L("leExt", [X2 + 12.15, 5.05], "LE FLAPS\nEXT", "g", { d: "LE FLAPS EXT: hücum kenarı cihazları açık." })]
});
const DU_C = mod("du_c", "N189", "Üst orta DU (motor göstergesi)", "Upper Center Display Unit", "31", [X2 + 4.3, 6.0, X2 + 13.0, 14.2], {
  dg: ["31-62-11"], conns: [{ d: "D3981", w: "W0001", at: [0.5, 0.5] }],
  desc: "N189 üst orta ekran: normalde motor birincil göstergesi (N1, EGT, N2, yakıt akışı) ve yakıt miktarı. Seçicilerle ND gösterebilir.",
  items: [SCR("duC", [X2 + 8.65, 10.05], 6.85, 6.65, { d: "Üst orta DU: motor göstergesi." })]
});
const P2_3 = mod("p2_3", "P2-3", "İniş takımı paneli", "Landing Gear Panel", "32", [X2 + 13.0, 0, X2 + 15.4, 14.2], {
  dg: ["32-64-11", "32-61-11"], conns: [{ d: "D11732", w: "W0001", at: [0.5, 0.15] }, { d: "D11990", w: "W0001", at: [0.5, 0.6] }],
  desc: "İniş takımı kolu (UP/OFF/DN) – M1952 iniş takımı kol modülü; yerde (air/ground) kol kilitli. Işıklar: yeşil = takım aşağıda kilitli; kırmızı = takım kolla uyumsuz veya hareket hâlinde. Limit hız plakaları.",
  texts: [tx("UP", X2 + 13.5, 6.55, 9), tx("OFF", X2 + 13.5, 7.8, 9), tx("DN", X2 + 13.5, 9.05, 9), tx("LANDING GEAR\nLIMIT (IAS)", X2 + 14.2, 11.3, 8), tx("OPERATING\nEXTEND 270-.82M\nRETRACT 235K\nEXTENDED 320K-.82M", X2 + 14.2, 12.15, 6), tx("FLAPS LIMIT (IAS)\n1-250K 15-200K\n2-250K 25-190K\n5-250K 30-175K\n10-210K 40-162K", X2 + 14.2, 13.35, 6)],
  items: [L("ngRed", [X2 + 14.2, 1.55], "NOSE\nGEAR", "r", { d: "Kırmızı NOSE GEAR: burun takımı kol konumuyla uyumsuz / hareket hâlinde (veya iniş için takım açık değil)." }),
    L("ngGrn", [X2 + 14.2, 2.05], "NOSE\nGEAR", "g", { d: "Yeşil NOSE GEAR: burun takımı aşağıda ve kilitli." }),
    L("lgRed", [X2 + 13.65, 2.7], "LEFT\nGEAR", "r", { wi: 0.85 }), L("rgRed", [X2 + 14.75, 2.7], "RIGHT\nGEAR", "r", { wi: 0.85 }),
    L("lgGrn", [X2 + 13.65, 3.2], "LEFT\nGEAR", "g", { wi: 0.85, d: "Yeşil: sol ana takım aşağıda kilitli." }), L("rgGrn", [X2 + 14.75, 3.2], "RIGHT\nGEAR", "g", { wi: 0.85, d: "Yeşil: sağ ana takım aşağıda kilitli." }),
    T("gearLever", [X2 + 14.3, 7.8], ["UP", "OFF", "DN"], 2, { style: "slot", lock: { pos: 0, msg: "Yerde iniş takımı kolu kilitlidir (air/ground sistemi YER): kol UP'a alınamaz. Kilidi el ile açma tetiği yalnız bakım içindir." }, d: "İniş takımı kolu: UP – takımları toplar; OFF – hidrolik basıncı keser (takımlar kilitlerinde); DN – takımları indirir (A sistemi). Yerde kol kilitlidir." })]
});

/* ============================ P3 – F/O ============================ */
const X3 = 38.0;
const P3_1 = mod("p3_1", "P3-1", "F/O üst şerit: fren basıncı, otomatik uçuş ışıkları, DU seçiciler", "F/O Instrument Panel (upper)", "31/22/29", [X3, 0.6, X3 + 16.8, 6.0], { shape: [[0, 0], [2.7, 0.3], [7.0, 2.3], [16.8, 3.52], [16.8, 5.4], [0, 5.4]],
  dg: ["31-62-13", "31-62-23", "22-14-11", "29-32-11"], conns: [{ d: "D2678", w: "W0003", at: [0.9, 0.4] }, { d: "D2441", w: "W0003", at: [0.75, 0.4] }, { d: "D3999", w: "W0001", at: [0.3, 0.5] }, { d: "D3991", w: "W0003", at: [0.15, 0.5] }],
  desc: "N138 hidrolik fren basınç göstergesi (fren akümülatörü / B sistemi), F/O A/P – A/T – FMC P/RST ışıkları, CABIN ALTITUDE, TAKEOFF CONFIG, SPEEDBRAKES EXTENDED, BELOW G/S, LOWER DU ve MAIN PANEL DUs seçicileri.",
  texts: [tx("TEST", X3 + 5.25, 4.4, 8), tx("1", X3 + 5.5, 3.55, 8), tx("2", X3 + 5.5, 4.1, 8), tx("LOWER DU", X3 + 7.2, 3.55, 10), tx("MAIN PANEL DUs", X3 + 9.6, 3.55, 10), tx("ND", X3 + 6.6, 4.3, 8), tx("NORM", X3 + 7.2, 3.88, 8), tx("ENG\nPRI", X3 + 7.85, 4.3, 8), tx("NORM", X3 + 9.55, 3.88, 8), tx("OUTBD\nPFD", X3 + 10.6, 4.3, 8), tx("ENG\nPRI", X3 + 8.85, 4.3, 8), tx("PFD", X3 + 8.85, 4.85, 8), tx("MFD", X3 + 9.15, 5.35, 8)],
  rects: [[...I(X3 + 2.6, 3.4), ...I(X3 + 5.7, 4.6), 10], [...I(X3 + 6.2, 3.3), ...I(X3 + 10.95, 5.6), 6]],
  items: [SCR("brakeP", [X3 + 1.3, 4.17], 1.55, 1.55, { d: "Hidrolik fren basıncı: normal 3000 psi (B sistemi); akümülatör ön dolum ~1000 psi. Park freni akümülatörle tutulur." }),
    L("apRstR", [X3 + 3.15, 4.0], "A/P\nP/RST", "r", { wi: 0.62, hi: 0.62, press: true }), L("atRstR", [X3 + 3.88, 4.0], "A/T\nP/RST", "r", { wi: 0.62, hi: 0.62, press: true }), L("fmcRstR", [X3 + 4.61, 4.0], "FMC\nP/RST", "a", { wi: 0.62, hi: 0.62, press: true }),
    T("afsTestR", [X3 + 5.24, 3.95], ["1", "", "2"], 1, { spring: [0, 2], springMs: 1500, d: "F/O otomatik uçuş ışıkları testi." }),
    L("cabAltR", [X3 + 2.15, 5.38], "CABIN\nALTITUDE", "r"), L("tocR", [X3 + 3.15, 5.38], "TAKEOFF\nCONFIG", "r"), L("sbExt", [X3 + 4.16, 5.38], "SPEEDBRAKES\nEXTENDED", "a", { d: "SPEEDBRAKES EXTENDED: uçuşta hava freni açık ve düşük irtifa/flap, ya da yerde kol aşağıyken spoilerler açık." }),
    L("belowGsR", [X3 + 5.17, 5.38], "BELOW G/S\nP-INHIBIT", "a", { press: true }),
    R("duLowerR", [X3 + 7.2, 4.62], ["ND", "NORM", "ENG PRI"], [-45, 0, 45], 1, { knob: "bar", r: 42, noLabels: true, d: "LOWER DU (F/O)." }),
    R("duMainR", [X3 + 9.55, 4.62], ["OUTBD PFD", "NORM", "ENG PRI", "PFD", "MFD"], [50, 0, -40, -80, -120], 1, { knob: "bar", r: 42, noLabels: true, d: "MAIN PANEL DUs (F/O): kaptanınkinin aynası." })]
});
const DU_RI = DU("ri", "N192", "F/O iç DU (ND)", "R", X3, "duRI", "D3987", "W0003", "N192 F/O navigasyon ekranı (iç DU). F/O DU'ları AC transfer bara 2'den beslenir; yalnız bataryada kararır.");
const DU_RO = DU("ro", "N191", "F/O dış DU (PFD)", "R", X3 + 8.4, "duRO", "D3985", "W0003", "N191 F/O birincil uçuş ekranı.");
const P3_3 = mod("p3_3", "P3-3", "F/O saati", "F/O Clock", "31", [X3 + 16.8, 4.12, X3 + 22.0, 14.2], { shape: [[0, 0], [0.6, 0.08], [4.8, 1.28], [5.2, 10.08], [0, 10.08]],
  dg: ["31-22-11"], conns: [{ d: "D716", w: "W0003", at: [0.5, 0.4] }],
  desc: "N146 F/O saati (UTC, tarih, kronometre).",
  texts: [tx("DO NOT EXTEND THE SPEEDBRAKE LEVER\nBEYOND THE FLIGHT DETENT IN FLIGHT", X3 + 19.4, 6.4, 6.5), tx("REGISTRATION\nSELCAL", X3 + 19.4, 12.6, 9)],
  rects: [[...I(X3 + 18.2, 12.25), ...I(X3 + 20.6, 12.95), 3]],
  items: [SCR("clockR", [X3 + 19.4, 8.4], 3.0, 3.0, { d: "Saat: UTC zaman ve tarih." }), B("chrR", [X3 + 17.85, 7.05], { ri: 0.13 }), B("etR", [X3 + 17.85, 9.75], { ri: 0.13 })]
});
const P3_7 = mod("p3_7", "P3-7", "GPWS test ve inhibit paneli", "Ground Proximity Test Panel", "34", [X3 + 3.3, 14.2, X3 + 9.0, 18.0], {
  dg: ["34-46-11"], conns: [{ d: "D1255", w: "W0003", at: [0.5, 0.45] }],
  desc: "GPWS (yere yaklaşma ikaz sistemi): INOP – GPWS arızası; SYS TEST – sesli/ışıklı test; FLAP INHIBIT / GEAR INHIBIT – flap/takım konfigürasyon uyarılarını bastırır (kapaklı); TERR INHIBIT – arazi (look-ahead) uyarılarını bastırır.",
  texts: [tx("GROUND PROXIMITY", X3 + 6.1, 14.42, 9), tx("GPWS", X3 + 4.65, 14.75, 7.5), tx("SYS TEST", X3 + 4.65, 16.55, 7.5), tx("FLAP\nINHIBIT", X3 + 6.46, 14.85, 7), tx("GEAR\nINHIBIT", X3 + 7.34, 14.85, 7), tx("TERR\nINHIBIT", X3 + 8.18, 14.85, 7), tx("NORM", X3 + 6.46, 17.45, 7), tx("NORM", X3 + 7.34, 17.45, 7), tx("NORM", X3 + 8.18, 17.45, 7)],
  items: [L("gpwsInop", [X3 + 4.65, 15.15], "INOP", "a", { d: "GPWS INOP: sistem arızası veya veri kaybı." }), B("gpwsTest", [X3 + 4.65, 16.0], { ri: 0.18, d: "SYS TEST: yerde sesli ve ışıklı test (‘GLIDESLOPE’, ‘PULL UP’ …)." }),
    T("flapInh", [X3 + 6.46, 16.3], ["INHIBIT", "NORM"], 1, { guard: "red", gst: 1, gw: 38, gh: 90, d: "FLAP INHIBIT (kapaklı)." }), T("gearInh", [X3 + 7.34, 16.3], ["INHIBIT", "NORM"], 1, { guard: "red", gst: 1, gw: 38, gh: 90, d: "GEAR INHIBIT (kapaklı)." }),
    T("terrInh", [X3 + 8.18, 16.3], ["INHIBIT", "NORM"], 1, { guard: "red", gst: 1, gw: 38, gh: 90, d: "TERR INHIBIT (kapaklı)." })]
});
const P3_4 = mod("p3_4", "P3-4", "F/O aydınlatma paneli", "Lighting Control Panel", "33", [X3 + 9.0, 14.2, X3 + 14.7, 18.0], {
  dg: ["33-11-11"], conns: [{ d: "D1038", w: "W0003", at: [0.5, 0.45] }],
  desc: "MAIN PANEL: F/O ana panel aydınlatması; INBD/OUTBD DU BRT: F/O ekran parlaklıkları.",
  texts: [tx("MAIN PANEL", X3 + 13.5, 14.5, 9), tx("INBD DU\nBRT", X3 + 12.0, 16.4, 8), tx("OUTBD DU\nBRT", X3 + 13.5, 16.4, 8)],
  items: [R("mainPnlR", [X3 + 13.5, 15.3], BRT, BRA, 2, { knob: "bar", r: 44 }), R("brtRI", [X3 + 12.0, 17.2], BRT, BRA, 3, { knob: "grip", r: 26, d: "F/O iç DU parlaklığı." }), R("brtRO", [X3 + 13.5, 17.2], BRT, BRA, 3, { knob: "grip", r: 26, d: "F/O dış DU parlaklığı." })]
});
const P3_L = mod("p3_l", "P3", "F/O alt panel: cam ve ayak havası, hoparlör", "Windshield / Foot Air", "21", [X3 + 14.7, 14.2, X3 + 22.0, 18.0], {
  desc: "WINDSHIELD AIR ve FOOT AIR çekme düğmeleri; F/O hoparlörü.",
  texts: [tx("WIND-\nSHIELD\nAIR", X3 + 15.6, 14.65, 7), tx("FOOT\nAIR", X3 + 16.8, 14.6, 8)],
  items: [B("wsR", [X3 + 15.6, 15.5], { ri: 0.25 }), B("footR", [X3 + 16.8, 15.5], { ri: 0.3 })]
});

export const MIP = {
  id: "mip", PX: U, OX: 0, OY: 0, x1: S(X3 + 22.0), yRow: S(18.0), rails: [],
  modules: [P1_1, P1_3, DU_LO, DU_LI, P1_L, P1_9, P1_5, P2_1, P2_2, DU_C, P2_3, P3_1, DU_RI, DU_RO, P3_3, P3_7, P3_4, P3_L],
  outline: [I(0, 5.1), I(5.4, 3.95), I(22.17, 0.55), I(22.17, 0), I(X2 + 15.4, 0), I(X3, 0.6), I(X3 + 2.7, 0.9), I(X3 + 7.0, 2.9), I(X3 + 17.4, 4.2), I(X3 + 21.6, 5.4), I(X3 + 22.0, 14.2), I(X3 + 22.0, 18.0), I(0, 18.0)],
  focus: { p1: "du_lo", p2: "du_c", p3: "du_ri" }
};
export const MIP_BUNDLES = { W0001: "Kaptan tarafı ana panel demeti", W0003: "F/O tarafı ana panel demeti", W2205: "Yedek göstergeler demeti" };
export const MIP_CONN_PN = {
  D895: ["BACC63CB16-24S6", "31-62-23"], D423: ["BACC63CB20-41SN", "31-62-13"], D714: ["BACC63CB16-24SN", "31-22-11"], D903: ["BACC45FT12-12S", "29-23-11"], D2437: ["BACC45FT14-15S6", "22-14-11"],
  D2650: ["BACC63CB20-28SN", "33-11-11"], D1036: ["BACC45FT12-12S", "33-11-11"], D333: ["BACC63CB22-55SN", "32-42-11"], D331: ["BACC63CB20-41SN", "31-62-13"], D339: ["BACC45FT14-15S", "31-62-23"],
  D11732: ["BACC45FT18-31S", "32-64-11"], D3681: ["BACC63CB16-24S6", "34-24-11"], D849: ["BACC45FT12-12S", "34-21-11"], D3679: ["BACC45FT22-55S6", "34-22-11"], D686: ["BACC45FT18-14S7", "27-52-11"],
  D11990: ["BACC45FT20-16S", "32-64-11"], D2678: ["BACC63CB10-5S10", "29-32-11"], D2441: ["BACC45FT14-15S6", "22-14-11"], D3999: ["BACC63CB16-24S7", "31-62-13"], D3991: ["BACC63CB16-24SN", "31-62-23"],
  D716: ["BACC63CB16-24SN", "31-22-11"], D1038: ["BACC63CB20-28SN", "33-11-11"]
};
