// Basitleştirilmiş güç ve ikaz ışığı mantığı (eğitim amaçlı).
// Yalnızca iyi bilinen, FCOM düzeyindeki davranışlar modellenir; hangi ışığın hangi baradan beslendiği modellenmez.

export const PRESETS = {
  cold: { label: "Soğuk ve karanlık", d: "Batarya anahtarı OFF, harici güç yok. Hiçbir ışık yanmaz, lamba testi çalışmaz." },
  bat: { label: "Yalnız batarya", d: "BAT ON, AC kaynak yok. Batarya ve standby baralar beslenir (statik inverter üzerinden standby AC). AC ile çalışan pompalar/ısıtıcılar çalışmaz." },
  gpu: { label: "Yer gücü (GPU)", d: "Harici güç bağlı ve iki transfer baraya verilmiş. Motorlar ve APU kapalı." },
  apu: { label: "APU çalışıyor", d: "APU çalışıyor, APU jeneratörü iki transfer barayı besliyor, APU bleed açık." },
  eng: { label: "Motorlar çalışıyor", d: "İki motor çalışıyor, IDG'ler baralarda; APU kapalı. Pompalar ve ısıtıcılar açık." }
};

// Sistemin çalışması için kapalı olması gereken devre kesiciler (WDM Circuit Breaker List kimlikleri)
export const SYS_CB = {
  xfeed: ["C00361"], hydEl1: ["C00882", "C00768"], hydEl2: ["C00881", "C00767"], stbyHyd: ["C01449"],
  yd: ["C00285", "C00286"], apuGen: ["C01285", "C01326"],
  pCapt: ["C00523"], pFo: ["C00525"], pLel: ["C00236"], pRel: ["C00237"], pAux: ["C00524"],
  wLS: ["C00225"], wLF: ["C00224"], wRF: ["C00226"], wRS: ["C00227"],
  pF1: ["C00827"], pA1: ["C00826"], pF2: ["C00829"], pA2: ["C00828"], pCL: ["C00845"], pCR: ["C00846"]
};

// Kontrol / ışık → ilgili WDM şeması (91-xx bölümleri; konnektör pinlerinde bu numara geçer)
export const CTRL_DG = {
  xfeed: ["28-22-11"], xfOpen: ["28-22-11"], ev1: ["28-21-11"], ev2: ["28-21-11"], sv1: ["28-21-11"], sv2: ["28-21-11"], fuelTemp: ["28-42-11"],
  pCL: ["28-23-11"], pCR: ["28-23-11"], pF1: ["28-23-11"], pF2: ["28-23-11"], pA1: ["28-23-11"], pA2: ["28-23-11"],
  lpCL: ["28-43-11"], lpCR: ["28-43-11"], lpF1: ["28-43-11"], lpF2: ["28-43-11"], lpA1: ["28-43-11"], lpA2: ["28-43-11"], fb1: ["73-31-11"], fb2: ["73-31-11"],
  hydE1: ["29-11-11"], hydE2: ["29-11-11"], hydEl1: ["29-11-12"], hydEl2: ["29-11-12"], hlpE1: ["29-33-11"], hlpE2: ["29-33-11"], hlpEl1: ["29-33-11"], hlpEl2: ["29-33-11"], hovE1: ["29-34-11"], hovE2: ["29-34-11"],
  yd: ["22-23-11"], ydLt: ["22-23-11"], fltA: ["29-35-11"], fltB: ["29-35-11"], sbRud: ["29-22-11"], sbLP: ["29-22-11"], altArm: ["27-53-11"], altPos: ["27-53-11"], splA: ["27-61-11"], splB: ["27-61-11"], autoSlat: ["27-83-11"], spdTrim: ["22-13-11"], machTrim: ["22-18-11"],
  bat: ["24-31-11"], batDis: ["24-31-11"], stbyPwr: ["24-34-11"], stbyOff: ["24-34-11"], disc1: ["24-11-11"], disc2: ["24-11-21"], drive1: ["24-11-11"], drive2: ["24-11-21"],
  gen1: ["24-22-11"], gen2: ["24-22-21"], apuGen1: ["24-22-31"], apuGen2: ["24-22-31"], gob1: ["24-22-11"], gob2: ["24-22-21"], apuGob: ["24-22-31"], busXfr: ["24-23-11"], tbo1: ["24-23-11"], tbo2: ["24-23-11"],
  grdPwr: ["24-41-11"], grdAvail: ["24-41-11"], elecLcd: ["24-28-11", "24-33-11"], dcSel: ["24-33-11"], acSel: ["24-28-11"],
  apuEgt: ["49-71-21"], apuLop: ["49-94-21"], apuFault: ["49-62-11"], apuOvs: ["49-62-11"], apuMaint: ["49-62-11"], apuSw: ["49-62-11"],
  wLS: ["30-41-11"], wLF: ["30-41-11"], wRF: ["30-41-12"], wRS: ["30-41-12"], prbA: ["30-31-11"], prbB: ["30-31-12"], wingAI: ["30-11-11"], engAI1: ["30-21-11"], engAI2: ["30-21-21"], wiperL: ["30-42-11"],
  recL: ["21-25-11"], recR: ["21-25-11"], packL: ["21-51-11"], packR: ["21-51-21"], duct: ["36-21-11"], pressMode: ["21-31-11"], cabAlt: ["21-33-11"],
  tCont: ["21-61-21"], tFwd: ["21-61-21"], tAft: ["21-61-22"], airTemp: ["21-61-51"],
  dFE: ["52-71-11"], dFS: ["52-71-12"], dAE: ["52-71-13"], dAS: ["52-71-13"], dFC: ["52-71-16"], dAC: ["52-71-16"], dEq: ["52-71-16"],
  stallT1: ["27-32-11"], stallT2: ["27-32-21"], irsL: ["34-21-11"], irsR: ["34-21-21"], eec1: ["73-21-12"], eec2: ["73-21-12"], eltSw: ["23-24-11"], eltLt: ["23-24-11"], fdrTest: ["31-31-11"]
};

export function newSim() { return { bat: true, gpu: true, apu: 0, apuT: 0, eng: [false, false], src: { 1: "grd", 2: "grd" }, irs: { L: 0, R: 0 } }; }

// ön ayar → anahtar konumları
export function applyPreset(sim, key, set) {
  const on = ["pCL", "pCR", "pF1", "pF2", "pA1", "pA2", "hydEl1", "hydEl2", "prbA", "prbB", "wLS", "wLF", "wRF", "wRS"];
  sim.eng = [false, false]; sim.apu = 0; sim.gpu = false; sim.src = { 1: null, 2: null }; sim.bat = key !== "cold";
  set("bat", key === "cold" ? 0 : 1); set("stbyPwr", 2); set("hydE1", 1); set("hydE2", 1); set("yd", key === "eng" ? 1 : 0);
  for (const id of on) set(id, key === "eng" ? 1 : 0);
  set("apuSw", key === "apu" ? 1 : 0); set("apuBl", key === "apu" ? 1 : 0);
  if (key === "gpu") { sim.gpu = true; sim.src = { 1: "grd", 2: "grd" }; }
  if (key === "apu") { sim.apu = 2; sim.src = { 1: "apu", 2: "apu" }; }
  if (key === "eng") { sim.eng = [true, true]; sim.src = { 1: "gen1", 2: "gen2" }; }
}

// yaylı jeneratör/yer gücü anahtarları ve APU anahtarı
export function onSwitch(sim, id, s, st, cbOk) {
  const disc = src => { for (const k of [1, 2]) if (sim.src[k] === src) sim.src[k] = null; };
  if (id === "grdPwr") { if (s === 2 && sim.gpu) { sim.src[1] = "grd"; sim.src[2] = "grd"; } if (s === 0) disc("grd"); }
  if (id === "apuGen1" || id === "apuGen2") { const k = id === "apuGen1" ? 1 : 2; if (s === 2 && sim.apu === 2 && cbOk("apuGen")) sim.src[k] = "apu"; if (s === 0 && sim.src[k] === "apu") sim.src[k] = null; }
  if (id === "gen1" || id === "gen2") { const k = id === "gen1" ? 1 : 2; if (s === 2 && sim.eng[k - 1]) sim.src[k] = "gen" + k; if (s === 0 && sim.src[k] === "gen" + k) sim.src[k] = null; }
  if (id === "apuSw") {
    if (s === 2 && sim.bat && sim.apu === 0) { sim.apu = 1; sim.apuT = performance.now(); }
    if (s === 0) { sim.apu = 0; disc("apu"); }
  }
  if (id === "bat") { sim.bat = s === 1; if (s === 0 && sim.apu) { sim.apu = 0; disc("apu"); } }
  if (id === "irsL" || id === "irsR") { const k = id === "irsL" ? "L" : "R"; sim.irs[k] = s === 0 ? 0 : (sim.irs[k] || performance.now()); }
}
export function tick(sim) { // zamanlı geçişler; değişiklik olduysa true
  let ch = false; const now = performance.now();
  if (sim.apu === 1 && now - sim.apuT > 6000) { sim.apu = 2; ch = true; }
  for (const k of ["L", "R"]) if (sim.irs[k] && sim.irs[k] !== -1 && now - sim.irs[k] > 12000) { sim.irs[k] = -1; ch = true; }
  return ch;
}
export const busy = sim => sim.apu === 1 || (sim.irs.L > 0) || (sim.irs.R > 0);

// Işık durumları: 1 yanık, 0.45 sönük (dim), 0 sönük. undefined → modüldeki anahtar kuralı (güç varsa) geçerli.
export function computeLights(sim, st, cbOk) {
  const bat = sim.bat;
  const ac = !!(sim.src[1] || sim.src[2]);
  const dc = bat || ac;
  const L = {};
  L.grdAvail = sim.gpu ? 1 : 0;
  if (!dc) return { dc, ac, L };
  const on = (id, v) => st(id) === v;
  const sysA = (on("hydE1", 1) && sim.eng[0]) || (on("hydEl2", 1) && ac && cbOk("hydEl2"));
  const sysB = (on("hydE2", 1) && sim.eng[1]) || (on("hydEl1", 1) && ac && cbOk("hydEl1"));
  const stbyAct = on("fltA", 0) || on("fltB", 0) || on("altArm", 1);
  const stbyPress = stbyAct && ac && cbOk("stbyHyd");
  // elektrik
  L.tbo1 = sim.src[1] ? 0 : 1; L.tbo2 = sim.src[2] ? 0 : 1; L.so1 = L.tbo1; L.so2 = L.tbo2;
  L.gob1 = sim.src[1] === "gen1" ? 0 : 1; L.gob2 = sim.src[2] === "gen2" ? 0 : 1;
  L.apuGob = sim.apu === 2 && sim.src[1] !== "apu" && sim.src[2] !== "apu" ? 1 : 0;
  L.drive1 = sim.eng[0] ? 0 : 1; L.drive2 = sim.eng[1] ? 0 : 1;
  L.stbyOff = on("stbyPwr", 1) ? 1 : 0;
  L.batDis = 0; L.trUnit = 0; L.elecLt = 0;
  // APU
  L.apuLop = st("apuSw") > 0 && sim.apu < 2 ? 1 : 0; L.apuFault = 0; L.apuOvs = 0; L.apuMaint = 0;
  // yakıt
  for (const [lt, sw] of [["lpCL", "pCL"], ["lpCR", "pCR"], ["lpF1", "pF1"], ["lpF2", "pF2"], ["lpA1", "pA1"], ["lpA2", "pA2"]]) L[lt] = on(sw, 1) && ac && cbOk(sw) ? 0 : 1;
  L.ev1 = sim.eng[0] ? 0 : 0.45; L.ev2 = sim.eng[1] ? 0 : 0.45; L.sv1 = L.ev1; L.sv2 = L.ev2;
  L.xfOpen = on("xfeed", 1) && cbOk("xfeed") ? 0.45 : 0;
  L.fb1 = 0; L.fb2 = 0;
  // hidrolik ve uçuş kumandaları
  L.hlpE1 = on("hydE1", 1) && sim.eng[0] ? 0 : 1; L.hlpE2 = on("hydE2", 1) && sim.eng[1] ? 0 : 1;
  L.hlpEl1 = on("hydEl1", 1) && ac && cbOk("hydEl1") ? 0 : 1; L.hlpEl2 = on("hydEl2", 1) && ac && cbOk("hydEl2") ? 0 : 1;
  L.hovE1 = 0; L.hovE2 = 0;
  const flt = (sw, sys) => on(sw, 1) ? 1 : on(sw, 2) ? (sys ? 0 : 1) : (stbyPress ? 0 : 1);
  L.lpA = flt("fltA", sysA); L.lpB = flt("fltB", sysB);
  L.sbRud = on("fltA", 0) || on("fltB", 0) ? 1 : 0;
  L.sbLP = stbyAct && !stbyPress ? 1 : 0; L.sbLQ = 0;
  L.ydLt = on("yd", 1) && sysB && cbOk("yd") ? 0 : 1;
  L.feel = 0; L.spdTrim = 0; L.machTrim = 0; L.autoSlat = 0;
  // ısıtma
  for (const [lt, sw] of [["wOn1", "wLS"], ["wOn2", "wLF"], ["wOn3", "wRF"], ["wOn4", "wRS"]]) L[lt] = on(sw, 1) && ac && cbOk(sw) ? 1 : 0;
  L.wOv1 = L.wOv2 = L.wOv3 = L.wOv4 = 0;
  const probe = (sw, lt, cb) => { L[lt] = on(sw, 1) && ac && cbOk(cb) ? 0 : 1; };
  probe("prbA", "pCapt", "pCapt"); probe("prbA", "pLel", "pLel"); probe("prbA", "pLav", "x"); probe("prbA", "pTemp", "x");
  probe("prbB", "pFo", "pFo"); probe("prbB", "pRel", "pRel"); probe("prbB", "pRav", "x"); probe("prbB", "pAux", "pAux");
  // havalandırma / klima
  L.eqSup = ac ? 0 : 1; L.eqExh = ac ? 0 : 1;
  L.ram1 = 1; L.ram2 = 1; L.packLt1 = 0; L.packLt2 = 0; L.wbo1 = L.wbo2 = 0; L.bto1 = L.bto2 = 0; L.autoFail = 0; L.offSched = 0;
  L.dualBleed = on("apuBl", 1) && sim.apu === 2 && (on("bl1", 1) || on("bl2", 1)) ? 1 : 0;
  L.cai1 = L.cai2 = 0; L.zt1 = L.zt2 = L.zt3 = 0;
  // aft panel
  L.eltLt = on("eltSw", 1) ? 1 : 0;
  L.fdrOff = on("fdrTest", 0) || sim.eng[0] || sim.eng[1] ? 0 : 1;
  L.passOxyOn = on("passOxy", 1) ? 1 : 0;
  for (const k of ["L", "R"]) {
    const sw = st("irs" + k), aligning = sim.irs[k] > 0;
    L["align" + k] = sw > 0 && aligning ? 1 : 0; L["ondc" + k] = sw > 0 && !ac ? 1 : 0; L["fault" + k] = 0; L["dcfail" + k] = 0;
  }
  L.gpsLt = 0; L.inop1 = 0; L.inop2 = 0; L.rev1 = L.rev2 = 0; L.engCtl1 = L.engCtl2 = 0; L.eec1 = 1; L.eec2 = 1; L.pseu = 0;
  L.gearL = L.gearR = L.gearN = 1;
  return { dc, ac, L };
}

// Gösterge iğneleri (değer, DIALS birimiyle)
export function gaugeValues(sim, st, dc, ac) {
  const now = performance.now();
  let egt = 0;
  if (sim.apu === 1) { const k = Math.min(1, (now - sim.apuT) / 6000); egt = k < 0.7 ? k / 0.7 * 8.2 : 8.2 - (k - 0.7) / 0.3 * 3.8; }
  else if (sim.apu === 2) egt = 4.4;
  const apuB = sim.apu === 2 && st("apuBl") === 1;
  const ductL = (sim.eng[0] && st("bl1") === 1) ? 32 : apuB ? 30 : 0, ductR = (sim.eng[1] && st("bl2") === 1) ? 31 : apuB && st("isoVlv") !== 0 ? 29 : 0;
  return { apuEgt: [egt], duct: [ductL, ductR], fuelTemp: [dc ? 18 : -40], airTemp: [dc ? 24 : 0], crewOxy: [dc ? 18.5 : 0] };
}

// P5-13 elektrik göstergesi (DC AMPS · CPS / DC VOLTS · AC AMPS · AC VOLTS)
export function elecMeter(sim, st, dc, ac) {
  if (!dc) return null;
  const bat = sim.bat, dcs = st("dcSel"), acs = st("acSel");
  let dA = "", dV = "";
  if (dcs === 0) { dA = "-"; dV = "-"; }
  else if (dcs === 1 || dcs === 2) { dA = ""; dV = ac ? "28" : "25"; }
  else if (dcs === 3) { dA = ac ? "5" : "-12"; dV = ac ? "28" : "24"; }
  else if (dcs === 4) { dA = ac ? "3" : "0"; dV = ac ? "27" : "24"; }
  else { dA = ac ? "25" : "0"; dV = ac ? "28" : "0"; }
  const srcOn = { 1: sim.gpu, 2: sim.eng[0], 3: sim.apu === 2, 4: sim.eng[1] }[acs];
  const loaded = { 1: "grd", 2: "gen1", 3: "apu", 4: "gen2" }[acs];
  let f = "0", aV = "0", aA = "0";
  if (acs === 0 || acs === 5) { if (bat || ac) { f = "400"; aV = "115"; aA = ""; } }
  else if (acs === 6) { f = "-"; aV = "-"; aA = "-"; }
  else if (srcOn) { f = "400"; aV = "115"; aA = (sim.src[1] === loaded || sim.src[2] === loaded) ? "62" : "0"; }
  return { dA, dV, f, aA, aV };
}
