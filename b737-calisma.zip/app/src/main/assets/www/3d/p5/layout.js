// 737NG P5 ön overhead panel – gerçek düzen.
// KAYNAK: AMM 31-11-94 Fig.101 "Forward Overhead Panel - Component Location" (ön yüz)
//         WDM 91-02-05 "P5 - Pilot Overhead Panel" (arka görünüş: D/W numaraları, TB, GD, menteşe)
//         WDM Equipment List D280A117 (konnektör parça numaraları), SWPM 20-61-11 (BACC45 yapısı)
// Koordinatlar AMM şeklinden ölçülmüştür: piksel (300 dpi kesit). 64.7 px = 1 inç. Sol üst köşe (18,25).
// Konnektör konumları WDM arka görünüşünden (arkadan bakış, fx = soldan oran) alınmıştır.

export const PX = 64.7, OX = 18, OY = 25;
export const PANEL = { x0: 18, x1: 1702, y0: 25, yRow: 1530 };

// ---------- öğe yardımcıları ----------
const T = (id, at, pos, st, o = {}) => ({ t: "T", id, at, pos, st, ...o });       // toggle (pos: üst→alt veya sol→sağ)
const R = (id, at, pos, ang, st, o = {}) => ({ t: "R", id, at, pos, ang, st, ...o }); // döner seçici (ang: derece, saat yönü, 0 = yukarı)
const L = (id, at, txt, c = "a", o = {}) => ({ t: "L", id, at, txt, c, ...o });     // ikaz lambası (w,h px)
const B = (id, at, o = {}) => ({ t: "B", id, at, ...o });                          // yuvarlak basmalı düğme
const G = (id, at, kind, r, o = {}) => ({ t: "G", id, at, kind, r, ...o });         // gösterge
const D = (id, at, kind, w, h, o = {}) => ({ t: "D", id, at, kind, w, h, ...o });   // LCD pencere
const J = (id, at, kind, o = {}) => ({ t: "J", id, at, kind, ...o });               // jak / mikrofon

const LP = (id, at, o) => L(id, at, "LOW\nPRESSURE", "a", o);

/* =============================================================== */
export const MODULES = [
/* ----------------------- 1. SÜTUN ----------------------- */
{ id: "p5_3", pn: "P5-3", name: "Uçuş Kumanda Paneli", en: "Flight Control Panel", ata: "27", rect: [18, 25, 390, 559],
  desc: "Birincil uçuş kumandalarının A/B hidrolik kaynaklarını, standby rudder'ı, alternatif flapları, spoylerleri ve yaw damper'ı kontrol eder.",
  conns: [{ d: "D624", w: "W2104", at: [0.35, 0.31] }, { d: "D630", w: "W2212", at: [0.65, 0.31] }],
  texts: [["FLT CONTROL", 132, 40, 12], ["A", 96, 55], ["B", 169, 55], ["STBY", 40, 95], ["RUD", 40, 108], ["OFF", 40, 125], ["A ON", 40, 142],
    ["STBY", 220, 95], ["RUD", 220, 108], ["OFF", 220, 125], ["B ON", 222, 142], ["STANDBY HYD", 305, 40, 12], ["ALTERNATE FLAPS", 305, 158, 12],
    ["OFF", 290, 182, 10, "left"], ["ARM", 290, 272, 10, "left"], ["UP", 330, 215], ["OFF", 365, 250, 10, "left"], ["DOWN", 330, 288],
    ["SPOILER", 133, 268, 12], ["A", 103, 284], ["B", 163, 284], ["OFF", 60, 350], ["ON", 60, 386], ["OFF", 210, 350], ["ON", 210, 386],
    ["YAW DAMPER", 130, 432, 12], ["OFF", 70, 508], ["ON", 70, 540]],
  items: [
    T("fltA", [96, 130], ["STBY RUD", "OFF", "ON"], 2, { guard: "red", gst: 2, gw: 42, gh: 110, lights: [{ id: "lpA", on: [0, 1] }], d: "A hidrolik sisteminin aileron, elevator ve rudder PCU'larına basıncını kontrol eder. STBY RUD: A kapatılır, standby pompa çalışır ve standby rudder PCU'yu besler. Kapakla ON konumunda korunur." }),
    T("fltB", [169, 130], ["STBY RUD", "OFF", "ON"], 2, { guard: "red", gst: 2, gw: 42, gh: 110, lights: [{ id: "lpB", on: [0, 1] }], d: "B hidrolik sistemi için aynı işlev." }),
    L("sbLQ", [305, 66], "LOW\nQUANTITY", "a", { w: 68, h: 23 }), L("sbLP", [305, 91], "LOW\nPRESSURE", "a", { w: 68, h: 23 }), L("sbRud", [305, 116], "STBY\nRUD ON", "a", { w: 68, h: 23 }),
    T("altArm", [245, 232], ["OFF", "ARM"], 0, { guard: "red", gst: 0, gw: 36, gh: 115, d: "Alternatif flap ana anahtarı. ARM: normal flap hidroliği bypass edilir, standby pompa çalışır, alternatif flap anahtarı aktif olur." }),
    T("altPos", [330, 250], ["UP", "OFF", "DOWN"], 1, { spring: [0], d: "ARM'dayken TE flapları elektrik motoruyla sürer. DOWN ayrıca LE cihazları standby hidrolikle tam açar. UP konumu yaylıdır." }),
    LP("lpA", [101, 228], { w: 65, h: 28 }), LP("lpB", [166, 228], { w: 65, h: 28 }),
    T("splA", [103, 355], ["OFF", "ON"], 1, { guard: "red", gst: 1, gw: 44, gh: 120, d: "A sistemi flight spoyler aktüatörleri." }),
    T("splB", [163, 355], ["OFF", "ON"], 1, { guard: "red", gst: 1, gw: 44, gh: 120, d: "B sistemi flight spoyler aktüatörleri." }),
    L("feel", [286, 357], "FEEL\nDIFF PRESS", "a", { w: 62, h: 25 }), L("spdTrim", [286, 384], "SPEED TRIM\nFAIL", "a", { w: 62, h: 25 }),
    L("machTrim", [286, 411], "MACH TRIM\nFAIL", "a", { w: 62, h: 25 }), L("autoSlat", [286, 438], "AUTO SLAT\nFAIL", "a", { w: 62, h: 25 }),
    L("ydLt", [130, 466], "YAW\nDAMPER", "a", { w: 60, h: 26 }),
    T("yd", [100, 524], ["OFF", "ON"], 1, { lights: [{ id: "ydLt", on: [0] }], d: "Yaw damper. Kapalı veya devre dışıyken YAW DAMPER ışığı yanar." })
  ] },
{ id: "p5_28", pn: "P5-28", name: "VHF Nav ve Pusula Enstrüman Anahtarlama Modülü", en: "Instrument Switching Module", ata: "34", rect: [18, 559, 390, 948],
  desc: "Navigasyon (VHF NAV, IRS, FMC) ve ekran (DEU kaynağı, EFIS kontrol paneli) transfer anahtarları. Bir sistem arızalandığında her iki pilotu tek kaynaktan beslemek için kullanılır.",
  conns: [{ d: "D553", w: "W2035", at: [0.30, 0.39] }, { d: "D1817", w: "W2135", at: [0.65, 0.39] }],
  texts: [["NAVIGATION", 205, 576, 12, "center", "line"], ["VHF NAV", 120, 592], ["BOTH", 60, 612], ["ON 1", 60, 625], ["BOTH", 182, 612], ["ON 2", 182, 625], ["NORMAL", 120, 660],
    ["IRS", 270, 592], ["BOTH", 210, 612], ["ON L", 210, 625], ["BOTH", 330, 612], ["ON R", 330, 625], ["NORMAL", 270, 660],
    ["FMC", 270, 707], ["BOTH", 210, 727], ["ON L", 210, 740], ["BOTH", 330, 727], ["ON R", 330, 740], ["NORMAL", 270, 778],
    ["DISPLAYS", 205, 810, 12, "center", "line"], ["SOURCE", 120, 830], ["AUTO", 120, 843], ["ALL", 55, 860], ["ON 1", 55, 873], ["ALL", 185, 860], ["ON 2", 185, 873],
    ["CONTROL PANEL", 270, 836], ["BOTH", 210, 865], ["ON 1", 210, 878], ["BOTH", 330, 865], ["ON 2", 330, 878], ["NORMAL", 270, 915]],
  items: [
    T("vhfNav", [120, 620], ["BOTH ON 1", "NORMAL", "BOTH ON 2"], 1, { horiz: true, d: "Her iki pilotun navigasyon göstergesini VHF NAV 1 veya 2 alıcısından besler." }),
    T("irsSel", [270, 620], ["BOTH ON L", "NORMAL", "BOTH ON R"], 1, { horiz: true, d: "Her iki tarafın ekranlarını sol veya sağ IRS'ten besler." }),
    T("fmcSel", [270, 735], ["BOTH ON L", "NORMAL", "BOTH ON R"], 1, { horiz: true, d: "Her iki CDU'yu ve ekranları sol veya sağ FMC'den besler." }),
    R("dspSrc", [120, 880], ["ALL ON 1", "AUTO", "ALL ON 2"], [-45, 0, 45], 1, { knob: "bar", r: 34, noLabels: true, d: "Ekran elektronik ünitesi (DEU) kaynağını seçer. AUTO normaldir." }),
    T("ctlPnl", [270, 872], ["BOTH ON 1", "NORMAL", "BOTH ON 2"], 1, { horiz: true, d: "EFIS kontrol panellerinden birini her iki taraf için kullanır." })
  ] },
{ id: "p5_2", pn: "P5-2", name: "Yakıt Paneli", en: "Fuel System Panel", ata: "28", rect: [18, 948, 390, 1530],
  desc: "Yakıt pompaları, crossfeed valfi, motor/spar valf ışıkları, filtre bypass ışıkları ve yakıt sıcaklığı göstergesi. Alt bölüm şematiktir: pompa anahtarlarının yeri tankların yerine karşılık gelir.",
  conns: [{ d: "D616", w: "W2218", at: [0.50, 0.19], mw: "N42" }, { d: "D626", w: "W2508", at: [0.25, 0.38] }, { d: "D628", w: "W2510", at: [0.75, 0.38] }],
  texts: [["CROSS", 140, 1145, 12], ["FEED", 268, 1145, 12], ["FUEL PUMPS", 205, 1228, 12], ["OFF", 205, 1243], ["L", 150, 1275], ["R", 262, 1275], ["ON", 205, 1278], ["CTR", 205, 1291],
    ["AFT", 88, 1392], ["FWD", 150, 1392], ["OFF", 120, 1405], ["FWD", 262, 1392], ["AFT", 323, 1392], ["OFF", 292, 1405], ["ON", 120, 1450], ["ON", 292, 1450],
    ["FUEL", 205, 1425, 12], ["PUMPS", 205, 1440, 12], ["1", 120, 1500, 12], ["2", 292, 1500, 12]],
  rects: [[50, 1128, 360, 1525, 12], [90, 1145, 320, 1325, 0]],
  lines: [[150, 1145, 150, 1192], [262, 1145, 262, 1192], [90, 1192, 150, 1192], [262, 1192, 320, 1192], [90, 1325, 90, 1355], [320, 1325, 320, 1355], [150, 1325, 150, 1355], [262, 1325, 262, 1355]],
  items: [
    L("ev1", [100, 979], "ENG VALVE\nCLOSED", "b", { w: 62, h: 25 }), L("sv1", [100, 1006], "SPAR VALVE\nCLOSED", "b", { w: 62, h: 25 }),
    G("fuelTemp", [205, 1020], "fueltemp", 58, { d: "Ana tank 1 yakıt sıcaklığı (°C)." }),
    L("ev2", [310, 979], "ENG VALVE\nCLOSED", "b", { w: 62, h: 25 }), L("sv2", [310, 1006], "SPAR VALVE\nCLOSED", "b", { w: 62, h: 25 }),
    L("fb1", [100, 1114], "FILTER\nBY PASS", "a", { w: 58, h: 25 }), L("xfOpen", [205, 1114], "VALVE\nOPEN", "b", { w: 58, h: 25 }), L("fb2", [310, 1114], "FILTER\nBY PASS", "a", { w: 58, h: 25 }),
    R("xfeed", [205, 1165], ["CLOSED", "OPEN"], [-90, 0], 0, { knob: "xfeed", r: 36, lights: [{ id: "xfOpen", on: [1] }], d: "Crossfeed valfi. Çubuk yatayken kapalı, dikeyken açık. Açıkken iki motor besleme manifoldu birleşir." }),
    LP("lpCL", [176, 1205], { w: 57, h: 25 }), LP("lpCR", [233, 1205], { w: 57, h: 25 }),
    T("pCL", [176, 1262], ["OFF", "ON"], 0, { lights: [{ id: "lpCL", on: [0] }], d: "Merkez tank sol pompası. Merkez pompaları daha yüksek basınçlıdır; önce merkez tank yakıtı kullanılır." }),
    T("pCR", [233, 1262], ["OFF", "ON"], 0, { lights: [{ id: "lpCR", on: [0] }], d: "Merkez tank sağ pompası." }),
    LP("lpA1", [73, 1368], { w: 57, h: 25 }), LP("lpF1", [130, 1368], { w: 57, h: 25 }), LP("lpF2", [280, 1368], { w: 57, h: 25 }), LP("lpA2", [337, 1368], { w: 57, h: 25 }),
    T("pA1", [88, 1420], ["OFF", "ON"], 0, { lights: [{ id: "lpA1", on: [0] }], d: "Ana tank 1 arka pompası." }),
    T("pF1", [150, 1420], ["OFF", "ON"], 0, { lights: [{ id: "lpF1", on: [0] }], d: "Ana tank 1 ön pompası." }),
    T("pF2", [262, 1420], ["OFF", "ON"], 0, { lights: [{ id: "lpF2", on: [0] }], d: "Ana tank 2 ön pompası." }),
    T("pA2", [323, 1420], ["OFF", "ON"], 0, { lights: [{ id: "lpA2", on: [0] }], d: "Ana tank 2 arka pompası." })
  ] },
/* ----------------------- 2. SÜTUN ----------------------- */
{ id: "blank2", pn: "—", name: "Boş panel", en: "Blank Panel", ata: "—", rect: [390, 25, 762, 172], blank: true,
  desc: "Kör plaka (blank panel). Bu konfigürasyonda bu yuvada modül yoktur.", conns: [], texts: [], items: [] },
{ id: "p5_13", pn: "P5-13", name: "Elektrik Ölçüm, Batarya ve Galley Güç Modülü", en: "Electrical Meters, Battery and Galley Power Module", ata: "24", rect: [390, 172, 762, 681],
  desc: "Seçilen DC/AC kaynağın voltaj, akım ve frekansını gösterir. Batarya anahtarı, CAB/UTIL ve IFE/PASS SEAT güç anahtarları ve elektrik arıza ışıkları buradadır.",
  conns: [{ d: "D652", w: "W2508", at: [0.20, 0.25] }, { d: "D10596", w: "W2508", at: [0.55, 0.50] }],
  texts: [["DC AMPS", 495, 196], ["CPS FREQ", 605, 196], ["DC VOLTS / AC AMPS / AC VOLTS", 578, 362], ["MAINT", 680, 428],
    ["OFF", 530, 573, 10, "left"], ["BAT", 530, 603, 11, "left"], ["ON", 530, 632, 10, "left"], ["OFF", 610, 572, 10, "left"], ["ON", 610, 625, 10, "left"], ["CAB/UTL", 595, 645],
    ["OFF", 700, 572, 10, "left"], ["ON", 700, 625, 10, "left"], ["IFE/PASS", 685, 645], ["SEAT", 685, 658], ["DC", 475, 672, 12, "center", "line2"], ["AC", 640, 672, 12, "center", "line2"]],
  lines: [[566, 455, 566, 665]],
  items: [
    D("elecLcd", [578, 272], "elec", 265, 125, { d: "LCD gösterge. Üst: DC AMPS ve CPS FREQ. Alt: DC VOLTS, AC AMPS, AC VOLTS. Değerler DC ve AC seçicilerine göre değişir." }),
    L("batDis", [470, 409], "BAT\nDISCHARGE", "a", { w: 64, h: 26 }), L("trUnit", [534, 409], "TR UNIT", "a", { w: 64, h: 26 }), L("elecLt", [598, 409], "ELEC", "a", { w: 64, h: 26 }),
    B("maint", [680, 400], { r: 13, d: "Elektrik sistemi bakım/BITE düğmesi." }),
    R("dcSel", [475, 505], ["TEST", "STBY PWR", "BAT BUS", "BAT", "AUX BAT", "TR1", "TR2", "TR3"], [180, -135, -90, -45, 0, 45, 90, 135], 3, { knob: "bar", r: 34, d: "DC ölçüm kaynağı." }),
    R("acSel", [655, 505], ["STBY PWR", "GRD PWR", "GEN1", "APU GEN", "GEN2", "INV", "TEST"], [-135, -90, -45, 0, 45, 90, 135], 0, { knob: "bar", r: 34, d: "AC ölçüm kaynağı." }),
    T("bat", [476, 610], ["OFF", "ON"], 1, { guard: "red", gst: 1, gw: 44, gh: 100, d: "Batarya ana anahtarı; ON konumunda kapakla korunur." }),
    T("cabUtil", [595, 598], ["OFF", "ON"], 1, { d: "Galley ve kabin servis (utility) yüklerinin gücü." }),
    T("ifePass", [685, 598], ["OFF", "ON"], 1, { d: "Uçuş içi eğlence ve yolcu koltuğu elektrik beslemesi." })
  ] },
{ id: "p5_5", pn: "P5-5", name: "Jeneratör Tahrik ve Yedek Güç Modülü", en: "Generator Drive and Standby Power Module", ata: "24", rect: [390, 681, 762, 948],
  desc: "IDG ayırma (DISCONNECT) anahtarları, DRIVE ışıkları ve standby güç anahtarı.",
  conns: [{ d: "D636", w: "W2218", at: [0.31, 0.43], note: "ENGINE NO.2" }, { d: "D1086", w: "W2508", at: [0.70, 0.43], note: "ENGINE NO.1" }],
  texts: [["1", 470, 692], ["2", 695, 692], ["STANDBY POWER", 578, 760], ["DISCONNECT", 470, 780], ["DISCONNECT", 695, 780], ["BAT", 538, 843], ["OFF", 578, 843], ["AUTO", 620, 843]],
  items: [
    L("drive1", [470, 718], "DRIVE", "a", { w: 55, h: 24 }), L("stbyOff", [578, 708], "STANDBY\nPWR OFF", "a", { w: 60, h: 28 }), L("drive2", [695, 718], "DRIVE", "a", { w: 55, h: 24 }),
    T("disc1", [470, 845], ["", "NORMAL"], 1, { guard: "red", gst: 1, gw: 40, gh: 110, spring: [0], d: "IDG 1'i motordan mekanik olarak ayırır. Uçuşta geri bağlanamaz; reset yerde, motor kapalıyken yapılır." }),
    T("stbyPwr", [578, 798], ["BAT", "OFF", "AUTO"], 2, { horiz: true, guard: "red", gst: 2, gw: 90, gh: 42, gHoriz: true, lights: [{ id: "stbyOff", on: [1] }], d: "AUTO: normal; tüm AC kaybında standby baralar bataryadan beslenir. BAT: bataryadan beslenir. OFF: standby baralar enerjisiz." }),
    T("disc2", [695, 845], ["", "NORMAL"], 1, { guard: "red", gst: 1, gw: 40, gh: 110, spring: [0], d: "IDG 2 ayırma anahtarı." })
  ] },
{ id: "p5_4", pn: "P5-4", name: "AC Sistem, Jeneratör ve APU Modülü", en: "AC System, Generator and APU Module", ata: "24/49", rect: [390, 948, 762, 1530],
  desc: "Yer gücü, bara transferi, motor ve APU jeneratör anahtarları; APU arıza ışıkları, APU EGT göstergesi ve sol silecek seçicisi.",
  conns: [{ d: "D730", w: "W2218", at: [0.20, 0.19], note: "ENGINE NO.2" }, { d: "D722", w: "W2112", at: [0.80, 0.19], note: "ENGINE NO.1" }, { d: "D634", w: "W2218", at: [0.20, 0.57], note: "APU" },
    { d: "D11988", w: "W2104", at: [0.45, 0.76], note: "LEFT WIPER CONT", mw: "S7" }, { d: "D446", w: "W2702", at: [0.80, 0.76], mw: "N24" }],
  texts: [["GRD", 578, 1008], ["PWR", 578, 1020], ["OFF", 578, 1032], ["ON", 578, 1080], ["BUS TRANSFER", 578, 1115, 12], ["O", 513, 1138], ["F", 513, 1150], ["F", 513, 1162], ["A", 643, 1132], ["U", 643, 1144], ["T", 643, 1156], ["O", 643, 1168],
    ["OFF", 485, 1268, 10, "left"], ["GEN 1", 468, 1310], ["ON", 478, 1295, 10, "left"], ["APU GEN", 578, 1310], ["OFF", 650, 1268, 10, "left"], ["ON", 663, 1295, 10, "left"], ["GEN 2", 700, 1310], ["APU", 578, 1330, 12],
    ["L WIPER", 663, 1390, 12]],
  rects: [[400, 1100, 755, 1320, 14]],
  items: [
    L("grdAvail", [578, 972], "GRD POWER\nAVAILABLE", "b", { w: 62, h: 28 }),
    T("grdPwr", [578, 1050], ["OFF", "", "ON"], 1, { spring: [0, 2], d: "Yer gücü takılı ve uygunsa GRD POWER AVAILABLE yanar. ON: yer gücünü iki transfer baraya bağlar. OFF: ayırır. Yaylı, ortaya döner." }),
    T("busXfr", [578, 1150], ["OFF", "AUTO"], 1, { horiz: true, guard: "red", gst: 1, gw: 90, gh: 42, gHoriz: true, d: "AUTO: kaynak kaybında BTB'ler transfer barayı otomatik diğer kaynağa aktarır. OFF: otomatik transfer engellenir." }),
    L("tbo1", [468, 1148], "TRANSFER\nBUS OFF", "a", { w: 60, h: 26 }), L("so1", [468, 1176], "SOURCE\nOFF", "a", { w: 60, h: 26 }), L("gob1", [468, 1204], "GEN OFF\nBUS", "b", { w: 60, h: 26 }),
    L("tbo2", [695, 1148], "TRANSFER\nBUS OFF", "a", { w: 60, h: 26 }), L("so2", [695, 1176], "SOURCE\nOFF", "a", { w: 60, h: 26 }), L("gob2", [695, 1204], "GEN OFF\nBUS", "b", { w: 60, h: 26 }),
    L("apuGob", [578, 1213], "APU GEN\nOFF BUS", "b", { w: 60, h: 26 }),
    T("gen1", [455, 1270], ["OFF", "", "ON"], 1, { spring: [0, 2], d: "Jeneratör 1'i transfer bara 1'e bağlar (ON) veya ayırır (OFF). Yaylı." }),
    T("apuGen1", [528, 1270], ["OFF", "", "ON"], 1, { spring: [0, 2], d: "APU jeneratörünü transfer bara 1'e bağlar." }),
    T("apuGen2", [625, 1270], ["OFF", "", "ON"], 1, { spring: [0, 2], d: "APU jeneratörünü transfer bara 2'ye bağlar." }),
    T("gen2", [697, 1270], ["OFF", "", "ON"], 1, { spring: [0, 2], d: "Jeneratör 2'yi transfer bara 2'ye bağlar veya ayırır." }),
    L("apuMaint", [482, 1360], "MAINT", "b", { w: 64, h: 24 }), L("apuLop", [546, 1360], "LOW OIL\nPRESSURE", "a", { w: 64, h: 24 }),
    L("apuFault", [610, 1360], "FAULT", "a", { w: 64, h: 24 }), L("apuOvs", [674, 1360], "OVER\nSPEED", "a", { w: 64, h: 24 }),
    G("apuEgt", [498, 1448], "egt", 62, { d: "APU egzoz gazı sıcaklığı (°C x100)." }),
    R("wiperL", [663, 1455], ["PARK", "INT", "LOW", "HIGH"], [0, 45, 90, 135], 0, { knob: "bar", r: 34, d: "Kaptan tarafı silecek." })
  ] },
/* ----------------------- 3. SÜTUN (dar, P5 yapısına bağlı paneller) ----------------------- */
{ id: "blank3", pn: "—", name: "Boş plaka", en: "Blank", ata: "—", rect: [775, 25, 945, 277], blank: true, desc: "Kör plaka.", conns: [], texts: [], items: [] },
{ id: "c_light", pn: "P5 (T60/T31)", name: "Aydınlatma Kontrol Paneli", en: "Circuit Breaker / Panel Lighting", ata: "33", rect: [775, 277, 945, 649], struct: true,
  desc: "Devre kesici panellerinin (T60) ve P5 panelinin (T31) aydınlatma ayarı. Bunlar ayarlı trafolardır (variable transformer); modül konnektörü yoktur, kabloları doğrudan bağlanır.",
  comps: [["T60", "Circuit breaker panel lighting – ayarlı trafo"], ["T31", "P5 panel lighting – ayarlı trafo"]],
  texts: [["CIRCUIT BREAKER", 860, 290, 12], ["BRIGHT", 862, 312, 10], ["OFF", 812, 390, 10], ["PANEL", 860, 405, 12], ["BRIGHT", 862, 425, 10], ["OFF", 812, 505, 10]],
  items: [
    R("cbLt", [858, 350], ["OFF", "BRIGHT"], [-150, 30], 0, { knob: "bar", r: 34, dim: true, d: "T60: P6/P18 devre kesici panellerinin aydınlatma şiddeti." }),
    R("pnlLt", [858, 465], ["OFF", "BRIGHT"], [-150, 30], 1, { knob: "bar", r: 34, dim: true, d: "T31: P5 overhead panelin entegre (arka) aydınlatma şiddeti. Modüllerin ışık plakaları 5V AC ile beslenir." })
  ] },
{ id: "c_cool", pn: "P5 (S870/S59)", name: "Ekipman Soğutma Paneli", en: "Equipment Cooling Panel", ata: "21", rect: [775, 649, 945, 830], struct: true,
  desc: "E/E bölümü soğutma besleme (SUPPLY) ve egzoz (EXHAUST) fanlarının seçimi. OFF ışıkları hava akışı kaybını gösterir.",
  comps: [["S870", "Supply anahtarı"], ["S59", "Exhaust anahtarı"], ["L1141", "Supply OFF ışığı"], ["L47", "Exhaust OFF ışığı"]],
  texts: [["EQUIP COOLING", 860, 662, 12], ["SUPPLY", 802, 690], ["EXHAUST", 915, 690], ["NORM", 860, 708], ["ALTN", 860, 738]],
  rects: [[792, 785, 930, 815, 0]],
  items: [
    T("eqSupply", [802, 722], ["NORM", "ALTN"], 0, { d: "S870: E/E besleme fanı – normal/alternatif." }),
    T("eqExhaust", [918, 722], ["NORM", "ALTN"], 0, { d: "S59: E/E egzoz fanı – normal/alternatif." }),
    L("eqSup", [826, 800], "OFF", "a", { w: 66, h: 26 }), L("eqExh", [895, 800], "OFF", "a", { w: 66, h: 26 })
  ] },
{ id: "c_emer", pn: "P5 (S7/L1)", name: "Acil Çıkış Işıkları Paneli", en: "Emergency Exit Lights", ata: "33", rect: [775, 830, 945, 1016], struct: true,
  desc: "Acil çıkış ışıkları anahtarı ve NOT ARMED ışığı. Kablolar D3072 konnektörü (W2218) üzerinden gelir.",
  comps: [["S7", "Emergency exit lights anahtarı (OFF/ARMED/ON)"], ["L1", "NOT ARMED ışığı"], ["D3072", "Konnektör, M/W R334 (W2218)"]],
  conns: [{ d: "D3072", w: "W2218", at: [0.5, 0.6], small: true, mw: "R334" }],
  texts: [["EMER EXIT LIGHTS", 860, 842, 11], ["OFF", 900, 875, 10, "left"], ["ARMED", 900, 913, 10, "left"], ["ON", 900, 950, 10, "left"]],
  items: [
    L("emerNA", [801, 918], "N\nO\nT\n\nA\nR\nM\nE\nD", "a", { w: 26, h: 82 }),
    T("emerExit", [865, 915], ["OFF", "ARMED", "ON"], 1, { guard: "yellow", gst: 1, gw: 48, gh: 135, lights: [{ id: "emerNA", on: [0, 2] }], d: "ARMED: uçak DC gücü kesilirse acil çıkış ışıkları otomatik yanar. Kapakla ARMED'da korunur. OFF/ON'da NOT ARMED yanar." })
  ] },
{ id: "c_signs", pn: "P5 (S45/S46)", name: "Yolcu İşaretleri ve Çağrı Paneli", en: "Passenger Signs / Call", ata: "33/23", rect: [775, 1016, 945, 1281], struct: true,
  desc: "NO SMOKING (bu konfigürasyonda CHIME ONLY) ve FASTEN BELTS işaretleri; ATTEND ve GRD CALL çağrı düğmeleri; kabinden kokpite çağrı (CALL) ışığı.",
  comps: [["S45", "No smoking anahtarı"], ["S46", "Fasten belts anahtarı"], ["M516", "Passenger sign diyot"], ["S36", "Attendant düğmesi"], ["S32", "Ground call düğmesi"], ["M527", "Ground horn diyot"], ["L19", "Captain call ışığı"]],
  texts: [["CHIME", 825, 1023, 10], ["ONLY", 825, 1035, 10], ["FASTEN", 905, 1023], ["BELTS", 905, 1036], ["OFF", 855, 1050, 10], ["AUTO", 855, 1078, 10], ["ON", 855, 1100, 10], ["ATTEND", 803, 1170], ["GRD", 905, 1160], ["CALL", 905, 1173]],
  rects: [[790, 1013, 862, 1045, 8]],
  items: [
    T("noSmk", [805, 1068], ["OFF", "AUTO", "ON"], 1, { d: "S45: No smoking / chime only işaretleri. AUTO: iniş takımı veya flap konumuna göre." }),
    T("belts", [902, 1068], ["OFF", "AUTO", "ON"], 1, { d: "S46: Kemer bağlayın işaretleri." }),
    L("paInUse", [858, 1180], "", "w", { w: 18, h: 72, d: "PA IN USE göstergesi (opsiyonel)." }),
    B("attend", [803, 1210], { r: 16, d: "S36: Kabin ekibini çağırır." }),
    B("grdCall", [905, 1210], { r: 16, d: "S32: Yer ekibini çağırır (burun teker yuvası kornası, M527)." }),
    L("call", [825, 1260], "CALL", "b", { w: 62, h: 24 })
  ] },
{ id: "c_rwiper", pn: "P5 (S22)", name: "Sağ Silecek Kontrolü", en: "Right Wiper Control", ata: "30", rect: [775, 1281, 945, 1530], struct: true,
  desc: "F/O tarafı silecek seçicisi (S22).", comps: [["S22", "Right wiper control"]],
  texts: [["R WIPER", 860, 1395, 12]],
  items: [R("wiperR", [858, 1465], ["PARK", "INT", "LOW", "HIGH"], [0, 45, 90, 135], 0, { knob: "bar", r: 34, d: "F/O tarafı silecek." })] },
/* ----------------------- 4. SÜTUN ----------------------- */
{ id: "p5_9", pn: "P5-9", name: "Cam ve Pitot Isıtma Modülü", en: "Window and Pitot Heat Panel", ata: "30", rect: [958, 26, 1329, 414],
  desc: "Kokpit camlarının elektrikli ısıtması ile pitot tüpleri, AOA vane'leri ve TAT probunun ısıtması. Isıtılmayan prob için ışık yanar.",
  conns: [{ d: "D638", w: "W2112", at: [0.30, 0.25] }, { d: "D644", w: "W2218", at: [0.70, 0.25] }],
  texts: [["L", 1066, 103, 12], ["WINDOW HEAT", 1140, 103, 12], ["R", 1215, 103, 12], ["SIDE", 1005, 140], ["FWD", 1072, 140], ["OFF", 1040, 150, 10], ["OVHT", 1137, 137], ["PWR TEST", 1137, 200], ["FWD", 1202, 140], ["SIDE", 1267, 140], ["OFF", 1235, 150, 10],
    ["ON", 1040, 205, 10], ["ON", 1235, 205, 10], ["PROBE", 1140, 225, 12, "center", "line3"], ["A", 1102, 245], ["B", 1177, 245], ["OFF", 1140, 255, 10], ["ON", 1140, 290, 10], ["HEAT", 1140, 302, 11]],
  items: [
    L("wOv1", [1034, 53], "OVERHEAT", "a", { w: 62, h: 25 }), L("wOv2", [1097, 53], "OVERHEAT", "a", { w: 62, h: 25 }), L("wOv3", [1185, 53], "OVERHEAT", "a", { w: 62, h: 25 }), L("wOv4", [1248, 53], "OVERHEAT", "a", { w: 62, h: 25 }),
    L("wOn1", [1034, 80], "ON", "g", { w: 62, h: 25 }), L("wOn2", [1097, 80], "ON", "g", { w: 62, h: 25 }), L("wOn3", [1185, 80], "ON", "g", { w: 62, h: 25 }), L("wOn4", [1248, 80], "ON", "g", { w: 62, h: 25 }),
    T("wLS", [1007, 177], ["OFF", "ON"], 1, { lights: [{ id: "wOn1", on: [1] }], d: "Sol yan cam ısıtması." }),
    T("wLF", [1072, 177], ["OFF", "ON"], 1, { lights: [{ id: "wOn2", on: [1] }], d: "Sol ön cam ısıtması (ön camlar kuş çarpmasına dayanıklılık için de ısıtılır)." }),
    T("wTest", [1137, 167], ["OVHT", "", "PWR TEST"], 1, { spring: [0, 2], d: "OVHT: aşırı ısınma devresi testi. PWR TEST: ısıtma kontrolcülerinin testi." }),
    T("wRF", [1202, 177], ["OFF", "ON"], 1, { lights: [{ id: "wOn3", on: [1] }], d: "Sağ ön cam ısıtması." }),
    T("wRS", [1267, 177], ["OFF", "ON"], 1, { lights: [{ id: "wOn4", on: [1] }], d: "Sağ yan cam ısıtması." }),
    L("pCapt", [1022, 241], "CAPT\nPITOT", "a", { w: 54, h: 27 }), L("pLel", [1022, 268], "L ELEV\nPITOT", "a", { w: 54, h: 27 }), L("pLav", [1022, 295], "L ALPHA\nVANE", "a", { w: 54, h: 27 }), L("pTemp", [1022, 322], "TEMP\nPROBE", "a", { w: 54, h: 27 }),
    T("prbA", [1102, 270], ["OFF", "ON"], 0, { lights: [{ id: "pCapt", on: [0] }, { id: "pLel", on: [0] }, { id: "pLav", on: [0] }, { id: "pTemp", on: [0] }], d: "Kaptan pitot, sol elevator pitot, sol alpha vane ve TAT probu ısıtması." }),
    T("prbB", [1177, 270], ["OFF", "ON"], 0, { lights: [{ id: "pFo", on: [0] }, { id: "pRel", on: [0] }, { id: "pRav", on: [0] }, { id: "pAux", on: [0] }], d: "F/O pitot, sağ elevator pitot, sağ alpha vane ve yardımcı pitot ısıtması." }),
    L("pFo", [1257, 241], "F/O\nPITOT", "a", { w: 54, h: 27 }), L("pRel", [1257, 268], "R ELEV\nPITOT", "a", { w: 54, h: 27 }), L("pRav", [1257, 295], "R ALPHA\nVANE", "a", { w: 54, h: 27 }), L("pAux", [1257, 322], "AUX\nPITOT", "a", { w: 54, h: 27 })
  ] },
{ id: "p5_11", pn: "P5-11", name: "Motor ve Kanat Buz Önleme Modülü", en: "Engine and Wing Anti-Ice Panel", ata: "30", rect: [958, 414, 1329, 632],
  desc: "Kanat ve motor giriş kaportası buz önleme anahtarları ve valf ışıkları.",
  conns: [{ d: "D648", w: "W2218", at: [0.40, 0.38] }, { d: "D462", w: "W2112", at: [0.70, 0.38] }],
  texts: [["WING ANTI-ICE", 1060, 535, 11], ["OFF", 1078, 560, 10, "left"], ["ON", 1078, 595, 10, "left"], ["ENG", 1215, 527, 11], ["ANTI-ICE", 1215, 540, 11], ["OFF", 1218, 555, 10], ["1", 1183, 610], ["ON", 1218, 598, 10], ["2", 1250, 610]],
  lines: [[1140, 520, 1140, 620]],
  items: [
    L("waL", [1027, 497], "L VALVE\nOPEN", "b", { w: 62, h: 27 }), L("waR", [1090, 497], "R VALVE\nOPEN", "b", { w: 62, h: 27 }),
    L("cai1", [1183, 461], "COWL\nANTI-ICE", "a", { w: 64, h: 26 }), L("cvo1", [1183, 488], "COWL VALVE\nOPEN", "b", { w: 64, h: 26 }),
    L("cai2", [1250, 461], "COWL\nANTI-ICE", "a", { w: 64, h: 26 }), L("cvo2", [1250, 488], "COWL VALVE\nOPEN", "b", { w: 64, h: 26 }),
    T("wingAI", [1052, 575], ["OFF", "ON"], 0, { lights: [{ id: "waL", on: [1] }, { id: "waR", on: [1] }], d: "Kanat buz önleme valfleri; bleed havası LE slatlarına gider." }),
    T("engAI1", [1183, 575], ["OFF", "ON"], 0, { lights: [{ id: "cvo1", on: [1] }], d: "Motor 1 giriş dudağı buz önleme valfi." }),
    T("engAI2", [1250, 575], ["OFF", "ON"], 0, { lights: [{ id: "cvo2", on: [1] }], d: "Motor 2 giriş dudağı buz önleme valfi." })
  ] },
{ id: "p5_8", pn: "P5-8", name: "Hidrolik Pompa Modülü", en: "Hydraulic Pumps Panel", ata: "29", rect: [958, 632, 1329, 846],
  desc: "A sistemi (ENG 1, ELEC 2) ve B sistemi (ELEC 1, ENG 2) pompa anahtarları ve ışıkları.",
  conns: [{ d: "D642", w: "W2212", at: [0.25, 0.37], note: "SYS A" }, { d: "D2486", w: "W2104", at: [0.70, 0.37], note: "SYS B" }],
  texts: [["ENG 1", 1030, 732], ["ELEC 2", 1095, 732], ["ELEC 1", 1190, 732], ["ENG 2", 1252, 732], ["OFF", 1060, 748, 10], ["OFF", 1220, 748, 10], ["ON", 1060, 792, 10], ["ON", 1220, 792, 10],
    ["A", 1060, 812, 11], ["HYD PUMPS", 1140, 812, 11], ["B", 1220, 812, 11]],
  rects: [[985, 722, 1300, 820, 10]], lines: [[1140, 722, 1140, 800]],
  items: [
    LP("hlpE1", [1024, 702], { w: 62, h: 26 }), L("hovE2", [1092, 674], "OVERHEAT", "a", { w: 62, h: 26 }), LP("hlpEl2", [1092, 702], { w: 62, h: 26 }),
    L("hovE1", [1192, 674], "OVERHEAT", "a", { w: 62, h: 26 }), LP("hlpEl1", [1192, 702], { w: 62, h: 26 }), LP("hlpE2", [1256, 702], { w: 62, h: 26 }),
    T("hydE1", [1030, 770], ["OFF", "ON"], 1, { lights: [{ id: "hlpE1", on: [0] }], d: "A sistemi motor tahrikli pompa (EDP). OFF: pompa kompansatörü depressurize edilir." }),
    T("hydEl2", [1092, 762], ["OFF", "ON"], 0, { lights: [{ id: "hlpEl2", on: [0] }], d: "A sistemi elektrikli pompa (EMDP)." }),
    T("hydEl1", [1192, 762], ["OFF", "ON"], 0, { lights: [{ id: "hlpEl1", on: [0] }], d: "B sistemi elektrikli pompa (EMDP)." }),
    T("hydE2", [1252, 770], ["OFF", "ON"], 1, { lights: [{ id: "hlpE2", on: [0] }], d: "B sistemi motor tahrikli pompa (EDP)." })
  ] },
{ id: "p5_20", pn: "P5-20", name: "Kapı İkaz Paneli", en: "Door Warning Annunciator", ata: "52", rect: [958, 846, 1329, 996],
  desc: "Gövde kapı ve servis kapaklarının açık/kilitsiz olduğunu gösteren ışıklar.",
  conns: [{ d: "D1406", w: "W2216", at: [0.30, 0.42] }, { d: "D482", w: "W2508", at: [0.70, 0.42] }],
  texts: [],
  items: [
    L("dFE", [1110, 880], "FWD\nENTRY", "a", { w: 62, h: 26 }), L("dFS", [1177, 880], "FWD\nSERVICE", "a", { w: 62, h: 26 }),
    L("dLFO", [1110, 908], "LEFT FWD\nOVERWING", "a", { w: 62, h: 26 }), L("dRFO", [1177, 908], "RIGHT FWD\nOVERWING", "a", { w: 62, h: 26 }), L("dFC", [1244, 908], "FWD\nCARGO", "a", { w: 62, h: 26 }),
    L("dEq", [1022, 922], "EQUIP", "a", { w: 62, h: 26 }),
    L("dLAO", [1110, 936], "LEFT AFT\nOVERWING", "a", { w: 62, h: 26 }), L("dRAO", [1177, 936], "RIGHT AFT\nOVERWING", "a", { w: 62, h: 26 }), L("dAC", [1244, 936], "AFT\nCARGO", "a", { w: 62, h: 26 }),
    L("dAE", [1110, 964], "AFT\nENTRY", "a", { w: 62, h: 26 }), L("dAS", [1177, 964], "AFT\nSERVICE", "a", { w: 62, h: 26 })
  ] },
{ id: "p5_7", pn: "P5-7", name: "Ses Kayıt Cihazı (CVR) Kontrol Paneli", en: "Voice Recorder Panel", ata: "23", rect: [958, 996, 1329, 1142],
  desc: "CVR mikrofon monitörü: alan mikrofonu, TEST ve ERASE düğmeleri, durum ışığı ve kulaklık jakı.",
  conns: [{ d: "D179", w: "W3329", at: [0.50, 0.44], pn: "MS3126F20-41S" }],
  texts: [["COCKPIT VOICE RECORDER MICROPHONE MONITOR", 1143, 1010, 9.5], ["ERASE", 1125, 1060], ["TEST", 1179, 1060], ["STATUS", 1062, 1130], ["HEADPHONE", 1247, 1130]],
  items: [
    J("cvrMic", [1062, 1058], "mic", { d: "Kokpit alan mikrofonu." }),
    L("cvrStat", [1062, 1105], "", "g", { w: 12, h: 12, round: true, d: "STATUS ışığı: TEST sırasında sistem sağlamsa yanar." }),
    B("cvrErase", [1125, 1083], { r: 9, d: "ERASE: uçak yerdeyken ve park freni çekiliyken kaydı siler (2 sn basılı tutulur)." }),
    B("cvrTest", [1179, 1083], { r: 9, d: "TEST: CVR kanallarını test eder; STATUS ışığı yanar." }),
    J("cvrJack", [1247, 1080], "jack", { d: "Kulaklık jakı: test tonunu veya kaydı dinlemek için." })
  ] },
{ id: "p5_16", pn: "P5-16", name: "Kabin İrtifa ve Tırmanma Oranı Göstergeleri", en: "Cabin Altimeter and Rate of Climb Panel", ata: "21", rect: [958, 1142, 1329, 1530],
  desc: "Kabin irtifası / fark basıncı (çift ibreli) göstergesi, kabin tırmanma oranı göstergesi ve irtifa uyarı kornası susturma düğmesi.",
  conns: [{ d: "D786", w: "W2216", at: [0.55, 0.23], mw: "N51" }, { d: "D654", w: "W2508", at: [0.20, 0.53] }, { d: "D794", w: "W2216", at: [0.55, 0.69], mw: "N55" }],
  texts: [["ALT", 1252, 1185], ["HORN", 1252, 1198], ["CUTOUT", 1252, 1211], ["PRESS DIFF", 996, 1385, 9], ["LIMIT: TAKE-", 996, 1396, 9], ["OFF & LDG", 996, 1407, 9], [".125 PSI", 996, 1418, 9]],
  rects: [[965, 1373, 1030, 1428, 10]],
  items: [
    G("cabAlt", [1077, 1257], "cabalt", 80, { shape: "oct", d: "Dış skala kabin irtifası (x1000 ft), iç skala fark basıncı (PSI)." }),
    B("hornCut", [1252, 1250], { r: 14, d: "Kabin irtifa uyarı kornasını susturur." }),
    G("cabClimb", [1102, 1460], "climb", 58, { shape: "sq", d: "Kabin irtifa değişim hızı (x1000 ft/dk)." })
  ] },
/* ----------------------- 5. SÜTUN ----------------------- */
{ id: "p5_88", pn: "P5-88", name: "Ses Kayıt Cihazı Anahtarı", en: "Voice Recorder Switch", ata: "23", rect: [1330, 25, 1702, 122],
  desc: "CVR çalışma modu: AUTO (motor çalışınca/havada otomatik) veya ON.",
  conns: [{ d: "D11125", w: "W2112", at: [0.60, 0.55] }],
  texts: [["VOICE", 1438, 60, 12], ["RECORDER", 1438, 74, 12], ["AUTO", 1516, 40, 10], ["ON", 1516, 105, 10]],
  items: [T("vrSw", [1516, 72], ["AUTO", "ON"], 0, { d: "AUTO: CVR ilk motor start'ından durmadan 5 dk sonrasına kadar çalışır. ON: yerde de kayıt." })] },
{ id: "p5_17", pn: "P5-17", name: "Kabin Sıcaklık Modülü", en: "Cabin Temperature Panel", ata: "21", rect: [1330, 122, 1702, 511],
  desc: "Hava sıcaklık göstergesi ve ölçüm noktası seçicisi, trim hava anahtarı, bölge sıcaklık seçicileri ve ZONE TEMP ışıkları.",
  conns: [ // WDM 91-02-05: 737-700 (YB123-YB124) ve YM507 sayfası ↔ 737-800 (YC503-YC570 vb.) sayfası farklı
    { d: "D656", w: "W2216", at: [0.20, 0.19], eff: "YB123-YB124, YM507" }, { d: "D90", w: "W2114", at: [0.50, 0.43], mw: "N11", eff: "YB123-YB124, YM507" },
    { d: "D620", w: "W2218", at: [0.20, 0.61], mw: "M393", eff: "YB123-YB124, YM507" }, { d: "D618", w: "W2216", at: [0.80, 0.61], mw: "M392", eff: "YB123-YB124, YM507" },
    { d: "D90", w: "W2114", at: [0.80, 0.22], mw: "N11", eff: "YC501-YL370, YR951-YV731" }, { d: "D3996", w: "W2216", at: [0.20, 0.64], eff: "YC501-YL370, YR951-YV731" },
    { d: "D3998", w: "W2218", at: [0.80, 0.64], eff: "YC501-YL370, YR951-YV731" }],
  texts: [["AIR TEMP", 1590, 140, 12], ["PASS", 1655, 140, 11], ["CAB", 1655, 152, 11], ["S", 1530, 172], ["U", 1530, 184], ["P", 1530, 196], ["P", 1530, 208], ["L", 1530, 220], ["Y", 1530, 232],
    ["D", 1548, 172], ["U", 1548, 184], ["C", 1548, 196], ["T", 1548, 208], ["P", 1688, 225], ["A", 1688, 237], ["C", 1688, 249], ["K", 1688, 261],
    ["TRIM AIR", 1496, 276, 12], ["OFF", 1520, 292, 10, "left"], ["ON", 1520, 318, 10, "left"],
    ["CONT CAB", 1408, 395, 11], ["FWD CAB", 1515, 395, 11], ["AFT CAB", 1623, 395, 11]],
  items: [
    G("airTemp", [1423, 182], "airtemp", 55, { d: "Seçilen besleme kanalı / kabin / paket sıcaklığı (°C)." }),
    R("airSrc", [1601, 208], ["CONT CAB", "FWD", "AFT", "FWD", "AFT", "R", "L"], [-135, -90, -45, 0, 45, 90, 135], 0, { knob: "bar", r: 34, labelR: 52, d: "AIR TEMP ölçüm noktası: kokpit (CONT CAB), besleme kanalları (SUPPLY DUCT FWD/AFT), kabin (PASS CAB FWD/AFT) veya paketler (PACK R/L)." }),
    T("trimAir", [1496, 305], ["OFF", "ON"], 1, { d: "Trim hava basınç düzenleme ve kesme valfi." }),
    L("zt1", [1408, 372], "ZONE\nTEMP", "a", { w: 60, h: 28 }), L("zt2", [1515, 372], "ZONE\nTEMP", "a", { w: 60, h: 28 }), L("zt3", [1623, 372], "ZONE\nTEMP", "a", { w: 60, h: 28 }),
    R("tCont", [1408, 450], ["OFF", "C", "AUTO", "W"], [-150, -100, 0, 100], 2, { knob: "bar", r: 34, arc: true, d: "Kokpit sıcaklık seçici: OFF, AUTO aralığı (C serin – W sıcak)." }),
    R("tFwd", [1515, 450], ["OFF", "C", "AUTO", "W"], [-150, -100, 0, 100], 2, { knob: "bar", r: 34, arc: true, d: "Ön kabin sıcaklık seçici." }),
    R("tAft", [1623, 450], ["OFF", "C", "AUTO", "W"], [-150, -100, 0, 100], 2, { knob: "bar", r: 34, arc: true, d: "Arka kabin sıcaklık seçici." })
  ] },
{ id: "p5_10", pn: "P5-10", name: "Klima / Bleed Hava Modülü", en: "Air Conditioning Panel", ata: "21/36", rect: [1330, 511, 1702, 1093],
  desc: "Resirkülasyon fanları, kanal basınç göstergesi, paketler, izolasyon valfi, motor ve APU bleed anahtarları, ilgili ışıklar ve basınçlandırma arıza ışıkları.",
  conns: [{ d: "D680", w: "W2218", at: [0.20, 0.18] }, { d: "D646", w: "W2216", at: [0.80, 0.18] }, { d: "D96", w: "W2218", at: [0.50, 0.41], mw: "N12" }],
  texts: [["L RECIRC FAN", 1405, 578, 11], ["OFF", 1430, 598, 10, "left"], ["AUTO", 1393, 632, 10], ["R RECIRC FAN", 1610, 578, 11], ["OFF", 1590, 598, 10, "right"], ["AUTO", 1600, 632, 10],
    ["OVHT", 1628, 677, 10], ["TEST", 1628, 722, 10], ["L PACK", 1400, 752, 11], ["OFF", 1418, 768, 10, "left"], ["AUTO", 1418, 780, 10, "left"], ["HIGH", 1418, 792, 10, "left"],
    ["ISOLATION", 1515, 770, 11], ["VALVE", 1515, 782, 11], ["CLOSE", 1515, 795, 10], ["AUTO", 1545, 828, 10, "left"], ["OPEN", 1515, 860, 10],
    ["R PACK", 1630, 752, 11], ["OFF", 1612, 768, 10, "right"], ["AUTO", 1612, 780, 10, "right"], ["HIGH", 1612, 792, 10, "right"],
    ["WING", 1362, 832, 8], ["ANTI", 1362, 842, 8], ["ICE", 1362, 852, 8], ["WING", 1675, 832, 8], ["ANTI", 1675, 842, 8], ["ICE", 1675, 852, 8],
    ["TRIP", 1518, 878, 10], ["RESET", 1518, 915, 10], ["OFF", 1425, 960, 10, "left"], ["ON", 1425, 990, 10, "left"], ["OFF", 1610, 960, 10, "right"], ["ON", 1610, 990, 10, "right"],
    ["1", 1398, 1010], ["APU", 1488, 1010], ["2", 1628, 1010], ["BLEED", 1518, 1033, 11, "center", "line4"]],
  rects: [[1343, 640, 1690, 1040, 18], [1396, 845, 1640, 1020, 8], [1347, 825, 1378, 860, 0], [1660, 825, 1691, 860, 0]],
  items: [
    L("dualBleed", [1413, 541], "DUAL\nBLEED", "a", { w: 62, h: 26 }), L("ram1", [1476, 541], "RAM DOOR\nFULL OPEN", "b", { w: 62, h: 26 }), L("ram2", [1625, 541], "RAM DOOR\nFULL OPEN", "b", { w: 62, h: 26 }),
    T("recL", [1413, 612], ["OFF", "AUTO"], 1, { d: "Sol resirkülasyon fanı." }),
    T("recR", [1613, 612], ["OFF", "AUTO"], 1, { d: "Sağ resirkülasyon fanı." }),
    G("duct", [1513, 690], "duct", 58, { shape: "tear", d: "Sol ve sağ pnömatik kanal basıncı (PSI). İki ibre: L ve R." }),
    B("ovhtTest", [1628, 700], { r: 14, d: "Kanat-gövde aşırı ısınma algılama devrelerini test eder." }),
    T("packL", [1398, 778], ["OFF", "AUTO", "HIGH"], 1, { d: "Sol klima paketi. AUTO normal, HIGH yüksek akış." }),
    T("isoVlv", [1515, 828], ["CLOSE", "AUTO", "OPEN"], 1, { d: "İzolasyon valfi: sol ve sağ manifoldu ayırır/birleştirir. AUTO: bir bleed veya paket kapalıysa açılır." }),
    T("packR", [1633, 778], ["OFF", "AUTO", "HIGH"], 1, { d: "Sağ klima paketi." }),
    L("packLt1", [1443, 863], "PACK", "a", { w: 64, h: 26 }), L("wbo1", [1443, 890], "WING-BODY\nOVERHEAT", "a", { w: 64, h: 26 }), L("bto1", [1443, 917], "BLEED\nTRIP OFF", "a", { w: 64, h: 26 }),
    B("tripReset", [1518, 896], { r: 15, d: "BLEED TRIP OFF, PACK ve ZONE TEMP ışıklarını (arıza giderildiyse) sıfırlar." }),
    L("packLt2", [1598, 863], "PACK", "a", { w: 64, h: 26 }), L("wbo2", [1598, 890], "WING-BODY\nOVERHEAT", "a", { w: 64, h: 26 }), L("bto2", [1598, 917], "BLEED\nTRIP OFF", "a", { w: 64, h: 26 }),
    T("bl1", [1398, 975], ["OFF", "ON"], 1, { d: "Motor 1 bleed valfi (PRSOV)." }),
    T("apuBl", [1488, 975], ["OFF", "ON"], 0, { lights: [{ id: "dualBleed", on: [1] }], d: "APU bleed valfi. Motor bleed'leri ile birlikte açıksa DUAL BLEED yanar (basit mantık)." }),
    T("bl2", [1628, 975], ["OFF", "ON"], 1, { d: "Motor 2 bleed valfi (PRSOV)." }),
    L("autoFail", [1421, 1066], "AUTO\nFAIL", "a", { w: 58, h: 26 }), L("offSched", [1479, 1066], "OFF SCHED\nDESCENT", "a", { w: 58, h: 26 }),
    L("altnLt", [1540, 1066], "ALTN", "g", { w: 58, h: 26 }), L("manLt", [1633, 1066], "MANUAL", "g", { w: 58, h: 26 })
  ] },
{ id: "p5_6", pn: "P5-6", name: "Kabin Basınç Seçici Modülü", en: "Cabin Pressure Selector Panel", ata: "21", rect: [1330, 1093, 1702, 1530],
  desc: "Otomatik mod için FLT ALT ve LAND ALT seçicileri; manuel outflow valf anahtarı ve göstergesi; mod seçici (AUTO/ALTN/MAN). Altta kabin irtifa çizelgesi.",
  conns: [{ d: "D10724", w: "W2112", at: [0.5, 0.26] }, { d: "D10726", w: "W2218", at: [0.5, 0.66] }],
  texts: [["AUTO", 1440, 1108, 11], ["FLT ALT", 1453, 1197, 11], ["LAND ALT", 1453, 1327, 11], ["MANUAL", 1608, 1105, 11], ["V", 1650, 1120], ["A", 1650, 1133], ["L", 1650, 1146], ["V", 1650, 1159], ["E", 1650, 1172],
    ["C", 1570, 1215], ["L", 1570, 1227], ["O", 1570, 1239], ["S", 1570, 1251], ["E", 1570, 1263], ["O", 1645, 1220], ["P", 1645, 1232], ["E", 1645, 1244], ["N", 1645, 1256],
    ["CAB ALT", 1368, 1497, 8], ["LAND ALT", 1415, 1497, 8], ["2000", 1475, 1497, 8], ["4000", 1530, 1497, 8], ["6000", 1585, 1497, 8], ["8000", 1640, 1497, 8],
    ["FLT ALT", 1368, 1515, 8], ["<FL160", 1440, 1515, 8], ["FL220", 1500, 1515, 8], ["FL280", 1555, 1515, 8], ["FL320", 1610, 1515, 8], ["FL410", 1665, 1515, 8]],
  rects: [[1345, 1487, 1690, 1525, 0]], lines: [[1550, 1100, 1550, 1475], [1550, 1285, 1700, 1285], [1345, 1506, 1690, 1506]],
  items: [
    D("fltAlt", [1453, 1162], "fltalt", 120, 40, { d: "Planlanan seyir irtifası." }), R("fltAltK", [1453, 1240], [""], [0], 0, { knob: "grip", r: 24, d: "FLT ALT seçici düğme." }),
    D("landAlt", [1453, 1292], "landalt", 120, 40, { d: "Varış havaalanı rakımı." }), R("landAltK", [1453, 1370], [""], [0], 0, { knob: "grip", r: 24, d: "LAND ALT seçici düğme." }),
    G("outflow", [1590, 1150], "outflow", 40, { shape: "half", d: "Outflow valf konumu (CLOSE–OPEN)." }),
    T("ofv", [1608, 1238], ["CLOSE", "", "OPEN"], 1, { horiz: true, spring: [0, 2], d: "MAN modunda outflow valfini kapatır/açar. Yaylı." }),
    R("pressMode", [1593, 1370], ["AUTO", "ALTN", "MAN"], [-40, 0, 40], 0, { knob: "bar", r: 34, lights: [{ id: "altnLt", on: [1] }, { id: "manLt", on: [2] }], d: "AUTO: otomatik kontrolcü. ALTN: yedek kontrolcü. MAN: outflow valfi elle." })
  ] }
];

// Ön kenar (cama yakın) ışık / start sırası – P5 yapısına bağlı tekil anahtarlar
export const BOTTOM = {
  id: "c_bottom", pn: "P5 (alt sıra)", name: "Dış Aydınlatma, APU ve Motor Start Sırası", en: "Exterior Lights / APU / Engine Start", ata: "33/49/80", struct: true,
  rect: [18, 1530, 1702, 1720],
  shape: [[0, 0], [26.03, 0], [26.03, 1.65], [20.4, 2.85], [5.6, 2.85], [0, 1.65]], // inç, sol üstten
  desc: "Panelin ön (cama yakın) kenarı. Modül değil, tekil anahtarlar doğrudan kablolanır. İki uçta paneli kapalı tutan INDEX TO LOCK kilitleri vardır.",
  comps: [["S260/S261", "Landing lights outboard (retractable) L/R"], ["S258/S259", "Landing lights inboard (fixed) L/R"], ["S268/S269", "Runway turnoff L/R"], ["S61", "Nose gear taxi light"],
    ["S248", "APU anahtarı"], ["S266/S267", "Engine 1/2 start"], ["S858", "Ignition select"], ["S635", "Logo"], ["S58", "Position/strobe"], ["S57", "Anti-collision"], ["S98", "Wing scanning"], ["S62", "Wheel well"], ["L383", "P5 external engine start lights"]],
  texts: [["LANDING", 300, 1545, 12], ["RETRACT", 237, 1557, 10], ["OFF", 380, 1557, 10], ["E", 150, 1550], ["X", 150, 1562], ["T", 150, 1574], ["E", 150, 1586], ["N", 150, 1598], ["D", 150, 1610],
    ["L", 205, 1608], ["ON", 237, 1608, 10], ["R", 268, 1608], ["L", 348, 1608], ["ON", 380, 1608, 10], ["R", 410, 1608], ["RETRACTABLE", 237, 1620, 11], ["FIXED", 380, 1620, 11],
    ["RUNWAY", 511, 1543, 11], ["TURNOFF", 511, 1555, 11], ["L", 480, 1567], ["R", 543, 1567], ["OFF", 511, 1585, 10], ["ON", 511, 1610, 10],
    ["TAXI", 608, 1543, 11], ["OFF", 608, 1560, 10], ["AUTO", 608, 1610, 10], ["APU", 666, 1543, 11], ["OFF", 662, 1580, 10], ["ON", 690, 1608, 10, "left"], ["START", 666, 1655, 10],
    ["ENGINE START", 968, 1543, 12], ["BOTH", 933, 1578, 10], ["IGN", 905, 1600, 10], ["L", 905, 1612, 10], ["IGN", 962, 1600, 10], ["R", 962, 1612, 10], ["1", 793, 1700], ["2", 1088, 1700],
    ["LOGO", 1256, 1545, 11], ["OFF", 1256, 1560, 10], ["ON", 1256, 1625, 10], ["POSITION", 1336, 1545, 11], ["STROBE &", 1336, 1557, 10], ["STEADY", 1336, 1569, 10], ["OFF", 1362, 1600, 10, "left"], ["STEADY", 1336, 1625, 10],
    ["ANTI", 1421, 1545, 11], ["COLLISION", 1421, 1557, 11], ["OFF", 1421, 1569, 10], ["ON", 1421, 1625, 10], ["WING", 1481, 1545, 11], ["OFF", 1481, 1569, 10], ["ON", 1481, 1625, 10],
    ["WHEEL", 1546, 1545, 11], ["WELL", 1546, 1557, 11], ["OFF", 1546, 1569, 10], ["ON", 1546, 1625, 10]],
  lines: [[118, 1535, 118, 1650], [720, 1535, 720, 1700], [1218, 1535, 1218, 1700], [1610, 1535, 1610, 1650], [180, 1572, 440, 1572], [310, 1572, 310, 1600]],
  items: [
    J("lockL", [65, 1582], "lock", { d: "INDEX TO LOCK: forward overhead panelin ön kenarını kilitler. Açılınca panel arka kenarındaki menteşe hattı etrafında aşağı döner ve arka tarafa erişim sağlar." }),
    T("llRL", [205, 1580], ["RETRACT", "EXTEND", "ON"], 0, { style: "paddle", d: "S260: sol geri çekilebilir (outboard) iniş ışığı: RETRACT / EXTEND / ON." }),
    T("llRR", [268, 1580], ["RETRACT", "EXTEND", "ON"], 0, { style: "paddle", d: "S261: sağ geri çekilebilir iniş ışığı." }),
    T("llFL", [348, 1580], ["OFF", "ON"], 0, { style: "paddle", d: "S258: sol sabit (inboard) iniş ışığı." }),
    T("llFR", [410, 1580], ["OFF", "ON"], 0, { style: "paddle", d: "S259: sağ sabit iniş ışığı." }),
    T("rtL", [480, 1590], ["OFF", "ON"], 0, { d: "S268: sol pist dönüş ışığı." }),
    T("rtR", [543, 1590], ["OFF", "ON"], 0, { d: "S269: sağ pist dönüş ışığı." }),
    T("taxi", [608, 1585], ["OFF", "AUTO"], 0, { d: "S61: burun takımı taksi ışığı." }),
    T("apuSw", [666, 1610], ["OFF", "ON", "START"], 0, { style: "slot", spring: [2], d: "S248: APU anahtarı. START'a alınıp bırakılır, ON'a döner. OFF: APU soğuma süresinden sonra durur." }),
    R("eng1St", [793, 1630], ["GRD", "AUTO", "CONT", "FLT"], [-50, 0, 35, 65], 1, { knob: "bar", r: 40, d: "S266: Motor 1 start. GRD: start valfi açılır ve ateşleme verilir; start sonrası otomatik geri döner. AUTO: gerekli durumlarda otomatik ateşleme. CONT: sürekli ateşleme. FLT: uçuşta yeniden start." }),
    T("ign", [933, 1600], ["IGN L", "BOTH", "IGN R"], 1, { horiz: true, d: "S858: start ve sürekli ateşlemede kullanılacak ateşleyiciyi seçer." }),
    R("eng2St", [1088, 1630], ["GRD", "AUTO", "CONT", "FLT"], [-50, 0, 35, 65], 1, { knob: "bar", r: 40, d: "S267: Motor 2 start." }),
    T("logo", [1256, 1593], ["OFF", "ON"], 0, { d: "S635: dikey stabilize logo ışıkları." }),
    T("posLt", [1336, 1593], ["STROBE & STEADY", "OFF", "STEADY"], 1, { d: "S58: seyir (konum) ve strob ışıkları." }),
    T("antiCol", [1421, 1595], ["OFF", "ON"], 0, { d: "S57: kırmızı çarpışma önleme (beacon) ışıkları." }),
    T("wingLt", [1481, 1595], ["OFF", "ON"], 0, { d: "S98: kanat hücum kenarı aydınlatması (buz kontrolü)." }),
    T("wwLt", [1546, 1595], ["OFF", "ON"], 0, { d: "S62: teker yuvası ışıkları." }),
    J("lockR", [1666, 1572], "lock", { d: "INDEX TO LOCK kilidi (sağ)." })
  ]
};

// WDM 91-02-05 – panel arka kenarı (menteşe tarafı) üzerindeki bloklar. x: ön görünüşte soldan inç.
export const TOP_PARTS = [
  { id: "TB507", kind: "tb", x: 2.7, name: "Terminal blok TB507", d: "Kablo uçlarının vidalı terminallere bağlandığı blok. Ortak beslemeler buradan dağıtılır." },
  { id: "TB508", kind: "tb", x: 23.3, name: "Terminal blok TB508", d: "Kablo uçlarının vidalı terminallere bağlandığı blok." },
  { id: "GD515", kind: "gd", x: 1.6 }, { id: "GD517", kind: "gd", x: 2.7 }, { id: "GD519", kind: "gd", x: 3.8 },
  { id: "GD503", kind: "gd", x: 7.6 }, { id: "GD506", kind: "gd", x: 18.6 }, { id: "GD520", kind: "gd", x: 17.5 },
  { id: "GD516", kind: "gd", x: 24.4 }, { id: "GD518", kind: "gd", x: 23.3 }
];

// WDM Master Bundle List (91-21-13) – demet açıklamaları
export const BUNDLES = {
  W2104: "LA1 – P5 OVHD PANEL TO EE BAY (E2-2)",
  W2112: "LA2 – P5 OVHD PANEL TO EE BAY (E2-1/E2-2/E3-1)",
  W2114: "LB2 – P5 OVHD TO AB0340A/AB0340B AND AE0101A DISC BRACKET",
  W2212: "RA1 – P5 OVHD PANEL",
  W2216: "RA2 – P5 OVHD PANEL TO EE BAY (E4-1)",
  W2218: "RB2 – P5 OVHD PANEL TO EE BAY (E3-1/E4-1/E4-2)",
  W2508: "SA2 – P5 OVHD PANEL TO EE BAY (E1-4/E4-1)",
  W2510: "SB2 – P5 OVHD PANEL TO EE BAY (E1-4/E4-1)",
  W2035: "NA2 – P5, E5-2",
  W2135: "RB2 – P5, E5-2",
  W2702: "AN2 – P5 OVHD PANEL TO EE BAY (E2-1)",
  W3329: "NN2 – VOICE RECORDER CONTROL PNL"
};

// WDM Equipment List (D280A117) – konnektör parça numaraları ve diyagram referansları
export const CONN_PN = {
  D624: ["BACC45FT22-55S6", "27-23-14"], D630: ["BACC45FT22-55S", "27-23-14"], D553: ["BACC45FT22-55S6", "34-51-41"], D1817: ["BACC45FT22-55S8", "34-51-41"],
  D616: ["BACC45FT14-7S", "28-42-11"], D626: ["BACC45FT20-41S", "28-43-11"], D628: ["BACC45FT20-41S6", "28-21-11"],
  D652: ["BACC45FT22-55S8", "24-28-11"], D10596: ["BACC45FT22-55S9", "24-31-11"], D636: ["BACC45FT18-31S9", "24-11-21"], D1086: ["BACC45FT20-41S6", "24-11-11"],
  D730: ["BACC45FT16-24S7", "24-11-11"], D722: ["BACC45FT16-24S9", "24-11-11"], D634: ["BACC45FT18-31S8", "24-22-21"], D11988: ["BACC45FT14-7S", "30-42-11"], D446: ["BACC45FT14-4S", "49-71-21"],
  D638: ["BACC45FT24-61S", "30-31-12"], D644: ["BACC45FT24-61S6", "30-41-12"], D648: ["BACC45FT18-31S8", "30-21-11"], D462: ["BACC45FT18-31S7", "30-21-11"],
  D642: ["BACC45FT16-24S", "29-11-11"], D2486: ["BACC45FT16-24S6", "29-11-11"], D1406: ["BACC45FT12-12S7", "52-71-11"], D482: ["BACC45FT12-12S6", "52-71-12"],
  D179: ["MS3126F20-41S", "23-71-01"], D786: ["BACC45FT10-5S", "33-12-11"], D654: ["BACC45FT12-12S", "21-33-11"], D794: ["BACC45FT8-2S", "33-12-11"],
  D11125: ["BACC45FT12-12S", "23-71-01"], D656: ["BACC45FT16-24S6", "21-51-21"], D90: ["BACC45FT14-7S", "21-61-51"], D620: ["BACC45FT12-12S6", "21-51-11"], D618: ["BACC45FT12-12S6", "21-61-11"],
  D680: ["BACC45FT22-55S6", "21-31-11"], D646: ["BACC45FT22-55S7", "21-31-11"], D96: ["BACC45FT12-12S8", "36-21-11"],
  D3996: ["BACC45FT16-24S6", "21-61-11"], D3998: ["BACC45FT16-24S", "21-61-13"], D10724: ["BACC45FT18-31S", "21-31-11"], D10726: ["BACC45FT18-31S6", "21-31-11"], D3072: ["BACS16X1A", "33-25-11"]
};
