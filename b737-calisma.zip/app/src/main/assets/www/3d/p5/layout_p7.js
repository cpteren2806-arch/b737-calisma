// 737NG glareshield (P7) – AMM 31-11-41 Fig.101 Sheet 2 (MCP ve EFIS kontrol panelleri), WDM 91-02-07 (P7 modülleri ve konnektörler).
// Şekildeki üç parça farklı ölçekte çizildiği için her biri kendi piksel ölçeğinden ortak birime (100 px = 1 inç) çevrilir.
// Gerçek boyutlar yaklaşık: EFIS kontrol paneli 5,75 inç (standart Dzus genişliği), MCP ≈ 18 inç.
const U = 100;                    // ortak ölçek: px/inç
const pieceL = { s: 690 / 5.75, ox: 0, oy: 0.12 };          // sol parça (efisL kesiti 1292x475)
const pieceM = { s: 2440 / 18.0, ox: 11.0, oy: 0 };          // MCP (mcp kesiti 2550x458)
const pieceR = { s: 615 / 5.75, ox: 11.0 + 18.6, oy: 0.12 }; // sağ parça (efisR kesiti 1308x475)
const P = (pc, x, y) => [Math.round((pc.ox + x / pc.s) * U * 10) / 10, Math.round((pc.oy + y / pc.s) * U * 10) / 10];
const S = (pc, v) => Math.round(v / pc.s * U * 10) / 10;
const rect = (pc, a, b, c, d) => [...P(pc, a, b), ...P(pc, c, d)];

const T = (id, at, pos, st, o = {}) => ({ t: "T", id, at, pos, st, ...o });
const R = (id, at, pos, ang, st, o = {}) => ({ t: "R", id, at, pos, ang, st, ...o });
const L = (id, at, txt, c = "a", o = {}) => ({ t: "L", id, at, txt, c, ...o });
const B = (id, at, o = {}) => ({ t: "B", id, at, ...o });
const D = (id, at, kind, w, h, o = {}) => ({ t: "D", id, at, kind, w, h, ...o });
const K = (id, at, txt, w, h, o = {}) => ({ t: "L", id, at, txt, c: "w", key: true, w, h, ...o });

// ---------- MCP (M198) ----------
const m = pieceM, mp = (x, y) => P(m, x, y), ms = v => S(m, v);
const mbtn = (id, x, y, txt, d) => L(id, mp(x, y), txt, "w", { w: ms(78), h: ms(78), press: true, latch: true, d });
const MCP = {
  id: "m198", pn: "M198", name: "Mode Control Panel (MCP)", en: "A/P Control Panel", ata: "22", dg: ["22-11-11", "22-11-51"], rect: rect(m, 40, 58, 2480, 440),
  desc: "Otopilot (A/P), uçuş direktörü (F/D) ve otomatik gaz (A/T) mod seçimi; hız, yön, irtifa, dikey hız ve kurs değerleri. Seçimler iki DFCS uçuş kontrol bilgisayarına (FCC A/B, E1 rafı) gider; aktif modlar PFD'deki mod göstergesinde (FMA) görünür.",
  conns: [{ d: "D299", w: "W2363", at: [0.16, 0.45] }, { d: "D301", w: "W2363", at: [0.50, 0.45] }, { d: "D1815", w: "W2465", at: [0.83, 0.45] }],
  texts: [["COURSE", ...mp(232, 102), 11], ["A/T", ...mp(490, 98), 11], ["ARM", ...mp(490, 120), 10], ["OFF", ...mp(490, 262), 10], ["IAS/MACH", ...mp(700, 102), 11], ["C/O", ...mp(600, 186), 10],
    ["SPD", ...mp(910, 266), 10], ["INTV", ...mp(912, 285), 10], ["HEADING", ...mp(1045, 102), 11], ["10", ...mp(945, 192), 9], ["30", ...mp(1140, 192), 9], ["F/D", ...mp(338, 310), 10], ["ON", ...mp(338, 328), 10], ["OFF", ...mp(338, 428), 10],
    ["ALTITUDE", ...mp(1392, 102), 11], ["ALT", ...mp(1600, 260), 10], ["INTV", ...mp(1600, 280), 10], ["VERT SPEED", ...mp(1636, 102), 11], ["DN", ...mp(1730, 218), 9], ["UP", ...mp(1730, 408), 9],
    ["A/P ENGAGE", ...mp(1933, 73), 11], ["A", ...mp(1826, 88), 10], ["B", ...mp(2036, 88), 10], ["DISENGAGE", ...mp(1933, 328), 10], ["COURSE", ...mp(2215, 102), 11], ["F/D", ...mp(2130, 310), 10], ["ON", ...mp(2130, 328), 10], ["OFF", ...mp(2130, 428), 10]],
  items: [
    D("crsL", mp(250, 146), "mcp:crs1", ms(170), ms(56)), R("crsLK", mp(222, 262), [""], [0], 0, { knob: "grip", r: ms(52), val: "crs1", step: 1, wrap: 360, d: "Kaptan COURSE: VOR/ILS kursunu ayarlar (kaptan ND/PFD). Sağ yarıya dokun: artır, sol yarıya: azalt." }),
    L("maL", mp(338, 258), "MA", "w", { w: ms(38), h: ms(38), round: true, d: "MA (Master) ışığı: o taraftaki F/D'nin ana (master) FCC olduğunu gösterir." }),
    T("fdL", mp(338, 380), ["ON", "OFF"], 1, { d: "Kaptan uçuş direktörü (F/D): ON iken PFD'de komut çubukları görünür." }),
    T("atArm", mp(490, 200), ["ARM", "OFF"], 1, { d: "A/T ARM: otomatik gazı devreye almaya hazırlar (solenoidle tutulur; A/T kesilince OFF'a düşer)." }),
    D("ias", mp(700, 148), "mcp:ias", ms(210), ms(56)), B("co", mp(597, 245), { r: ms(36), d: "C/O (changeover): IAS ↔ MACH göstergesini değiştirir." }),
    R("iasK", mp(716, 307), [""], [0], 0, { knob: "grip", r: ms(52), val: "ias", step: 1, d: "Hız seçici: hedef IAS/MACH." }),
    B("spdIntv", mp(835, 245), { r: ms(42), d: "SPD INTV: VNAV'da FMC hızına müdahale (speed intervene)." }),
    mbtn("n1", 420, 375, "N1", "N1 modu: A/T, FMC'nin hesapladığı N1 sınırına göre gaz verir."), mbtn("speed", 552, 375, "SPEED", "SPEED modu: A/T, MCP'de seçili hızı tutar."),
    mbtn("vnav", 885, 143, "VNAV", "VNAV: dikey profil FMC'den."), mbtn("lvlChg", 885, 375, "LVL CHG", "LVL CHG: seçili irtifaya hızı koruyarak tırmanma/alçalma."),
    D("hdg", mp(1045, 148), "mcp:hdg", ms(170), ms(56)), R("hdgK", mp(1043, 240), [""], [0], 0, { knob: "grip", r: ms(38), val: "hdg", step: 1, wrap: 360, d: "Yön seçici (HDG)." }),
    R("bank", mp(1043, 240), ["10", "15", "20", "25", "30"], [-60, -30, 0, 30, 60], 3, { knob: "ring", r: ms(66), noLabels: true, d: "Bank açısı sınırı (HDG SEL/VOR'da): 10–30°." }),
    mbtn("hdgSel", 1043, 375, "HDG SEL", "HDG SEL: seçili yöne dön."), mbtn("lnav", 1205, 143, "LNAV", "LNAV: yanal rota FMC'den."),
    mbtn("vorLoc", 1205, 255, "VOR LOC", "VOR/LOC: seçili VOR radyalini veya localizer'ı takip."), mbtn("app", 1205, 375, "APP", "APP: localizer ve glideslope (ILS yaklaşma)."),
    D("alt", mp(1390, 148), "mcp:alt", ms(205), ms(56)), R("altK", mp(1390, 237), [""], [0], 0, { knob: "grip", r: ms(52), val: "alt", step: 100, min: 0, max: 50000, d: "İrtifa seçici (100 ft adım)." }),
    B("altIntv", mp(1518, 237), { r: ms(42), d: "ALT INTV: VNAV'da irtifa kısıtını siler / yeni irtifaya geçer." }),
    mbtn("altHld", 1390, 375, "ALT HLD", "ALT HLD: mevcut irtifayı tut."), mbtn("vs", 1518, 375, "V/S", "V/S: seçili dikey hızla tırmanma/alçalma."),
    D("vsD", mp(1635, 148), "mcp:vs", ms(190), ms(56)), R("vsK", mp(1672, 320), [""], [0], 0, { knob: "grip", r: ms(40), val: "vs", step: 100, min: -7900, max: 6000, d: "V/S tekerleği: üst yarı DN (alçalma), alt yarı UP (tırmanma)." }),
    mbtn("cmdA", 1850, 143, "CMD", "A/P A – CMD: otopilot A (FCC A) devrede."), mbtn("cmdB", 2016, 143, "CMD", "A/P B – CMD: otopilot B (FCC B) devrede."),
    mbtn("cwsA", 1850, 265, "CWS", "CWS A: kumanda tekerleği kuvvetiyle yönlendirme (control wheel steering)."), mbtn("cwsB", 2016, 265, "CWS", "CWS B."),
    T("apDisc", mp(1933, 380), ["", "DISENGAGE"], 0, { style: "paddle", horiz: false, d: "A/P DISENGAGE çubuğu: aşağı çekilince iki otopilot da kesilir." }),
    D("crsR", mp(2215, 146), "mcp:crs2", ms(170), ms(56)), R("crsRK", mp(2242, 262), [""], [0], 0, { knob: "grip", r: ms(52), val: "crs2", step: 1, wrap: 360, d: "F/O COURSE." }),
    L("maR", mp(2135, 258), "MA", "w", { w: ms(38), h: ms(38), round: true }),
    T("fdR", mp(2130, 380), ["ON", "OFF"], 1, { d: "F/O uçuş direktörü." })
  ]
};

// ---------- EFIS kontrol paneli ve six-pack ----------
function efis(side, pc, X) {
  const p = (x, y) => P(pc, x, y), s = v => S(pc, v), id = k => k + side;
  const kx = side === "L" ? [628, 712, 795, 878, 962, 1045, 1128] : [105, 185, 270, 352, 435, 518, 603];
  const keys = ["WXR", "STA", "WPT", "ARPT", "DATA", "POS", "TERR"];
  return {
    id: "p7_" + (side === "L" ? "1" : "2"), pn: side === "L" ? "P7-1" : "P7-2", name: (side === "L" ? "Kaptan" : "F/O") + " EFIS kontrol paneli", en: "EFIS Control Panel", ata: "31/34", dg: [side === "L" ? "31-62-11" : "31-62-21"],
    rect: rect(pc, X.r[0], X.r[1], X.r[2], X.r[3]),
    desc: "ND mod/menzil seçimi, minimum (RADIO/BARO) ve baro ayarı, harita katmanları (WXR, STA, WPT, ARPT, DATA, POS, TERR), VOR/ADF iğneleri. Komutlar DEU'lara (E3 rafı) gider.",
    conns: [{ d: side === "L" ? "D3993" : "D3995", w: side === "L" ? "W0001" : "W0003", at: [side === "L" ? 0.47 : 0.61, 0.30] }],
    texts: [["MINS", ...p(X.mins[0], X.mins[1] - 92), 10], ["RADIO", ...p(X.mins[0] - 62, X.mins[1] - 60), 9], ["BARO", ...p(X.mins[0] + 62, X.mins[1] - 60), 9],
      ["FPV", ...p(X.fpv, 75), 10], ["MTRS", ...p(X.mtrs, 75), 10], ["BARO", ...p(X.baro[0], X.baro[1] - 92), 10], ["IN", ...p(X.baro[0] - 55, X.baro[1] - 60), 9], ["HPA", ...p(X.baro[0] + 55, X.baro[1] - 60), 9],
      ["VOR 1", ...p(X.v1, 210), 9], ["ADF 1", ...p(X.v1, 305), 9], ["VOR 2", ...p(X.v2, 210), 9], ["ADF 2", ...p(X.v2, 305), 9]],
    items: [
      R(id("mins"), p(X.mins[0], X.mins[1]), ["RADIO", "BARO"], [-40, 40], 1, { knob: "round", r: s(70), noLabels: true, d: "MINS: minimum referansı RADIO (radyo altimetre) veya BARO; dış halka çevrilerek değer ayarlanır." }),
      B(id("rst"), p(X.mins[0], X.mins[1]), { r: s(28), d: "RST: minimum ikazını sıfırlar." }),
      B(id("fpv"), p(X.fpv, 118), { r: s(28), d: "FPV: PFD'de uçuş yolu vektörünü gösterir." }), B(id("mtrs"), p(X.mtrs, 118), { r: s(28), d: "MTRS: irtifayı metre olarak da gösterir." }),
      R(id("baro"), p(X.baro[0], X.baro[1]), ["IN", "HPA"], [-40, 40], 1, { knob: "round", r: s(70), noLabels: true, d: "BARO: altimetre ayarı birimi (inHg / hPa); dış halka ile değer." }),
      B(id("std"), p(X.baro[0], X.baro[1]), { r: s(28), d: "STD: standart basınç (29.92 inHg / 1013 hPa)." }),
      T(id("vor1"), p(X.v1, 258), ["VOR", "OFF", "ADF"], 1, { d: "ND'deki 1 numaralı iğne: VOR 1 veya ADF 1." }),
      R(id("mode"), p(X.ctr[0], X.ctr[1]), ["APP", "VOR", "MAP", "PLN"], [-60, -30, 10, 40], 2, { knob: "bar", r: s(46), d: "ND modu: APP, VOR, MAP, PLN. Ortadaki CTR düğmesi merkezli/genişletilmiş görünüm." }),
      B(id("ctr"), p(X.ctr[0], X.ctr[1]), { r: s(20), d: "CTR: ND'yi merkezli görünüme alır." }),
      R(id("rng"), p(X.tfc[0], X.tfc[1]), ["5", "10", "20", "40", "80", "160", "320", "640"], [-90, -60, -30, 0, 30, 60, 90, 120], 3, { knob: "bar", r: s(46), d: "ND menzili (NM). Ortadaki TFC: TCAS trafiğini gösterir." }),
      B(id("tfc"), p(X.tfc[0], X.tfc[1]), { r: s(20), d: "TFC: TCAS trafiği." }),
      T(id("vor2"), p(X.v2, 258), ["VOR", "OFF", "ADF"], 1, { d: "ND'deki 2 numaralı iğne: VOR 2 veya ADF 2." }),
      ...keys.map((k, i) => K(id("k" + k), p(kx[i], 350), k, s(52), s(46), { d: k + ": ND'de ilgili harita katmanını açar/kapatır." }))
    ]
  };
}
const EFIS_L = efis("L", pieceL, { r: [570, 57, 1188, 390], mins: [680, 148], fpv: 832, mtrs: 925, baro: [1060, 148], v1: 640, ctr: [773, 262], tfc: [950, 262], v2: 1120 });
const EFIS_R = efis("R", pieceR, { r: [45, 57, 660, 390], mins: [155, 150], fpv: 305, mtrs: 398, baro: [540, 150], v1: 115, ctr: [262, 262], tfc: [437, 262], v2: 590 });

function sixpack(side, pc, xs) {
  const p = (x, y) => P(pc, x, y), s = v => S(pc, v), id = k => k + side;
  const L6 = side === "L" ? [["FLT CONT", "flt"], ["IRS", "irs"], ["FUEL", "fuel"], ["ELEC", "elec"], ["APU", "apu"], ["OVHT/DET", "ovht"]] : [["ANTI-ICE", "ice"], ["HYD", "hyd"], ["DOORS", "doors"], ["ENG", "eng"], ["OVERHEAD", "ovhd"], ["AIR COND", "air"]];
  const [c1, c2, mc, fw] = xs;
  return {
    id: "p7_6" + side, pn: "P7 (" + (side === "L" ? "sol" : "sağ") + ")", name: (side === "L" ? "Sol" : "Sağ") + " ikaz grubu (FIRE WARN / MASTER CAUTION / six-pack)", en: "Master Caution and System Annunciators", ata: "31", struct: true,
    rect: rect(pc, side === "L" ? 40 : 655, 140, side === "L" ? 575 : 1200, 310),
    desc: "FIRE WARN (kırmızı) ve MASTER CAUTION (amber) ışıklı düğmeleri ile altı sistem ikaz ışığı (six-pack). Bir sistemde amber ikaz yanınca MASTER CAUTION ve ilgili six-pack ışığı yanar. MASTER CAUTION'a basınca ikisi de söner (sıfırlama); six-pack'e basınca etkin ikazlar yeniden gösterilir (recall). Işıklar WDM'de D40738/D40740 ayrılabilir bağlantıları üzerinden beslenir.",
    comps: [["L00340/L00341", "FIRE WARN ve MASTER CAUTION ışık grupları (sol)"], ["D40738J/P · D40740J/P", "Glareshield ayrılabilir bağlantıları (W0001/W0104, W0003/W0204)"]],
    conns: [], texts: [],
    items: [
      L("fireW" + side, p(fw, 212), "FIRE\nWARN", "r", { w: s(102), h: s(105), press: true, d: "FIRE WARN: herhangi bir yangın/aşırı ısınma ikazında kırmızı yanar ve yangın zili çalar. Basınca zil susar ve ışık söner (BELL CUTOUT)." }),
      L("mc" + side, p(mc, 212), "MASTER\nCAUTION", "a", { w: s(102), h: s(105), press: true, d: "MASTER CAUTION: bir sistemde amber ikaz yanınca yanar. Basınca söner ve six-pack ikazları sıfırlanır." }),
      ...L6.map(([t, k], i) => L("six_" + k, p(i < 3 ? c1 : c2, [180, 230, 272][i % 3]), t, "a", { w: s(122), h: s(38), press: true, six: k, d: t + " grubu: overhead'de bu gruba ait bir amber ikaz yanınca yanar. Six-pack'e basmak tüm etkin ikazları yeniden gösterir (recall)." }))
    ]
  };
}
const SIX_L = sixpack("L", pieceL, [366, 497, 237, 112]);
const SIX_R = sixpack("R", pieceR, [733, 863, 993, 1118]);

// glareshield alt kenarı (yapı) – şekildeki trapez dış hatlar
const Wtot = (pieceR.ox + 1308 / pieceR.s) * U;
export const P7 = {
  id: "p7", PX: U, OX: 0, OY: 0, x1: Math.round(Wtot), yRow: Math.round((0.12 + 400 / pieceL.s) * U),
  rails: [], modules: [SIX_L, EFIS_L, MCP, EFIS_R, SIX_R],
  outline: [P(pieceL, 20, 110), P(pieceL, 700, 0), P(pieceR, 520, 0), P(pieceR, 1210, 112), P(pieceR, 1210, 265), P(pieceR, 830, 400), P(pieceL, 405, 398), P(pieceL, 20, 270)]
};
export const P7_BUNDLES = { W2363: "Bkz. WDM Master Bundle List – MCP", W2465: "Bkz. WDM Master Bundle List – MCP", W0001: "Kaptan tarafı ana panel demeti", W0003: "F/O tarafı ana panel demeti" };
export const P7_CONN_PN = { D299: ["BACC63CB22-55SN", "22-11-11"], D301: ["BACC63CB14-15SN", "22-11-51"], D1815: ["BACC63CB22-55S6", "22-11-11"], D3993: ["BACC63CB22-55S9", "31-62-11"], D3995: ["BACC63CB22-55S9", "31-62-21"] };
// six-pack grupları: overhead ışık kimlikleri (power.js / layout) → grup
export const SIX_GROUPS = {
  flt: ["lpA", "lpB", "ydLt", "feel", "spdTrim", "machTrim", "autoSlat", "sbLP", "sbLQ", "sbRud"],
  irs: ["faultL", "faultR", "dcfailL", "dcfailR", "ondcL", "ondcR", "gpsLt"],
  fuel: ["lpCL", "lpCR", "lpF1", "lpF2", "lpA1", "lpA2", "fb1", "fb2"],
  elec: ["drive1", "drive2", "stbyOff", "tbo1", "tbo2", "so1", "so2", "batDis", "trUnit", "elecLt"],
  apu: ["apuLop", "apuFault", "apuOvs"], ovht: [],
  ice: ["pCapt", "pLel", "pLav", "pTemp", "pFo", "pRel", "pRav", "pAux", "wOv1", "wOv2", "wOv3", "wOv4", "cai1", "cai2"],
  hyd: ["hlpE1", "hlpE2", "hlpEl1", "hlpEl2", "hovE1", "hovE2"],
  doors: ["dFE", "dFS", "dLFO", "dRFO", "dFC", "dEq", "dLAO", "dRAO", "dAC", "dAE", "dAS"],
  eng: ["rev1", "rev2", "engCtl1", "engCtl2"], ovhd: ["eqSup", "eqExh", "emerNA", "pseu"],
  air: ["packLt1", "packLt2", "wbo1", "wbo2", "bto1", "bto2", "zt1", "zt2", "zt3", "autoFail", "offSched"]
};
