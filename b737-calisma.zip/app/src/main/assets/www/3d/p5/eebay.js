// E/E bölmesi rafları (E1–E6) – WDM 91-03-0x raf şemaları ve 91-01-05 raf konum tablosundan.
import * as THREE from '../three.module.js';
import { OrbitControls } from '../OrbitControls.js';
import { RoomEnvironment } from '../RoomEnvironment.js';
import { mergeGeometries } from '../BufferGeometryUtils.js';
import { S as ST } from './state.js';
import * as DATA from './data.js';
import { AFT } from './layout_aft.js';

const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const FF = '"RC", "Roboto Condensed", "Arial Narrow", sans-serif';
const K = 18;            // şema puanı → inç (raf şemasındaki raf aralıkları WL farklarıyla uyumlu)
const DEPTH = 12;
const AFT_D = new Set(AFT.modules.flatMap(m => (m.conns || []).map(c => DATA.normD(c.d))));
const RACK_DESC = {
  E1: "E/E bölmesinin önündeki raf. Uçuş kontrol bilgisayarları, TCAS, MMR, VOR/DME, VHF, ATC transponder gibi aviyonik üniteler.",
  E2: "Sol taraftaki raf. Batarya şarj cihazı, statik inverter, APU start üniteleri, yangın algılama modülü, cam ısıtma kontrol üniteleri.",
  E3: "Orta raf. CDS ekran elektronik üniteleri (DEU 1/2), radyo altimetreler, stall management/yaw damper bilgisayarları, DFDAU, bölge sıcaklık kontrolörleri.",
  E4: "Sağ taraftaki raf. Kabin basınç kontrolörü 2, klima röle kutuları, cam ısıtma kontrol üniteleri 3/4, SELCAL, REU.",
  E5: "ADIRU 1/2, FMC ve DIU'nun bulunduğu raf.",
  E6: "Arka kargo bölmesi tarafındaki raf."
};

function faceTex(u, w, h) {
  const c = document.createElement("canvas"), P = 60; c.width = Math.max(32, Math.round(w * P)); c.height = Math.max(32, Math.round(h * P));
  const g = c.getContext("2d");
  const grd = g.createLinearGradient(0, 0, 0, c.height); grd.addColorStop(0, u.prov ? "#9aa2a8" : "#3a3f45"); grd.addColorStop(1, u.prov ? "#8a9298" : "#2c3035"); g.fillStyle = grd; g.fillRect(0, 0, c.width, c.height);
  g.strokeStyle = "#1b1d20"; g.lineWidth = 6; g.strokeRect(3, 3, c.width - 6, c.height - 6);
  // tutamaklar
  g.fillStyle = "#b9bec4"; g.fillRect(c.width * 0.08, c.height * 0.1, c.width * 0.06, c.height * 0.8); g.fillRect(c.width * 0.86, c.height * 0.1, c.width * 0.06, c.height * 0.8);
  // etiket
  const lw = c.width * 0.62, lh = c.height * 0.55, lx = (c.width - lw) / 2, ly = c.height * 0.2;
  g.fillStyle = "#e9e6dc"; g.fillRect(lx, ly, lw, lh);
  g.fillStyle = "#1a1a1a"; g.textAlign = "center"; g.textBaseline = "middle";
  const lines = u.name.split("\n"); let fs = Math.min(lh / (lines.length + 1.6), 46);
  g.font = `700 ${fs}px ${FF}`; const mw = Math.max(...lines.map(l => g.measureText(l).width)); if (mw > lw * 0.92) fs *= lw * 0.92 / mw;
  g.font = `700 ${fs}px ${FF}`;
  lines.forEach((l, i) => g.fillText(l, c.width / 2, ly + fs * 0.9 + i * fs * 1.05));
  g.font = `500 ${fs * 0.8}px ${FF}`; g.fillText(u.m.replace(/^M0*/, "M"), c.width / 2, ly + lh - fs * 0.6);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}
function tagTex(t1, t2) {
  const c = document.createElement("canvas"); c.width = 256; c.height = 96; const g = c.getContext("2d");
  g.fillStyle = "#f4f2ea"; g.fillRect(0, 0, 256, 96); g.fillStyle = "#111"; g.textAlign = "center"; g.textBaseline = "middle";
  g.font = `700 38px ${FF}`; g.fillText(t1, 128, t2 ? 34 : 48); if (t2) { g.font = `500 24px ${FF}`; g.fillText(t2, 128, 74); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export async function mount(rootEl) {
  rootEl.innerHTML = `<div class="v3">
    <div class="v3-stage"><canvas></canvas><div class="v3-hint">Üniteye veya arkadaki konnektöre dokun</div><div class="v3-load">E/E rafı yükleniyor…</div>
      <div class="v3-tools"><button data-t="front" class="on">Ön</button><button data-t="back">Arka</button><button data-t="pull" disabled>Üniteyi çıkar</button><button data-t="fit">Ortala</button></div></div>
    <div class="v3-bar">
      ${DATA.SEG("ee")}
      <label class="v3-sel"><span>Uçak</span><select class="v3-tail"></select></label>
      <div class="v3-tabs"></div>
    </div>
    <div class="v3-info"></div>
    <p class="v3-note">Kaynak: WDM 91-03-01…06 raf şemaları (ünite M-numarası, adı, raf konnektörü D-numarası, raf demetleri), 91-01-05 raf konum tablosu (STA/WL/BL), Equipment List (parça numaraları). Ünite boyutları şemadaki oranlardan ölçeklendi (temsilî); derinlik sabit alındı. Raflar tek tek gösterilir; bölmedeki yerleşim üstten görünüş şemasındadır.</p>
  </div>`;
  const stage = rootEl.querySelector(".v3-stage"), canvasEl = rootEl.querySelector("canvas"), info = rootEl.querySelector(".v3-info"), tabs = rootEl.querySelector(".v3-tabs");
  const [M, EE] = await Promise.all([DATA.meta(), DATA.load("ee")]);
  const pinsP = DATA.pinsFor(ST.tail).catch(() => null);
  const tailSel = rootEl.querySelector(".v3-tail");
  const groups = {}; for (const f of M.fleet) (groups[f[0]] = groups[f[0]] || []).push(f);
  tailSel.innerHTML = Object.entries(groups).map(([mdl, list]) => `<optgroup label="${esc(mdl)}">${list.map(f => `<option value="${f[2]}">${esc(f[3])} (${f[2]})</option>`).join("")}</optgroup>`).join("");
  tailSel.value = ST.tail;
  tailSel.onchange = () => { ST.tail = tailSel.value; try { localStorage.setItem("b737.tail", tailSel.value); } catch (e) {} window.dispatchEvent(new HashChangeEvent("hashchange")); };

  const racks = {};
  for (const r of EE.racks) if (!racks[r.rack] && DATA.effOk(r.eff, ST.tail)) racks[r.rack] = r;
  const names = Object.keys(racks).sort();
  const focus = ST.eeFocus; ST.eeFocus = null;
  let cur = names[0];
  if (focus) for (const n of names) if (racks[n].units.some(u => u.d.some(d => d[0] === focus.D) || u.m === focus.D)) cur = n;

  let renderer;
  try { renderer = new THREE.WebGLRenderer({ canvas: canvasEl, antialias: true }); } catch (e) { stage.innerHTML = '<p style="padding:16px">Bu cihazda 3D (WebGL) desteklenmiyor.</p>'; return () => {}; }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2)); renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.shadowMap.enabled = true;
  const dark = matchMedia("(prefers-color-scheme: dark)").matches;
  const scene = new THREE.Scene(); scene.background = new THREE.Color(dark ? 0x10161d : 0xdfe5eb);
  const pmrem = new THREE.PMREMGenerator(renderer); const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture; scene.environment = envTex; scene.environmentIntensity = 0.7;
  const key = new THREE.DirectionalLight(0xffffff, 1.3); key.position.set(-20, 30, 40); key.castShadow = true; key.shadow.mapSize.set(1024, 1024); Object.assign(key.shadow.camera, { left: -40, right: 40, top: 40, bottom: -40 }); scene.add(key);
  const cam = new THREE.PerspectiveCamera(36, 1, 0.5, 600), controls = new OrbitControls(cam, canvasEl);
  controls.enableDamping = true; controls.dampingFactor = 0.12; controls.screenSpacePanning = true; controls.minDistance = 6; controls.maxDistance = 220;
  rootEl.querySelector(".v3-load").remove();
  let dirty = true;
  const resize = () => { const w = stage.clientWidth, h = stage.clientHeight; if (!w || !h) return; renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); dirty = true; };
  const ro = new ResizeObserver(resize); ro.observe(stage); resize();
  controls.addEventListener("change", () => dirty = true);

  const MAT = {
    frame: new THREE.MeshStandardMaterial({ color: 0x8b949b, metalness: 0.6, roughness: 0.45 }),
    shelf: new THREE.MeshStandardMaterial({ color: 0xa7aeb4, metalness: 0.5, roughness: 0.5 }),
    body: new THREE.MeshStandardMaterial({ color: 0x2f3338, metalness: 0.4, roughness: 0.5 }),
    prov: new THREE.MeshStandardMaterial({ color: 0x9aa2a8, transparent: true, opacity: 0.35, depthWrite: false }),
    conn: new THREE.MeshStandardMaterial({ color: 0x5f6a4c, metalness: 0.75, roughness: 0.38 }),
    wire: new THREE.MeshStandardMaterial({ color: 0xe6e2d3, roughness: 0.75 }),
    hold: new THREE.MeshStandardMaterial({ color: 0x1c1d20, metalness: 0.3, roughness: 0.4 })
  };
  let G = null, sel = null; const hl = [];
  const clearHL = () => { while (hl.length) { const m = hl.pop(); m.material = m.userData.orig; delete m.userData.orig; } };
  const highlight = obj => obj.traverse(m => { if (!m.isMesh || m.userData.orig) return; m.userData.orig = m.material; const mk = mt => { const q = mt.clone(); if (q.emissive) { q.emissive = new THREE.Color(0x2a6cf0); q.emissiveIntensity = 0.45; } return q; }; m.material = Array.isArray(m.material) ? m.material.map(mk) : mk(m.material); hl.push(m); });

  function build(name) {
    if (G) { scene.remove(G.grp); G.grp.traverse(o => { if (o.isMesh) { o.geometry.dispose(); (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => { if (!Object.values(MAT).includes(m)) { m.map?.dispose(); m.dispose(); } }); } }); }
    clearHL(); sel = null;
    const r = racks[name], grp = new THREE.Group(); scene.add(grp);
    const all = [...r.shelves.map(s => s.box), ...r.units.map(u => u.box)];
    const X0 = Math.min(...all.map(b => b[0])), X1 = Math.max(...all.map(b => b[2])), Y0 = Math.min(...all.map(b => b[1])), Y1 = Math.max(...all.map(b => b[3]));
    const X = px => (px - X0) / K, Y = py => -(py - Y0) / K, W = (X1 - X0) / K, H = (Y1 - Y0) / K;
    const fg = [];
    fg.push(new THREE.BoxGeometry(1, H + 2, DEPTH + 4).translate(-0.6, -H / 2, -DEPTH / 2), new THREE.BoxGeometry(1, H + 2, DEPTH + 4).translate(W + 0.6, -H / 2, -DEPTH / 2));
    fg.push(new THREE.BoxGeometry(W + 2.2, 0.8, DEPTH + 4).translate(W / 2, 1.2, -DEPTH / 2));
    grp.add(new THREE.Mesh(mergeGeometries(fg), MAT.frame));
    const shelves = [];
    for (const s of r.shelves) {
      const [a, b, c, d] = s.box, w = (c - a) / K;
      const plate = new THREE.Mesh(new THREE.BoxGeometry(w, 0.3, DEPTH + 3), MAT.shelf); plate.position.set(X(a) + w / 2, Y(d) - 0.15, -DEPTH / 2 - 0.5); plate.receiveShadow = true; grp.add(plate);
      const lab = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.9), new THREE.MeshStandardMaterial({ map: tagTex(s.id, s.loc ? `STA ${s.loc[0]} WL ${s.loc[1]}` : ""), roughness: 0.8 }));
      lab.position.set(X(s.at[0]), Y(d) + 0.2, 1.05); grp.add(lab);
      shelves.push({ s, y: Y(d), x0: X(a), x1: X(c) });
    }
    const units = [];
    for (const u of r.units) {
      const [a, b, c, d] = u.box, w = (c - a) / K - 0.15;
      const sh = shelves.find(q => q.s.id === u.shelf), base = sh ? sh.y : Y(d);
      const h = Math.max(1.5, Math.min((d - b) / K, (sh ? Y(b) - base : (d - b) / K))) - 0.2;
      const g = new THREE.Group(); g.position.set(X(a) + w / 2 + 0.07, base + h / 2, 0);
      const ft = faceTex(u, w, h);
      const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, DEPTH), u.prov ? MAT.prov : [MAT.body, MAT.body, MAT.body, MAT.body, new THREE.MeshStandardMaterial({ map: ft, roughness: 0.55, metalness: 0.2 }), MAT.body]);
      body.position.z = -DEPTH / 2; body.castShadow = !u.prov; g.add(body);
      if (!u.prov) { const hd = new THREE.Mesh(mergeGeometries([new THREE.BoxGeometry(0.25, h * 0.15, 0.6).translate(-w / 2 + 0.25, -h / 2 + h * 0.12, 0.3), new THREE.BoxGeometry(0.25, h * 0.15, 0.6).translate(w / 2 - 0.25, -h / 2 + h * 0.12, 0.3)]), MAT.hold); g.add(hd); }
      const part = { kind: "unit", u, obj: g, base: g.position.clone(), pull: 0, conns: [] };
      body.userData.part = part;
      u.d.forEach((dd, i) => {
        const cg = new THREE.Group(), n = u.d.length, cx = X(a) + (i + 1) * (w / (n + 1)) + 0.07, cy = base + h / 2;
        const rect = /^(BACC6|DPX|BACC66)/.test(dd[1]);
        const shellG = rect ? new THREE.BoxGeometry(Math.min(w * 0.6, 3.2), Math.min(h * 0.55, 2.2), 0.8) : new THREE.CylinderGeometry(0.6, 0.6, 0.8, 24).rotateX(Math.PI / 2);
        const shell = new THREE.Mesh(shellG, MAT.conn); shell.position.z = -DEPTH - 0.45; cg.add(shell);
        const tag = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 0.6), new THREE.MeshStandardMaterial({ map: tagTex(dd[0].replace(/^D0*/, "D"), u.m.replace(/^M0*/, "M")), roughness: 0.8, side: THREE.DoubleSide }));
        tag.position.set(0, Math.min(h * 0.55, 2.2) / 2 + 0.55, -DEPTH - 0.9); tag.rotation.y = Math.PI; cg.add(tag);
        const tail = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([new THREE.Vector3(0, 0, -DEPTH - 0.85), new THREE.Vector3(0, 0, -DEPTH - 2.2), new THREE.Vector3(0, -(cy - base) + 0.4, -DEPTH - 3.2)]), 12, 0.35, 8), MAT.wire); cg.add(tail);
        cg.position.set(cx, cy, 0); grp.add(cg);
        const cp = { kind: "conn", u, dd, obj: cg, unit: part }; cg.traverse(m => { if (m.isMesh) m.userData.part = cp; });
        part.conns.push(cp);
      });
      grp.add(g); units.push(part);
    }
    // raf demetleri (şemanın kenarındaki W numaraları)
    for (const b of r.bundles) {
      const y = Y(b.at[1]), left = X(b.at[0]) < W / 2, x0 = left ? -1.5 : W + 1.5, x1 = left ? W * 0.75 : W * 0.25;
      const tube = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([new THREE.Vector3(x0 + (left ? -3 : 3), y + 4, -DEPTH - 3.4), new THREE.Vector3(x0, y, -DEPTH - 3.4), new THREE.Vector3(x1, y - 0.6, -DEPTH - 3.4)]), 24, 0.5, 10), MAT.wire);
      const tag = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 0.8), new THREE.MeshStandardMaterial({ map: tagTex(b.id, ""), roughness: 0.8, side: THREE.DoubleSide })); tag.position.set(x0, y + 1.1, -DEPTH - 3.4); tag.rotation.y = Math.PI;
      const bp = { kind: "bundle", b, obj: tube }; tube.userData.part = bp; tag.userData.part = bp; grp.add(tube, tag);
    }
    G = { grp, r, units, W, H };
    tabs.querySelectorAll("button").forEach(b => b.classList.toggle("on", b.dataset.r === name));
    fit("front");
  }
  function fit(side) {
    const vf = THREE.MathUtils.degToRad(cam.fov), hf = 2 * Math.atan(Math.tan(vf / 2) * cam.aspect);
    const d = Math.max((G.W / 2 + 3) / Math.tan(hf / 2), (G.H / 2 + 3) / Math.tan(vf / 2)) * 1.02;
    controls.target.set(G.W / 2, -G.H / 2, -DEPTH / 2);
    cam.position.set(G.W / 2 + (side === "back" ? 8 : 0), -G.H / 2 + (side === "back" ? 6 : 1), side === "back" ? -DEPTH / 2 - d : -DEPTH / 2 + d);
    controls.update(); dirty = true;
    rootEl.querySelectorAll('[data-t="front"],[data-t="back"]').forEach(b => b.classList.toggle("on", b.dataset.t === side));
  }
  tabs.innerHTML = names.map(n => `<button data-r="${n}">${n}</button>`).join("");
  tabs.querySelectorAll("button").forEach(b => b.onclick = () => { cur = b.dataset.r; build(cur); showInfo(); });

  async function p5Links(Ds) {
    const P = await pinsP; if (!P) return [];
    const set = new Set(Ds), hits = [];
    for (const D in P.pins) for (const q of P.pins[D]) for (const path of q.paths) { const s = path.find(x => x[0] === "w" && set.has(x[6])); if (s) { hits.push({ D, t: q.t, w: q.w, b: q.b, dg: q.dg, at: s[6] + (s[7] && s[7] !== "=L" ? "-" + s[7] : ""), panel: AFT_D.has(D) ? "aft" : "fwd" }); break; } }
    return hits;
  }
  function overview() {
    const L = EE.loc, pts = Object.entries(L).filter(([k]) => names.includes(k.split("-")[0]) || k.startsWith("E6"));
    const byR = {}; for (const [k, v] of pts) (byR[k.split("-")[0]] = byR[k.split("-")[0]] || []).push(v);
    const sx = sta => 20 + (sta - 290) * 3.2, sy = bl => 110 - bl * 2.4;
    const fwdRacks = Object.entries(byR).filter(([r, v]) => v[0][0] < 500);
    return `<p class="v3-sub">E/E bölmesi yerleşimi (üstten, WDM 91-01-05 STA/BL; burun solda):</p><svg viewBox="0 0 330 200" class="v3-plan"><rect x="4" y="30" width="322" height="160" rx="70" fill="none" stroke="var(--line)" stroke-width="2"/><line x1="10" y1="110" x2="320" y2="110" stroke="var(--line)" stroke-dasharray="4 4"/><text x="300" y="104" font-size="9" fill="var(--mute)">BL 0</text><text x="10" y="22" font-size="10" fill="var(--mute)">◀ ileri</text>
      ${fwdRacks.map(([r, v]) => { const sta = v[0][0], bl = v.reduce((s, q) => s + q[2], 0) / v.length; return `<g data-r="${r}" class="v3-planr${r === cur ? " on" : ""}"><rect x="${sx(sta) - 16}" y="${sy(bl) - 10}" width="32" height="20" rx="3"/><text x="${sx(sta)}" y="${sy(bl) + 4}" text-anchor="middle" font-size="11" font-weight="700">${r}</text></g>`; }).join("")}
      </svg><p class="v3-sub">Raf (STA / WL / BL): ${Object.entries(L).filter(([k]) => names.includes(k.split("-")[0])).map(([k, v]) => `${k} ${v[0]}/${v[1]}/${v[2]}`).join(" · ")}. BL işareti WDM tablosundaki gibidir.</p>`;
  }
  function backLink() {
    if (!focus || !focus.back) return "";
    return `<div class="v3-resume"><button class="v3-btn pri" data-a="back">‹ P5 paneline dön</button></div>`;
  }
  function showInfo() {
    const r = racks[cur];
    if (!sel) {
      info.innerHTML = `${backLink()}<small>${esc(DATA.tailLabel(ST.tail))} · WDM 91-03-0${cur[1]} sayfa ${r.page} · ${r.look === "AFT" ? "arkaya bakış" : "ileriye bakış"}</small><b>${esc(cur)} rafı</b><p>${esc(RACK_DESC[cur] || "")}</p>
        <p class="v3-sub">Üniteler:</p><ul class="v3-ul">${r.units.map((u, i) => `<li><button class="v3-link" data-u="${i}">${esc(u.shelf)} · ${esc(u.name.replace(/\n/g, " "))}</button> ${esc(u.m.replace(/^M0*/, "M"))}${u.d.length ? " · " + u.d.map(d => esc(d[0].replace(/^D0*/, "D"))).join(", ") : ""}</li>`).join("")}</ul>
        <p class="v3-sub">Raf demetleri:</p><ul class="v3-ul">${r.bundles.map(b => `<li><b>${esc(b.id)}</b> ${esc(b.desc)}</li>`).join("")}</ul>${overview()}`;
      info.querySelectorAll("[data-u]").forEach(b => b.onclick = () => selectPart(G.units[+b.dataset.u], true));
      info.querySelectorAll("[data-r]").forEach(g => g.onclick = () => { cur = g.dataset.r; build(cur); showInfo(); });
      bindBack(); return;
    }
    const part = sel.kind === "unit" ? sel : sel.unit, u = part.u;
    const sh = r.shelves.find(s => s.id === u.shelf), loc = sh && sh.loc;
    info.innerHTML = `${backLink()}<small>${esc(cur)} · raf ${esc(u.shelf)}${loc ? ` · STA ${loc[0]} WL ${loc[1]} BL ${loc[2]}` : ""}</small><b>${esc(u.name.replace(/\n/g, " "))}</b>
      <table class="v3-tbl"><tr><td>Ünite</td><td>${esc(u.m)} – ${esc(u.desc || "")}</td></tr><tr><td>Parça no</td><td>${esc(u.pn || "—")}</td></tr><tr><td>WDM şema</td><td>${esc(u.dg)} ${esc(M.titles[u.dg] || "")}</td></tr>
      ${u.d.map(d => `<tr><td>Raf konn.</td><td><b>${esc(d[0])}</b> ${esc(d[1])}${d[3] ? " – " + esc(d[3]) : ""}</td></tr>`).join("")}</table>
      ${u.prov ? '<p class="v3-sub">Provizyon (PROV): bu yuva kablolu ama ünite takılı değil.</p>' : ""}
      <p class="v3-sub">P5 panelinden bu üniteye gelen teller (Wire List izi):</p><ul class="v3-ul v3-hits"><li>aranıyor…</li></ul>
      <p class="v3-sub">Raf ünitesi arkadaki raf konnektörüne (ARINC 404/600 tipi dikdörtgen veya dairesel) oturur; ön tutamak kilitleri (hold-down) açılıp ünite raydan çekilerek sökülür. Sökmeden önce AMM'deki CB'ler açılır ve ESD önlemleri alınır.</p>`;
    bindBack();
    p5Links(u.d.map(d => d[0])).then(h => {
      const ul = info.querySelector(".v3-hits"); if (!ul) return;
      ul.innerHTML = h.length ? h.slice(0, 40).map(x => `<li><button class="v3-link" data-D="${x.D}" data-t="${esc(x.t)}" data-p="${x.panel}">${esc(DATA.shortD(x.D))}-${esc(x.t)}</button> → ${esc(x.at)} · tel ${esc(x.w)} · ${esc(x.b)} · ${esc(x.dg)} ${esc(M.titles[x.dg] || "")}</li>`).join("") + (h.length > 40 ? `<li>… ${h.length - 40} tel daha</li>` : "") : "<li>P5 modül konnektörlerinden doğrudan bu üniteye giden tel bulunamadı (bağlantı başka panel, veri yolu veya röle üzerinden olabilir).</li>";
      ul.querySelectorAll("[data-D]").forEach(b => b.onclick = () => { ST.p5Focus = { panel: b.dataset.p, D: b.dataset.D, pin: b.dataset.t }; location.hash = b.dataset.p === "aft" ? "#/3d/p5aft" : "#/3d/p5"; });
    });
  }
  function bindBack() {
    const b = info.querySelector('[data-a="back"]'); if (!b) return;
    b.onclick = () => { const bk = focus.back; ST.p5Focus = { panel: bk.panel, D: bk.D, pin: bk.pin }; location.hash = bk.panel === "aft" ? "#/3d/p5aft" : "#/3d/p5"; };
  }
  function selectPart(p, fly) {
    clearHL(); sel = p; if (p) highlight(p.obj);
    const pb = rootEl.querySelector('[data-t="pull"]'); const up = p && (p.kind === "unit" ? p : p.unit);
    pb.disabled = !up || up.u.prov; pb.textContent = up && up.pull ? "Üniteyi tak" : "Üniteyi çıkar";
    showInfo();
    if (fly && p) { const box = new THREE.Box3().setFromObject(p.obj), c = box.getCenter(new THREE.Vector3()); const back = p.kind === "conn", dd = Math.max(16, box.getSize(new THREE.Vector3()).length() * 1.8); controls.target.copy(c); cam.position.set(c.x + (back ? 6 : 2), c.y + 2, back ? c.z - dd : c.z + dd); controls.update(); }
    dirty = true;
  }
  rootEl.querySelectorAll(".v3-tools button").forEach(b => b.onclick = () => {
    const t = b.dataset.t;
    if (t === "front" || t === "back") fit(t);
    if (t === "fit") fit("front");
    if (t === "pull" && sel) { const up = sel.kind === "unit" ? sel : sel.unit; up.pull = up.pull ? 0 : 1; b.textContent = up.pull ? "Üniteyi tak" : "Üniteyi çıkar"; }
  });
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(); let down = null;
  let multi = false; const ptrs = new Set();
  canvasEl.addEventListener("pointerdown", e => { ptrs.add(e.pointerId); if (ptrs.size > 1) multi = true; if (ptrs.size === 1) { multi = false; down = [e.clientX, e.clientY]; } });
  canvasEl.addEventListener("pointercancel", e => { ptrs.delete(e.pointerId); down = null; });
  canvasEl.addEventListener("pointerup", e => {
    ptrs.delete(e.pointerId); if (!down || multi) { if (!ptrs.size) down = null; return; } const mv = Math.hypot(e.clientX - down[0], e.clientY - down[1]); down = null; if (mv > 14) return;
    const rc = canvasEl.getBoundingClientRect(); ndc.set(((e.clientX - rc.left) / rc.width) * 2 - 1, -((e.clientY - rc.top) / rc.height) * 2 + 1); ray.setFromCamera(ndc, cam);
    const hit = ray.intersectObjects(G.grp.children, true).find(h => h.object.userData.part);
    const p = hit ? hit.object.userData.part : null;
    if (p && p.kind === "bundle") { selectPart(null); info.insertAdjacentHTML("afterbegin", `<div class="v3-card"><b>${esc(p.b.id)}</b> – ${esc(p.b.desc || "")}</div>`); return; }
    selectPart(p);
  });
  build(cur);
  if (focus) { const u = G.units.find(x => x.u.d.some(d => d[0] === focus.D)); if (u) { const c = u.conns.find(c => c.dd[0] === focus.D); selectPart(c || u, true); } else showInfo(); } else showInfo();
  let alive = true;
  (function loop() {
    if (!alive) return; requestAnimationFrame(loop); controls.update();
    for (const p of G.units) { const z = p.base.z + p.pull * 9; if (Math.abs(p.obj.position.z - z) > 0.01) { p.obj.position.z += (z - p.obj.position.z) * 0.15; dirty = true; } }
    if (dirty) { renderer.render(scene, cam); dirty = false; }
  })();
  rootEl.__ee = { scene, cam, G: () => G, select: m => { const u = G.units.find(x => x.u.m === m); selectPart(u, true); } };
  return () => { alive = false; ro.disconnect(); controls.dispose(); scene.traverse(o => { if (o.isMesh) { o.geometry.dispose(); const ms = Array.isArray(o.material) ? o.material : [o.material]; ms.forEach(m => { m.map?.dispose(); m.dispose(); }); } }); envTex.dispose(); pmrem.dispose(); renderer.dispose(); renderer.forceContextLoss?.(); };
}
