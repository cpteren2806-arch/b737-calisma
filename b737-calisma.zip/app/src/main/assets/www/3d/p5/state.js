// 3D görünümler arasında paylaşılan durum (sayfa oturumu boyunca). Uçak seçimi tarayıcıda hatırlanır.
import { DEFAULT_TAIL } from "./data.js";
const ls = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };

export const S = {
  tail: ls.get("b737.tail") || DEFAULT_TAIL,
  power: "gpu",              // cold | bat | gpu | apu | eng
  night: false,
  pulled: new Set(),         // açılmış (çekilmiş) CB kimlikleri (C00361…)
  tagged: new Set(),         // emniyet etiketi takılmış CB'ler
  disc: new Set(),           // ayrılmış konnektörler (D00628…)
  bulbs: new Set(),          // yanık ampuller (ışık kimliği)
  scen: null,                // etkin arıza senaryosu
  amm: null,                 // { key, task, step, mod }
  cbFocus: null,             // CB görünümünde vurgulanacak [{cb}] listesi
  p5Focus: null,             // P5 görünümüne dönüşte seçilecek { plug, pin }
  panel: "fwd"
};
const subs = new Set();
export const onState = f => { subs.add(f); return () => subs.delete(f); };
export const emit = () => subs.forEach(f => { try { f(S); } catch (e) {} });
export function setTail(code) { S.tail = code; ls.set("b737.tail", code); emit(); }
export function pullCB(id, v, tag) { if (v) S.pulled.add(id); else S.pulled.delete(id); if (tag != null) { if (tag) S.tagged.add(id); else S.tagged.delete(id); } emit(); }
import { newSim } from "./power.js";
S.sim = newSim();
S.ctl = {};                  // anahtar konumları (görünümler arası korunur)
