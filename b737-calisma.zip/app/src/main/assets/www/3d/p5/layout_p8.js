// 737NG orta konsol – aft electronic panel (P8).
// KAYNAK: WDM 91-02-08 Sayfa 2 "P8 – Aft Electronic Panel, plan view" (YC501–YC570: modül sırası, konnektör ve demet numaraları),
//         AMM 31-11-91 Fig. 101 (Aft Electronic Panel – Component Location; modül ön yüzleri), WDM Equipment List D280A117.
// Ölçek: 100 px = 1 inç. Modül genişliği standart Dzus 5,75 inç; yükseklikler AMM şeklinden ölçülmüştür (yaklaşık).
const U = 100, CW = 575;
const T = (id, at, pos, st, o = {}) => ({ t: "T", id, at, pos, st, ...o });
const R = (id, at, pos, ang, st, o = {}) => ({ t: "R", id, at, pos, ang, st, ...o });
const L = (id, at, txt, c = "a", o = {}) => ({ t: "L", id, at, txt, c, ...o });
const B = (id, at, o = {}) => ({ t: "B", id, at, ...o });
const D = (id, at, kind, w, h, o = {}) => ({ t: "D", id, at, kind, w, h, ...o });
const K = (id, at, txt, w, h, o = {}) => ({ t: "L", id, at, txt, c: "w", key: true, w, h, ...o });

// satır sınırları (px) – WDM plan görünüşündeki sıra
const Y = { fire: 0, r1: 288, r2: 550, r3: 812, r4: 1262, r5: 1525, r6: 1825, end: 2090 };
const COL = i => [i * CW, (i + 1) * CW];
// modül oluşturucu: yerel inç koordinatları → panel px
function mod(id, pn, name, en, ata, x0, y0, x1, y1, o = {}) {
  const q = (x, y) => [Math.round(x0 + x * U), Math.round(y0 + y * U)];
  const m = { id, pn, name, en, ata, rect: [x0, y0, x1, y1], conns: [], texts: [], rects: [], lines: [], items: [], ...o };
  return { m, q };
}
const fmtF = (v, d) => (v / 1000).toFixed(d);
const freq = (lo, hi, coarse, fine) => ({ lo, hi, coarse, fine });

/* ---------- radyo ayar paneli (VHF COMM, SB 23-1297 sonrası RTP görünümü) ---------- */
function rtp(n, pn, col, D1, W1) {
  const [x0, x1] = COL(col), { m, q } = mod("p8_rtp" + n, pn, `VHF COMM-${n} / radyo ayar paneli`, `VHF Communication Control Panel ${n}`, "23", x0, Y.r1, x1, Y.r2, {
    dg: ["23-12-11", "23-12-21", "23-12-31"],
    desc: `VHF ${n} haberleşme telsizinin frekans seçimi. Solda AKTİF (kullanılan), sağda BEKLEME (STANDBY) frekansı; ⇔ tuşu ikisini değiştirir. Çift düğme: dış halka MHz, iç düğme kHz (25 kHz adım). Alttaki VHF1/VHF2/VHF3 tuşları panelin hangi telsizi ayarladığını seçer (ışıklı). Telsiz alıcı-vericisi E/E bölmesinde (E1/E2 rafları), anteni gövde üst/alt yüzünde.`,
    conns: [{ d: D1, w: W1, at: [0.5, 0.45] }]
  });
  const sel = ST => ST.mcp["rtp" + n] || n, key = (ST, k) => `vhf${sel(ST)}${k}`;
  m.texts.push(["ACTIVE", ...q(1.55, 0.27), 12], ["STANDBY", ...q(4.2, 0.27), 12], ["TEST", ...q(4.15, 1.12), 10], ["VHF", ...q(4.15, 1.6), 10], ["HF SENS", ...q(0.62, 2.42), 9]);
  m.rects.push([...q(1.25, 1.25), ...q(3.62, 2.2), 8]);
  m.items.push(
    D("rtp" + n + "A", q(1.55, 0.72), "fmt", 190, 48, { fmt: ST => fmtF(ST.mcp[key(ST, "A")], 3) }),
    D("rtp" + n + "S", q(4.2, 0.72), "fmt", 190, 48, { fmt: ST => fmtF(ST.mcp[key(ST, "S")], 3) }),
    B("rtp" + n + "X", q(2.88, 0.72), { r: 17, act: ST => { const a = key(ST, "A"), s = key(ST, "S"); [ST.mcp[a], ST.mcp[s]] = [ST.mcp[s], ST.mcp[a]]; }, d: "Transfer (⇔): bekleme frekansını aktif yapar; eski aktif frekans beklemeye geçer." }),
    K("rtp" + n + "Off", q(0.62, 1.32), "OFF", 46, 26, { d: "OFF: radyo ayar panelini kapatır (PNL OFF ışığı)." }),
    K("rtp" + n + "T", q(4.15, 1.32), "TEST", 46, 26, { d: "TEST: seçili VHF alıcısının susturucusunu (squelch) açar; gürültü duyulursa alıcı çalışıyor." }),
    ...[["VHF1", 1, 1.72, 1.52], ["VHF2", 2, 2.44, 1.52], ["VHF3", 3, 3.16, 1.52]].map(([t, k, x, y]) => L(`rtp${n}v${k}`, q(x, y), t, "w", { w: 58, h: 26, press: true, rtp: [n, k], d: `${t}: bu panel ${t} telsizini ayarlar. Normalde panel ${n} → VHF ${n}; diğerini seçmek ‘off-side tuning’ uyarısı verir.` })),
    ...[["HF1", 1.72, 1.95], ["AM", 2.44, 1.95], ["HF2", 3.16, 1.95]].map(([t, x, y]) => K(`rtp${n}${t}`, q(x, y), t, 58, 26, { d: t + ": HF telsiz seçimi (bu filoda HF takılı değil – WDM'de P8-11/12 konnektörü yok)." })),
    R("rtp" + n + "Sens", q(0.62, 2.0), [""], [0], 0, { knob: "grip", r: 22, d: "HF SENS: HF alıcı hassasiyeti." }),
    R("rtp" + n + "K", q(5.0, 1.62), [""], [0], 0, { knob: "dual", r: 44, dual: true, val: ST => key(ST, "S"), freq: freq(118000, 136975, 1000, 25), d: "Frekans seçici (BEKLEME): dış halka MHz, iç düğme kHz. Dış kenara dokun = MHz, merkeze dokun = kHz; sağ yarı artırır, sol yarı azaltır." })
  );
  return m;
}
/* ---------- VHF NAV ---------- */
function nav(n, pn, col, conns) {
  const [x0, x1] = COL(col), { m, q } = mod("p8_nav" + n, pn, `VHF NAV-${n} kontrol paneli`, `VHF/NAV Control Panel ${n}`, "34", x0, Y.r2, x1, Y.r3, {
    dg: [n === 1 ? "34-51-11" : "34-51-21", "34-31-11"], conns,
    desc: `VOR/ILS/DME ${n} frekans seçimi. AKTİF frekans alıcıya (MMR/VOR ${n}, E/E bölmesi) gider; ⇔ ile bekleme frekansı aktif olur. ILS frekansı seçilince aynı anda glideslope ve DME de ayarlanır (eşli frekans). TEST: VOR/ILS alıcı testi.`
  });
  const k = "nav" + n;
  m.texts.push(["ACTIVE", ...q(1.55, 0.27), 12], ["STANDBY", ...q(4.2, 0.27), 12], ["NAV", ...q(0.3, 1.75), 13], ["TEST", ...q(0.95, 1.45), 10]);
  m.items.push(
    D(k + "A", q(1.55, 0.72), "fmt", 170, 48, { fmt: ST => fmtF(ST.mcp[k + "A"], 2) }),
    D(k + "S", q(4.2, 0.72), "fmt", 170, 48, { fmt: ST => fmtF(ST.mcp[k + "S"], 2) }),
    B(k + "X", q(2.88, 0.72), { r: 17, act: ST => { [ST.mcp[k + "A"], ST.mcp[k + "S"]] = [ST.mcp[k + "S"], ST.mcp[k + "A"]]; }, d: "Transfer: bekleme ↔ aktif." }),
    K(k + "T", q(0.95, 1.75), "TEST", 46, 26, { d: "VOR/ILS testi: ND/PFD'de test sapması gösterilir." }),
    R(k + "K", q(4.2, 1.72), [""], [0], 0, { knob: "dual", r: 44, dual: true, val: k + "S", freq: freq(108000, 117950, 1000, 50), d: "Frekans: dış halka MHz, iç düğme 50 kHz." })
  );
  return m;
}
/* ---------- ses kontrol paneli (ACP) ---------- */
const MICS = [["VHF 1", "vhf1"], ["VHF 2", "vhf2"], ["VHF 3", "vhf3"], ["HF 1", "hf1"], ["HF 2", "hf2"], ["FLT", "flt"], ["SVC", "svc"], ["PA", "pa"]];
function acp(side, pn, col, conns) {
  const [x0, x1] = COL(col), { m, q } = mod("p8_acp" + side, pn, `${side === "L" ? "Kaptan" : "F/O"} ses kontrol paneli (ACP)`, `${side === "L" ? "CAPT" : "F/O"} Audio Selector Panel`, "23", x0, Y.r3, x1, Y.r4, {
    dg: [side === "L" ? "23-51-11" : "23-51-21"], conns,
    desc: "Mikrofon seçici (MIC SELECTOR): mikrofonu hangi telsize/interfona bağlayacağını seçer (tek seçim). Alıcı düğmeleri: basınca açılır (dinleme), çevirince ses. R/T–I/C: el mikrofonu/maske bas-konuş. Sinyaller REU'ya (remote electronics unit, E/E bölmesi) gider; REU sesleri karıştırıp kulaklığa verir. ALT: REU arızasında doğrudan yedek ses yolu.",
  });
  const p = "acp" + side + "_";
  m.texts.push(["MIC SELECTOR", ...q(2.88, 0.18), 11, "center", "line"]);
  MICS.forEach(([t, k], i) => {
    const x = 0.55 + i * 0.665;
    m.items.push(L(p + "m" + k, q(x, 0.62), t, "w", { w: 54, h: 54, press: true, latch: true, grp: p + "mic", d: `${t} mikrofon seçimi: bas-konuş (PTT) bu kanala yayın yapar. Üstteki CALL ışığı gelen çağrıyı (SELCAL/kabin) gösterir.` }));
    m.texts.push([t.replace(" ", ""), ...q(x, 1.18), 9]);
    m.items.push(R(p + "r" + k, q(x, 1.55), ["OFF", "ON"], [-60, 30], k === "vhf1" ? 1 : 0, { knob: "grip", r: 22, d: `${t} alıcı düğmesi: bas = aç/kapat (dinle), çevir = ses seviyesi.` }));
  });
  [["NAV 1", "nav1"], ["NAV 2", "nav2"], ["ADF 1", "adf1"], ["ADF 2", "adf2"], ["MKR", "mkr"], ["SPKR", "spkr"]].forEach(([t, k], i) => {
    const x = 1.2 + i * 0.665; m.texts.push([t.replace(" ", ""), ...q(x, 2.05), 9]);
    m.items.push(R(p + "r" + k, q(x, 2.42), ["OFF", "ON"], [-60, 30], 0, { knob: "grip", r: 22, d: `${t} alıcısı: navigasyon tanıtma (Mors) sesi / marker / hoparlör.` }));
  });
  m.texts.push(["R/T", ...q(0.75, 3.12), 10], ["I/C", ...q(0.75, 3.88), 10], ["MASK", ...q(1.6, 3.12), 10], ["BOOM", ...q(1.6, 3.88), 10], ["V", ...q(2.6, 3.12), 10], ["B", ...q(2.95, 3.0), 10], ["R", ...q(3.3, 3.12), 10], ["ALT", ...q(4.55, 3.12), 10], ["NORM", ...q(4.55, 3.88), 10]);
  m.items.push(
    T(p + "rt", q(0.75, 3.5), ["R/T", "", "I/C"], 1, { spring: [0, 2], d: "R/T: seçili telsizde yayın (bas-konuş). I/C: interfon (kilitlenir)." }),
    T(p + "mask", q(1.6, 3.5), ["MASK", "BOOM"], 1, { d: "MASK/BOOM: mikrofon kaynağı – oksijen maskesi mikrofonu veya kulaklık mikrofonu." }),
    R(p + "flt", q(2.95, 3.5), ["V", "B", "R"], [-40, 0, 40], 1, { knob: "bar", r: 34, d: "Filtre: V (yalnız ses), B (ikisi), R (yalnız tanıtma/Mors)." }),
    T(p + "alt", q(4.55, 3.5), ["ALT", "NORM"], 1, { d: "ALT: REU arızasında bu panel için yedek (degrade) ses moduna geçer." })
  );
  return m;
}
/* ---------- ATC / TCAS ---------- */
function atc() {
  const [x0, x1] = COL(1), { m, q } = mod("p8_atc", "P8-29", "Transponder (ATC/TCAS) kontrol paneli", "Dual ATC Control Panel", "34", x0, Y.r3, x1, Y.r4, {
    dg: ["34-53-11", "34-53-21"], conns: [{ d: "D519", w: "W2247", at: [0.3, 0.4] }, { d: "D211", w: "W2177", at: [0.7, 0.4] }],
    desc: "İki transponder (ATC 1/2) ve TCAS kontrolü. Mod seçici: STBY (yayın yok), TA ONLY, TA/RA (TCAS tam çalışır), TEST. Kod 4 haneli sekizlik (0–7). IDENT: radar ekranında uçağı vurgular. ALT RPTG: Mod C irtifa bildirimi. ATC FAIL: seçili transponder arızası."
  });
  m.texts.push(["ALT OFF", ...q(0.55, 0.2), 9], ["ALT ON", ...q(1.15, 0.2), 9], ["STBY", ...q(1.2, 0.48), 9], ["TEST", ...q(0.75, 0.85), 9], ["TA", ...q(1.75, 0.6), 9], ["TA/RA", ...q(1.95, 0.88), 9],
    ["ATC1  2", ...q(3.0, 0.38), 9], ["ATC", ...q(4.55, 0.38), 9], ["FAIL", ...q(4.55, 0.98), 9], ["IDENT", ...q(2.88, 1.85), 9], ["1", ...q(0.48, 1.4), 9], ["2", ...q(0.48, 1.88), 9], ["TCAS / MOD S", ...q(2.88, 3.2), 12], ["(TCAS bilgisayarı ve transponderler E/E bölmesinde)", ...q(2.88, 3.55), 9]);
  const code = ST => ST.mcp.atcCode || "2000";
  m.items.push(
    T("atcAlt", q(0.85, 0.4), ["ALT OFF", "ALT ON"], 1, { horiz: true, d: "İrtifa bildirimi (Mode C/S) kapalı / açık." }),
    R("atcMode", q(1.35, 0.85), ["TEST", "STBY", "TA", "TA/RA"], [-80, -30, 30, 80], 1, { knob: "bar", r: 36, d: "Mod: TEST (sistem testi), STBY (transponder yayın yapmaz), TA (yalnız trafik uyarısı), TA/RA (trafik ve çözüm uyarısı)." }),
    D("atcCode", q(3.0, 0.75), "fmt", 150, 46, { fmt: ST => (ST.ctl.atcSel === 1 ? "2 " : "1 ") + code(ST) }),
    L("atcFail", q(4.55, 0.7), "", "a", { w: 26, h: 26, round: true, d: "ATC FAIL: seçili transponder arızalı (TEST'te yanar)." }),
    T("atcSel", q(0.75, 1.65), ["1", "2"], 0, { d: "Transponder seçimi: ATC 1 veya ATC 2." }),
    R("atcK1", q(1.85, 1.6), [""], [0], 0, { knob: "dual", r: 40, dual: true, val: "atcCode", atc: 0, d: "Kodun ilk iki hanesi: dış halka 1. hane, iç düğme 2. hane (0–7)." }),
    B("atcId", q(2.88, 1.6), { r: 24, d: "IDENT: ~18 sn kimlik darbesi (radar kontrolör ekranında vurgulanır)." }),
    R("atcK2", q(3.9, 1.6), [""], [0], 0, { knob: "dual", r: 40, dual: true, val: "atcCode", atc: 2, d: "Kodun son iki hanesi: dış halka 3., iç düğme 4. hane." })
  );
  return m;
}
/* ---------- yangın paneli P8-1 ---------- */
function fire() {
  const s = 52.9, x0 = 287.5, y0 = Y.fire, { m, q } = mod("p8_1", "P8-1", "Motor ve APU yangın kontrol paneli", "Engine and APU Fire Control Panel", "26", x0, y0, x0 + 1150, Y.r1, {
    dg: ["26-11-11", "26-11-21", "26-11-31", "26-21-11"],
    conns: [{ d: "D576", w: "W5506", at: [0.1, 0.45] }, { d: "D1078", w: "W5506", at: [0.3, 0.45] }, { d: "D580", w: "W6506", at: [0.5, 0.45] }, { d: "D1080", w: "W6506", at: [0.7, 0.45] }, { d: "D578", w: "W6506", at: [0.9, 0.45] }],
    desc: "Motor 1, APU ve motor 2 yangın kolları; aşırı ısınma/yangın algılama seçimi (OVHT DET A/B), algılama testi ve söndürücü (şişe) devre testi. Yangın kolu çekilince ilgili motor/APU'nun yakıt, bleed, hidrolik ve jeneratör bağlantısı kesilir; çevrilince seçilen şişe boşaltılır. Algılama ve kontrol: yangın algılama modülü (E/E rafı) – iki döngülü (loop A/B) dedektörler."
  });
  const p = (X, Yy) => q((X - 421) / s, (Yy - 412) / s);
  m.texts.push(["OVHT DET", ...p(498, 422), 11], ["A", ...p(466, 449), 9], ["B", ...p(520, 449), 9], ["NORMAL", ...p(496, 475), 9], ["TEST", ...p(496, 517), 10], ["FAULT\nINOP", ...p(452, 540), 8], ["OVHT\nFIRE", ...p(540, 540), 8],
    ["OVHT DET", ...p(814, 422), 11], ["A", ...p(783, 449), 9], ["B", ...p(836, 449), 9], ["NORMAL", ...p(813, 475), 9], ["ENGINES", ...p(930, 462), 10], ["EXT TEST", ...p(922, 486), 8], ["L", ...p(924, 520), 9], ["R", ...p(992, 520), 9], ["APU", ...p(934, 556), 9],
    ["FIRE SWITCHES", ...p(799, 520), 9], ["(FUEL SHUTOFF) PULL WHEN ILLUMINATED", ...p(799, 535), 6.5], ["LOCK OVERRIDE: PRESS BUTTON UNDER HANDLE", ...p(799, 548), 6.5], ["DISCH", ...p(562, 465), 8], ["DISCH", ...p(719, 465), 8], ["DISCH", ...p(878, 465), 8]);
  m.rects.push([...p(744, 514), ...p(855, 561), 6]);
  const handle = (id, X, txt, eng) => L(id, p(X, 510), txt, "r", { w: 70, h: 190, press: true, fire: eng, fpos: ["NORMAL (içeride)", "ÇEKİLİ", "SOLA ÇEVRİLİ", "SAĞA ÇEVRİLİ"],
    d: `${eng === "apu" ? "APU" : "Motor " + eng} yangın kolu. Yangın/aşırı ısınma testinde ve gerçek yangında kırmızı yanar. Çekilince: ${eng === "apu" ? "APU yakıt valfi, giriş kapağı, bleed valfi kapanır, APU jeneratörü ayrılır, APU durur" : "motor yakıt kesme ve spar valfi, bleed valfi, hidrolik kesme valfi kapanır, jeneratör ayrılır, thrust reverser kilitlenir"} ve söndürücü squib devresi hazırlanır. Sola/sağa çevrilince ${eng === "apu" ? "APU şişesi" : "sol / sağ motor şişesi"} boşaltılır. Kol, yangın uyarısı yokken mekanik kilitlidir (altındaki düğmeyle açılır).` });
  m.items.push(
    T("ovhtDet1", p(490, 447), ["A", "NORMAL", "B"], 1, { horiz: true, d: "Motor 1 aşırı ısınma/yangın dedektör seçimi: NORMAL = A ve B döngüsü birlikte (AND), A veya B = yalnız o döngü." }),
    L("ovht1", p(497, 492), "ENG 1\nOVERHEAT", "a", { w: 92, h: 44, d: "ENG 1 OVERHEAT: motor 1'de aşırı ısınma (testte de yanar)." }),
    T("fTest", p(494, 540), ["FAULT/INOP", "", "OVHT/FIRE"], 1, { horiz: true, spring: [0, 2], springMs: 4000, d: "Algılama testi. FAULT/INOP: dedektör arıza devresi testi → FAULT ve APU DET INOP yanar. OVHT/FIRE: aşırı ısınma/yangın devresi testi → yangın zili, FIRE WARN, OVERHEAT ve yangın kolları, WHEEL WELL yanar. (Uygulamada 4 sn basılı kalır.)" }),
    handle("fh1", 562, "1", 1),
    L("wheelWell", p(647, 430), "WHEEL\nWELL", "r", { w: 92, h: 44, d: "WHEEL WELL: ana iniş takımı yuvasında yangın." }),
    L("fireFault", p(647, 465), "FAULT", "a", { w: 92, h: 44, d: "FAULT: iki motordan birinde iki dedektör döngüsü de arızalı (algılama yok)." }),
    L("apuDetInop", p(647, 500), "APU DET\nINOP", "a", { w: 92, h: 44, d: "APU DET INOP: APU yangın algılama döngüsü arızalı." }),
    L("apuBottle", p(647, 535), "APU BOTTLE\nDISCHARGED", "a", { w: 92, h: 44, d: "APU şişesi boşaltıldı / basınç düşük." }),
    K("bellCut", p(734, 427), "BELL CUTOUT", 96, 28, { d: "BELL CUTOUT: yangın zilini susturur ve FIRE WARN ışıklarını söndürür (yangın kolları yanmaya devam eder)." }),
    handle("fhApu", 719, "APU", "apu"),
    T("ovhtDet2", p(808, 447), ["A", "NORMAL", "B"], 1, { horiz: true, d: "Motor 2 dedektör döngüsü seçimi." }),
    L("ovht2", p(813, 492), "ENG 2\nOVERHEAT", "a", { w: 92, h: 44, d: "ENG 2 OVERHEAT." }),
    handle("fh2", 878, "2", 2),
    L("lBottle", p(886, 440), "L BOTTLE\nDISCHARGED", "a", { w: 92, h: 44, d: "Sol motor söndürücü şişesi boşaltıldı." }),
    L("rBottle", p(948, 440), "R BOTTLE\nDISCHARGED", "a", { w: 92, h: 44, d: "Sağ motor söndürücü şişesi boşaltıldı." }),
    T("exTest", p(962, 484), ["1", "", "2"], 1, { horiz: true, spring: [0, 2], springMs: 3000, d: "EXT TEST: şişe squib (ateşleyici) devrelerinin sürekliliğini test eder. 1 ya da 2: yeşil L, R ve APU ışıkları yanmalı." }),
    L("extL", p(944, 520), "", "g", { w: 30, h: 30, round: true, d: "Sol şişe squib testi (yeşil = devre sağlam)." }),
    L("extR", p(972, 520), "", "g", { w: 30, h: 30, round: true, d: "Sağ şişe squib testi." }),
    L("extA", p(960, 546), "", "g", { w: 30, h: 30, round: true, d: "APU şişe squib testi." })
  );
  return m;
}
/* ---------- diğer modüller ---------- */
function adf() {
  const [x0, x1] = COL(0), { m, q } = mod("p8_adf", "P8-70", "ADF kontrol paneli (dual)", "Dual ADF Control Panel", "34", x0, Y.r4, x1, Y.r5, {
    dg: ["34-57-11", "34-57-21"], conns: [{ d: "D3659", w: "W2265", at: [0.3, 0.4] }, { d: "D3661", w: "W2267", at: [0.7, 0.4] }],
    desc: "ADF (otomatik yön bulucu) frekans seçimi: 190–1799,5 kHz. ADF modunda ND'de iğne NDB'yi gösterir; ANT: yalnız ses alımı. TONE: CW (taşıyıcı) yayınları duyulabilir yapar."
  });
  m.texts.push(["ACTIVE", ...q(1.55, 0.22), 11], ["STANDBY", ...q(4.2, 0.22), 11], ["ADF", ...q(0.25, 1.65), 13], ["ADF", ...q(1.6, 1.32), 9], ["ANT", ...q(2.1, 1.32), 9], ["OFF", ...q(2.95, 1.32), 9], ["ON", ...q(3.35, 1.32), 9], ["TONE", ...q(3.15, 2.3), 9]);
  m.items.push(
    D("adfA", q(1.55, 0.68), "fmt", 170, 46, { fmt: ST => (ST.mcp.adfA / 10).toFixed(1) }), D("adfS", q(4.2, 0.68), "fmt", 170, 46, { fmt: ST => (ST.mcp.adfS / 10).toFixed(1) }),
    B("adfX", q(2.88, 0.68), { r: 17, act: ST => { [ST.mcp.adfA, ST.mcp.adfS] = [ST.mcp.adfS, ST.mcp.adfA]; }, d: "Transfer." }),
    R("adfMode", q(1.85, 1.75), ["ADF", "ANT"], [-30, 30], 0, { knob: "bar", r: 30, d: "ADF: yön bulma; ANT: yalnız ses (anten modu)." }),
    T("adfTone", q(3.15, 1.75), ["OFF", "ON"], 0, { horiz: true, d: "TONE: BFO – modülasyonsuz (CW) yayınları duyulur yapar." }),
    R("adfK", q(4.75, 1.75), [""], [0], 0, { knob: "dual", r: 44, dual: true, val: "adfS", freq: freq(1900, 17995, 100, 5), d: "Frekans: dış halka 10 kHz, iç düğme 0,5 kHz." })
  );
  return m;
}
function wxr() {
  const [x0, x1] = COL(1), { m, q } = mod("p8_wxr", "P8-52", "Hava radarı kontrol paneli", "Weather Radar Control Panel", "34", x0, Y.r4, x1, Y.r5, {
    dg: ["34-41-11"], conns: [{ d: "D193", w: "W6491", at: [0.5, 0.4] }],
    desc: "Hava radarı (WXR) – iki pilot için ayrı mod, kazanç (GAIN) ve anten eğimi (TILT). MAP: yer haritalama, AUTO: otomatik kazanç/eğim (hava), MAN: el ile. TEST: radar testi (ND'de test deseni). Radar alıcı-vericisi burunda, anten radomun içinde."
  });
  m.texts.push(["TEST", ...q(2.82, 0.12), 9], ["NORM", ...q(3.3, 0.18), 9], ["WXR", ...q(0.2, 0.8), 11], ["WXR", ...q(5.55, 0.8), 11], ["GAIN", ...q(2.0, 1.15), 9], ["GAIN", ...q(3.75, 1.15), 9], ["TILT", ...q(0.85, 1.18), 9], ["TILT", ...q(4.9, 1.18), 9]);
  const side = (k, x) => [
    R("wxMode" + k, q(x, 0.6), ["MAP", "AUTO", "MAN"], [-40, 0, 40], 1, { knob: "bar", r: 30, d: "Radar modu (" + (k === "L" ? "kaptan" : "F/O") + " ND)." }),
  ];
  m.items.push(...side("L", 1.4), ...side("R", 4.3),
    R("wxTest", q(2.85, 0.55), ["TEST", "NORM"], [-35, 35], 1, { knob: "round", r: 30, d: "TEST/NORM: radar sistem testi." }),
    R("wxTiltL", q(0.85, 1.75), ["15↓", "10↓", "5↓", "0", "5↑", "10↑", "15↑"], [-120, -80, -40, 0, 40, 80, 120], 3, { knob: "grip", r: 30, d: "Kaptan anten eğimi (°)." }),
    R("wxGainL", q(2.0, 1.75), ["MIN", "CAL", "MAX"], [-90, 0, 90], 1, { knob: "bar", r: 30, d: "Kazanç: CAL = kalibre (normal)." }),
    R("wxGainR", q(3.75, 1.75), ["MIN", "CAL", "MAX"], [-90, 0, 90], 1, { knob: "bar", r: 30, d: "F/O kazanç." }),
    R("wxTiltR", q(4.9, 1.75), ["15↓", "10↓", "5↓", "0", "5↑", "10↑", "15↑"], [-120, -80, -40, 0, 40, 80, 120], 3, { knob: "grip", r: 30, d: "F/O anten eğimi." })
  );
  return m;
}
function blank(id, pn, name, en, x0, y0, x1, y1, note, conns = []) {
  const { m, q } = mod(id, pn, name, en, "", x0, y0, x1, y1, { blank: true, conns, desc: note });
  m.texts.push([pn, ...q((x1 - x0) / 200, (y1 - y0) / 200 - 0.15), 11], [name.toUpperCase(), ...q((x1 - x0) / 200, (y1 - y0) / 200 + 0.15), 8]);
  return m;
}
function printer() {
  const [x0, x1] = COL(0), { m, q } = mod("p8_prn", "P8-54", "ACMS yazıcı", "ACMS Printer", "31", x0, Y.r5, x1, Y.r6, {
    dg: ["31-33-01"], conns: [{ d: "D2649", w: "W2805", at: [0.5, 0.4] }],
    desc: "Kokpit yazıcısı: ACARS mesajları, ACMS/FDAMS raporları ve FMC çıktıları basılır. PAPER ADV: kağıt ilerletir; TEST: yazıcı test sayfası. BUSY/PAPER/FAULT ışıkları durum gösterir."
  });
  m.rects.push([...q(0.6, 0.35), ...q(5.15, 0.75), 4], [...q(0.8, 0.5), ...q(4.95, 0.58), 0]);
  m.texts.push(["PRINTER", ...q(2.88, 1.05), 12]);
  m.items.push(
    L("prnBusy", q(1.0, 1.7), "BUSY", "w", { w: 64, h: 30 }), L("prnPaper", q(1.9, 1.7), "PAPER", "a", { w: 64, h: 30, d: "Kağıt az/bitti." }), L("prnFault", q(2.8, 1.7), "FAULT", "a", { w: 64, h: 30 }),
    K("prnAdv", q(3.8, 1.7), "PAPER\nADV", 62, 40, { d: "Kağıt ilerletme." }), K("prnReset", q(4.65, 1.7), "RESET", 62, 40), K("prnTest", q(4.2, 2.45), "TEST", 62, 32, { d: "Test sayfası basar." })
  );
  return m;
}
function selcal() {
  const x0 = CW, x1 = CW + 300, { m, q } = mod("p8_selcal", "P8-66", "SELCAL paneli", "SELCAL Control Panel", "23", x0, Y.r5, x1, Y.r6, {
    dg: ["23-22-11"], conns: [{ d: "D551", w: "W2401", at: [0.5, 0.4] }],
    desc: "SELCAL (seçmeli çağrı): yer istasyonu uçağın 4 harfli kodunu gönderince ilgili telsizin ışığı yanar ve gong çalar; pilot sürekli dinlemek zorunda kalmaz. Işığa basmak sıfırlar. Kod çözücü E/E bölmesinde."
  });
  m.texts.push(["SELCAL", ...q(1.5, 0.25), 11]);
  [["VHF\n1", 0.62, 0.8], ["VHF\n2", 1.5, 0.8], ["VHF\n3", 2.38, 0.8], ["HF\n1", 1.0, 1.65], ["HF\n2", 2.0, 1.65]].forEach(([t, x, y], i) => m.items.push(L("sc" + i, q(x, y), t, "w", { w: 64, h: 58, press: true, d: t.replace("\n", " ") + " SELCAL çağrısı: yanınca o telsizden çağrı var; basınca sıfırlanır." })));
  return m;
}
function cargo() {
  const x0 = CW + 300, x1 = 2 * CW, { m, q } = mod("p8_cargo", "P8-75", "Kargo yangın paneli", "Cargo Fire Control / Smoke Detection", "26", x0, Y.r5, x1, Y.r6, {
    dg: ["26-16-21", "26-23-11"], conns: [{ d: "D12760", w: "W2110", at: [0.5, 0.4] }],
    desc: "Ön ve arka kargo bölmesi duman algılama ve söndürme. DET SELECT: algılama döngüsü (A/NORM/B). TEST: algılama ve söndürme devrelerini test eder. ARMED: söndürücü bölmesini seçer (kırmızı FWD/AFT = duman). DISCH: kapaklı anahtar, seçili bölmeye halon boşaltır."
  });
  m.texts.push(["DET SELECT", ...q(1.0, 0.18), 8], ["FWD", ...q(0.55, 0.42), 8], ["AFT", ...q(1.4, 0.42), 8], ["EXT", ...q(2.25, 0.18), 8], ["CARGO FIRE", ...q(1.37, 2.8), 9]);
  m.items.push(
    R("cgDetF", q(0.55, 0.8), ["A", "NORM", "B"], [-35, 0, 35], 1, { knob: "bar", r: 22, d: "Ön bölme dedektör döngüsü seçimi." }),
    R("cgDetA", q(1.4, 0.8), ["A", "NORM", "B"], [-35, 0, 35], 1, { knob: "bar", r: 22, d: "Arka bölme dedektör döngüsü seçimi." }),
    L("cgExtF", q(2.05, 0.55), "", "g", { w: 22, h: 22, round: true, d: "Ön squib testi (yeşil)." }), L("cgExtA", q(2.45, 0.55), "", "g", { w: 22, h: 22, round: true, d: "Arka squib testi (yeşil)." }),
    L("cgFault", q(2.25, 1.0), "DETECTOR\nFAULT", "a", { w: 70, h: 34, d: "DETECTOR FAULT: bir bölmede algılama yok." }),
    K("cgTest", q(0.55, 1.45), "TEST", 44, 30, { d: "Kargo yangın testi: FWD/AFT kırmızı ışıklar, EXT yeşil ışıklar, DISCH ve yangın zili (3 sn)." }),
    L("cgFwd", q(1.25, 1.55), "FWD\nARMED", "r", { w: 60, h: 52, press: true, latch: true, d: "FWD: ön bölmede duman algılanınca kırmızı yanar; basınca söndürme sistemi ön bölmeye hazırlanır (ARMED beyaz)." }),
    L("cgAft", q(1.95, 1.55), "AFT\nARMED", "r", { w: 60, h: 52, press: true, latch: true, d: "AFT: arka bölme için aynı." }),
    T("cgDisch", q(2.55, 1.75), ["", "DISCH"], 0, { guard: "red", gst: 0, gw: 40, gh: 70, d: "DISCH: ARMED bölmeye halon şişesini boşaltır (kapaklı)." }),
    L("cgDiscLt", q(2.55, 2.45), "DISCH", "a", { w: 46, h: 22, d: "Kargo şişesi boşaltıldı." })
  );
  return m;
}
function flood() {
  const [x0, x1] = COL(0), { m, q } = mod("p8_50", "P8-50", "Taşkın (flood) ve panel ışık kontrolü", "Flood and Panel Light Control", "33", x0, Y.r6, x1, Y.end, {
    dg: ["33-11-41", "33-14-12"], conns: [{ d: "D3432", w: "W6206", at: [0.5, 0.4] }],
    desc: "FLOOD: orta konsol üst taşkın ışığı; PANEL: P8 panel arka aydınlatması (lightplate) parlaklığı."
  });
  m.texts.push(["FLOOD", ...q(1.6, 0.2), 11], ["PANEL", ...q(3.95, 0.2), 11], ["OFF", ...q(0.95, 1.9), 9], ["OFF", ...q(3.3, 1.9), 9], ["BRIGHT", ...q(1.85, 0.5), 9], ["BRIGHT", ...q(4.2, 0.5), 9]);
  m.items.push(R("p8Flood", q(1.6, 1.25), ["OFF", "DIM", "MED", "BRIGHT"], [-130, -40, 40, 130], 0, { knob: "bar", r: 52, d: "FLOOD parlaklığı." }), R("p8Panel", q(3.95, 1.25), ["OFF", "DIM", "MED", "BRIGHT"], [-130, -40, 40, 130], 2, { knob: "bar", r: 52, d: "P8 panel aydınlatması." }));
  return m;
}
function trim() {
  const [x0, x1] = COL(1), { m, q } = mod("p8_43", "P8-43", "Rudder ve aileron trim paneli", "Rudder Trim / Aileron Trim", "27", x0, Y.r6, x1, Y.end, {
    dg: ["27-11-11", "27-21-11", "27-28-11"], conns: [{ d: "D2930", w: "W6208", at: [0.2, 0.4] }, { d: "D2934", w: "W6208", at: [0.5, 0.4] }, { d: "D3116", w: "W6208", at: [0.8, 0.4] }],
    desc: "RUDDER TRIM: yaylı düğme, rudder trim aktüatörünü (elektrik motoru) sola/sağa sürer; gösterge N159 birim cinsinden trimi gösterir. AILERON TRIM: iki yaylı anahtar birlikte itilmelidir (tek anahtar etkisiz) – aileron feel ve merkezleme ünitesini kaydırır."
  });
  m.texts.push(["RUDDER TRIM", ...q(2.88, 0.12), 10], ["AILERON", ...q(0.95, 0.88), 9], ["LEFT\nWING DOWN", ...q(0.42, 1.65), 7], ["RIGHT\nWING DOWN", ...q(1.5, 1.65), 7], ["NOSE\nLEFT", ...q(2.95, 1.0), 8], ["NOSE\nRIGHT", ...q(4.9, 1.0), 8]);
  m.items.push(
    D("rudInd", q(2.88, 0.45), "fmt", 330, 44, { fmt: ST => { const x = ST.mcp.rudTrim || 0; return (Math.abs(x).toFixed(1)) + (x < 0 ? " L" : x > 0 ? " R" : "  "); }, d: "Rudder trim göstergesi (N159): 0–15 birim sol/sağ." }),
    T("ailT1", q(0.95, 1.25), ["LEFT WING DOWN", "", "RIGHT WING DOWN"], 1, { horiz: true, spring: [0, 2], d: "Aileron trim anahtarı 1 (ikisi birlikte itilmeli)." }),
    T("ailT2", q(0.95, 1.78), ["LEFT WING DOWN", "", "RIGHT WING DOWN"], 1, { horiz: true, spring: [0, 2], d: "Aileron trim anahtarı 2." }),
    R("rudTrimK", q(3.9, 1.45), ["NOSE LEFT", "", "NOSE RIGHT"], [-40, 0, 40], 1, { knob: "bar", r: 50, spring: [0, 2], d: "Rudder trim: sola/sağa çevir (yaylı). Her çevirme 0,5 birim." })
  );
  return m;
}
function stabDoor() {
  const [x0, x1] = COL(2), { m, q } = mod("p8_47", "P8-47", "Stab trim ve kokpit kapısı paneli", "Stab Trim and Cabin Door Lock Panel", "27/52", x0, Y.r6, x1, Y.end, {
    dg: ["27-41-11", "52-51-11"], conns: [{ d: "D3428", w: "W6206", at: [0.3, 0.4] }, { d: "D698", w: "W6208", at: [0.7, 0.4] }],
    desc: "STAB TRIM OVRD/NORM: NORM'da kolon trim kesme anahtarları (yanlış yönde kolon hareketi) stabilizer trimini durdurur; OVRD bu kesmeyi devre dışı bırakır (kapaklı). FLT DK DOOR: UNLKD = kapıyı açar, AUTO = normal (acil erişim kodu girilince süre sonunda açılır), DENY = acil erişim isteğini reddeder. LOCK FAIL: kilit arızası; AUTO UNLK: acil erişim kodu girildi, kapı geri sayımda."
  });
  m.texts.push(["STAB TRIM", ...q(0.9, 0.18), 10], ["OVRD", ...q(1.3, 0.75), 9], ["NORM", ...q(1.3, 1.4), 9], ["FLT DK DOOR", ...q(3.6, 0.18), 10], ["UNLKD", ...q(3.95, 0.48), 8], ["AUTO", ...q(4.45, 0.35), 8], ["DENY", ...q(5.15, 0.48), 8]);
  m.lines.push([...q(1.75, 0.2), ...q(1.75, 2.1)]);
  m.items.push(
    T("stabOvrd", q(0.75, 1.05), ["OVRD", "NORM"], 1, { guard: "red", gst: 1, gw: 44, gh: 90, d: "STAB TRIM OVRD/NORM (kapaklı, normalde NORM)." }),
    L("lockFail", q(2.55, 0.85), "LOCK\nFAIL", "a", { w: 64, h: 36, d: "LOCK FAIL: kapı kilidi arızalı veya kilit modülü güç kaybı." }),
    L("autoUnlk", q(2.55, 1.35), "AUTO\nUNLK", "a", { w: 64, h: 36, d: "AUTO UNLK: kabinden acil erişim kodu girildi; DENY yapılmazsa kapı süre sonunda açılır." }),
    R("fdDoor", q(4.45, 1.15), ["UNLKD", "AUTO", "DENY"], [-45, 0, 45], 1, { knob: "bar", r: 50, spring: [0, 2], d: "Kokpit kapısı kilit seçici (yaylı UNLKD/DENY, normal AUTO)." })
  );
  return m;
}

const MODS = [
  fire(),
  rtp(1, "P8-2", 0, "D203", "W2403"), rtp(3, "P8-8", 1, "D549", "W2407"), rtp(2, "P8-3", 2, "D209", "W2405"),
  nav(1, "P8-25", 0, [{ d: "D303", w: "W2149", at: [0.3, 0.4] }, { d: "D263", w: "W2149", at: [0.7, 0.4] }]),
  blank("p8_40", "P8-40", "ACARS kontrol (provizyon)", "ACARS Control", CW, Y.r2, 2 * CW, Y.r3, "ACARS kontrol paneli yeri. Bu filoda ACARS MCDU üzerinden kullanılır; konnektör D1963 (W2801) seçili uçakta bağlı değil.", [{ d: "D1963", w: "W2801", at: [0.5, 0.4] }]),
  nav(2, "P8-26", 2, [{ d: "D305", w: "W2151", at: [0.3, 0.4] }, { d: "D265", w: "W2151", at: [0.7, 0.4] }]),
  acp("L", "P8-6", 0, [{ d: "D131", w: "W3323", at: [0.3, 0.4] }, { d: "D133", w: "W3323", at: [0.7, 0.4] }]),
  atc(),
  acp("R", "P8-7", 2, [{ d: "D135", w: "W3319", at: [0.3, 0.4] }, { d: "D137", w: "W3319", at: [0.7, 0.4] }]),
  adf(), wxr(),
  blank("p8_11", "P8-11", "HF-1 (takılı değil)", "HF-1 Control Panel", 2 * CW, Y.r4, 2 * CW + 288, Y.r5, "HF-1 kontrol paneli yeri. Seçili filoda HF takılı değil (WDM Equipment List'te D419 kaydı yok).", [{ d: "D419", w: "W2511", at: [0.5, 0.4] }]),
  blank("p8_12", "P8-12", "HF-2 (takılı değil)", "HF-2 Control Panel", 2 * CW + 288, Y.r4, 3 * CW, Y.r5, "HF-2 kontrol paneli yeri (D773 kaydı yok).", [{ d: "D773", w: "W2515", at: [0.5, 0.4] }]),
  printer(), selcal(), cargo(),
  blank("p8_53", "P8-53", "Gözlemci ses paneli (provizyon)", "OBS Audio Selector", 2 * CW, Y.r5, 3 * CW, Y.r6, "Gözlemci (OBS) ses seçici paneli yeri; seçili uçakta konnektör D11133/D11135 kaydı yok.", [{ d: "D11133", w: "W3327", at: [0.3, 0.4] }, { d: "D11135", w: "W3327", at: [0.7, 0.4] }]),
  flood(), trim(), stabDoor()
];

export const P8 = {
  id: "p8", PX: U, OX: 0, OY: 0, x1: 3 * CW, yRow: Y.end, rails: [], modules: MODS,
  outline: [[287.5, 0], [1437.5, 0], [1437.5, Y.r1], [3 * CW, Y.r1], [3 * CW, Y.end], [0, Y.end], [0, Y.r1], [287.5, Y.r1]]
};
export const P8_BUNDLES = {
  W5506: "Yangın paneli – motor 1/APU", W6506: "Yangın paneli – APU/motor 2", W2403: "VHF 1 kontrol", W2407: "VHF 3 kontrol", W2405: "VHF 2 kontrol", W2149: "VHF NAV 1", W2151: "VHF NAV 2", W2801: "ACARS",
  W3323: "Kaptan ACP", W3319: "F/O ACP", W2247: "ATC 2", W2177: "ATC 1", W2265: "ADF 1", W2267: "ADF 2", W6491: "Hava radarı", W2511: "HF 1", W2515: "HF 2", W2805: "Yazıcı", W2401: "SELCAL", W2110: "Kargo duman algılama",
  W3327: "OBS ses", W6206: "P8 aydınlatma / kapı", W6208: "Trim kontrolleri"
};
export const P8_CONN_PN = {
  D576: ["BACC45FT18-31S8", "26-21-11"], D1078: ["BACC45FT18-31S", "26-21-11"], D580: ["BACC45FT18-31S7", "26-21-11"], D1080: ["BACC45FT18-31S6", "26-21-11"], D578: ["BACC45FT18-31S9", "26-21-11"],
  D203: ["BACC63CB20-41SN", "23-12-11"], D549: ["BACC63CB20-41SN", "23-12-31"], D209: ["BACC63CB20-41SN", "23-12-21"], D303: ["BACC63CB22-55SN", "34-51-11"], D263: ["BACC63CB22-55S8", "34-51-11"],
  D305: ["BACC63CB22-55SN", "34-51-21"], D265: ["BACC63CB22-55S8", "34-51-21"], D1963: ["MS3126F20-41S", "23-27-31"], D131: ["BACC45FT14A15S7", "23-22-11"], D133: ["MS3126F14-19S", "23-51-11"],
  D135: ["BACC45FT14A15S7", "23-22-11"], D137: ["MS3126F14-19S", "23-51-21"], D519: ["BACC45FT16-24S8", "34-53-21"], D211: ["BACC45FT16-24S7", "34-53-11"], D3659: ["BACC63CB16-24S6", "34-57-11"],
  D3661: ["BACC63CB16-24S9", "34-57-21"], D193: ["MS3126F18-32S", "34-41-11"], D2649: ["MS3126F20-41S", "31-33-01"], D551: ["MS3475W14-19S", "23-22-11"], D12760: ["BACC45FT24-61S", "26-16-21"],
  D3432: ["BACC45FT16-10S", "33-11-41"], D2930: ["BACC45FT12-12S7", "27-11-11"], D2934: ["BACC63CB12-12SN", "27-28-11"], D3116: ["BACC45FT12-12S6", "27-21-11"], D3428: ["BACC45FT16-24S", "52-51-11"], D698: ["BACC45FT12-12S", "27-41-11"]
};
export const P8_DEFAULTS = { vhf1A: 118100, vhf1S: 121500, vhf2A: 121500, vhf2S: 131725, vhf3A: 131550, vhf3S: 129900, nav1A: 110300, nav1S: 113600, nav2A: 110300, nav2S: 116400, adfA: 3250, adfS: 4100, atcCode: "2000", rudTrim: 0, rtp1: 1, rtp2: 2, rtp3: 3 };
