// 737NG P5 overhead panel (ön ve aft bölüm) – AMM 31-11-94/95 ve WDM 91-02-05'e göre 3D model.
import * as THREE from '../three.module.js';
import { OrbitControls } from '../OrbitControls.js';
import { RoomEnvironment } from '../RoomEnvironment.js';
import { mergeGeometries } from '../BufferGeometryUtils.js';
import * as FWD from './layout.js';
import { AFT, AFT_BUNDLES, AFT_CONN_PN } from './layout_aft.js';
import { S as ST, onState, emit } from './state.js';
import * as DATA from './data.js';
import * as PW from './power.js';
import * as TOOLS from './tools.js';

const PPI = 112;
const FF = '"RC", "Roboto Condensed", "Arial Narrow", sans-serif';
const TXT = 0.8;
const DEPTH = 3.0;
const Z_BACK = -0.05 - DEPTH;
const Z_LANE = -5.0;
const PULL = 7;
let PX = 64.7, OX = 18, OY = 25;          // etkin panelin ölçeği (buildScene ayarlar)
const X = px => (px - OX) / PX;
const Y = py => -(py - OY) / PX;

const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const LEGEND_COL = { a: 0xffa424, b: 0x55b8ff, g: 0x5ee07a, w: 0xf2f2f2 };

export function cfgFor(panel) {
  if (panel === "aft") return {
    key: "aft", PX: AFT.PX, OX: AFT.OX, OY: AFT.OY, x0: AFT.OX, x1: AFT.x1, yRow: AFT.yRow, rails: AFT.rails, modules: AFT.modules, bottom: AFT.bottom, topParts: AFT.topParts,
    bundles: { ...FWD.BUNDLES, ...AFT_BUNDLES }, connPN: { ...FWD.CONN_PN, ...AFT_CONN_PN }, topBand: 1.6, bottomH: (960 - 775) / AFT.PX, ltTarget: [906, 130], ltName: "L385 aft ışık plakası beslemesi",
    tbL: 5.8, tbR: 20.4, tbY: 0.55, title: "737NG aft overhead paneli (P5 arka bölüm)",
    src: "AMM 31-11-95 Fig. 101 (aft overhead yerleşimi), WDM 91-02-05 Sheet 2 (YC503-YC570; konnektör ve demet numaraları), WDM Equipment List D280A117, Master Bundle List."
  };
  return {
    key: "fwd", PX: FWD.PX, OX: FWD.OX, OY: FWD.OY, x0: FWD.PANEL.x0, x1: FWD.PANEL.x1, yRow: FWD.PANEL.yRow, rails: [18, 390, 768, 951, 1329.5, 1702], modules: FWD.MODULES, bottom: FWD.BOTTOM, topParts: FWD.TOP_PARTS,
    bundles: FWD.BUNDLES, connPN: FWD.CONN_PN, topBand: 2.2, bottomH: 2.85, ltTarget: [858, 465], ltName: "T31 P5 panel aydınlatma trafosu",
    tbL: 2.7, tbR: 23.3, tbY: 1.45, title: "737NG ön overhead paneli (P5)",
    src: "AMM 31-11-94 Fig. 101 (ön yüz yerleşimi), WDM 91-02-05 Sheet 1 (737-700 ve 737-800 sayfaları; konnektör ve demet numaraları), WDM Equipment List D280A117 (parça numaraları), SWPM 20-61-11."
  };
}

let fontsP = null;
function loadFonts() {
  if (!fontsP) fontsP = Promise.all([["rc500.woff2", "500"], ["rc700.woff2", "700"]].map(([f, w]) => {
    try { const ff = new FontFace("RC", `url(${new URL("./" + f, import.meta.url)})`, { weight: w }); return ff.load().then(x => document.fonts.add(x)).catch(() => {}); }
    catch (e) { return Promise.resolve(); }
  }));
  return fontsP;
}

/* ============================ YARDIMCI ============================ */
function canvas(w, h) { const c = document.createElement("canvas"); c.width = Math.max(4, Math.round(w)); c.height = Math.max(4, Math.round(h)); return c; }
function tex(c, aniso) { const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = aniso || 4; return t; }
function textLines(g, txt, x, y, size, opts = {}) {
  const lines = String(txt).split("\n");
  g.font = `${opts.weight || 700} ${size}px ${FF}`; g.textAlign = opts.align || "center"; g.textBaseline = "middle";
  const lh = size * 1.02, y0 = y - (lines.length - 1) * lh / 2;
  lines.forEach((ln, i) => g.fillText(ln, x, y0 + i * lh));
}
function rrect(g, x, y, w, h, r) { r = Math.max(0, Math.min(r, w / 2, h / 2)); g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
function knobLabels(o) { return !(o.noLabels || o.dim || o.knob === "xfeed" || o.knob === "grip" || o.pos.length < 2); }
const cylZ = (r1, r2, h, seg = 24, open = false) => { const g = new THREE.CylinderGeometry(r1, r2, h, seg, 1, open); g.rotateX(Math.PI / 2); return g; };
export function parsePN(pn) {
  const m = /^BACC45F([TN])(\d+)([A-E]|-)(\d+)([PS])(\d)?$/.exec(pn || "");
  if (!m) return null;
  return { plug: m[1] === "T", shell: +m[2], clamp: m[3], insert: +m[4], contact: m[5], key: m[6] || "N" };
}
export const CLAMP = { "-": "kablo kelepçesi yok", A: "BACC10GH düz tek bacaklı kelepçe", B: "MS27559 dik açılı saddle kelepçe", C: "MS27291 düz saddle kelepçe", D: "BACC10JC dik açılı tek bacaklı kelepçe", E: "BACC10JS düz kompozit kelepçe" };

/* ============================ DOKULAR ============================ */
// Ön yüz: renkli doku + gece aydınlatması için yazı maskesi (yarı çözünürlük)
function drawFace(m, items, w, h, shaped) {
  const c = canvas(w * PPI, h * PPI), g = c.getContext("2d");
  const [x0, y0] = m.rect, P = v => v * PPI, FX = px => (px - x0) / PX * PPI, FY = py => (py - y0) / PX * PPI, FS = s => s / PX * PPI * TXT;
  const grd = g.createLinearGradient(0, 0, 0, c.height); grd.addColorStop(0, "#747c82"); grd.addColorStop(1, "#6c747a");
  g.fillStyle = grd; g.fillRect(0, 0, c.width, c.height);
  const img = g.getImageData(0, 0, c.width, c.height), d = img.data;
  for (let i = 0; i < d.length; i += 4) { const n = (Math.random() - 0.5) * 6; d[i] += n; d[i + 1] += n; d[i + 2] += n; }
  g.putImageData(img, 0, 0);
  if (!shaped) {
    g.strokeStyle = "rgba(255,255,255,.16)"; g.lineWidth = 3; g.beginPath(); g.moveTo(2, c.height - 2); g.lineTo(2, 2); g.lineTo(c.width - 2, 2); g.stroke();
    g.strokeStyle = "rgba(0,0,0,.32)"; g.beginPath(); g.moveTo(c.width - 2, 2); g.lineTo(c.width - 2, c.height - 2); g.lineTo(2, c.height - 2); g.stroke();
  }
  if (m.blank) return { map: tex(c, 8), mask: null };
  const mc = canvas(w * PPI / 2, h * PPI / 2), mg = mc.getContext("2d");
  mg.fillStyle = "#000"; mg.fillRect(0, 0, mc.width, mc.height); mg.scale(0.5, 0.5);
  const ink = (gg, col) => {
    gg.strokeStyle = col; gg.fillStyle = col; gg.lineWidth = P(0.016);
    for (const [a, b, cc, dd, r] of (m.rects || [])) { rrect(gg, FX(a), FY(b), FX(cc) - FX(a), FY(dd) - FY(b), (r || 0) / PX * PPI); gg.stroke(); }
    for (const [a, b, cc, dd] of (m.lines || [])) { gg.beginPath(); gg.moveTo(FX(a), FY(b)); gg.lineTo(FX(cc), FY(dd)); gg.stroke(); }
    for (const [txt, px, py, size = 10.5, align = "center", deco] of (m.texts || [])) {
      gg.fillStyle = col; textLines(gg, txt, FX(px), FY(py), FS(size), { align, weight: size >= 11.5 ? 700 : 600 });
      if (deco) {
        const tw = gg.measureText(txt).width, gap = P(0.08);
        const left = deco === "line" ? P(0.2) : FX(px) - tw / 2 - P(1.0), right = deco === "line" ? w * PPI - P(0.2) : FX(px) + tw / 2 + P(1.0);
        gg.beginPath(); gg.moveTo(left, FY(py)); gg.lineTo(FX(px) - tw / 2 - gap, FY(py)); gg.moveTo(FX(px) + tw / 2 + gap, FY(py)); gg.lineTo(right, FY(py)); gg.stroke();
      }
    }
  };
  const itemsPass = (gg, col, bg) => {
    for (const o of items) {
      const cx = FX(o.at[0]), cy = FY(o.at[1]);
      if (o.t === "L") { if (bg) { gg.fillStyle = "#1b1d20"; const lw = (o.w / PX + 0.06) * PPI, lh = (o.h / PX + 0.06) * PPI; gg.fillRect(cx - lw / 2, cy - lh / 2, lw, lh); } }
      else if (o.t === "T") { if (bg) { gg.fillStyle = "#2b2f33"; gg.beginPath(); gg.arc(cx, cy, P(0.16), 0, 7); gg.fill(); if (o.style === "slot") { gg.fillStyle = "#1c1f22"; gg.fillRect(cx - P(0.13), cy - P(0.5), P(0.26), P(0.95)); } } }
      else if (o.t === "R" && knobLabels(o)) {
        const r = (o.labelR || o.r * 1.42) / PX * PPI;
        gg.strokeStyle = col; gg.lineWidth = P(0.014);
        o.pos.forEach((p, i) => {
          const a = (o.ang[i] - 90) * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
          gg.beginPath(); gg.moveTo(cx + ca * r * 0.72, cy + sa * r * 0.72); gg.lineTo(cx + ca * r * 0.84, cy + sa * r * 0.84); gg.stroke();
          if (!p) return;
          gg.fillStyle = col; textLines(gg, p, cx + ca * r * 1.0, cy + sa * r * 0.98, FS(9.5), { weight: 600, align: Math.abs(ca) < 0.3 ? "center" : ca < 0 ? "right" : "left" });
        });
        if (o.arc) { gg.beginPath(); gg.arc(cx, cy, r * 0.78, (o.ang[1] - 90) * Math.PI / 180, (o.ang[o.ang.length - 1] - 90) * Math.PI / 180); gg.stroke(); }
      }
      else if (o.t === "R" && o.dim) { const r = o.r * 1.25 / PX * PPI; gg.strokeStyle = col; gg.lineWidth = P(0.014); gg.beginPath(); gg.arc(cx, cy, r, (-150 - 90) * Math.PI / 180, (30 - 90) * Math.PI / 180); gg.stroke(); }
      else if (!bg) continue;
      else if (o.t === "G") {
        const r = o.r / PX * PPI; gg.fillStyle = "#16181b";
        if (o.shape === "oct") { gg.beginPath(); for (let k = 0; k < 8; k++) { const a = (k + 0.5) * Math.PI / 4; gg.lineTo(cx + Math.cos(a) * r * 1.22, cy + Math.sin(a) * r * 1.22); } gg.fill(); }
        else if (o.shape === "sq") { rrect(gg, cx - r * 1.12, cy - r * 1.12, r * 2.24, r * 2.24, r * 0.2); gg.fill(); }
        else if (o.shape === "tear") { gg.beginPath(); gg.arc(cx, cy, r * 1.12, 0, 7); gg.fill(); gg.beginPath(); gg.moveTo(cx - r * 1.0, cy - r * 0.5); gg.lineTo(cx - r * 2.0, cy); gg.lineTo(cx - r * 1.0, cy + r * 0.5); gg.fill(); gg.beginPath(); gg.moveTo(cx + r * 1.0, cy - r * 0.5); gg.lineTo(cx + r * 2.0, cy); gg.lineTo(cx + r * 1.0, cy + r * 0.5); gg.fill(); }
        else { gg.beginPath(); gg.arc(cx, cy, r * 1.1, 0, 7); gg.fill(); }
      }
      else if (o.t === "D") { gg.fillStyle = "#16181b"; const ww = o.w / PX * PPI, hh = o.h / PX * PPI; rrect(gg, cx - ww / 2 - P(0.07), cy - hh / 2 - P(0.07), ww + P(0.14), hh + P(0.14), P(0.08)); gg.fill(); }
      else if (o.t === "B") { gg.fillStyle = "#24272b"; gg.beginPath(); gg.arc(cx, cy, o.r / PX * PPI * 1.35, 0, 7); gg.fill(); }
    }
  };
  ink(g, "#f2f2ec"); itemsPass(g, "#f2f2ec", true);
  ink(mg, "#ffffff"); itemsPass(mg, "#ffffff", false);
  g.fillStyle = "#3a3f44";
  if (!shaped) for (const [x, y] of [[0.17, 0.17], [w - 0.17, 0.17], [0.17, h - 0.17], [w - 0.17, h - 0.17]]) { g.beginPath(); g.arc(P(x), P(y), P(0.1), 0, 7); g.fill(); }
  return { map: tex(c, 8), mask: tex(mc, 4) };
}

function legendTex(txt, w, h, bg = "#151413") {
  const c = canvas(220, Math.max(24, 220 * h / w)), g = c.getContext("2d");
  g.fillStyle = bg; g.fillRect(0, 0, c.width, c.height);
  if (txt) {
    const lines = txt.split("\n"), vertical = lines.length > 4;
    let size = vertical ? c.height / (lines.length + 1) : Math.min(c.height / (lines.length + 0.8), 44);
    g.font = `700 ${size}px ${FF}`;
    const mw = Math.max(...lines.map(l => g.measureText(l).width));
    if (mw > c.width * 0.88) size *= c.width * 0.88 / mw;
    g.fillStyle = "#f2f2f2"; textLines(g, txt, c.width / 2, c.height / 2, size);
  }
  return tex(c);
}

const DIALS = {
  fueltemp: { min: -40, max: 40, a0: -150, a1: 150, major: 20, val: [18], unit: "°C", title: "FUEL\nTEMP" },
  egt: { min: 0, max: 10, a0: -230, a1: 40, major: 2, val: [0], unit: "°C x 100", title: "EGT", red: 9.6 },
  duct: { min: 0, max: 80, a0: 120, a1: -120, major: 20, val: [32, 30], unit: "PSI", title: "DUCT\nPRESS" },
  airtemp: { min: 0, max: 100, a0: -150, a1: 150, major: 20, val: [24], unit: "°C", title: "TEMP" },
  cabalt: { min: 0, max: 50, a0: -150, a1: 150, major: 5, val: [0.4, 0], unit: "x 1000 FEET", title: "CABIN\nALT", inner: { min: 0, max: 10, major: 1, a0: -150, a1: 150 } },
  climb: { min: -2, max: 2, a0: -270, a1: 90, major: 0.5, val: [0], unit: "1000 FT/MIN", title: "CABIN\nCLIMB", labels: [[-2, "2"], [-1, "1"], [-0.5, ".5"], [0, "0"], [0.5, ".5"], [1, "1"], [2, "2"]] },
  outflow: { min: 0, max: 1, a0: -60, a1: 60, major: 1, val: [0.85], unit: "", labels: [] },
  oxy: { min: 0, max: 20, a0: -135, a1: 135, major: 4, val: [18.5], unit: "PSI x 100", title: "OXY\nPRESS" }
};
const dialAngle = (q, v) => q.a0 + (Math.max(q.min, Math.min(q.max, v)) - q.min) / (q.max - q.min) * (q.a1 - q.a0);
function dialTex(kind) {
  const s = DIALS[kind], N = 384, c = canvas(N, N), g = c.getContext("2d"), r = N / 2;
  const light = kind === "outflow";
  g.fillStyle = light ? "#e9e6dc" : "#0f1012"; g.beginPath(); g.arc(r, r, r, 0, 7); g.fill();
  const fg = light ? "#111" : "#f0f0ea";
  const ring = (q, R, lab, col) => {
    g.strokeStyle = col; g.fillStyle = col;
    const step = q.major / 5;
    for (let v = q.min; v <= q.max + 1e-6; v += step) {
      const a = (dialAngle(q, v) - 90) * Math.PI / 180, k = (v - q.min) / q.major, maj = Math.abs(k - Math.round(k)) < 1e-6;
      g.lineWidth = maj ? 4 : 2; const r1 = R * (maj ? 0.8 : 0.88);
      g.beginPath(); g.moveTo(r + Math.cos(a) * r1, r + Math.sin(a) * r1); g.lineTo(r + Math.cos(a) * R * 0.96, r + Math.sin(a) * R * 0.96); g.stroke();
    }
    const labs = q.labels || (() => { const L = []; const st = (q.max - q.min) / q.major > 8 ? q.major * 2 : q.major; for (let v = q.min; v <= q.max + 1e-6; v += st) L.push([v, String(Math.round(v * 10) / 10)]); return L; })();
    for (const [v, t] of labs) { const a = (dialAngle(q, v) - 90) * Math.PI / 180; textLines(g, t, r + Math.cos(a) * R * 0.63, r + Math.sin(a) * R * 0.63, lab); }
  };
  ring(s, r * 0.97, 38, fg);
  if (s.inner) ring(s.inner, r * 0.5, 24, "#f0f0ea");
  if (s.red != null) { const a = (dialAngle(s, s.red) - 90) * Math.PI / 180; g.strokeStyle = "#e23b2e"; g.lineWidth = 10; g.beginPath(); g.moveTo(r + Math.cos(a) * r * 0.74, r + Math.sin(a) * r * 0.74); g.lineTo(r + Math.cos(a) * r * 0.94, r + Math.sin(a) * r * 0.94); g.stroke(); }
  g.fillStyle = fg;
  if (s.title) textLines(g, s.title, r, r - r * (s.inner ? 0.12 : 0.3), s.inner ? 22 : 30);
  if (s.unit) textLines(g, s.unit, r, r + r * 0.4, 20, { weight: 500 });
  return tex(c);
}
const SEG = "#f4ad3a";
function drawLcd(g, W, H, kind, v) {
  g.fillStyle = "#101410"; g.fillRect(0, 0, W, H);
  if (!v) return;
  g.fillStyle = SEG;
  if (kind === "elec") { const d = (t, x, y) => textLines(g, t, x * W, y * H, H * 0.26); d(v.dA, 0.3, 0.33); d(v.f, 0.72, 0.33); d(v.dV, 0.3, 0.73); d(v.aA, 0.55, 0.73); d(v.aV, 0.8, 0.73); }
  else textLines(g, v.txt, W * 0.92, H / 2 + 2, H * (v.small ? 0.5 : 0.72), { align: "right" });
}
function moduleLabelTex(m) {
  const c = canvas(512, 256), g = c.getContext("2d");
  g.fillStyle = "#e9e6dc"; g.fillRect(0, 0, 512, 256); g.strokeStyle = "#555"; g.lineWidth = 4; g.strokeRect(6, 6, 500, 244);
  g.fillStyle = "#222"; textLines(g, m.pn, 256, 50, 46);
  textLines(g, m.en.toUpperCase(), 256, 120, m.en.length > 30 ? 21 : 28, { weight: 500 });
  textLines(g, "BOEING  P/N: —", 256, 178, 24, { weight: 500 }); textLines(g, "S/N: —", 256, 216, 24, { weight: 500 });
  return tex(c);
}
function idTagTex(t1, t2) {
  const c = canvas(256, 96), g = c.getContext("2d");
  g.fillStyle = "#f4f2ea"; g.fillRect(0, 0, 256, 96); g.fillStyle = "#111";
  textLines(g, t1, 128, t2 ? 34 : 48, 40); if (t2) textLines(g, t2, 128, 74, 26, { weight: 500 });
  return tex(c);
}
const insertCache = {};
function insertTex(n, sockets) {
  const key = n + (sockets ? "s" : "p"); if (insertCache[key]) return insertCache[key];
  const N = 256, c = canvas(N, N), g = c.getContext("2d"), r = N / 2;
  g.fillStyle = "#1f1f1f"; g.beginPath(); g.arc(r, r, r, 0, 7); g.fill();
  const pts = []; if (n % 2) pts.push([0, 0]);
  const rings = Math.max(1, Math.ceil((Math.sqrt(12 * n - 3) - 3) / 6)); let ring = 0;
  while (pts.length < n) { ring++; const cnt = Math.min(n - pts.length, ring * 6 + (ring === rings ? 99 : 0)); const rr = ring / (rings + 0.5); for (let i = 0; i < cnt; i++) { const a = i / cnt * Math.PI * 2 + ring * 0.4; pts.push([Math.cos(a) * rr, Math.sin(a) * rr]); } }
  const dot = Math.max(3, 64 / Math.sqrt(n + 4));
  for (const [x, y] of pts) { g.fillStyle = sockets ? "#080808" : "#d4a537"; g.beginPath(); g.arc(r + x * r * 0.86, r + y * r * 0.86, dot, 0, 7); g.fill(); if (sockets) { g.strokeStyle = "#5a5a5a"; g.lineWidth = 1.5; g.stroke(); } }
  g.fillStyle = "#cfcfcf"; g.font = `600 18px ${FF}`; g.textAlign = "center"; g.fillText("A", r, 18);
  return (insertCache[key] = tex(c));
}

/* ============================ SAHNE ============================ */
function buildScene(scene, cfg, tail) {
  PX = cfg.PX; OX = cfg.OX; OY = cfg.OY;
  const PW = (cfg.x1 - cfg.x0) / PX, PH_MOD = (cfg.yRow - cfg.OY) / PX, TOPB = cfg.topBand;
  const HINGE = new THREE.Vector3(0, TOPB, -5.6);
  const M = {
    chrome: new THREE.MeshStandardMaterial({ color: 0xd8dadc, metalness: 1, roughness: 0.22 }),
    black: new THREE.MeshStandardMaterial({ color: 0x141517, metalness: 0.2, roughness: 0.55 }),
    blackGloss: new THREE.MeshStandardMaterial({ color: 0x0c0c0d, metalness: 0.3, roughness: 0.3 }),
    white: new THREE.MeshStandardMaterial({ color: 0xf2f2ee, roughness: 0.5, emissive: 0xffe2b0, emissiveIntensity: 0 }),
    edge: new THREE.MeshStandardMaterial({ color: 0x5c646a, metalness: 0.4, roughness: 0.5 }),
    housing: new THREE.MeshStandardMaterial({ color: 0x4a5056, metalness: 0.65, roughness: 0.45 }),
    alodine: new THREE.MeshStandardMaterial({ color: 0xb9a66a, metalness: 0.8, roughness: 0.38 }),
    rail: new THREE.MeshStandardMaterial({ color: 0x30353a, metalness: 0.7, roughness: 0.4 }),
    tray: new THREE.MeshStandardMaterial({ color: 0x8a9298, metalness: 0.55, roughness: 0.5, side: THREE.DoubleSide }),
    connShell: new THREE.MeshStandardMaterial({ color: 0x5f6a4c, metalness: 0.75, roughness: 0.38 }),
    connRing: new THREE.MeshStandardMaterial({ color: 0x4d573c, metalness: 0.7, roughness: 0.42 }),
    backshell: new THREE.MeshStandardMaterial({ color: 0x9fa6ad, metalness: 0.9, roughness: 0.3 }),
    wire: new THREE.MeshStandardMaterial({ color: 0xe6e2d3, metalness: 0, roughness: 0.75 }),
    wireLt: new THREE.MeshStandardMaterial({ color: 0xd9d4c2, metalness: 0, roughness: 0.8 }),
    sleeve: new THREE.MeshStandardMaterial({ color: 0x232527, metalness: 0, roughness: 0.9 }),
    nylon: new THREE.MeshStandardMaterial({ color: 0xe8e3cf, metalness: 0, roughness: 0.6 }),
    brass: new THREE.MeshStandardMaterial({ color: 0xb08d57, metalness: 1, roughness: 0.35 }),
    guardRed: new THREE.MeshPhysicalMaterial({ color: 0xb3221b, metalness: 0, roughness: 0.28, clearcoat: 0.6, clearcoatRoughness: 0.25 }),
    guardYel: new THREE.MeshPhysicalMaterial({ color: 0xd8b21f, metalness: 0, roughness: 0.3, clearcoat: 0.5, clearcoatRoughness: 0.3 }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0xffffff, metalness: 0, roughness: 0.04, transparent: true, opacity: 0.14, depthWrite: false }),
    ceiling: new THREE.MeshStandardMaterial({ color: 0x9aa7b4, metalness: 0.2, roughness: 0.8, transparent: true, opacity: 0.16, side: THREE.DoubleSide, depthWrite: false }),
    bezel: new THREE.MeshStandardMaterial({ color: 0x9aa0a4, metalness: 0.1, roughness: 0.7 }),
    key: new THREE.MeshStandardMaterial({ color: 0x3b3f44, metalness: 0.2, roughness: 0.5 })
  };
  const Gm = {
    bushing: mergeGeometries([cylZ(0.085, 0.085, 0.2, 20).translate(0, 0, 0.1), cylZ(0.15, 0.15, 0.055, 6).translate(0, 0, 0.03)]),
    lever: mergeGeometries([cylZ(0.032, 0.045, 0.46, 14).translate(0, 0, 0.23), cylZ(0.062, 0.05, 0.13, 16).translate(0, 0, 0.5), new THREE.SphereGeometry(0.062, 16, 10).translate(0, 0, 0.565)]),
    paddle: mergeGeometries([cylZ(0.04, 0.05, 0.25, 12).translate(0, 0, 0.12), new THREE.BoxGeometry(0.34, 0.09, 0.34).translate(0, 0, 0.4)]),
    slotLever: mergeGeometries([new THREE.BoxGeometry(0.16, 0.08, 0.3).translate(0, 0, 0.15), new THREE.BoxGeometry(0.2, 0.2, 0.08).translate(0, 0, 0.32)]),
    needle: new THREE.BoxGeometry(0.03, 1, 0.012).translate(0, 0.5, 0),
    dzus: cylZ(0.1, 0.1, 0.04, 18).translate(0, 0, 0.02), dzusSlot: new THREE.BoxGeometry(0.14, 0.024, 0.01).translate(0, 0, 0.042)
  };

  const root = new THREE.Group(); root.position.copy(HINGE); scene.add(root);
  const panel = new THREE.Group(); panel.position.copy(HINGE).multiplyScalar(-1); root.add(panel);
  const parts = [], ctrls = [], lightsById = {}, mods = [], back = [], faceMats = [], bundleParts = {}, plugs = {};
  const shadowAll = o => o.traverse(x => { if (x.isMesh) { x.castShadow = true; x.receiveShadow = true; } });
  const tag = (obj, p) => obj.traverse(x => { if (x.isMesh && !x.userData.ctrl && !x.userData.connOf) x.userData.part = p; });
  const effConns = m => (m.conns || []).filter(c => !c.eff || DATA.effOk(c.eff, tail));

  function buildModule(m, hOverride) {
    const [x0, y0, x1, y1] = m.rect, w = (x1 - x0) / PX, h = hOverride || (y1 - y0) / PX;
    const grp = new THREE.Group(); grp.position.set(X(x0), Y(y0), 0);
    const part = { id: m.id, kind: "module", m, name: m.name, obj: grp, base: grp.position.clone(), pull: 0, conns: [], w, h, dzus: [] };
    const L = (px, py) => [(px - x0) / PX, -(py - y0) / PX];
    const face = drawFace(m, m.items, w, h, !!m.shape);
    const faceMat = new THREE.MeshStandardMaterial({ map: face.map, metalness: 0.15, roughness: 0.62, emissive: face.mask ? 0xffdca0 : 0, emissiveMap: face.mask, emissiveIntensity: 0 });
    if (face.mask) faceMats.push(faceMat);
    let plate;
    if (m.shape) {
      const sh = new THREE.Shape(m.shape.map(([a, b]) => new THREE.Vector2(a, -b)));
      const geo = new THREE.ExtrudeGeometry(sh, { depth: 0.1, bevelEnabled: false }); geo.translate(0, 0, -0.05);
      const uv = geo.attributes.uv, pos = geo.attributes.position;
      for (let i = 0; i < uv.count; i++) uv.setXY(i, pos.getX(i) / w, 1 + pos.getY(i) / h);
      plate = new THREE.Mesh(geo, [faceMat, M.edge]);
    } else {
      plate = new THREE.Mesh(new THREE.BoxGeometry(w - 0.04, h - 0.04, 0.1), [M.edge, M.edge, M.edge, M.edge, faceMat, M.edge]);
      plate.position.set(w / 2, -h / 2, 0);
    }
    plate.receiveShadow = true; grp.add(plate);
    if (!m.blank && !m.struct) {
      const hous = new THREE.Mesh(new THREE.BoxGeometry(w - 0.4, h - 0.4, DEPTH), M.housing); hous.position.set(w / 2, -h / 2, -0.05 - DEPTH / 2); grp.add(hous);
      const lab = new THREE.Mesh(new THREE.PlaneGeometry(Math.min(2.2, w * 0.4), Math.min(1.1, w * 0.2)), new THREE.MeshStandardMaterial({ map: moduleLabelTex(m), roughness: 0.8 }));
      lab.position.set(w * 0.72, -h + Math.min(0.95, h * 0.28), Z_BACK - 0.005); lab.rotation.y = Math.PI; grp.add(lab);
    }
    const stat = { chrome: [], black: [], blackGloss: [] };
    if (!m.shape) for (const [x, y] of [[0.17, 0.17], [w - 0.17, 0.17], [0.17, h - 0.17], [w - 0.17, h - 0.17]]) {
      stat.chrome.push(Gm.dzus.clone().translate(x, -y, 0.05));
      const sl = new THREE.Mesh(Gm.dzusSlot, M.black); sl.position.set(x, -y, 0.05); sl.rotation.z = Math.random() * 3; grp.add(sl); part.dzus.push(sl);
    }
    const Z = 0.05;
    for (const o of m.items) {
      const [lx, ly] = L(o.at[0], o.at[1]);
      if (o.t === "T") {
        stat.chrome.push(Gm.bushing.clone().translate(lx, ly, Z));
        const piv = new THREE.Group(); piv.position.set(lx, ly, Z + 0.14);
        const lever = new THREE.Mesh(o.style === "paddle" ? Gm.paddle : o.style === "slot" ? Gm.slotLever : Gm.lever, o.style === "slot" ? M.blackGloss : M.chrome);
        piv.add(lever); grp.add(piv);
        const c = { o, mod: part, kind: "T", piv, state: ST.ctl[o.id] ?? o.st, target: 0, dir: 1 };
        lever.userData.ctrl = c;
        if (o.guard) {
          const gw = o.gw / PX, gh = o.gh / PX, ht = 0.42, gm = o.guard === "yellow" ? M.guardYel : M.guardRed, t = 0.045;
          const hinge = new THREE.Group(); let gg;
          if (o.gHoriz) {
            hinge.position.set(lx + gw / 2, ly, Z);
            gg = mergeGeometries([new THREE.BoxGeometry(gw, gh, t).translate(-gw / 2, 0, ht), new THREE.BoxGeometry(gw, 0.04, ht).translate(-gw / 2, gh / 2, ht / 2), new THREE.BoxGeometry(gw, 0.04, ht).translate(-gw / 2, -gh / 2, ht / 2), new THREE.BoxGeometry(0.04, gh, ht).translate(-gw, 0, ht / 2),
              new THREE.CylinderGeometry(0.055, 0.055, gh + 0.06, 14).translate(0, 0, 0.06), new THREE.BoxGeometry(0.13, gh * 0.45, 0.04).translate(-gw - 0.05, 0, ht - 0.02)]);
          } else {
            hinge.position.set(lx, ly - gh / 2, Z);
            gg = mergeGeometries([new THREE.BoxGeometry(gw, gh, t).translate(0, gh / 2, ht), new THREE.BoxGeometry(0.04, gh, ht).translate(-gw / 2, gh / 2, ht / 2), new THREE.BoxGeometry(0.04, gh, ht).translate(gw / 2, gh / 2, ht / 2), new THREE.BoxGeometry(gw, 0.04, ht).translate(0, gh, ht / 2),
              new THREE.CylinderGeometry(0.055, 0.055, gw + 0.06, 14).rotateZ(Math.PI / 2).translate(0, 0, 0.06), new THREE.BoxGeometry(gw * 0.45, 0.13, 0.04).translate(0, gh + 0.05, ht - 0.02)]);
          }
          const gmesh = new THREE.Mesh(gg, gm); hinge.add(gmesh); grp.add(hinge);
          stat.black.push(new THREE.BoxGeometry(o.gHoriz ? 0.1 : gw + 0.1, o.gHoriz ? gh + 0.1 : 0.1, 0.05).translate(o.gHoriz ? lx + gw / 2 + 0.02 : lx, o.gHoriz ? ly : ly - gh / 2 - 0.02, Z + 0.025));
          c.hinge = hinge; c.gHoriz = !!o.gHoriz; c.guardOpen = c.state !== o.gst; gmesh.userData.ctrl = c;
        }
        ctrls.push(c);
      } else if (o.t === "R") {
        const k = o.r / PX;
        const piv = new THREE.Group(); piv.position.set(lx, ly, Z); grp.add(piv);
        let body, ptr;
        if (o.knob === "grip") {
          body = new THREE.Mesh(cylZ(k, k, 0.3, 18).translate(0, 0, 0.15), M.blackGloss);
          ptr = new THREE.Mesh(new THREE.BoxGeometry(0.03, k * 0.6, 0.01).translate(0, k * 0.4, 0.305), M.white);
        } else if (o.knob === "round") {
          body = new THREE.Mesh(cylZ(k * 0.65, k * 0.7, 0.3, 28).translate(0, 0, 0.15), M.blackGloss);
          ptr = new THREE.Mesh(new THREE.BoxGeometry(0.035, k * 0.5, 0.01).translate(0, k * 0.35, 0.305), M.white);
        } else {
          const bw = o.knob === "xfeed" ? k * 0.5 : k * 0.42;
          body = new THREE.Mesh(mergeGeometries([cylZ(k * 0.95, k, 0.08, 32).translate(0, 0, 0.04), new THREE.BoxGeometry(bw, k * 2, 0.24).translate(0, 0, 0.2)]), M.blackGloss);
          ptr = new THREE.Mesh(new THREE.BoxGeometry(0.04, k * 0.75, 0.01).translate(0, k * 0.55, 0.325), M.white);
        }
        piv.add(body, ptr);
        const c = { o, mod: part, kind: "R", piv, state: ST.ctl[o.id] ?? o.st, target: 0 };
        body.userData.ctrl = c; ptr.userData.ctrl = c; ctrls.push(c);
      } else if (o.t === "L" && o.key) {
        const lw = o.w / PX, lh = o.h / PX, lt = legendTex(o.txt, lw, lh, "#34383d");
        stat.black.push(new THREE.BoxGeometry(lw + 0.05, lh + 0.05, 0.05).translate(lx, ly, Z + 0.025));
        const mat = new THREE.MeshStandardMaterial({ map: lt, roughness: 0.55, emissive: 0xffdca0, emissiveMap: lt, emissiveIntensity: 0 });
        const keyM = new THREE.Mesh(new THREE.BoxGeometry(lw - 0.03, lh - 0.03, 0.14), [M.key, M.key, M.key, M.key, mat, M.key]); keyM.position.set(lx, ly, Z + 0.1); grp.add(keyM);
        faceMats.push(mat);
        const c = { o, mod: part, kind: "B", mesh: keyM, baseZ: keyM.position.z }; keyM.userData.ctrl = c; ctrls.push(c);
      } else if (o.t === "L") {
        const lw = o.w / PX, lh = o.h / PX;
        stat.black.push(new THREE.BoxGeometry(lw + 0.06, lh + 0.06, 0.06).translate(lx, ly, Z + 0.03));
        const lt = legendTex(o.txt, lw, lh);
        const mat = new THREE.MeshStandardMaterial({ map: lt, emissiveMap: lt, emissive: 0x000000, color: 0x4a4642, roughness: 0.25, metalness: 0 });
        const lens = o.round ? new THREE.Mesh(cylZ(lw / 2, lw / 2, 0.08, 16), mat) : new THREE.Mesh(new THREE.BoxGeometry(lw - 0.02, lh - 0.02, 0.07), [M.black, M.black, M.black, M.black, mat, M.black]);
        lens.position.set(lx, ly, Z + 0.065); grp.add(lens);
        const c = { o, mod: part, kind: "L", mesh: lens, mat, lit: 0, color: LEGEND_COL[o.c || "a"] };
        lens.userData.ctrl = c; ctrls.push(c); lightsById[o.id] = c;
        if (o.guard) { // kapaklı ışıklı anahtar (EEC): şeffaf kapak
          const gm = new THREE.Mesh(new THREE.BoxGeometry(lw + 0.14, lh + 0.14, 0.36), new THREE.MeshPhysicalMaterial({ color: 0xeeeeee, roughness: 0.1, transparent: true, opacity: 0.22, depthWrite: false }));
          gm.position.set(lx, ly, Z + 0.22); gm.userData.ctrl = c; grp.add(gm);
        }
      } else if (o.t === "B") {
        const r = o.r / PX;
        stat.chrome.push(cylZ(r * 1.3, r * 1.35, 0.06, 24).translate(lx, ly, Z + 0.03));
        const cap = new THREE.Mesh(cylZ(r, r, 0.16, 24), M.blackGloss); cap.position.set(lx, ly, Z + 0.1); grp.add(cap);
        const c = { o, mod: part, kind: "B", mesh: cap, baseZ: cap.position.z }; cap.userData.ctrl = c; ctrls.push(c);
      } else if (o.t === "G") {
        const R0 = o.r / PX;
        const wall = new THREE.Mesh(new THREE.CylinderGeometry(R0 + 0.02, R0 + 0.02, 0.16, 48, 1, true).rotateX(Math.PI / 2), M.black); wall.position.set(lx, ly, Z + 0.07); grp.add(wall);
        stat.blackGloss.push(new THREE.RingGeometry(R0 - 0.01, R0 + 0.09, 48).translate(lx, ly, Z + 0.15));
        const dt = dialTex(o.kind);
        const fmat = new THREE.MeshStandardMaterial({ map: dt, roughness: 0.7, emissive: o.kind === "outflow" ? 0 : 0xffe6c0, emissiveMap: dt, emissiveIntensity: 0 });
        if (o.kind !== "outflow") faceMats.push(fmat);
        const face = new THREE.Mesh(new THREE.CircleGeometry(R0, 48), fmat);
        face.position.set(lx, ly, Z + 0.012); grp.add(face);
        const s = DIALS[o.kind]; const c = { o, mod: part, kind: "G", needles: [], mesh: face, dial: s, targets: [] };
        s.val.forEach((v, i) => {
          const inner = s.inner && i === 1;
          const n = new THREE.Mesh(Gm.needle, M.white); n.scale.set(i === 1 && !inner ? 0.75 : 1, R0 * (inner ? 0.5 : 0.85), 1);
          n.position.set(lx, ly, Z + 0.03 + i * 0.006); n.rotation.z = -dialAngle(inner ? s.inner : s, v) * Math.PI / 180;
          grp.add(n); c.needles.push(n); c.targets.push(n.rotation.z);
        });
        stat.black.push(cylZ(0.06, 0.06, 0.04, 16).translate(lx, ly, Z + 0.05));
        const glass = new THREE.Mesh(new THREE.CircleGeometry(R0 + 0.02, 48), M.glass); glass.position.set(lx, ly, Z + 0.13); grp.add(glass);
        [face, wall, glass, ...c.needles].forEach(q => q.userData.ctrl = c); ctrls.push(c);
      } else if (o.t === "D") {
        const ww = o.w / PX, hh = o.h / PX, cv = canvas(ww * 160, hh * 160), lt = tex(cv);
        const mat = new THREE.MeshStandardMaterial({ map: lt, emissiveMap: lt, emissive: 0xffffff, emissiveIntensity: 0.55, roughness: 0.15 });
        const win = new THREE.Mesh(new THREE.BoxGeometry(ww, hh, 0.04), [M.black, M.black, M.black, M.black, mat, M.black]); win.position.set(lx, ly, Z); grp.add(win);
        const c = { o, mod: part, kind: "D", mesh: win, cv, lt, mat, last: "" }; win.userData.ctrl = c; ctrls.push(c);
      } else if (o.t === "J") {
        let mesh;
        if (o.kind === "mic") { mesh = new THREE.Mesh(cylZ(0.42, 0.45, 0.08, 32), M.black); mesh.position.set(lx, ly, Z + 0.04); stat.black.push(cylZ(0.5, 0.5, 0.03, 32).translate(lx, ly, Z + 0.015)); }
        else if (o.kind === "jack") { mesh = new THREE.Mesh(mergeGeometries([cylZ(0.22, 0.22, 0.08, 6).translate(0, 0, 0.04), cylZ(0.13, 0.13, 0.16, 18).translate(0, 0, 0.1)]), M.chrome); mesh.position.set(lx, ly, Z); stat.black.push(cylZ(0.06, 0.06, 0.02, 12).translate(lx, ly, Z + 0.185)); }
        else { mesh = new THREE.Mesh(mergeGeometries([cylZ(0.38, 0.38, 0.1, 28).translate(0, 0, 0.05), new THREE.BoxGeometry(0.1, 0.55, 0.06).translate(0, 0, 0.12)]), M.chrome); mesh.position.set(lx, ly, Z); }
        grp.add(mesh); const c = { o, mod: part, kind: "J", mesh }; mesh.userData.ctrl = c; ctrls.push(c);
      }
    }
    for (const k in stat) if (stat[k].length) grp.add(new THREE.Mesh(mergeGeometries(stat[k]), M[k]));

    if (m.struct) {
      const bg = [], tg = [];
      for (const o of m.items) {
        if (o.t === "L" || o.t === "J") continue;
        const [lx, ly] = L(o.at[0], o.at[1]);
        if (o.t === "R") bg.push(new THREE.BoxGeometry(0.9, 0.9, 1.1).translate(lx, ly, -0.65));
        else bg.push(cylZ(0.26, 0.26, 1.0, 16).translate(lx, ly, -0.55));
        for (let k = 0; k < 3; k++) tg.push(new THREE.CylinderGeometry(0.035, 0.035, 0.28, 6).rotateX(Math.PI / 2).translate(lx - 0.12 + k * 0.12, ly, -1.15));
      }
      if (bg.length) { grp.add(new THREE.Mesh(mergeGeometries(bg), M.housing)); grp.add(new THREE.Mesh(mergeGeometries(tg), M.brass)); }
    }

    effConns(m).forEach((cd, i) => {
      const pn = cd.pn || cfg.connPN[cd.d]?.[0], info = parsePN(pn);
      const ms = /MS3126F(\d+)/.exec(pn || ""), pt = /PT0\dSE-(\d+)/.exec(pn || "");
      const shell = info ? info.shell : ms ? +ms[1] : pt ? +pt[1] : 8;
      const rad = (shell / 16 + 0.3) / 2;
      const cx = w * (1 - cd.at[0]), cy = -h * cd.at[1], z0 = m.struct ? -1.3 : Z_BACK;
      const rec = new THREE.Group(); rec.position.set(cx, cy, z0);
      const flange = new THREE.Mesh(new THREE.BoxGeometry(rad * 2 + 0.28, rad * 2 + 0.28, 0.07), M.connShell); flange.position.z = -0.035;
      const sh = new THREE.Mesh(cylZ(rad * 0.82, rad * 0.82, 0.32, 32), M.connShell); sh.position.z = -0.2;
      const nIns = info ? info.insert : (/-(\d+)S/.exec(pn || "") ? +/-(\d+)S/.exec(pn)[1] : 2);
      const ins = new THREE.Mesh(new THREE.CircleGeometry(rad * 0.76, 32), new THREE.MeshStandardMaterial({ map: insertTex(nIns, false), roughness: 0.6 }));
      ins.position.z = -0.37; ins.rotation.y = Math.PI;
      rec.add(flange, sh, ins); grp.add(rec);
      const cn = { cd, D: DATA.normD(cd.d), idx: i, pn, info, nIns, rad, local: new THREE.Vector3(cx, cy, z0), rec };
      [flange, sh, ins].forEach(q => q.userData.connOf = cn);
      part.conns.push(cn);
    });
    part.lightConn = m.blank || m.shape ? null : new THREE.Vector3(0.45, -h + 0.45, m.struct ? -1.3 : Z_BACK);
    if (part.lightConn) { const lc = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.24, 0.2), M.nylon); lc.position.copy(part.lightConn).add(new THREE.Vector3(0, 0, -0.1)); grp.add(lc); }

    shadowAll(grp); tag(grp, part); plate.castShadow = false;
    part.x0 = X(x0); part.y0 = Y(y0);
    panel.add(grp); parts.push(part); mods.push(part);
    return part;
  }
  cfg.modules.forEach(m => buildModule(m));
  buildModule(cfg.bottom, cfg.bottom.shape ? 2.85 : null);
  const yBottom = Y(cfg.bottom.rect[1]) - cfg.bottomH;

  const addPart = (id, name, desc, obj, extra = {}, parent = panel) => { const p = { id, kind: "struct", name, desc, obj, base: obj.position.clone(), ...extra }; shadowAll(obj); tag(obj, p); parent.add(obj); parts.push(p); back.push(p); return p; };

  { // Dzus rayları
    const g = new THREE.Group(), rg = [], dg = [];
    for (const x of cfg.rails.map(X)) {
      rg.push(new THREE.BoxGeometry(0.22, PH_MOD + 0.3, 0.55).translate(x, -PH_MOD / 2, -0.33));
      for (let y = -0.2; y > -PH_MOD; y -= 0.75) dg.push(cylZ(0.05, 0.05, 0.2, 8).translate(x, y, -0.68));
    }
    rg.push(new THREE.BoxGeometry(PW + 0.3, 0.24, 0.55).translate(PW / 2, 0.05, -0.33), new THREE.BoxGeometry(PW + 0.3, 0.24, 0.55).translate(PW / 2, -PH_MOD, -0.33));
    g.add(new THREE.Mesh(mergeGeometries(rg), M.rail), new THREE.Mesh(mergeGeometries(dg), M.alodine));
    addPart("rails", "Dzus rayları", "Modüllerin oturduğu raylar. Arka yüzlerindeki yaylı Dzus yuvaları (receptacle) modüllerin çeyrek tur bağlantı elemanlarını tutar. Raylar modüllerin topraklama (bonding) yoludur. Sütun genişliği 5,75 inç; ortadaki dar sütun yaklaşık 2,6–3,1 inç.", g, { grp: "Arka yapı" });
  }
  { // kasa + menteşe
    const g = new THREE.Group(), tg = [], dz = 4.9, hy = PH_MOD + TOPB + cfg.bottomH, cy = (TOPB - PH_MOD - cfg.bottomH) / 2;
    tg.push(new THREE.BoxGeometry(0.08, hy, dz).translate(-0.3, cy, -dz / 2 - 0.3), new THREE.BoxGeometry(0.08, hy, dz).translate(PW + 0.3, cy, -dz / 2 - 0.3));
    tg.push(new THREE.BoxGeometry(PW + 0.68, 0.08, dz).translate(PW / 2, TOPB, -dz / 2 - 0.3));
    tg.push(new THREE.BoxGeometry(PW + 0.68, TOPB, 0.08).translate(PW / 2, TOPB / 2, -1.2));
    g.add(new THREE.Mesh(mergeGeometries(tg), M.tray));
    addPart("tray", "Panel kasası ve üst bant", cfg.key === "fwd" ? "Forward overhead panelin taşıyıcı kasası. Modüllerin üstündeki (arka kenar) bantta terminal blokları (TB507, TB508) ve toprak blokları (GD5xx) bulunur. Kasanın arka kenarı menteşe hattıdır; ön kenardaki INDEX TO LOCK kilitleri açılınca panel aşağı döner." : "Aft overhead panelin taşıyıcı kasası. Menteşe hattının üstünde (gövde tarafında) TB501–TB506 terminal blokları, alt sıranın arkasında GD508/GD509 toprak blokları bulunur. WDM: \"AFT SECTION (HINGED DOWN LOOKING AFT)\".", g, { grp: "Arka yapı" });
    const hg = new THREE.Group();
    const pin = cylZ(0.09, 0.09, PW + 0.6, 16); pin.rotateY(Math.PI / 2); pin.translate(PW / 2, TOPB, HINGE.z);
    const leaves = []; for (let i = 0; i < 12; i++) leaves.push(new THREE.BoxGeometry(PW / 12 - 0.1, 0.06, 0.5).translate(PW / 24 + i * PW / 12, TOPB + (i % 2 ? 0.08 : -0.08), HINGE.z + (i % 2 ? -0.25 : 0.25)));
    hg.add(new THREE.Mesh(mergeGeometries([pin, ...leaves]), M.backshell));
    addPart("hinge", "Menteşe hattı", "WDM 91-02-05'teki 'HINGE LINE (REFERENCE)'. Panel bu hat etrafında aşağı döner ve arka tarafa erişim sağlar. Kablo demetleri menteşeyi koruyucu kılıflı esneme döngüleriyle (service loop) geçer; böylece panel açılırken kablolar gerilmez.", hg, { grp: "Arka yapı" });
  }
  for (const tp of cfg.topParts) {
    const g = new THREE.Group();
    if (tp.kind === "tb") {
      const geo = [new THREE.BoxGeometry(3.2, 0.36, 0.35).translate(0, 0, -0.18)], st = [];
      for (let k = 0; k < 4; k++) { geo.push(new THREE.BoxGeometry(0.06, 0.38, 0.4).translate(-1.6 + k * 0.8, 0, -0.2)); for (let j = 0; j < 4; j++) st.push(cylZ(0.05, 0.05, 0.25, 8).translate(-1.4 + k * 0.8 + j * 0.13, 0, -0.45)); }
      g.add(new THREE.Mesh(mergeGeometries(geo), M.nylon), new THREE.Mesh(mergeGeometries(st), M.brass));
    } else {
      const st = []; for (let j = 0; j < 4; j++) st.push(cylZ(0.04, 0.04, 0.3, 8).translate(-0.24 + j * 0.16, 0, -0.35));
      g.add(new THREE.Mesh(new THREE.BoxGeometry(0.85, 0.42, 0.3).translate(0, 0, -0.15), M.nylon), new THREE.Mesh(mergeGeometries(st), M.brass));
    }
    const t = new THREE.Mesh(new THREE.PlaneGeometry(tp.kind === "tb" ? 1.0 : 0.7, tp.kind === "tb" ? 0.32 : 0.26), new THREE.MeshStandardMaterial({ map: idTagTex(tp.id), roughness: 0.8, side: THREE.DoubleSide }));
    t.position.set(1.0, tp.kind === "tb" ? 0.0 : 0.38, -0.5); t.rotation.y = Math.PI; g.add(t);
    g.position.set(tp.x, tp.y ?? (tp.kind === "tb" ? 1.45 : 0.72), -1.25);
    addPart(tp.id, tp.name || (tp.kind === "tb" ? "Terminal blok " + tp.id : "Toprak bloğu " + tp.id), (tp.d || (tp.kind === "tb" ? "Kablo uçlarının terminallere bağlandığı blok; ortak beslemeler buradan dağıtılır. Kontaklar WDM TERMINAL STRIP listesindedir." : "Toprak (ground) bloğu. Modül ve devre toprak kabloları halka terminallerle buraya toplanır. Temas yüzeyi temiz ve iletken olmalı; kontak numaraları WDM GROUND LIST (91-21-21)'dedir.")) + (tp.note ? "<br><small>" + tp.note + "</small>" : ""), g, { grp: "Terminal / toprak blokları" });
  }

  /* ---------- fişler ve demetler ---------- */
  const wList = {};
  for (const mp of mods) for (const cn of mp.conns) (wList[cn.cd.w] = wList[cn.cd.w] || []).push({ mp, cn });
  const avgX = arr => arr.reduce((s, q) => s + q.mp.x0 + q.cn.local.x, 0) / arr.length;
  const wNames = Object.keys(wList).sort((a, b) => avgX(wList[a]) - avgX(wList[b]));
  const laneY = i => 0.25 + i * Math.min(0.13, (TOPB - 0.5) / Math.max(1, wNames.length)), exitX = i => 2.2 + i * (PW - 4.4) / Math.max(1, wNames.length - 1);
  wNames.forEach((W, i) => {
    const lane = laneY(i), zl = Z_LANE - (i % 3) * 0.22, ex = exitX(i);
    const g = new THREE.Group(); const xs = [ex];
    for (const { mp, cn } of wList[W]) {
      const wp = new THREE.Vector3(mp.x0, mp.y0, 0).add(cn.local);
      const pg = new THREE.Group(); pg.position.copy(wp);
      const r = cn.rad;
      const ring = new THREE.Mesh(cylZ(r, r, 0.36, 32), M.connRing); ring.position.z = -0.48;
      const body = new THREE.Mesh(cylZ(r * 0.86, r * 0.86, 0.25, 28), M.connShell); body.position.z = -0.75;
      const bs = new THREE.Mesh(cylZ(r * 0.55, r * 0.82, 0.48, 24), M.backshell); bs.position.z = -1.08;
      const sad = new THREE.Mesh(new THREE.BoxGeometry(r * 1.5, 0.08, 0.14), M.backshell); sad.position.z = -1.3;
      const sock = new THREE.Mesh(new THREE.CircleGeometry(r * 0.76, 32), new THREE.MeshStandardMaterial({ map: insertTex(cn.nIns, true), roughness: 0.7 })); sock.position.z = -0.31;
      const idt = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.34), new THREE.MeshStandardMaterial({ map: idTagTex(cn.cd.d, W), roughness: 0.8, side: THREE.DoubleSide }));
      idt.position.set(0, r + 0.3, -1.0); idt.rotation.y = Math.PI;
      pg.add(ring, body, bs, sad, sock, idt);
      const pp = { id: "plug-" + cn.cd.d, kind: "plug", grp: "Modül konnektörleri", mod: mp, cn, name: `${cn.cd.d} (${mp.m.pn})`, obj: pg, base: pg.position.clone() };
      shadowAll(pg); pg.traverse(q => { if (q.isMesh) q.userData.part = pp; });
      panel.add(pg); parts.push(pp); back.push(pp); cn.plug = pp; plugs[cn.D] = pp;
      const leftSide = cn.local.x < mp.w / 2;
      const xr = (leftSide ? mp.x0 + 0.1 : mp.x0 + mp.w - 0.1) + ((i % 5) - 2) * 0.07;
      const zb = wp.z - 1.35, zr = zl + 0.35;
      const curve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(wp.x, wp.y, zb), new THREE.Vector3(wp.x, wp.y, zb - 0.45),
        new THREE.Vector3((wp.x * 0.3 + xr * 0.7), wp.y + 0.15, zr), new THREE.Vector3(xr, wp.y + 0.5, zr),
        new THREE.Vector3(xr, (wp.y + lane) / 2, zr), new THREE.Vector3(xr, lane - 0.35, zr), new THREE.Vector3(xr, lane, zl)], false, "centripetal");
      g.add(new THREE.Mesh(new THREE.TubeGeometry(curve, 60, 0.06 + Math.min(0.05, r * 0.06), 8), M.wire));
      xs.push(xr);
    }
    const xmin = Math.min(...xs), xmax = Math.max(...xs), thick = 0.09 + wList[W].length * 0.025;
    if (xmax - xmin > 0.05) g.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.LineCurve3(new THREE.Vector3(xmin, lane, zl), new THREE.Vector3(xmax, lane, zl)), 8, thick, 10), M.wire));
    const tieG = []; for (let x = xmin + 0.4; x < xmax; x += 1.1) tieG.push(new THREE.TorusGeometry(thick + 0.01, 0.014, 5, 16).rotateY(Math.PI / 2).translate(x, lane, zl));
    if (tieG.length) g.add(new THREE.Mesh(mergeGeometries(tieG), M.sleeve));
    const exitCurve = new THREE.CatmullRomCurve3([new THREE.Vector3(ex, lane, zl), new THREE.Vector3(ex, lane + 0.6, zl - 0.1), new THREE.Vector3(ex, TOPB - 0.3, HINGE.z + 0.4), new THREE.Vector3(ex, TOPB, HINGE.z)]);
    g.add(new THREE.Mesh(new THREE.TubeGeometry(exitCurve, 20, thick, 10), M.wire));
    bundleParts[W] = addPart("bundle-" + W, `${W} demeti`, `<b>${W}</b> – ${cfg.bundles[W] || ""}<br>Bu demete bağlı konnektörler: ${wList[W].map(q => q.cn.cd.d + " (" + q.mp.m.pn + ")").join(", ")}.<br><small>Demet numarası ve bağlantılar WDM'den; panel arkasındaki çizgisel güzergâh temsilidir.</small>`, g, { grp: "Kablo demetleri", W });
    const cg = new THREE.Group(), hp = new THREE.Vector3(ex, TOPB, HINGE.z), toward = ex < PW / 2 ? -1 : 1;
    const cc = new THREE.CatmullRomCurve3([hp, hp.clone().add(new THREE.Vector3(0, 0.8, -0.6)), hp.clone().add(new THREE.Vector3(toward * 1.5, 1.6, -3.0)), new THREE.Vector3(toward < 0 ? -3 - i * 0.2 : PW + 3 + i * 0.2, TOPB + 2.6 + (i % 4) * 0.25, HINGE.z - 11)]);
    cg.add(new THREE.Mesh(new THREE.TubeGeometry(cc, 30, thick, 10), M.wire));
    cg.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([hp.clone().add(new THREE.Vector3(0, -0.02, 0.02)), hp.clone().add(new THREE.Vector3(0, 0.4, -0.3)), hp.clone().add(new THREE.Vector3(0, 0.8, -0.6))]), 8, thick + 0.04, 10), M.sleeve));
    scene.add(cg); shadowAll(cg);
    const cp = { id: "ceil-" + W, kind: "struct", name: `${W} – tavan tarafı`, desc: `${W} demetinin menteşe hattından sonraki kısmı. Menteşe üzerinde koruyucu kılıflı esneme döngüsü (service loop) vardır. ${cfg.bundles[W] || ""}`, obj: cg, base: cg.position.clone(), grp: "Kablo demetleri" };
    cg.traverse(q => { if (q.isMesh) q.userData.part = cp; }); parts.push(cp); back.push(cp);
  });
  { // aydınlatma kabloları
    const g = new THREE.Group(), geos = [], tgt = new THREE.Vector3(X(cfg.ltTarget[0]), Y(cfg.ltTarget[1]), -1.4);
    for (const mp of mods) {
      if (!mp.lightConn) continue;
      const p = new THREE.Vector3(mp.x0, mp.y0, 0).add(mp.lightConn).add(new THREE.Vector3(0, 0, -0.2));
      geos.push(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([p, p.clone().add(new THREE.Vector3(0, 0.3, -0.8)), new THREE.Vector3((p.x + tgt.x) / 2, Math.max(p.y, tgt.y) + 0.8, -4.2), tgt.clone().add(new THREE.Vector3(0, 0.4, -0.3))]), 24, 0.035, 6));
    }
    if (geos.length) g.add(new THREE.Mesh(mergeGeometries(geos), M.wireLt));
    addPart("ltWires", "Panel aydınlatma kabloları (5V AC)", `Modüllerin entegre ışık plakalarını (LT PLT) besleyen ince kablolar; her modülün küçük bir ışık plakası konnektörü vardır. Besleme: ${cfg.ltName}. P6-3'teki OVERHEAD 5V devre kesicileriyle korunur. (Güzergâh temsilidir.)`, g, { grp: "Kablo demetleri" });
  }
  { // tekil anahtar kabloları → TB
    const g = new THREE.Group(), geos = [];
    const tb = x => new THREE.Vector3(x < PW / 2 ? cfg.tbL : cfg.tbR, cfg.tbY, -1.7);
    for (const mp of mods) {
      if (!mp.m.struct) continue;
      for (const o of mp.m.items) {
        if (o.t === "J" || o.t === "L") continue;
        const p = new THREE.Vector3(X(o.at[0]), Y(o.at[1]), -1.25), t = tb(p.x);
        geos.push(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([p, p.clone().add(new THREE.Vector3(0, 0.3, -0.9)), new THREE.Vector3(p.x, Math.min(p.y + 2, -1.0), -3.6), new THREE.Vector3((p.x + t.x) / 2, Math.max(0.3, t.y - 0.5), -3.4), t]), 30, 0.045, 6));
      }
    }
    if (geos.length) g.add(new THREE.Mesh(mergeGeometries(geos), M.wire));
    addPart("discrete", "Tekil anahtar kabloları", "Modül olmayan anahtarlar (orta sütun ve ön kenar sırası) modül konnektörü olmadan doğrudan kablolanır. Kablo uçları terminal bloklarında ve ilgili demetlerde toplanır; tek tek bağlantılar WDM'in ilgili sistem bölümündedir. (Güzergâh temsilidir.)", g, { grp: "Kablo demetleri" });
  }
  const PH = PH_MOD + cfg.bottomH;
  const ceil = new THREE.Group();
  ceil.add(new THREE.Mesh(new THREE.BoxGeometry(PW + 10, PH + 14, 0.08).translate(PW / 2, -PH / 2 + 3, HINGE.z - 3.5), M.ceiling));
  const fg = []; for (let y = 6; y > -PH - 4; y -= 7) fg.push(new THREE.BoxGeometry(PW + 10, 0.12, 1.6).translate(PW / 2, y, HINGE.z - 2.7));
  ceil.add(new THREE.Mesh(mergeGeometries(fg), new THREE.MeshStandardMaterial({ color: 0x8796a5, metalness: 0.5, roughness: 0.5, transparent: true, opacity: 0.3, depthWrite: false })));
  scene.add(ceil);
  const ceilP = { id: "ceiling", kind: "struct", name: "Gövde tavan yapısı", obj: ceil, noPick: true, base: ceil.position.clone() };
  ceil.traverse(q => { if (q.isMesh) q.userData.part = ceilP; });
  { // çevre kaplama
    const g = new THREE.Group(), bw = 0.8;
    g.add(new THREE.Mesh(mergeGeometries([new THREE.BoxGeometry(PW + bw * 2, bw, 0.4).translate(PW / 2, bw / 2 + 0.1 + Math.max(0, -Y(cfg.modules[0].rect[1]) * -1), -0.08),
      new THREE.BoxGeometry(bw, PH + 3.5, 0.4).translate(-bw / 2 - 0.05, -PH / 2 + 0.3, -0.08), new THREE.BoxGeometry(bw, PH + 3.5, 0.4).translate(PW + bw / 2 + 0.05, -PH / 2 + 0.3, -0.08)]), M.bezel));
    addPart("bezel", "Overhead çevre kaplaması", "Panelin çevresindeki kokpit tavan kaplaması (trim).", g, { grp: "Arka yapı" });
  }
  return { parts, ctrls, lightsById, mods, back, root, ceilP, yBottom, faceMats, bundleParts, plugs, PW, PH, HINGE, M };
}

/* ============================ GÖRÜNTÜLEYİCİ ============================ */
export async function mount(rootEl, opts = {}) {
  const cfg = cfgFor(opts.panel || "fwd");
  ST.panel = cfg.key;
  rootEl.innerHTML = `
  <div class="v3">
    <div class="v3-stage"><canvas></canvas>
      <div class="v3-hint">Anahtarın üst/alt yarısına dokun · modüle dokun: yakınlaş</div>
      <div class="v3-load">Panel yükleniyor…</div>
      <div class="v3-tools">
        <button data-t="front" class="on">Ön</button>
        <button data-t="back">Arka</button>
        <button data-t="hinge">Paneli aç</button>
        <button data-t="pull" disabled>Modülü çıkar</button>
        <button data-t="test">Işık testi</button>
        <button data-t="night">Gece</button>
        <button data-t="ceil">Tavan</button>
        <button data-t="reset">Sıfırla</button>
      </div>
    </div>
    <div class="v3-bar">
      <div class="v3-seg"><a href="#/3d/p5" class="${cfg.key === "fwd" ? "on" : ""}">Ön</a><a href="#/3d/p5aft" class="${cfg.key === "aft" ? "on" : ""}">Aft</a><a href="#/3d/cb">CB</a><a href="#/3d/ee">E/E</a></div>
      <label class="v3-sel"><span>Uçak</span><select class="v3-tail"></select></label>
      <label class="v3-sel"><span>Güç</span><select class="v3-pwr">${Object.entries(PW.PRESETS).map(([k, v]) => `<option value="${k}">${esc(v.label)}</option>`).join("")}</select></label>
      <div class="v3-btns"><button data-x="scen">Arıza senaryoları</button><button data-x="quiz">WDM quiz</button></div>
    </div>
    <div class="v3-info"></div>
    <div class="v3-chips"></div>
    <p class="v3-note">Kaynak: ${esc(cfg.src)} Panel arkasındaki demet çizgileri temsilidir; pin ve tel bilgileri WDM Hookup/Wire List'ten seçili uçağın etkinliğine göre süzülür. Işık mantığı basitleştirilmiştir. Eğitim amaçlıdır; bakımda yetkili güncel dokümanı kullanın.</p>
  </div>`;
  const canvasEl = rootEl.querySelector("canvas"), stage = rootEl.querySelector(".v3-stage");
  const info = rootEl.querySelector(".v3-info"), chips = rootEl.querySelector(".v3-chips");
  await Promise.all([loadFonts(), DATA.meta().catch(() => null)]);
  const tailSel = rootEl.querySelector(".v3-tail");
  try {
    const M = await DATA.meta();
    const groups = {}; for (const f of M.fleet) (groups[f[0]] = groups[f[0]] || []).push(f);
    tailSel.innerHTML = Object.entries(groups).map(([mdl, list]) => `<optgroup label="${esc(mdl)}">${list.map(f => `<option value="${f[2]}">${esc(f[3])} (${f[2]})</option>`).join("")}</optgroup>`).join("");
    tailSel.value = ST.tail;
  } catch (e) { tailSel.innerHTML = `<option>${esc(ST.tail)}</option>`; }
  tailSel.onchange = () => { ST.tail = tailSel.value; try { localStorage.setItem("b737.tail", tailSel.value); } catch (e) {} emit(); window.dispatchEvent(new HashChangeEvent("hashchange")); };

  let renderer;
  try { renderer = new THREE.WebGLRenderer({ canvas: canvasEl, antialias: true, powerPreference: "high-performance" }); }
  catch (e) { stage.innerHTML = '<p style="padding:16px">Bu cihazda 3D (WebGL) desteklenmiyor.</p>'; return () => {}; }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  const dark = matchMedia("(prefers-color-scheme: dark)").matches;
  const scene = new THREE.Scene(); const bgDay = new THREE.Color(dark ? 0x10161d : 0xdfe5eb), bgNight = new THREE.Color(0x05070a); scene.background = bgDay.clone();
  const pmrem = new THREE.PMREMGenerator(renderer); const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environment = envTex; scene.environmentIntensity = 0.62;
  const S = buildScene(scene, cfg, ST.tail);
  const PWd = S.PW;
  const key = new THREE.DirectionalLight(0xffffff, 1.7); key.position.set(PWd / 2 - 8, 6, 24); key.target.position.set(PWd / 2, -13, 0);
  key.castShadow = true; key.shadow.mapSize.set(2048, 2048); Object.assign(key.shadow.camera, { left: -18, right: 18, top: 18, bottom: -18, near: 1, far: 70 });
  key.shadow.bias = -0.0004; key.shadow.normalBias = 0.02; scene.add(key, key.target);
  const rim = new THREE.DirectionalLight(0xffffff, 0.7); rim.position.set(PWd / 2 + 10, 10, -30); scene.add(rim);
  const flood = new THREE.PointLight(0xfff1dc, 0, 60, 1.6); flood.position.set(PWd / 2, -4, 16); scene.add(flood);
  const cam = new THREE.PerspectiveCamera(36, 1, 0.1, 400);
  const controls = new OrbitControls(cam, canvasEl);
  controls.enableDamping = true; controls.dampingFactor = 0.12; controls.minDistance = 2.5; controls.maxDistance = 110; controls.zoomSpeed = 1.2; controls.screenSpacePanning = true;

  rootEl.querySelector(".v3-load").remove();
  const HINGE = S.HINGE;
  const center = new THREE.Vector3(PWd / 2, (S.yBottom + cfg.topBand) / 2 - 0.6, 0);
  let dirty = true;
  const resize = () => { const w = stage.clientWidth, h = stage.clientHeight; if (!w || !h) return; renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); dirty = true; };
  const ro = new ResizeObserver(resize); ro.observe(stage); resize();
  const fullH = S.PH + cfg.topBand + 1.5;
  const fitDist = () => { const vf = THREE.MathUtils.degToRad(cam.fov), hf = 2 * Math.atan(Math.tan(vf / 2) * cam.aspect); return Math.max((PWd / 2 + 0.9) / Math.tan(hf / 2), fullH / 2 / Math.tan(vf / 2)) * 0.97; };
  let camAnim = null;
  function goView(side) {
    const d = fitDist();
    let pos, tgt = center.clone();
    if (side === "open") {
      const a = -1.05, v = new THREE.Vector3(center.x, center.y, -2.5).sub(HINGE);
      const vr = new THREE.Vector3(v.x, v.y * Math.cos(a) - v.z * Math.sin(a), v.y * Math.sin(a) + v.z * Math.cos(a));
      tgt = HINGE.clone().add(vr);
      pos = tgt.clone().add(new THREE.Vector3(0.2, -0.62, -0.76).normalize().multiplyScalar(d * 1.45));
    } else pos = side === "back" ? new THREE.Vector3(center.x + 5, center.y + 10, -d) : new THREE.Vector3(center.x, center.y - 1.5, d);
    camAnim = { from: cam.position.clone(), to: pos, tf: controls.target.clone(), tt: tgt, t: 0 };
    rootEl.querySelectorAll('[data-t="front"],[data-t="back"]').forEach(b => b.classList.toggle("on", b.dataset.t === side));
  }
  function fitBox(box, dirHint) {
    const ctr = box.getCenter(new THREE.Vector3()), size = box.getSize(new THREE.Vector3()).length();
    const dir = dirHint || cam.position.clone().sub(controls.target).normalize();
    camAnim = { from: cam.position.clone(), to: ctr.clone().addScaledVector(dir, Math.max(7, Math.min(45, size * 1.5))), tf: controls.target.clone(), tt: ctr, t: 0 };
  }
  cam.position.set(center.x, center.y - 1.5, fitDist()); controls.target.copy(center); controls.update();

  /* ---------- durum, güç ve ışıklar ---------- */
  const ctlById = {}; for (const c of S.ctrls) if (c.o.id && (c.kind === "T" || c.kind === "R")) ctlById[c.o.id] = c;
  const stOf = id => ctlById[id] ? ctlById[id].state : ST.ctl[id];
  let cbLive = id => !ST.pulled.has(id);
  const refreshLive = () => { cbLive = PW.makeCbLive(ST.sim, stOf, ST.busMap, DATA.effOk, ST.tail, ST.pulled); };
  const cbOk = sys => (PW.SYS_CB[sys] || []).every(c => cbLive(c));
  let lightCBs = {};       // ışık → kendi devresinin CB'leri (WDM pin izlerinden)
  const modDead = mp => mp.pull > 0 || mp.conns.some(cn => ST.disc.has(cn.D));
  let lampTest = false, power = { dc: true, ac: true, L: {} };
  function setLit(c, v) { if (c.o.press) c.color = ST.ctl[c.o.id] ? LEGEND_COL.a : LEGEND_COL.w; c.lit = v; c.mat.color.setHex(v ? 0x9a948c : 0x4a4642); c.mat.emissive.setHex(v ? c.color : 0); c.mat.emissiveIntensity = v ? (v < 1 ? 0.75 : 1.9) * (ST.night ? 0.8 : 1) : 0; }
  function setNeedles(c, vals) { c.dial.val.forEach((_, i) => { if (vals[i] == null) return; const inner = c.dial.inner && i === 1; c.targets[i] = -dialAngle(inner ? c.dial.inner : c.dial, vals[i]) * Math.PI / 180; }); }
  function updDisplay(c) {
    const k = c.o.kind, dc = power.dc && !modDead(c.mod);
    let v = null;
    if (dc) {
      if (k === "elec") v = PW.elecMeter(ST.sim, stOf, power.dc, power.ac);
      else if (k === "fltalt") v = { txt: "35000" };
      else if (k === "landalt") v = { txt: "200" };
      else if (k === "isduL" || k === "isduR") {
        const side = stOf("sysDspl") === 1 ? "R" : "L", on = stOf("irs" + side) > 0, sel = stOf("dsplSel");
        if (on) {
          const al = ST.sim.irs[side] > 0, pp = ST.isduPos || ["N41 15.6", "E028 44.3"];
          const T = { 0: ["8888888", "8888888"], 1: ["273.0", "0"], 2: pp, 3: ["   ", "   "], 4: ["273.0", al ? "6" : ""] }[sel] || ["", ""];
          const buf = ST.isduBuf || "";
          v = { txt: buf ? (k === "isduL" && /^[NS]/.test(buf) ? buf : k === "isduR" && /^[EW]/.test(buf) ? buf : (k === "isduL" ? T[0] : T[1])) : (k === "isduL" ? T[0] : T[1]), small: true };
        }
      }
    }
    const sig = JSON.stringify(v); if (sig === c.last) return; c.last = sig;
    const g = c.cv.getContext("2d"); drawLcd(g, c.cv.width, c.cv.height, k, v); c.lt.needsUpdate = true; c.mat.emissiveIntensity = v ? 0.55 : 0;
  }
  function computeLights() {
    refreshLive();
    power = PW.computeLights(ST.sim, stOf, cbOk);
    const rule = {};
    for (const c of S.ctrls) if (c.o.lights) for (const L of c.o.lights) if (L.on.includes(c.state)) rule[L.id] = 1;
    for (const id in S.lightsById) {
      const c = S.lightsById[id];
      let v = power.L[id] !== undefined ? power.L[id] : (power.dc && rule[id] ? 1 : 0);
      if (lampTest && power.dc) v = 1;
      if (ST.bulbs.has(id) || modDead(c.mod) || (!lampTest && lightCBs[id] && lightCBs[id].some(cb => !cbLive(cb)))) v = 0;
      setLit(c, v);
    }
    const gv = PW.gaugeValues(ST.sim, stOf, power.dc, power.ac);
    for (const c of S.ctrls) {
      if (c.kind === "G" && gv[c.o.id]) setNeedles(c, modDead(c.mod) ? c.dial.val.map(() => c.dial.min) : gv[c.o.id]);
      if (c.kind === "D") updDisplay(c);
    }
    applyNight();
    dirty = true;
  }
  function applyNight() {
    const lit = power.dc && (stOf("pnlLt") ?? 1) !== 0;
    const k = ST.night ? (lit ? 1.0 : 0) : 0;
    for (const m of S.faceMats) m.emissiveIntensity = k;
    S.M.white.emissiveIntensity = ST.night && lit ? 0.35 : 0;
    scene.background.copy(ST.night ? bgNight : bgDay);
    scene.environmentIntensity = ST.night ? 0.035 : 0.62;
    key.intensity = ST.night ? 0.05 : 1.7; rim.intensity = ST.night ? 0.03 : 0.7;
    const dome = cfg.key === "aft" && power.dc ? [0.35, 0, 1.2][stOf("domeW") ?? 1] : 0;
    flood.intensity = ST.night ? 30 * dome + (lit ? 4 : 0) : 0;
    rootEl.querySelector('[data-t="night"]').classList.toggle("on", ST.night);
  }
  function targetFor(c) {
    if (c.kind === "T") { const n = c.o.pos.length; return n === 2 ? [-0.5, 0.5][c.state] : [-0.5, 0, 0.5][c.state]; }
    if (c.kind === "R") { if (c.o.pos.length === 1) return c.spin || 0; return -c.o.ang[c.state] * Math.PI / 180; }
    return 0;
  }
  const applyT = (c, v) => { if (c.o.horiz) c.piv.rotation.y = v; else c.piv.rotation.x = v; };
  const getT = c => c.o.horiz ? c.piv.rotation.y : c.piv.rotation.x;
  const guardAngle = c => c.guardOpen ? (c.gHoriz ? -1.75 : 1.75) : 0;
  const applyG = (c, v) => { if (c.gHoriz) c.hinge.rotation.y = v; else c.hinge.rotation.x = v; };
  const getG = c => c.gHoriz ? c.hinge.rotation.y : c.hinge.rotation.x;
  for (const c of S.ctrls) {
    if (c.kind === "T") { c.target = targetFor(c); applyT(c, c.target); if (c.hinge) applyG(c, guardAngle(c)); }
    if (c.kind === "R") c.piv.rotation.z = c.target = targetFor(c);
  }
  function setCtl(id, s) { ST.ctl[id] = s; const c = ctlById[id]; if (!c) return; c.state = s; c.target = targetFor(c); if (c.hinge) c.guardOpen = c.state !== c.o.gst; }
  function setPower(keyName) {
    PW.applyPreset(ST.sim, keyName, setCtl); ST.power = keyName; pwrSel.value = keyName; computeLights();
  }
  const pwrSel = rootEl.querySelector(".v3-pwr"); pwrSel.value = ST.power;
  pwrSel.onchange = () => { setPower(pwrSel.value); showInfo(); };
  computeLights();

  /* ---------- seçim ve bilgi ---------- */
  let selPart = null, selCtrl = null; const hl = [];
  function clearHL() { while (hl.length) { const m = hl.pop(); m.material = m.userData.origMat; delete m.userData.origMat; } }
  function highlight(obj, col = 0x2a6cf0) {
    obj.traverse(m => { if (!m.isMesh || m.userData.origMat) return; m.userData.origMat = m.material; const mk = mt => { const q = mt.clone(); if (q.emissive && !(q.emissiveIntensity > 0.6)) { q.emissive = new THREE.Color(col); q.emissiveIntensity = 0.42; } return q; }; m.material = Array.isArray(m.material) ? m.material.map(mk) : mk(m.material); hl.push(m); });
  }
  const clearAll = clearHL;
  const modOf = p => p ? (p.kind === "module" ? p : p.mod || null) : null;
  const KIND_TR = { T: "Anahtar", R: "Seçici", B: "Düğme", G: "Gösterge", D: "Gösterge", J: "" };
  const ctx = {}; // araçlara (tools.js) verilen arayüz
  function ctrlName(c) {
    const o = c.o;
    if (c.kind === "L" && !o.key) { const t = (o.txt || "").split("\n"); return ((t.length > 4 ? t.join("") : t.join(" ")) || "Gösterge") + " ışığı"; }
    if (o.key) return (o.txt || "").replace(/\n/g, " ") + " tuşu";
    const dd = o.d || ""; const mm = /^([A-Z][A-Z0-9/]{1,8}):/.exec(dd);
    return (mm ? mm[1] + " – " : "") + (KIND_TR[c.kind] || "Kontrol") + (o.pos && o.pos.length > 1 ? " (" + o.pos.filter(Boolean).join(" / ") + ")" : "");
  }
  function showInfo() {
    const p = selPart, c = selCtrl;
    if (ctx.ammActive && ctx.ammActive()) { TOOLS.ammRender(ctx); return; }
    if (c) {
      const o = c.o, m = c.mod.m; let st = "";
      if ((c.kind === "T" || c.kind === "R") && o.pos.length > 1) st = `<span class="v3-st">Konum: <b>${esc(o.pos[c.state] || "orta")}</b>${c.hinge ? (c.guardOpen ? " · kapak açık" : " · kapak kapalı") : ""}</span>`;
      if (c.kind === "L" && !o.key) st = `<span class="v3-st">${ST.bulbs.has(o.id) ? "Ampul yanık" : c.lit ? (c.lit < 1 ? "Sönük (dim) yanıyor" : "Yanıyor") : "Sönük"}</span>`;
      const posBtns = (c.kind === "T" || c.kind === "R") && o.pos.length > 1 ? `<div class="v3-posb">${o.pos.map((p, i) => `<button data-ps="${i}" class="${i === c.state ? "on" : ""}">${esc(p || "orta")}${o.spring && o.spring.includes(i) ? " ↺" : ""}</button>`).join("")}</div>` : "";
      info.innerHTML = `<small>${esc(m.pn)} · ${esc(m.name)}</small><b>${esc(ctrlName(c))}</b> ${st}${posBtns}<p>${o.d || LDESC(o) || ""}${o.spring ? " <small>↺ yaylı konum: bırakınca geri döner.</small>" : ""}</p><div class="v3-x"></div>`;
      info.querySelectorAll("[data-ps]").forEach(b => b.onclick = () => { operate(c, undefined, +b.dataset.ps); showInfo(); });
      TOOLS.ctrlExtras(ctx, c, info.querySelector(".v3-x"));
      return;
    }
    if (p && p.kind === "module") {
      const m = p.m;
      const cl = p.conns.map(cn => `<li><b>${esc(cn.cd.d)}</b> · ${esc(cn.pn || "")} · ${esc(cn.cd.w)}${cn.cd.note ? " · " + esc(cn.cd.note) : ""}${ST.disc.has(cn.D) ? ' · <span class="v3-bad">ayrılmış</span>' : ""}</li>`).join("");
      const comps = m.comps ? `<p class="v3-sub">WDM bileşenleri:</p><ul class="v3-ul">${m.comps.map(([a, b]) => `<li><b>${esc(a)}</b> – ${esc(b)}</li>`).join("")}</ul>` : "";
      info.innerHTML = `<small>${esc(m.pn)} · ATA ${esc(m.ata)} · ${esc(m.en)}</small><b>${esc(m.name)}</b><p>${m.desc}</p>${cl ? `<p class="v3-sub">Arka konnektörler (WDM 91-02-05, ${esc(DATA.tailLabel(ST.tail))}):</p><ul class="v3-ul">${cl}</ul>` : ""}${comps}<div class="v3-x"></div>`;
      TOOLS.moduleExtras(ctx, p, info.querySelector(".v3-x"));
      return;
    }
    if (p && p.kind === "plug") { TOOLS.plugInfo(ctx, p, info); return; }
    if (p) { info.innerHTML = `<b>${esc(p.name)}</b><p>${p.desc || ""}</p>`; return; }
    info.innerHTML = `<b>${esc(cfg.title)}</b><p>Seçili uçak: <b>${esc(DATA.tailLabel(ST.tail))}</b> · Güç: <b>${esc(PW.PRESETS[ST.power].label)}</b>. ${esc(PW.PRESETS[ST.power].d)}</p><p>Anahtarlara dokunarak çalıştır. <b>Arka</b> ile konnektörleri ve demetleri gör; bir konnektöre dokununca pin yüzü, her pinin teli, demeti, kesiti ve uçtan uca izi (devre kesiciye kadar) çıkar. Modül seçince ilgili <b>AMM söküm/takma görevi</b> adım adım uygulanabilir.</p>`;
  }
  function select(p, c) {
    clearAll(); selPart = p; selCtrl = c || null;
    if (c) { if (c.piv || c.mesh) highlight(c.piv || c.mesh); } else if (p) highlight(p.obj);
    const mod = modOf(c ? c.mod : p);
    const pb = rootEl.querySelector('[data-t="pull"]'); pb.disabled = !mod || !!mod.m.struct || !!mod.m.blank;
    if (mod) pb.textContent = mod.pull ? "Modülü tak" : "Modülü çıkar";
    chips.querySelectorAll("button").forEach(b => b.classList.toggle("on", !!(p || c) && b.dataset.id === (c ? c.mod.id : p.id)));
    showInfo(); dirty = true;
  }
  function focusParts(list, dirHint) {
    clearAll(); const box = new THREE.Box3();
    list.filter(Boolean).forEach((p, i) => { highlight(p.obj, i === 0 ? 0x2a6cf0 : 0xf0a020); box.expandByObject(p.obj); });
    if (!box.isEmpty()) fitBox(box, dirHint || (hingeOpen ? null : new THREE.Vector3(0.25, 0.35, -1).normalize()));
    dirty = true;
  }

  const timers = [];
  // dirHint: -1 = yukarı/sola/saat yönü tersine, +1 = aşağı/sağa/saat yönüne (dokunulan yarıya göre), setTo: doğrudan konum
  function operate(c, dirHint, setTo) {
    if (c.kind === "T") {
      if (c.hinge && !c.guardOpen) { c.guardOpen = true; if (setTo == null) { computeLights(); return; } }
      const n = c.o.pos.length, prev = c.state;
      if (setTo != null) c.state = setTo;
      else if (dirHint) c.state = Math.max(0, Math.min(n - 1, c.state + dirHint));
      else if (n === 2) c.state = 1 - c.state;
      else if (c.o.spring && c.o.spring.length === 2) { c.alt = !c.alt; c.state = c.alt ? 0 : 2; }
      else { if (c.state === 0) c.dir = 1; if (c.state === n - 1) c.dir = -1; c.state += c.dir; }
      if (c.o.spring && c.o.spring.includes(c.state)) {
        const backTo = c.o.spring.length === 2 ? c.o.st : (c.state === n - 1 ? n - 2 : c.state === 0 ? 1 : c.o.st);
        timers.push(setTimeout(() => { c.state = backTo; ST.ctl[c.o.id] = backTo; c.target = targetFor(c); if (c.hinge && c.state === c.o.gst) c.guardOpen = false; computeLights(); if (selCtrl === c) showInfo(); }, 650));
      }
      if (c.hinge && c.state === c.o.gst && prev !== c.state) c.guardOpen = false;
      c.target = targetFor(c);
    } else if (c.kind === "R") {
      if (c.o.pos.length === 1) { c.spin = (c.spin || 0) - 0.5; c.target = c.spin; return; }
      const n = c.o.pos.length; if (c.dir == null) c.dir = 1;
      let ns;
      if (setTo != null) { ns = setTo; c.dir = ns >= c.state ? 1 : -1; }
      else if (dirHint && n > 2) { ns = Math.max(0, Math.min(n - 1, c.state + dirHint)); c.dir = dirHint; }
      else { ns = c.state + c.dir; if (ns < 0 || ns >= n) { c.dir = -c.dir; ns = c.state + c.dir; } }
      c.state = ns;
      if (c.o.spring && c.o.spring.includes(c.state)) { const b = c.state - c.dir; c.dir = -c.dir; timers.push(setTimeout(() => { c.state = b; ST.ctl[c.o.id] = b; c.target = targetFor(c); computeLights(); if (selCtrl === c) showInfo(); }, 800)); }
      c.target = targetFor(c);
    } else if (c.kind === "B" && /^isduK/.test(c.o.id || "")) { // ISDU klavyesi: hizalamada konum girişi (N/S + enlem → ENT, E/W + boylam → ENT)
      c.mesh.position.z = c.baseZ - 0.05; timers.push(setTimeout(() => { c.mesh.position.z = c.baseZ; dirty = true; }, 180));
      const t = (c.o.txt || "").split("\n"), buf = ST.isduBuf || "";
      if (t[0] === "CLR") ST.isduBuf = "";
      else if (t[0] === "ENT") {
        if (/^[NS]\d{3,}/.test(buf) || /^[EW]\d{4,}/.test(buf)) {
          const fmt = buf[0] === "N" || buf[0] === "S" ? buf[0] + buf.slice(1, 3) + " " + buf.slice(3, 5) + "." + (buf[5] || "0") : buf[0] + buf.slice(1, 4) + " " + buf.slice(4, 6) + "." + (buf[6] || "0");
          const pp = ST.isduPos ? [...ST.isduPos] : ["N41 15.6", "E028 44.3"]; pp[/^[NS]/.test(fmt) ? 0 : 1] = fmt; ST.isduPos = pp;
        }
        ST.isduBuf = "";
      } else if (t.length > 1 && !buf && /[NSEW]/.test(t[0])) ST.isduBuf = t[0];
      else if (buf && buf.length < 8) ST.isduBuf = buf + t[t.length - 1];
    } else if (c.kind === "B") {
      c.mesh.position.z = c.baseZ - 0.06; timers.push(setTimeout(() => { c.mesh.position.z = c.baseZ; dirty = true; }, 220));
      if (c.o.id === "leTest") { lampTest = true; computeLights(); timers.push(setTimeout(() => { lampTest = !!rootEl.querySelector('[data-t="test"].on'); computeLights(); }, 1500)); }
    }
    if (c.o.id && (c.kind === "T" || c.kind === "R")) { ST.ctl[c.o.id] = c.state; PW.onSwitch(ST.sim, c.o.id, c.state, stOf, cbOk); }
    computeLights();
  }
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2();
  const vis = o => { while (o) { if (!o.visible) return false; o = o.parent; } return true; };
  // Dokunma: çoklu parmak hareketlerini yok say, küçük kaymaya tolerans, ıskalanan dokunuşta en yakın kontrolü bul
  let down = null, multi = false; const ptrs = new Set();
  canvasEl.addEventListener("pointerdown", e => { ptrs.add(e.pointerId); if (ptrs.size > 1) multi = true; if (ptrs.size === 1) { multi = false; down = [e.clientX, e.clientY]; } });
  const ptrEnd = e => { ptrs.delete(e.pointerId); };
  canvasEl.addEventListener("pointercancel", e => { ptrEnd(e); down = null; });
  const tmpV = new THREE.Vector3();
  const screenOf = (obj, r) => { obj.getWorldPosition(tmpV); tmpV.project(cam); return [(tmpV.x + 1) / 2 * r.width, (1 - tmpV.y) / 2 * r.height, tmpV.z]; };
  const camFacing = c => { const n = new THREE.Vector3(0, 0, 1).applyQuaternion((c.piv || c.mesh).getWorldQuaternion(new THREE.Quaternion())); const p = (c.piv || c.mesh).getWorldPosition(new THREE.Vector3()); return n.dot(cam.position.clone().sub(p)) > 0; };
  canvasEl.addEventListener("pointerup", e => {
    ptrEnd(e);
    if (!down || multi) { if (!ptrs.size) down = null; return; }
    const mv = Math.hypot(e.clientX - down[0], e.clientY - down[1]); down = null; if (mv > 14) return;
    const r = canvasEl.getBoundingClientRect(), tx = e.clientX - r.left, ty = e.clientY - r.top;
    ndc.set(tx / r.width * 2 - 1, -(ty / r.height) * 2 + 1);
    ray.setFromCamera(ndc, cam);
    const hits = ray.intersectObjects(scene.children, true).filter(h => vis(h.object) && (h.object.userData.ctrl || h.object.userData.connOf || (h.object.userData.part && !h.object.userData.part.noPick)));
    let c = (hits.find(h => h.object.userData.ctrl) || {}).object?.userData.ctrl || null;
    if (c && hits[0].object.userData.connOf) c = null;
    if (!c) { // ıskalanan dokunuş: ekranda en yakın çalıştırılabilir kontrol (28 px içinde)
      let best = null, bd = 28;
      for (const k of S.ctrls) {
        if (!(k.kind === "T" || k.kind === "R" || k.kind === "B" || (k.kind === "L" && k.o.press))) continue;
        const ob = k.piv || k.mesh; if (!vis(ob) || !camFacing(k)) continue;
        const [sx, sy, sz] = screenOf(ob, r); if (sz > 1) continue;
        const d = Math.hypot(sx - tx, sy - ty); if (d < bd) { bd = d; best = k; }
      }
      c = best;
    }
    if (c) {
      if (c.kind === "L" && c.o.press) { ST.ctl[c.o.id] = ST.ctl[c.o.id] ? 0 : 1; computeLights(); }
      if (c.kind === "T" || c.kind === "R" || c.kind === "B") {
        let dir;
        if ((c.kind === "T" || c.kind === "R") && c.o.pos.length > 2) { // dokunulan yarıya göre yön (gerçek anahtar gibi)
          const [sx, sy] = screenOf(c.piv, r);
          const horiz = c.kind === "R" || c.o.horiz, d = horiz ? tx - sx : ty - sy;
          if (Math.abs(d) > 4) dir = d < 0 ? -1 : 1;
        }
        operate(c, dir);
      }
      if (ctx.ammActive()) TOOLS.ammStop(ctx, true);
      select(c.mod, c); return;
    }
    if (!hits.length) { select(null); return; }
    const o = hits[0].object;
    if (o.userData.connOf) { select(o.userData.connOf.plug); return; }
    const p = o.userData.part;
    // uzaktan bir modüle dokunulduysa yakınlaştır: küçük anahtarlara basmak kolaylaşır
    if (p && p.kind === "module" && cam.position.distanceTo(controls.target) > 30) { selectAndFly(p); return; }
    select(p);
  });

  const groups = [["Modüller (ön)", S.mods.filter(p => !p.m.blank).map(p => ({ id: p.id, label: (p.m.pn && p.m.pn !== "—" && !p.m.struct ? p.m.pn + " " : "") + p.m.name, p }))]];
  const byGrp = {}; for (const p of S.back) if (!p.noPick && !(p.id || "").startsWith("ceil-")) (byGrp[p.grp || "Arka yapı"] = byGrp[p.grp || "Arka yapı"] || []).push(p);
  for (const gname of ["Modül konnektörleri", "Kablo demetleri", "Terminal / toprak blokları", "Arka yapı"]) if (byGrp[gname]) groups.push([gname, byGrp[gname].map(p => ({ id: p.id, label: p.kind === "plug" ? p.cn.cd.d : p.name, p }))]);
  const flat = groups.flatMap(g => g[1]);
  chips.innerHTML = groups.map(([g, list]) => `<div class="v3-chhead">${esc(g)}</div>` + list.map(c => `<button data-id="${c.id}">${esc(c.label)}</button>`).join("")).join("");
  let hingeOpen = false;
  function selectAndFly(p) {
    select(p);
    const box = new THREE.Box3().setFromObject(p.kind === "module" ? p.obj.children[0] : p.obj);
    const isBack = p.kind !== "module";
    let dir = null;
    if (isBack && !hingeOpen) { dir = new THREE.Vector3(0.25, 0.35, -1).normalize(); rootEl.querySelectorAll('[data-t="front"],[data-t="back"]').forEach(b2 => b2.classList.toggle("on", b2.dataset.t === "back")); }
    if (!isBack && !hingeOpen) dir = new THREE.Vector3(0, -0.05, 1).normalize();
    fitBox(box, dir);
  }
  chips.querySelectorAll("button").forEach(b => b.onclick = () => {
    const c = flat.find(x => x.id === b.dataset.id);
    if (selPart === c.p && !selCtrl) { select(null); return; }
    if (ctx.ammActive()) TOOLS.ammStop(ctx, true);
    selectAndFly(c.p);
    stage.scrollIntoView({ behavior: "smooth", block: "start" });
  });
  function setHinge(v) { hingeOpen = v; const b = rootEl.querySelector('[data-t="hinge"]'); b.classList.toggle("on", v); b.textContent = v ? "Paneli kapat" : "Paneli aç"; goView(v ? "open" : "front"); }
  function setPull(mp, v) { mp.pull = v; const pb = rootEl.querySelector('[data-t="pull"]'); if (modOf(selCtrl ? selCtrl.mod : selPart) === mp) pb.textContent = v ? "Modülü tak" : "Modülü çıkar"; computeLights(); }
  rootEl.querySelectorAll(".v3-tools button").forEach(b => b.onclick = () => {
    const t = b.dataset.t;
    if (t === "front" || t === "back") goView(t);
    if (t === "hinge") setHinge(!hingeOpen);
    if (t === "pull") { const mod = modOf(selCtrl ? selCtrl.mod : selPart); if (mod) setPull(mod, mod.pull ? 0 : 1); }
    if (t === "test") { lampTest = !lampTest; b.classList.toggle("on", lampTest); computeLights(); if (selCtrl) showInfo(); }
    if (t === "night") { ST.night = !ST.night; computeLights(); }
    if (t === "ceil") { const v = !S.ceilP.obj.visible; S.ceilP.obj.visible = v; b.classList.toggle("on", v); dirty = true; }
    if (t === "reset") {
      for (const c of S.ctrls) if (c.kind === "T" || c.kind === "R") { c.state = c.o.st; c.spin = 0; c.target = targetFor(c); if (c.hinge) c.guardOpen = c.o.st !== c.o.gst; delete ST.ctl[c.o.id]; }
      S.mods.forEach(m => m.pull = 0); lampTest = false; hingeOpen = false;
      ST.disc.clear(); ST.bulbs.clear(); ST.pulled.clear(); ST.tagged.clear(); ST.scen = null; ST.amm = null; ST.night = false;
      Object.assign(ST.sim, PW.newSim()); ST.power = "gpu"; pwrSel.value = "gpu";
      rootEl.querySelector('[data-t="test"]').classList.remove("on"); const hb = rootEl.querySelector('[data-t="hinge"]'); hb.classList.remove("on"); hb.textContent = "Paneli aç";
      const pb = rootEl.querySelector('[data-t="pull"]'); pb.textContent = "Modülü çıkar";
      computeLights(); select(null); goView("front");
    }
  });
  rootEl.querySelectorAll(".v3-btns button").forEach(b => b.onclick = () => {
    if (ctx.ammActive()) TOOLS.ammStop(ctx, true);
    clearAll(); selPart = null; selCtrl = null;
    if (b.dataset.x === "scen") TOOLS.scenarios(ctx); else TOOLS.quiz(ctx);
    info.scrollIntoView({ behavior: "smooth", block: "start" });
  });
  S.ceilP.obj.visible = false;
  controls.addEventListener("change", () => dirty = true);

  /* ---------- araç arayüzü ---------- */
  Object.assign(ctx, {
    cfg, S, info, ST, DATA, PW, esc, cbLiveOf: id => cbLive(id), select, selectAndFly, focusParts, showInfo, operate, setCtl, setPower, setHinge, setPull, goView, computeLights, stOf, cbOk, modDead,
    ammActive: () => !!(ST.amm && ST.amm.panel === cfg.key && ST.amm.on),
    get hingeOpen() { return hingeOpen; },
    setLampTest: v => { lampTest = v; rootEl.querySelector('[data-t="test"]').classList.toggle("on", v); computeLights(); },
    setDisc: (D, v) => { if (v) ST.disc.add(D); else ST.disc.delete(D); computeLights(); },
    spinDzus: (mp, loose) => { mp.dzus.forEach(d => d.rotation.z += loose ? -1.57 : 1.57); dirty = true; },
    plugOf: D => S.plugs[DATA.normD(D)], modById: id => S.mods.find(m => m.id === id), bundle: W => S.bundleParts[W],
    nav: h => { location.hash = h; }, render: () => { dirty = true; }, data: null
  });
  ctx.dataP = Promise.all([DATA.pinsFor(ST.tail), DATA.cbsFor(ST.tail), DATA.meta(), DATA.load("amm"), DATA.load("ee").catch(() => null), DATA.load("buses").catch(() => null)]).then(([pins, cbs, meta, amm, ee, buses]) => (ST.busMap = buses, ctx.data = { pins: pins.pins, eq: pins.eq, cbs, meta, amm, eeD: new Set(ee ? ee.racks.flatMap(r => DATA.effOk(r.eff, ST.tail) ? r.units.flatMap(u => u.d.map(d => d[0])) : []) : []) })).catch(e => { ctx.dataErr = e; return null; });
  const offState = onState(() => { computeLights(); });

  let alive = true;
  const ease = (a, b, k) => a + (b - a) * k;
  let lastTick = 0;
  function loop(now) {
    if (!alive) return;
    requestAnimationFrame(loop);
    let moving = false;
    if (camAnim) { camAnim.t = Math.min(1, camAnim.t + 0.06); const k = 1 - Math.pow(1 - camAnim.t, 3); cam.position.lerpVectors(camAnim.from, camAnim.to, k); controls.target.lerpVectors(camAnim.tf, camAnim.tt, k); if (camAnim.t >= 1) camAnim = null; moving = true; }
    controls.update();
    if (PW.busy(ST.sim) && now - lastTick > 120) { lastTick = now; PW.tick(ST.sim); computeLights(); if (selCtrl || selPart) showInfoSoft(); }
    for (const c of S.ctrls) {
      if (c.kind === "T") {
        const v = getT(c); if (Math.abs(v - c.target) > 0.002) { applyT(c, ease(v, c.target, 0.35)); moving = true; }
        if (c.hinge) { const g = guardAngle(c), gv = getG(c); if (Math.abs(gv - g) > 0.002) { applyG(c, ease(gv, g, 0.25)); moving = true; } }
      } else if (c.kind === "R") { if (Math.abs(c.piv.rotation.z - c.target) > 0.002) { c.piv.rotation.z = ease(c.piv.rotation.z, c.target, 0.3); moving = true; } }
      else if (c.kind === "G") c.needles.forEach((n, i) => { if (Math.abs(n.rotation.z - c.targets[i]) > 0.002) { n.rotation.z = ease(n.rotation.z, c.targets[i], 0.12); moving = true; } });
    }
    for (const m of S.mods) { const z = m.base.z + m.pull * PULL; if (Math.abs(m.obj.position.z - z) > 0.002) { m.obj.position.z = ease(m.obj.position.z, z, 0.12); moving = true; } }
    for (const D in S.plugs) { const p = S.plugs[D], z = p.base.z - (ST.disc.has(D) ? 0.9 : 0); if (Math.abs(p.obj.position.z - z) > 0.002) { p.obj.position.z = ease(p.obj.position.z, z, 0.15); moving = true; } }
    const ha = hingeOpen ? -1.05 : 0;
    if (Math.abs(S.root.rotation.x - ha) > 0.001) { S.root.rotation.x = ease(S.root.rotation.x, ha, 0.08); moving = true; }
    if (moving) dirty = true;
    if (dirty) { renderer.render(scene, cam); dirty = false; }
  }
  let softT = 0; function showInfoSoft() { const n = performance.now(); if (n - softT > 900) { softT = n; if (selCtrl) showInfo(); } }
  select(null); requestAnimationFrame(loop);
  // başka görünümden gelen odak (CB görünümü → pin) ve süren AMM görevi
  ctx.dataP.then(d => {
    if (!alive) return;
    if (d) {
      for (const id in S.lightsById) {
        const dgs = PW.CTRL_DG[id]; if (!dgs) continue;
        const set = new Set();
        for (const cn of S.lightsById[id].mod.conns) for (const q of d.pins[cn.D] || []) if (dgs.includes(q.dg)) for (const p of q.paths) { const l = p[p.length - 1]; if (l && l[8] === "cb") set.add(l[6]); }
        if (set.size) lightCBs[id] = [...set];
      }
      ctx.lightCBs = lightCBs; computeLights();
    }
    if (ST.p5Focus && ST.p5Focus.panel === cfg.key) { const f = ST.p5Focus; ST.p5Focus = null; const p = ctx.plugOf(f.D); if (p) { selectAndFly(p); if (f.pin) setTimeout(() => TOOLS.showPin(ctx, p, f.pin), 80); } }
    else if (ST.amm && ST.amm.panel === cfg.key) { ST.amm.on = true; TOOLS.ammRender(ctx); }
  });
  rootEl.__p5 = { S, ctx, select, operate, goView, cam, controls, render: () => { dirty = true; }, setHinge, renderer, scene };
  return () => {
    alive = false; offState(); timers.forEach(clearTimeout); ro.disconnect(); controls.dispose();
    scene.traverse(o => { if (o.isMesh) { o.geometry.dispose(); const ms = Array.isArray(o.material) ? o.material : [o.material]; ms.forEach(m => { m.map?.dispose(); m.emissiveMap?.dispose(); m.dispose(); }); } });
    envTex.dispose(); pmrem.dispose(); renderer.dispose(); renderer.forceContextLoss?.();
  };
}

function LDESC(o) {
  const t = (o.txt || "").replace(/\n/g, " ").replace(/\s+/g, " ").trim();
  const map = {
    "LOW PRESSURE": "İlgili pompanın çıkış basıncı düşük. Pompa kapalıyken de yanar.", "OVERHEAT": "Aşırı ısınma (elektrikli hidrolik pompa veya cam ısıtma).",
    "VALVE OPEN": "Crossfeed valfi açık (mavi). Geçişte parlak, açıkken sönük (dim) yanar.", "ENG VALVE CLOSED": "Motor yakıt valfi kapalı (sönük mavi) / geçişte (parlak).", "SPAR VALVE CLOSED": "Kanat ön sparındaki yakıt valfi kapalı (sönük) / geçişte (parlak).",
    "FILTER BY PASS": "Motor yakıt filtresi tıkanmak üzere.", "TRANSFER BUS OFF": "İlgili AC transfer bara enerjisiz.", "SOURCE OFF": "Transfer baraya seçilmiş kaynak bağlı değil.",
    "GEN OFF BUS": "Motor jeneratörü (IDG) baraya bağlı değil (mavi).", "APU GEN OFF BUS": "APU çalışıyor, jeneratörü hiçbir baraya bağlı değil (mavi).", "GRD POWER AVAILABLE": "Yer gücü bağlı ve uygun (mavi).",
    "DRIVE": "IDG düşük yağ basıncı / yüksek sıcaklık veya IDG ayrılmış. Motor dururken yanar.", "STANDBY PWR OFF": "Standby baralardan biri enerjisiz.", "BAT DISCHARGE": "Batarya aşırı deşarj oluyor.",
    "TR UNIT": "TRU arızası.", "ELEC": "Elektrik sisteminde bakım gerektiren arıza (yerde).", "WING-BODY OVERHEAT": "Pnömatik kanalda sıcak hava kaçağı.", "BLEED TRIP OFF": "Aşırı sıcaklık/basınç nedeniyle bleed valfi kapandı.",
    "PACK": "Paket aşırı ısındı/kapandı veya kontrol arızası.", "DUAL BLEED": "APU bleed valfi ve motor bleed valfi aynı anda açık.", "RAM DOOR FULL OPEN": "Ram hava kapağı tam açık (mavi); yerde normaldir.",
    "ZONE TEMP": "Bölge kanalı aşırı ısındı veya kontrol arızası.", "AUTO FAIL": "Otomatik basınç kontrolcüsü arızası.", "OFF SCHED DESCENT": "Seçilen FLT ALT'a ulaşmadan alçalma başladı.",
    "ALTN": "Yedek basınç kontrolcüsü aktif.", "MANUAL": "Basınçlandırma manuel modda.", "COWL ANTI-ICE": "Motor buz önleme kanalında aşırı basınç.", "COWL VALVE OPEN": "Motor buz önleme valfi açık (mavi).",
    "ON": "Cam ısıtma çalışıyor (yeşil).", "YAW DAMPER": "Yaw damper devrede değil (B sistemi basıncı ve anahtar ON gerekir).", "STBY RUD ON": "Standby rudder devrede.", "LOW QUANTITY": "Standby hidrolik seviyesi düşük.",
    "FEEL DIFF PRESS": "Elevator feel sisteminde A/B basınç farkı.", "SPEED TRIM FAIL": "Speed trim arızası.", "MACH TRIM FAIL": "Mach trim arızası.", "AUTO SLAT FAIL": "Autoslat arızası.",
    "N O T A R M E D": "Acil çıkış ışıkları ARMED konumunda değil (L1).", "OFF": "Hava akışı yok veya sistem kapalı.", "MAINT": "APU bakım gerektiriyor (mavi).",
    "LOW OIL PRESSURE": "APU yağ basıncı düşük (start sırasında normal).", "FAULT": "Arıza – ilgili sistem/APU kapanır.", "OVER SPEED": "APU aşırı devir – APU kapanır.", "CALL": "Kabinden kokpite çağrı (L19, mavi).",
    "L VALVE OPEN": "Sol kanat buz önleme valfi açık (mavi).", "R VALVE OPEN": "Sağ kanat buz önleme valfi açık (mavi).", "ALIGN": "IRS hizalanıyor (beyaz). Söndüğünde NAV moduna geçilmiştir; uçak hizalama süresince hareket ettirilmemeli.",
    "ON DC": "IRS DC (batarya) gücünde çalışıyor.", "DC FAIL": "IRS'in DC yedek beslemesi arızalı.", "GPS": "GPS arızası.", "INOP": "Kullanılmıyor.", "ELT": "ELT yayın yapıyor.", "PSEU": "Yakınlık anahtarı elektronik ünitesinde arıza (yerde).",
    "REVERSER": "Thrust reverser sisteminde arıza veya izolasyon valfi uyumsuz.", "ENGINE CONTROL": "Motor kontrol sisteminde dispatch'i etkileyen arıza (yerde).", "PASS OXY ON": "Yolcu oksijen sistemi devrede.",
    "LEFT GEAR": "Sol ana takım aşağıda ve kilitli.", "RIGHT GEAR": "Sağ ana takım aşağıda ve kilitli.", "NOSE GEAR": "Burun takımı aşağıda ve kilitli.", "TRANSIT": "LE cihazı hareket halinde."
  };
  if (map[t]) return map[t];
  if (/PITOT|VANE|PROBE/.test(t)) return "İlgili prob ısıtılmıyor. Prob ısıtma anahtarı kapalıyken veya AC yokken yanar.";
  if (/ENTRY|SERVICE|OVERWING|CARGO|EQUIP/.test(t)) return "İlgili kapı veya servis kapağı tam kapalı/kilitli değil.";
  return o.d || "";
}
