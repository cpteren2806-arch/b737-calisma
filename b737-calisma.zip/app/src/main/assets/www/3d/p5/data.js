// WDM/AMM veri yükleyici ve yardımcılar (uçak etkinliği, pin, CB).
const base = new URL("./data/", import.meta.url);
const cache = {};
export const load = n => cache[n] || (cache[n] = fetch(new URL(n + ".json", base)).then(r => { if (!r.ok) throw new Error(n + ".json yüklenemedi"); return r.json(); }).catch(e => { delete cache[n]; throw e; }));

let IDX = null, META = null;
export async function meta() {
  if (META) return META;
  META = await load("meta");
  IDX = {}; META.fleet.forEach((f, i) => IDX[f[2]] = i);
  return META;
}
export const DEFAULT_TAIL = "YC503";
export function effOk(s, code) {
  s = String(s || "").replace(/~/g, "");
  if (!s.trim() || /\bALL\b/.test(s) || !IDX) return true;
  const i = IDX[code]; if (i == null) return true;
  for (const part of s.match(/Y[A-Z]\d{3}(?:-Y[A-Z]\d{3})?/g) || []) {
    if (part.includes("-")) { const [a, b] = part.split("-"); if (IDX[a] != null && IDX[b] != null && IDX[a] <= i && i <= IDX[b]) return true; }
    else if (part === code) return true;
  }
  return false;
}
export const tailInfo = code => META && META.fleet.find(f => f[2] === code);
export const tailLabel = code => { const f = tailInfo(code); return f ? `${f[3]} · ${f[0]} (${f[2]})` : code; };

export const normD = d => String(d).replace(/^D(\d+)/, (m, n) => "D" + n.padStart(5, "0"));
export const shortD = d => String(d).replace(/^D0+(\d)/, "D$1");
export const panelName = p => { const m = /^([PJ])0*(\d+)-0*(\d+)$/.exec(p || ""); if (!m) return p; return m[1] + m[2] + (m[3] !== "0" ? "-" + m[3] : ""); };
export const gridName = g => { const m = /^([A-Z])0*(\d+)$/.exec(g || ""); return m ? m[1] + m[2] : g; };
export const gridKey = g => gridName(g);
export const PANEL_DESC = {
  P6: "F/O elektronik sistem devre kesici paneli (P6) – sağ pilot koltuğunun arkası",
  P18: "Kaptan elektronik sistem devre kesici paneli (P18) – sol pilot koltuğunun arkası",
  P91: "Güç dağıtım paneli No.1 (P91) – E/E bölmesi",
  P92: "Güç dağıtım paneli No.2 (P92) – E/E bölmesi",
  J9: "Yardımcı batarya / şarj devre kesicileri (J9)"
};

/* pinler: belirli uçağa göre filtrelenmiş */
export async function pinsFor(code) {
  const [P, M] = await Promise.all([load("pins"), meta()]);
  const gi = M.group[code] ?? M.group[DEFAULT_TAIL];
  const out = {};
  for (const d in P.pins) {
    const list = P.pins[d].filter(r => !r[6] || r[6][gi] === "1");
    if (list.length) out[d] = list.map(r => ({ t: r[0], w: r[1], b: r[2], ga: r[3], dg: r[4], paths: r[5] }));
  }
  return { pins: out, eq: P.eq };
}
export const eqDesc = (eq, id) => {
  const s = (eq && eq[id]) || ""; if (!s) return "";
  return s.replace(/\/\/+$/, "").replace(/\s*\/\/\s*/g, " · ").replace(/^(PLUG|SOCKET|RECEPT\w*)-\s*/, "$1 – ").trim();
};

/* devre kesiciler */
export async function cbsFor(code) {
  const [C] = await Promise.all([load("cbs"), meta()]);
  const list = C.filter(r => effOk(r.eff, code)).map(r => ({ ...r, pn: panelName(r.panel), g: gridName(r.grid) }));
  const byId = {}; for (const r of list) (byId[r.cb] = byId[r.cb] || r);
  return { list, byId };
}
export const PANEL_ORDER = ["P18-1", "P18-2", "P18-3", "P6-1", "P6-2", "P6-3", "P6-4", "P6-11", "P6-12", "P91", "P92", "J9"];
