// P6 / P18 (ve P91/P92, J9) devre kesici panelleri – WDM Circuit Breaker List (91-02-00) ızgara konumlarından 3D.
import * as THREE from '../three.module.js';
import { OrbitControls } from '../OrbitControls.js';
import { RoomEnvironment } from '../RoomEnvironment.js';
import { S as ST, pullCB, onState } from './state.js';
import * as DATA from './data.js';
import { AFT } from './layout_aft.js';
const AFT_D = new Set(AFT.modules.flatMap(m => (m.conns || []).map(c => DATA.normD(c.d))));

const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const FF = '"RC", "Roboto Condensed", "Arial Narrow", sans-serif';
const PX_X = 0.82, PX_Y = 1.3, MARGIN_L = 0.9, MARGIN_T = 1.25, PPI = 130;

function wrap(g, txt, maxW) {
  const words = txt.split(/\s+/), lines = []; let cur = "";
  for (const w of words) { const t = cur ? cur + " " + w : w; if (g.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; }
  if (cur) lines.push(cur);
  return lines.slice(0, 3);
}
function plateTex(pn, recs, rows, cols, W, H) {
  const c = document.createElement("canvas"); c.width = Math.round(W * PPI); c.height = Math.round(H * PPI);
  const g = c.getContext("2d"), P = v => v * PPI;
  const grd = g.createLinearGradient(0, 0, 0, c.height); grd.addColorStop(0, "#737b81"); grd.addColorStop(1, "#6a7278"); g.fillStyle = grd; g.fillRect(0, 0, c.width, c.height);
  g.fillStyle = "#f2f2ec"; g.strokeStyle = "#f2f2ec"; g.textAlign = "center"; g.textBaseline = "middle";
  g.font = `700 ${P(0.24)}px ${FF}`; g.textAlign = "left"; g.fillText(pn, P(0.25), P(0.3));
  g.textAlign = "center"; g.font = `700 ${P(0.17)}px ${FF}`;
  for (let k = 1; k <= cols; k++) g.fillText(String(k), P(MARGIN_L + (k - 0.5) * PX_X), P(MARGIN_T - 0.45));
  rows.forEach((r, i) => { g.fillText(r, P(0.4), P(MARGIN_T + (i + 0.62) * PX_Y)); });
  g.lineWidth = P(0.012);
  for (const r of recs) {
    const x = P(MARGIN_L + (r.col - 0.5) * PX_X), y = P(MARGIN_T + (r.row + 0.62) * PX_Y);
    g.beginPath(); g.arc(x, y, P(0.21), 0, 7); g.stroke();
    g.font = `600 ${P(0.085)}px ${FF}`;
    const name = r.name.replace(/^CB-/, "");
    const lines = wrap(g, name, P(PX_X - 0.06));
    lines.forEach((ln, i) => g.fillText(ln, x, y - P(0.5) + (i - (lines.length - 1) / 2) * P(0.1)));
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}

export async function mount(rootEl) {
  rootEl.innerHTML = `<div class="v3">
    <div class="v3-stage"><canvas></canvas><div class="v3-hint">CB'ye dokun: seç · tekrar dokun: çek / it</div><div class="v3-load">Devre kesici paneli yükleniyor…</div>
      <div class="v3-tools"><button data-t="fit">Ortala</button><button data-t="open">Açık CB'ler</button><button data-t="closeall">Hepsini kapat</button></div></div>
    <div class="v3-bar">
      <div class="v3-seg"><a href="#/3d/p5">Ön panel</a><a href="#/3d/p5aft">Aft panel</a><a href="#/3d/cb" class="on">CB panelleri</a></div>
      <label class="v3-sel"><span>Uçak</span><select class="v3-tail"></select></label>
      <div class="v3-tabs"></div>
    </div>
    <div class="v3-info"></div>
    <p class="v3-note">Kaynak: WDM Circuit Breaker List (91-02-00) ve Charts 91-02-06 / 91-02-18: her CB'nin paneli, ızgara konumu (satır harfi + sütun numarası), kimliği ve WDM şeması. Seçili uçağın etkinliğine göre süzülür. CB gövdeleri ve etiket yerleşimi temsilidir; akım değerleri gösterilmez. Çekilmiş CB'de beyaz yaka görünür; kırmızı etiket emniyet etiketi (safety tag) demektir.</p>
  </div>`;
  const stage = rootEl.querySelector(".v3-stage"), canvasEl = rootEl.querySelector("canvas"), info = rootEl.querySelector(".v3-info"), tabs = rootEl.querySelector(".v3-tabs");
  const [M, CB] = await Promise.all([DATA.meta(), DATA.cbsFor(ST.tail)]);
  const pinsP = DATA.pinsFor(ST.tail).catch(() => null);
  const tailSel = rootEl.querySelector(".v3-tail");
  const groups = {}; for (const f of M.fleet) (groups[f[0]] = groups[f[0]] || []).push(f);
  tailSel.innerHTML = Object.entries(groups).map(([mdl, list]) => `<optgroup label="${esc(mdl)}">${list.map(f => `<option value="${f[2]}">${esc(f[3])} (${f[2]})</option>`).join("")}</optgroup>`).join("");
  tailSel.value = ST.tail;
  tailSel.onchange = () => { ST.tail = tailSel.value; try { localStorage.setItem("b737.tail", tailSel.value); } catch (e) {} window.dispatchEvent(new HashChangeEvent("hashchange")); };

  const byPanel = {}; for (const r of CB.list) (byPanel[r.pn] = byPanel[r.pn] || []).push(r);
  const panels = DATA.PANEL_ORDER.filter(p => byPanel[p]).concat(Object.keys(byPanel).filter(p => !DATA.PANEL_ORDER.includes(p)));
  const focus = ST.cbFocus; const focusIds = new Set(focus ? focus.ids : []);
  let cur = (focus && CB.list.find(r => focusIds.has(r.cb))?.pn) || "P6-3";
  if (!byPanel[cur]) cur = panels[0];

  let renderer;
  try { renderer = new THREE.WebGLRenderer({ canvas: canvasEl, antialias: true }); } catch (e) { stage.innerHTML = '<p style="padding:16px">Bu cihazda 3D (WebGL) desteklenmiyor.</p>'; return () => {}; }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2)); renderer.toneMapping = THREE.ACESFilmicToneMapping;
  const dark = matchMedia("(prefers-color-scheme: dark)").matches;
  const scene = new THREE.Scene(); scene.background = new THREE.Color(dark ? 0x10161d : 0xdfe5eb);
  const pmrem = new THREE.PMREMGenerator(renderer); const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture; scene.environment = envTex; scene.environmentIntensity = 0.7;
  const key = new THREE.DirectionalLight(0xffffff, 1.4); key.position.set(-6, 8, 20); scene.add(key);
  const cam = new THREE.PerspectiveCamera(36, 1, 0.1, 300), controls = new OrbitControls(cam, canvasEl);
  controls.enableDamping = true; controls.dampingFactor = 0.12; controls.screenSpacePanning = true; controls.minDistance = 2; controls.maxDistance = 80;
  rootEl.querySelector(".v3-load").remove();
  let dirty = true;
  const resize = () => { const w = stage.clientWidth, h = stage.clientHeight; if (!w || !h) return; renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); dirty = true; };
  const ro = new ResizeObserver(resize); ro.observe(stage); resize();
  controls.addEventListener("change", () => dirty = true);

  const MAT = {
    knob: new THREE.MeshStandardMaterial({ color: 0x151618, metalness: 0.3, roughness: 0.35 }),
    collar: new THREE.MeshStandardMaterial({ color: 0xf4f4f0, roughness: 0.4 }),
    nut: new THREE.MeshStandardMaterial({ color: 0xc9ccd0, metalness: 1, roughness: 0.25 }),
    tag: new THREE.MeshStandardMaterial({ color: 0xc8261c, roughness: 0.6, side: THREE.DoubleSide }),
    ring: new THREE.MeshStandardMaterial({ color: 0x2a6cf0, emissive: 0x2a6cf0, emissiveIntensity: 1.2 }),
    sel: new THREE.MeshStandardMaterial({ color: 0xf0a020, emissive: 0xf0a020, emissiveIntensity: 1.2 })
  };
  let G = null, sel = null;
  function build(pn) {
    if (G) { scene.remove(G.grp); G.grp.traverse(o => { if (o.isMesh) { o.geometry.dispose(); (Array.isArray(o.material) ? o.material : []).forEach(m => { m.map?.dispose(); m.dispose(); }); } }); }
    const recs0 = byPanel[pn] || [];
    const rows = [...new Set(recs0.map(r => r.g[0]))].sort(), cols = Math.max(...recs0.map(r => +r.g.slice(1)));
    const seen = new Set(), recs = [];
    for (const r of recs0) { const k = r.g; if (seen.has(k)) continue; seen.add(k); recs.push({ ...r, row: rows.indexOf(r.g[0]), col: +r.g.slice(1) }); }
    const W = MARGIN_L + cols * PX_X + 0.4, H = MARGIN_T + rows.length * PX_Y + 0.3;
    const grp = new THREE.Group(); scene.add(grp);
    const plate = new THREE.Mesh(new THREE.BoxGeometry(W, H, 0.12), [0, 0, 0, 0, 0, 0].map((_, i) => i === 4 ? new THREE.MeshStandardMaterial({ map: plateTex(pn, recs, rows, cols, W, H), roughness: 0.6, metalness: 0.15 }) : new THREE.MeshStandardMaterial({ color: 0x5c646a, metalness: 0.4, roughness: 0.5 })));
    plate.position.set(W / 2, -H / 2, -0.06); grp.add(plate);
    const n = recs.length;
    const knobG = new THREE.CylinderGeometry(0.15, 0.16, 0.34, 20).rotateX(Math.PI / 2).translate(0, 0, 0.17);
    const collarG = new THREE.CylinderGeometry(0.168, 0.168, 0.16, 20, 1, true).rotateX(Math.PI / 2).translate(0, 0, 0.08);
    const nutG = new THREE.CylinderGeometry(0.24, 0.24, 0.07, 6).rotateX(Math.PI / 2).translate(0, 0, 0.035);
    const tagG = new THREE.BoxGeometry(0.34, 0.5, 0.01).translate(0, -0.38, 0.02);
    const knobs = new THREE.InstancedMesh(knobG, MAT.knob, n), collars = new THREE.InstancedMesh(collarG, MAT.collar, n), nuts = new THREE.InstancedMesh(nutG, MAT.nut, n), tags = new THREE.InstancedMesh(tagG, MAT.tag, n);
    grp.add(knobs, collars, nuts, tags);
    const pos = r => new THREE.Vector3(MARGIN_L + (r.col - 0.5) * PX_X, -(MARGIN_T + (r.row + 0.62) * PX_Y), 0);
    const rings = new THREE.Group(); grp.add(rings);
    G = { grp, recs, knobs, collars, nuts, tags, pos, rings, W, H, pn };
    refresh();
    fit();
    return G;
  }
  const m4 = new THREE.Matrix4(), q0 = new THREE.Quaternion(), one = new THREE.Vector3(1, 1, 1), zero = new THREE.Vector3(0, 0, 0);
  function refresh() {
    if (!G) return;
    G.recs.forEach((r, i) => {
      const p = G.pos(r), out = ST.pulled.has(r.cb) ? 0.16 : 0;
      G.nuts.setMatrixAt(i, m4.compose(p, q0, one));
      G.knobs.setMatrixAt(i, m4.compose(p.clone().add(new THREE.Vector3(0, 0, 0.05 + out)), q0, one));
      G.collars.setMatrixAt(i, m4.compose(p.clone().add(new THREE.Vector3(0, 0, 0.05)), q0, out ? one : zero));
      G.tags.setMatrixAt(i, m4.compose(p.clone().add(new THREE.Vector3(0.05, 0, 0.12)), q0, ST.tagged.has(r.cb) ? one : zero));
    });
    for (const k of ["knobs", "collars", "nuts", "tags"]) G[k].instanceMatrix.needsUpdate = true;
    while (G.rings.children.length) { const o = G.rings.children.pop(); o.geometry.dispose(); }
    G.recs.forEach(r => {
      const isSel = sel && sel.cb === r.cb && sel.g === r.g;
      if (!focusIds.has(r.cb) && !isSel) return;
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.035, 8, 28), isSel ? MAT.sel : MAT.ring); ring.position.copy(G.pos(r)).add(new THREE.Vector3(0, 0, 0.03)); G.rings.add(ring);
    });
    tabs.querySelectorAll("button").forEach(b => { const ps = byPanel[b.dataset.p] || []; b.classList.toggle("on", b.dataset.p === cur); b.classList.toggle("warn", ps.some(r => ST.pulled.has(r.cb))); b.classList.toggle("foc", ps.some(r => focusIds.has(r.cb))); });
    dirty = true;
  }
  function fit() {
    const vf = THREE.MathUtils.degToRad(cam.fov), hf = 2 * Math.atan(Math.tan(vf / 2) * cam.aspect);
    const d = Math.max(G.W / 2 / Math.tan(hf / 2), G.H / 2 / Math.tan(vf / 2)) * 1.08;
    controls.target.set(G.W / 2, -G.H / 2, 0); cam.position.set(G.W / 2, -G.H / 2 - 1, d); controls.update(); dirty = true;
  }
  tabs.innerHTML = panels.map(p => `<button data-p="${p}">${p}</button>`).join("");
  tabs.querySelectorAll("button").forEach(b => b.onclick = () => { cur = b.dataset.p; sel = null; build(cur); showInfo(); });

  async function circuitsOf(cb) {
    const P = await pinsP; if (!P) return [];
    const hits = [];
    for (const D in P.pins) for (const q of P.pins[D]) for (const path of q.paths) { const l = path[path.length - 1]; if (l && l[6] === cb) hits.push({ D, t: q.t, w: q.w, b: q.b, dg: q.dg, panel: AFT_D.has(D) ? "aft" : "fwd" }); }
    return hits;
  }
  function backLink() {
    if (!focus || !focus.back) return "";
    return `<div class="v3-resume"><button class="v3-btn pri" data-a="back">‹ ${focus.back.amm ? "AMM görevine dön" : "P5 paneline dön"}</button></div>`;
  }
  function bindBack() {
    const b = info.querySelector('[data-a="back"]'); if (!b) return;
    b.onclick = () => { const bk = focus.back; if (bk.D) ST.p5Focus = { panel: bk.panel, D: bk.D, pin: bk.pin }; if (bk.amm && ST.amm) ST.amm.on = true; ST.cbFocus = null; location.hash = bk.panel === "aft" ? "#/3d/p5aft" : "#/3d/p5"; };
  }
  function showInfo() {
    const pulled = CB.list.filter(r => ST.pulled.has(r.cb));
    if (!sel) {
      const fl = focus ? CB.list.filter(r => focusIds.has(r.cb)) : [];
      info.innerHTML = `${backLink()}<small>${esc(DATA.tailLabel(ST.tail))}</small><b>${esc(cur)} devre kesici paneli</b><p>${esc(DATA.PANEL_DESC[cur.split("-")[0]] || "")}. Bu panelde ${(byPanel[cur] || []).length} CB kaydı var.</p>
        ${fl.length ? `<p class="v3-sub">Aranan devre kesiciler (mavi halka):</p><ul class="v3-ul">${fl.map(r => `<li><button class="v3-link" data-go="${r.cb}">${esc(r.pn)} ${esc(r.g)}</button> ${esc(r.name.replace(/^CB-/, ""))} (${esc(r.cb)})${ST.pulled.has(r.cb) ? ' <span class="v3-st v3-bad">AÇIK</span>' : ""}</li>`).join("")}</ul>` : ""}
        <p class="v3-sub">Açık (çekilmiş) CB'ler: ${pulled.length ? "" : "yok"}</p>${pulled.length ? `<ul class="v3-ul">${pulled.map(r => `<li><button class="v3-link" data-go="${r.cb}">${esc(r.pn)} ${esc(r.g)}</button> ${esc(r.name.replace(/^CB-/, ""))}${ST.tagged.has(r.cb) ? " · etiketli" : ""}</li>`).join("")}</ul>` : ""}
        <p class="v3-sub">Ara:</p><input class="v3-search" placeholder="CB adı, kimliği (C00361) veya konum (B7)"><ul class="v3-ul v3-res"></ul>`;
      const inp = info.querySelector(".v3-search"), res = info.querySelector(".v3-res");
      inp.oninput = () => { const q = inp.value.trim().toUpperCase(); if (q.length < 2) { res.innerHTML = ""; return; } res.innerHTML = CB.list.filter(r => r.name.includes(q) || r.cb.includes(q) || (r.pn + " " + r.g).includes(q) || r.g === q).slice(0, 30).map(r => `<li><button class="v3-link" data-go="${r.cb}" data-g="${r.g}" data-p="${r.pn}">${esc(r.pn)} ${esc(r.g)}</button> ${esc(r.name.replace(/^CB-/, ""))}</li>`).join(""); bindGo(res); };
      bindGo(info); bindBack(); return;
    }
    const r = sel, out = ST.pulled.has(r.cb);
    info.innerHTML = `${backLink()}<small>${esc(r.pn)} · ızgara ${esc(r.g)} · ${esc(r.cb)}</small><b>${esc(r.name)}</b> <span class="v3-st${out ? " v3-bad" : ""}">${out ? "AÇIK (çekili)" : "KAPALI"}${ST.tagged.has(r.cb) ? " · etiketli" : ""}</span>
      <table class="v3-tbl"><tr><td>WDM şema</td><td>${esc(r.dg)} ${esc(M.titles[r.dg] || "")}</td></tr><tr><td>Etkinlik</td><td>${esc(r.eff)}</td></tr></table>
      <div class="row v3-row"><button class="v3-btn pri" data-a="tog">${out ? "İt (kapat)" : "Çek (aç)"}</button><button class="v3-btn" data-a="tag">${ST.tagged.has(r.cb) ? "Etiketi sök" : "Emniyet etiketi tak"}</button></div>
      <p class="v3-sub">Bu CB'ye giden P5 konnektör pinleri:</p><ul class="v3-ul v3-hits"><li>aranıyor…</li></ul>
      <p class="v3-sub">Bakım uygulaması: AMM'de "Open these circuit breakers and install safety tags" denildiğinde CB çekilir ve üzerine DO-NOT-CLOSE etiketi takılır; iş bitince etiket sökülüp CB kapatılır.</p>`;
    info.querySelector('[data-a="tog"]').onclick = () => { pullCB(r.cb, !out, out ? false : null); refresh(); showInfo(); };
    info.querySelector('[data-a="tag"]').onclick = () => { const t = ST.tagged.has(r.cb); pullCB(r.cb, ST.pulled.has(r.cb), !t); refresh(); showInfo(); };
    bindBack();
    circuitsOf(r.cb).then(h => {
      const ul = info.querySelector(".v3-hits"); if (!ul) return;
      ul.innerHTML = h.length ? h.slice(0, 20).map(x => `<li><button class="v3-link" data-D="${x.D}" data-t="${esc(x.t)}" data-pnl="${x.panel}">${esc(DATA.shortD(x.D))}-${esc(x.t)}</button> tel ${esc(x.w)} · ${esc(x.b)} · ${esc(x.dg)}</li>`).join("") : "<li>P5 modül konnektörlerinden doğrudan bu CB'ye giden tel yok (devre başka panelden veya röle üzerinden geçer).</li>";
      ul.querySelectorAll("[data-D]").forEach(b => b.onclick = () => { ST.p5Focus = { panel: b.dataset.pnl, D: b.dataset.D, pin: b.dataset.t }; location.hash = b.dataset.pnl === "aft" ? "#/3d/p5aft" : "#/3d/p5"; });
    });
  }
  function bindGo(el) {
    el.querySelectorAll("[data-go]").forEach(b => b.onclick = () => {
      const r = CB.list.find(x => x.cb === b.dataset.go && (!b.dataset.g || (x.g === b.dataset.g && x.pn === b.dataset.p)));
      if (!r) return; if (r.pn !== cur) { cur = r.pn; build(cur); }
      sel = G.recs.find(x => x.cb === r.cb) || null; refresh(); showInfo(); flyTo(sel);
    });
  }
  function flyTo(r) { if (!r) return; const p = G.pos(r); controls.target.copy(p); cam.position.set(p.x, p.y - 0.6, 7); controls.update(); dirty = true; }
  rootEl.querySelectorAll(".v3-tools button").forEach(b => b.onclick = () => {
    const t = b.dataset.t;
    if (t === "fit") fit();
    if (t === "open") { sel = null; showInfo(); }
    if (t === "closeall") { [...ST.pulled].forEach(id => pullCB(id, false, false)); refresh(); showInfo(); }
  });
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(); let down = null;
  canvasEl.addEventListener("pointerdown", e => { down = [e.clientX, e.clientY]; });
  canvasEl.addEventListener("pointerup", e => {
    if (!down) return; const mv = Math.hypot(e.clientX - down[0], e.clientY - down[1]); down = null; if (mv > 8) return;
    const rc = canvasEl.getBoundingClientRect(); ndc.set(((e.clientX - rc.left) / rc.width) * 2 - 1, -((e.clientY - rc.top) / rc.height) * 2 + 1); ray.setFromCamera(ndc, cam);
    const hit = ray.intersectObjects([G.knobs, G.nuts], false)[0];
    if (!hit) { sel = null; refresh(); showInfo(); return; }
    const r = G.recs[hit.instanceId];
    if (sel && sel.cb === r.cb && sel.g === r.g) pullCB(r.cb, !ST.pulled.has(r.cb), ST.pulled.has(r.cb) ? false : null);
    sel = r; refresh(); showInfo();
  });
  const off = onState(() => refresh());
  build(cur);
  if (focus) { const f = G.recs.find(r => focusIds.has(r.cb)); if (f) { sel = null; setTimeout(() => flyTo(f), 30); } }
  showInfo();
  let alive = true;
  (function loop() { if (!alive) return; requestAnimationFrame(loop); controls.update(); if (dirty) { renderer.render(scene, cam); dirty = false; } })();
  rootEl.__cb = { scene, cam, G: () => G, select: id => { const r = G.recs.find(x => x.cb === id); sel = r; refresh(); showInfo(); flyTo(r); } };
  return () => { alive = false; off(); ro.disconnect(); controls.dispose(); scene.traverse(o => { if (o.isMesh) { o.geometry.dispose(); const ms = Array.isArray(o.material) ? o.material : [o.material]; ms.forEach(m => { m.map?.dispose(); m.dispose(); }); } }); envTex.dispose(); pmrem.dispose(); renderer.dispose(); renderer.forceContextLoss?.(); };
}
