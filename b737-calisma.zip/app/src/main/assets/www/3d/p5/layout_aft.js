// 737NG P5 aft overhead panel – AMM 31-11-95 Fig.101 (ön yüz) ve WDM 91-02-05 Sheet 2 (arka: YC503-YC570).
// Koordinatlar AMM şeklinden (300 dpi kesit). 68.3 px = 1 inç. Modül alanı sol üst (14,84).
const T = (id, at, pos, st, o = {}) => ({ t: "T", id, at, pos, st, ...o });
const R = (id, at, pos, ang, st, o = {}) => ({ t: "R", id, at, pos, ang, st, ...o });
const L = (id, at, txt, c = "a", o = {}) => ({ t: "L", id, at, txt, c, ...o });
const B = (id, at, o = {}) => ({ t: "B", id, at, ...o });
const G = (id, at, kind, r, o = {}) => ({ t: "G", id, at, kind, r, ...o });
const D = (id, at, kind, w, h, o = {}) => ({ t: "D", id, at, kind, w, h, ...o });
const J = (id, at, kind, o = {}) => ({ t: "J", id, at, kind, ...o });
const K = (id, at, txt, o = {}) => ({ t: "L", id, at, txt, c: "w", key: true, w: 36, h: 32, ...o });

export const AFT = {
  id: "aft", PX: 68.3, OX: 14, OY: 84, x1: 1800, yRow: 775,
  rails: [14, 407, 800, 1013, 1406, 1800],
  modules: [
    { id: "a_top", pn: "—", name: "Üst kapak", en: "Top Cover", ata: "—", rect: [14, 5, 1800, 84], blank: true, desc: "Aft overhead panelin arka kenarındaki kapak şeridi.", conns: [], texts: [], items: [] },
    { id: "a_b1", pn: "—", name: "Boş panel", en: "Blank Panel", ata: "—", rect: [14, 84, 407, 366], blank: true, desc: "Kör plaka.", conns: [], texts: [], items: [] },
    { id: "a_b2", pn: "—", name: "Boş panel", en: "Blank Panel", ata: "—", rect: [14, 366, 407, 442], blank: true, desc: "Kör plaka.", conns: [], texts: [], items: [] },
    { id: "p5_80", pn: "P5-80", name: "ELT Kontrol Paneli", en: "Emergency Locator Transmitter Control Panel", ata: "23", rect: [14, 442, 407, 596],
      desc: "Acil durum yer belirleme vericisinin (ELT) uzaktan kontrol paneli: kapaklı ARM/ON anahtarı ve ELT ışığı.",
      conns: [{ d: "D2889", w: "W2589", at: [0.50, 0.29] }],
      texts: [["ELT", 215, 455, 12], ["ARM", 250, 490, 10, "right"], ["ON", 250, 565, 10, "right"]],
      items: [L("eltLt", [105, 522], "ELT", "a", { w: 66, h: 30 }),
        T("eltSw", [295, 525], ["ARM", "ON"], 0, { guard: "red", gst: 0, gw: 58, gh: 125, d: "ELT anahtarı. ARM: ELT darbe sensörüyle otomatik çalışır. ON: verici elle çalıştırılır (test/acil)." })] },
    { id: "p5_12", pn: "P5-12", name: "LE Cihazları İkaz Paneli", en: "Flaps and Slats (LE Devices) Annunciator", ata: "27", rect: [14, 596, 407, 775],
      desc: "Hücum kenarı flap (1-4) ve slat (1-8) konum ışıkları: TRANSIT (amber), EXT ve FULL EXT (yeşil). TEST düğmesi tüm ışıkları test eder.",
      conns: [{ d: "D650", w: "W2218", at: [0.50, 0.38] }],
      texts: [["LE DEVICES", 215, 609, 12], ["FLAPS", 215, 622, 9], ["TRANSIT", 216, 655, 8], ["EXT", 216, 672, 8], ["FULL EXT", 216, 690, 8], ["SLATS", 95, 742, 9], ["SLATS", 335, 742, 9], ["TEST", 216, 762, 9],
        ["1", 166, 630, 8], ["2", 190, 630, 8], ["3", 243, 630, 8], ["4", 267, 630, 8], ["1", 50, 712, 8], ["2", 76, 712, 8], ["3", 102, 712, 8], ["4", 128, 712, 8], ["5", 305, 712, 8], ["6", 331, 712, 8], ["7", 357, 712, 8], ["8", 383, 712, 8]],
      items: (() => {
        const o = [];
        const col = (id, x, rows) => rows.forEach(([r, c, y]) => o.push(L(`le${id}${r}`, [x, y], "", c, { w: 22, h: 15, d: r === "t" ? "TRANSIT: cihaz hareket halinde veya konum uyuşmazlığı (amber)." : r === "e" ? "EXT: cihaz açık (yeşil)." : "FULL EXT: slat tam açık (yeşil)." })));
        const slat = [["t", "a", 652], ["e", "g", 670], ["f", "g", 688]], flap = [["t", "a", 652], ["e", "g", 670]];
        [50, 76, 102, 128].forEach((x, i) => col("s" + (i + 1), x, slat));
        [166, 190].forEach((x, i) => col("f" + (i + 1), x, flap));
        [243, 267].forEach((x, i) => col("f" + (i + 3), x, flap));
        [305, 331, 357, 383].forEach((x, i) => col("s" + (i + 5), x, slat));
        o.push(B("leTest", [216, 740], { r: 11, d: "LE DEVICES ışık testi." }));
        return o;
      })() },
    { id: "a_b3", pn: "—", name: "Boş panel", en: "Blank Panel", ata: "—", rect: [407, 84, 800, 199], blank: true, desc: "Kör plaka.", conns: [], texts: [], items: [] },
    { id: "p5_70", pn: "P5-70", name: "IRS Ekran Ünitesi (ISDU)", en: "Inertial System Display Unit", ata: "34", rect: [407, 199, 800, 519],
      desc: "IRS verilerini (konum, rüzgâr, yer hızı/iz, baş/durum) gösterir; hizalama sırasında mevcut konum klavyeden girilir.",
      conns: [{ d: "D2183", w: "W2135", at: [0.20, 0.47] }, { d: "D2169", w: "W2035", at: [0.80, 0.47] }],
      texts: [["IRS DISPLAY", 600, 214, 11], ["DSPL SEL", 500, 302, 10, "center", "line2"], ["SYS DSPL", 500, 425, 10, "center", "line2"]],
      items: [D("isduL", [525, 252], "isduL", 128, 40, { d: "Sol pencere: enlem / iz / rüzgâr yönü." }), D("isduR", [690, 252], "isduR", 128, 40, { d: "Sağ pencere: boylam / yer hızı / rüzgâr hızı." }),
        R("dsplSel", [492, 357], ["TEST", "TK/GS", "PPOS", "WIND", "HDG/STS"], [-110, -70, -25, 25, 75], 2, { knob: "bar", r: 26, d: "ISDU ekran seçici." }),
        R("sysDspl", [492, 452], ["L", "R"], [-30, 30], 0, { knob: "bar", r: 26, d: "Sol veya sağ IRS verisi." }),
        ...[["1", 652, 348], ["N\n2", 692, 348], ["3", 732, 348], ["W\n4", 652, 388], ["H\n5", 692, 388], ["E\n6", 732, 388], ["7", 652, 428], ["S\n8", 692, 428], ["9", 732, 428], ["ENT", 652, 468], ["0", 692, 468], ["CLR", 732, 468]].map(([t, x, y], i) => K("isduK" + i, [x, y], t, { d: "ISDU klavyesi: hizalamada konum girişi (N/S/E/W + rakamlar, ENT ile girilir)." }))] },
    { id: "p5_69", pn: "P5-69", name: "IRS Mod Seçici Ünitesi", en: "IRS Mode Select Unit", ata: "34", rect: [407, 519, 800, 775],
      desc: "Sol ve sağ IRS mod seçicileri (OFF/ALIGN/NAV/ATT) ve IRS durum ışıkları.",
      conns: [{ d: "D2171", w: "W2035", at: [0.20, 0.39] }, { d: "D2173", w: "W2135", at: [0.80, 0.39] }],
      texts: [["L", 548, 760, 11], ["IRS", 600, 760, 11], ["R", 645, 760, 11]],
      items: [L("gpsLt", [500, 548], "GPS", "a", { w: 68, h: 28 }), L("inop1", [565, 548], "INOP", "a", { w: 56, h: 28 }), L("inop2", [628, 548], "INOP", "a", { w: 56, h: 28 }),
        L("alignL", [470, 610], "ALIGN", "w", { w: 58, h: 28 }), L("ondcL", [530, 610], "ON DC", "a", { w: 58, h: 28 }), L("faultL", [470, 640], "FAULT", "a", { w: 58, h: 28 }), L("dcfailL", [530, 640], "DC FAIL", "a", { w: 58, h: 28 }),
        L("alignR", [650, 610], "ALIGN", "w", { w: 58, h: 28 }), L("ondcR", [712, 610], "ON DC", "a", { w: 58, h: 28 }), L("faultR", [650, 640], "FAULT", "a", { w: 58, h: 28 }), L("dcfailR", [712, 640], "DC FAIL", "a", { w: 58, h: 28 }),
        R("irsL", [522, 705], ["OFF", "ALIGN", "NAV", "ATT"], [-95, -50, 15, 60], 0, { knob: "bar", r: 30, d: "Sol IRS modu. ALIGN/NAV: hizalama (yerde yaklaşık 10 dk); NAV: navigasyon; ATT: yalnız tutum (uçuşta yeniden hizalama)." }),
        R("irsR", [700, 705], ["OFF", "ALIGN", "NAV", "ATT"], [-95, -50, 15, 60], 0, { knob: "bar", r: 30, d: "Sağ IRS modu." })] },
    { id: "c_svc", pn: "P5 (S50)", name: "Servis İnterfon Anahtarı", en: "Service Interphone", ata: "23", rect: [800, 84, 1013, 775], struct: true,
      desc: "Servis interfon sisteminin (yer ekibi jakları) kesme anahtarı.", comps: [["S50", "Interphone cutoff"]],
      texts: [["SERVICE", 906, 488, 11], ["INTERPHONE", 906, 500, 11], ["OFF", 906, 520, 10], ["ON", 906, 600, 10]], rects: [[818, 465, 995, 620, 12]],
      items: [T("svcInt", [906, 560], ["OFF", "ON"], 0, { d: "S50: servis interfon jaklarını (gövde dışı ve iç) sisteme bağlar." })] },
    { id: "p5_15", pn: "P5-15", name: "Gözlemci Ses Seçici Paneli", en: "Observer Audio Selector Panel", ata: "23", rect: [1013, 84, 1406, 391],
      desc: "Gözlemci koltuğu için ses kontrol paneli (ACP): mikrofon seçici düğmeleri, alıcı ses düğmeleri, R/T–I/C ve MASK–BOOM anahtarları, filtre seçici ve ALT/NORM anahtarı.",
      conns: [{ d: "D139", w: "W3327", at: [0.50, 0.44], pn: "PT08SE-14-19S-SR" }],
      texts: [["MIC SELECTOR", 1210, 98, 10, "center", "line"], ["1-VHF-2-(INOP)", 1092, 182, 9], ["1-(INOP)", 1192, 182, 9], ["FLT", 1257, 182, 9], ["SVC", 1300, 182, 9], ["PA", 1342, 182, 9],
        ["1-NAV-2", 1104, 238, 9], ["1-(INOP)", 1205, 238, 9], ["MKR", 1271, 238, 9], ["SPKR", 1315, 238, 9], ["R/T", 1085, 318, 9], ["I/C", 1085, 362, 9], ["MASK", 1132, 318, 9], ["BOOM", 1132, 362, 9], ["ALT", 1318, 316, 9], ["NORM", 1318, 362, 9]],
      items: [...[1050, 1092, 1132, 1173, 1215, 1257, 1300, 1340].map((x, i) => K("mic" + i, [x, 130], "|||", { w: 32, h: 50, d: "Mikrofon seçici (VHF 1/2/3, HF, FLT, SVC, PA)." })),
        ...[1050, 1092, 1132, 1173, 1215, 1257, 1300, 1340].map((x, i) => R("rcv" + i, [x, 210], [""], [0], 0, { knob: "grip", r: 15, d: "Alıcı ses düğmesi (bas-çek / çevir)." })),
        ...[1083, 1125, 1185, 1228, 1271, 1315].map((x, i) => R("rcvb" + i, [x, 262], [""], [0], 0, { knob: "grip", r: 15, d: "Alıcı ses düğmesi (NAV, MKR, SPKR)." })),
        T("rtic", [1085, 340], ["R/T", "", "I/C"], 1, { spring: [0, 2], d: "R/T: seçili vericide yayın. I/C: interfon." }),
        T("maskBoom", [1132, 340], ["MASK", "BOOM"], 1, { d: "Oksijen maskesi veya kulaklık (boom) mikrofonu." }),
        R("filter", [1210, 338], ["V", "B", "R"], [-40, 0, 40], 1, { knob: "bar", r: 26, d: "Filtre: V (ses), B (her ikisi), R (kod/menzil)." }),
        T("altNorm", [1318, 338], ["ALT", "NORM"], 1, { d: "ALT: ACP arızasında yedek mod." })] },
    { id: "p5_68", pn: "P5-68", name: "Motor Kontrol Modülü (EEC)", en: "Engine Control Module", ata: "73", rect: [1013, 391, 1406, 570],
      desc: "EEC normal/alternate mod anahtarları (kapaklı, ışıklı basmalı), REVERSER ve ENGINE CONTROL ışıkları.",
      conns: [{ d: "D2952", w: "W2112", at: [0.20, 0.43] }, { d: "D3172", w: "W2218", at: [0.80, 0.43] }],
      texts: [["1", 1065, 406, 11], ["ENGINE", 1210, 406, 11], ["2", 1315, 406, 11], ["EEC", 1180, 476, 10], ["EEC", 1262, 476, 10]], lines: [[1040, 465, 1380, 465]],
      items: [L("rev1", [1110, 440], "REVERSER", "a", { w: 72, h: 30 }), L("rev2", [1307, 440], "REVERSER", "a", { w: 72, h: 30 }),
        L("engCtl1", [1088, 527], "ENGINE\nCONTROL", "a", { w: 68, h: 34 }), L("engCtl2", [1335, 527], "ENGINE\nCONTROL", "a", { w: 68, h: 34 }),
        L("eec1", [1180, 515], "ON\n\nALTN", "w", { w: 48, h: 62, press: true, guard: true, d: "EEC 1: ON (normal mod) / ALTN (alternate mod). Kapaklı ışıklı basmalı anahtar. Dokununca mod değişir: ALTN'de amber yanar." }),
        L("eec2", [1262, 515], "ON\n\nALTN", "w", { w: 48, h: 62, press: true, guard: true, d: "EEC 2: ON / ALTN." })] },
    { id: "p5_14", pn: "P5-14", name: "Oksijen Sistemi Modülü", en: "Oxygen System Panel", ata: "35", rect: [1013, 570, 1406, 775],
      desc: "Mürettebat oksijen basınç göstergesi ve yolcu oksijeni kapaklı anahtarı, PASS OXY ON ışığı.",
      conns: [{ d: "D440", w: "W2508", at: [0.20, 0.45] }, { d: "D432", w: "W2508", at: [0.80, 0.28], mw: "N20" }],
      texts: [["CREW", 1100, 587, 12], ["OXYGEN", 1100, 602, 12], ["PASS OXYGEN", 1290, 585, 12], ["NORMAL", 1290, 640, 10, "right"], ["ON", 1290, 692, 10, "right"]], lines: [[1205, 580, 1205, 610]],
      items: [G("crewOxy", [1100, 690], "oxy", 60, { d: "Mürettebat oksijen silindiri basıncı (PSI x100)." }),
        T("passOxy", [1340, 665], ["NORMAL", "ON"], 0, { guard: "red", gst: 0, gw: 46, gh: 125, d: "Yolcu oksijeni: ON konumu maskeleri düşürür ve sistemi devreye alır." }),
        L("passOxyOn", [1262, 745], "PASS OXY\nON", "a", { w: 70, h: 30 })] },
    { id: "a_b4", pn: "—", name: "Boş panel", en: "Blank Panel", ata: "—", rect: [1406, 84, 1800, 238], blank: true, desc: "Kör plaka.", conns: [], texts: [], items: [] },
    { id: "a_b5", pn: "—", name: "Boş panel", en: "Blank Panel", ata: "—", rect: [1406, 238, 1800, 391], blank: true, desc: "Kör plaka.", conns: [], texts: [], items: [] },
    { id: "p5_19", pn: "P5-19", name: "Uçuş Kayıt ve Mach Hız Uyarı Test Modülü", en: "Flight Recorder and Mach Airspeed Warning", ata: "31", rect: [1406, 391, 1800, 545],
      desc: "Uçuş veri kaydedici TEST/NORMAL kapaklı anahtarı ve OFF ışığı; mach/hava hızı uyarı test düğmeleri.",
      conns: [{ d: "D483", w: "W2508", at: [0.50, 0.29] }],
      texts: [["FLIGHT RECORDER", 1505, 423, 11], ["TEST", 1445, 467, 9], ["NORMAL", 1515, 467, 9], ["MACH", 1720, 410, 10], ["AIRSPEED", 1720, 423, 10], ["WARNING", 1720, 436, 10], ["TEST", 1720, 450, 9], ["NO 1", 1665, 467, 9], ["NO 2", 1745, 467, 9]],
      rects: [[1432, 400, 1775, 475, 10]],
      items: [T("fdrTest", [1490, 505], ["TEST", "NORMAL"], 1, { horiz: true, guard: "red", gst: 1, gw: 110, gh: 44, gHoriz: true, d: "Uçuş veri kaydedici. NORMAL: kayıt otomatik (motor çalışınca). TEST: yerde kaydı test için çalıştırır." }),
        L("fdrOff", [1600, 505], "OFF", "a", { w: 66, h: 30 }),
        B("machT1", [1665, 505], { r: 13, d: "Mach/hava hızı uyarı sistemi 1 testi (clacker)." }), B("machT2", [1745, 505], { r: 13, d: "Mach/hava hızı uyarı sistemi 2 testi." })] },
    { id: "p5_18", pn: "P5-18", name: "Stall Uyarı Test Modülü", en: "Stall Warning Test", ata: "27", rect: [1406, 545, 1800, 673],
      desc: "Stall uyarı sistemlerinin (stick shaker) test düğmeleri.",
      conns: [{ d: "D2351", w: "W2218", at: [0.20, 0.33] }, { d: "D2349", w: "W2112", at: [0.80, 0.33] }],
      texts: [["STALL WARNING TEST", 1600, 572, 11], ["NO.1", 1525, 590, 10], ["NO.2", 1665, 590, 10]], rects: [[1470, 560, 1735, 598, 10]],
      items: [B("stallT1", [1525, 640], { r: 15, d: "Stall uyarı sistemi 1 testi: kaptan stick shaker'ı titrer (AC gerekli)." }), B("stallT2", [1665, 640], { r: 15, d: "Stall uyarı sistemi 2 testi: F/O stick shaker'ı." })] },
    { id: "a_b6", pn: "—", name: "Boş panel", en: "Blank Panel", ata: "—", rect: [1406, 673, 1800, 775], blank: true, desc: "Kör plaka.", conns: [], texts: [], items: [] }
  ],
  bottom: {
    id: "a_bottom", pn: "P5 (aft alt sıra)", name: "Aft Panel Ön Sırası", en: "Aft Panel Forward Row", ata: "33/32", struct: true, rect: [14, 775, 1800, 960],
    desc: "PSEU ışığı, beyaz kubbe ışığı anahtarı (S103), iniş takımı yedek gösterge ışıkları (L481, L482, L1001) ve iki uçta INDEX TO LOCK kilitleri.",
    comps: [["L1331", "PSEU ışığı"], ["S103", "White dome light (DIM/OFF/BRIGHT)"], ["R215", "Dome light direnci"], ["L481", "Right main gear system 2 light"], ["L482", "Left main gear system 2 light"], ["L1001", "Nose gear system 2 light"], ["L385", "P5 aft light plate"]],
    texts: [["DOME WHITE", 893, 822, 11], ["DIM", 893, 836, 10], ["OFF", 925, 862, 10, "left"], ["BRIGHT", 893, 892, 10]], rects: [[835, 800, 960, 950, 0]],
    items: [J("lockAL", [65, 880], "lock", { d: "INDEX TO LOCK: aft overhead panel kilidi." }), L("pseu", [325, 857], "PSEU", "a", { w: 70, h: 30, d: "PSEU ışığı: yakınlık anahtarı elektronik ünitesinde arıza (yerde)." }),
      T("domeW", [882, 862], ["DIM", "OFF", "BRIGHT"], 1, { d: "S103: beyaz kubbe ışığı." }),
      L("gearL", [1055, 826], "LEFT\nGEAR", "g", { w: 70, h: 32, d: "Sol ana takım aşağıda kilitli (yedek sistem 2 göstergesi)." }), L("gearR", [1135, 826], "RIGHT\nGEAR", "g", { w: 70, h: 32, d: "Sağ ana takım aşağıda kilitli." }),
      L("gearN", [1095, 860], "NOSE\nGEAR", "g", { w: 70, h: 32, d: "Burun takımı aşağıda kilitli." }), J("lockAR", [1750, 895], "lock", { d: "INDEX TO LOCK (sağ)." })]
  },
  topParts: [
    { id: "TB502", kind: "tb", x: 20.4, y: 0.95 }, { id: "TB504", kind: "tb", x: 20.4, y: 0.55 }, { id: "TB506", kind: "tb", x: 20.4, y: 0.15 },
    { id: "TB501", kind: "tb", x: 5.8, y: 0.95 }, { id: "TB503", kind: "tb", x: 5.8, y: 0.55 }, { id: "TB505", kind: "tb", x: 5.8, y: 0.15, note: "WDM notu: TB505'in taralı konumları (sürtünme riski nedeniyle) kullanılmaz." },
    { id: "GD508", kind: "gd", x: 17.0, y: -11.4 }, { id: "GD509", kind: "gd", x: 10.2, y: -11.4 }
  ]
};

export const AFT_BUNDLES = { W2589: "NN2 – ELT CONTROL PANEL (RIGHT SIDE)", W3327: "NC3 – F/OBS FLIGHT INPH" };
export const AFT_CONN_PN = {
  D2889: ["BACC45FT16A24S7", "23-24-11"], D650: ["BACC45FT22-55S9", "27-81-11"], D2183: ["BACC45FT18-31S6", "34-21-21"], D2169: ["BACC45FT18-31S", "34-21-11"],
  D2171: ["BACC45FT16-24S7", "34-21-11"], D2173: ["BACC45FT16-24S6", "34-21-21"], D139: ["PT08SE-14-19S-SR", "23-51-31"], D2952: ["BACC45FT16-24S", "73-21-12"], D3172: ["BACC45FT16-24S6", "73-21-12"],
  D440: ["BACC45FT12-12S", "35-21-11"], D432: ["BACC45FT10-5S", "35-11-11"], D483: ["BACC45FT20-41S", "21-27-21"], D2351: ["BACC45FT12-12S6", "27-32-21"], D2349: ["BACC45FT12-12S", "27-32-11"]
};
