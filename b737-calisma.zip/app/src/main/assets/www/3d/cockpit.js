// Kokpit içi gezinme sahnesi. Panel yüzleri AMM 31-11 "Component Location" şekillerinden (çizim dokusu).
// Ölçüler yaklaşıktır (metre): x sağa, y yukarı, -z ileri (camlara doğru). Orijin: iki koltuğun ortası, zemin.
import * as THREE from './three.module.js';
import { OrbitControls } from './OrbitControls.js';
import { RoomEnvironment } from './RoomEnvironment.js';
import { mergeGeometries } from './BufferGeometryUtils.js';

const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const TEX = n => new URL("./cockpit/" + n, import.meta.url).href;
const FF = '"Roboto Condensed","Arial Narrow",sans-serif';

export const PANELS = [
  { id: "p5f", t: "Ön overhead paneli (P5)", d: "Elektrik, yakıt, hidrolik, klima/bleed, buz koruma, ışıklar. Arka bağlantılar, pinler ve devre izleme hazır.", go: "#/3d/p5" },
  { id: "p5a", t: "Aft overhead paneli (P5)", d: "IRS, ELT, LE cihazları, gözlemci ses paneli, EEC, oksijen, test düğmeleri.", go: "#/3d/p5aft" },
  { id: "p7", t: "Glareshield (P7)", d: "Mode Control Panel (otopilot/otomatik gaz), iki EFIS kontrol paneli, FIRE WARN ve MASTER CAUTION ile sistem ikaz ışıkları (six-pack).", go: "#/3d/p7" },
  { id: "p1", t: "Kaptan gösterge paneli (P1)", d: "PFD ve ND ekranları, saat, ekran seçicileri, burun tekerleği dümeni, aydınlatma kontrolleri.", go: "#/3d/p1" },
  { id: "p2", t: "Orta gösterge paneli (P2)", d: "Üst EICAS ekranı (upper DU), standby göstergeler, iniş takımı kolu ve ışıkları, autobrake, flap göstergesi.", go: "#/3d/p2" },
  { id: "p3", t: "F/O gösterge paneli (P3)", d: "F/O PFD ve ND, ekran seçicileri, GPWS paneli, saat.", go: "#/3d/p3" },
  { id: "p9", t: "Ön elektronik panel (P9)", d: "İki FMC CDU ve alt orta ekran (lower DU).", go: null },
  { id: "stand", t: "Kontrol sehpası", d: "Gaz kolları, yakıt kesme (start) kolları, hız freni, flap kolu, stabilizer trim tekerlekleri, park freni.", go: null },
  { id: "p8", t: "Orta konsol – aft elektronik panel (P8)", d: "Radyo panelleri (VHF/NAV/ADF/ATC), ses kontrol panelleri, yangın paneli, hava radarı, rudder ve aileron trim, kokpit kapısı.", go: "#/3d/p8" },
  { id: "p6", t: "P6 devre kesici paneli", d: "F/O koltuğunun arkasında; P6-1…P6-4, P6-11/12.", go: "#/3d/cb" },
  { id: "p18", t: "P18 devre kesici paneli", d: "Kaptan koltuğunun arkasında; P18-1…P18-3.", go: "#/3d/cb" },
  { id: "eebay", t: "E/E bölmesi (altta)", d: "Kokpit zemininin altındaki elektronik ekipman bölmesi; E1–E6 rafları.", go: "#/3d/ee" }
];
export const BUILT = new Set(["p5f", "p5a", "p7", "p8", "p1", "p2", "p3", "p6", "p18", "eebay"]);

function texLoad(url) { return new Promise(res => new THREE.TextureLoader().load(url, t => { t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; res(t); }, undefined, () => res(null))); }
async function composite(names, gap) { // görüntüleri yan yana birleştir (glareshield)
  const imgs = await Promise.all(names.map(n => new Promise(r => { const i = new Image(); i.onload = () => r(i); i.onerror = () => r(null); i.src = TEX(n); })));
  const h = Math.max(...imgs.filter(Boolean).map(i => i.height)), w = imgs.reduce((s, i) => s + (i ? i.width * h / i.height : 0), 0) + gap * (imgs.length - 1);
  const c = document.createElement("canvas"); c.width = Math.round(w); c.height = h; const g = c.getContext("2d"); g.fillStyle = "#60686e"; g.fillRect(0, 0, c.width, h);
  let x = 0; for (const i of imgs) { if (!i) continue; const ww = i.width * h / i.height; g.drawImage(i, x, 0, ww, h); x += ww + gap; }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return { t, aspect: c.width / h };
}
function drawnTex(w, h, fn) { const c = document.createElement("canvas"); c.width = w; c.height = h; const g = c.getContext("2d"); g.fillStyle = "#60686e"; g.fillRect(0, 0, w, h); g.strokeStyle = "#eeeee8"; g.fillStyle = "#eeeee8"; g.lineWidth = 3; fn(g, w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; }

export async function mount(rootEl) {
  rootEl.innerHTML = `<div class="v3">
    <div class="v3-stage tall"><canvas></canvas><div class="v3-hint">Panele dokun · tekrar dokun: aç</div><div class="v3-load">Kokpit hazırlanıyor…</div>
      <div class="v3-tools"><button data-t="seat" class="on">Pilot görüşü</button><button data-t="up">Overhead</button><button data-t="ped">Konsol</button><button data-t="back">Arka</button><button data-t="ac">‹ Uçak</button></div></div>
    <div class="v3-info"></div>
    <div class="v3-chips">${PANELS.map(p => `<button data-p="${p.id}">${esc(p.t)}${BUILT.has(p.id) ? "" : " ·"}</button>`).join("")}</div>
    <p class="v3-note">Panel yüzleri AMM 31-11 "Component Location" şekillerinden; kokpit biçimi ve ölçüleri temsilîdir. "·" işaretli paneller için ayrıntılı 3D görünüm hazırlanıyor.</p></div>`;
  const stage = rootEl.querySelector(".v3-stage"), canvasEl = rootEl.querySelector("canvas"), info = rootEl.querySelector(".v3-info");
  let renderer;
  try { renderer = new THREE.WebGLRenderer({ canvas: canvasEl, antialias: true }); } catch (e) { stage.innerHTML = '<p style="padding:16px">Bu cihazda 3D (WebGL) desteklenmiyor.</p>'; return () => {}; }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2)); renderer.toneMapping = THREE.ACESFilmicToneMapping;
  const scene = new THREE.Scene(); scene.background = new THREE.Color(0x0b1118);
  const pmrem = new THREE.PMREMGenerator(renderer); const env = pmrem.fromScene(new RoomEnvironment(), 0.04).texture; scene.environment = env; scene.environmentIntensity = 0.7;
  const dl = new THREE.DirectionalLight(0xfff4e6, 1.0); dl.position.set(0.5, 3, 1.5); scene.add(dl);
  const cam = new THREE.PerspectiveCamera(60, 1, 0.02, 50), controls = new OrbitControls(cam, canvasEl);
  controls.enableDamping = true; controls.dampingFactor = 0.1; controls.minDistance = 0.25; controls.maxDistance = 5; controls.screenSpacePanning = true; controls.rotateSpeed = 0.6;
  let dirty = true;
  const resize = () => { const w = stage.clientWidth, h = stage.clientHeight; if (!w || !h) return; renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); dirty = true; };
  const ro = new ResizeObserver(resize); ro.observe(stage); resize();
  controls.addEventListener("change", () => dirty = true);

  const M = {
    shell: new THREE.MeshStandardMaterial({ color: 0x8c949b, roughness: 0.8, metalness: 0.05, side: THREE.DoubleSide }),
    dark: new THREE.MeshStandardMaterial({ color: 0x2c3136, roughness: 0.6, metalness: 0.2 }),
    trim: new THREE.MeshStandardMaterial({ color: 0x5b636a, roughness: 0.7, metalness: 0.15 }),
    seat: new THREE.MeshStandardMaterial({ color: 0x3a4048, roughness: 0.9 }),
    chrome: new THREE.MeshStandardMaterial({ color: 0xc8ccd0, roughness: 0.3, metalness: 0.9 }),
    glass: new THREE.MeshPhysicalMaterial({ color: 0x88aacc, transparent: true, opacity: 0.12, roughness: 0.05, depthWrite: false, side: THREE.DoubleSide })
  };
  const panels = {};
  // a,b: panelin alt ve üst kenar orta noktaları; w genişlik; yüz normali kameraya doğru (n)
  function panel(id, tex, w, a, b, n, extra = {}) {
    const A = new THREE.Vector3(...a), Bv = new THREE.Vector3(...b), up = Bv.clone().sub(A), h = up.length();
    const mat = new THREE.MeshStandardMaterial({ map: tex || null, color: tex ? 0xffffff : 0x60686e, roughness: 0.65, metalness: 0.1, emissive: 0x2a6cf0, emissiveIntensity: 0 });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
    const yv = up.normalize(), nv = new THREE.Vector3(...n).normalize(), xv = new THREE.Vector3().crossVectors(yv, nv).normalize(), zv = new THREE.Vector3().crossVectors(xv, yv);
    m.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(xv, yv, zv));
    m.position.copy(A).addScaledVector(yv, h / 2);
    if (extra.yaw) m.rotateY(extra.yaw);
    m.userData.panel = id; scene.add(m);
    const back = new THREE.Mesh(new THREE.BoxGeometry(w + 0.02, h + 0.02, 0.03), M.trim); back.position.copy(m.position).addScaledVector(zv, -0.017); back.quaternion.copy(m.quaternion); back.userData.panel = id; scene.add(back);
    panels[id] = { mesh: m, mat, normal: zv.clone(), center: m.position.clone(), size: Math.max(w, h) };
    return m;
  }
  const [tP1, tP2, tP3, tP8, tP5f, tP5a, gl] = await Promise.all(["p1.jpg", "p2.jpg", "p3.jpg", "p8.jpg", "p5f.jpg", "p5a.jpg"].map(n => texLoad(TEX(n))).concat([composite(["p7_efisL.jpg", "p7_mcp.jpg", "p7_efisR.jpg"], 60)]));
  rootEl.querySelector(".v3-load")?.remove();

  // --- yapı: zemin, yan duvarlar, camlar ---
  { const g = [];
    g.push(new THREE.BoxGeometry(2.3, 0.04, 3.2).translate(0, -0.02, 0.2));
    for (const s of [-1, 1]) g.push(new THREE.BoxGeometry(0.04, 1.2, 2.6).translate(1.12 * s, 0.6, 0.4));
    g.push(new THREE.BoxGeometry(2.3, 0.04, 2.4).translate(0, 2.32, 0.5));
    scene.add(new THREE.Mesh(mergeGeometries(g), M.shell));
    // cam çerçeveleri (6 cam)
    const fr = [];
    const P = [[-1.1, 1.25, -0.55], [-1.0, 1.95, -0.75], [-0.62, 1.32, -1.1], [-0.55, 2.0, -1.0], [0, 1.35, -1.25], [0, 2.02, -1.12]];
    const seg = (p, q) => { const a = new THREE.Vector3(...p), b = new THREE.Vector3(...q), d = b.clone().sub(a); const gg = new THREE.CylinderGeometry(0.025, 0.025, d.length(), 8); gg.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.clone().normalize())); gg.translate(...a.clone().add(b).multiplyScalar(0.5).toArray()); fr.push(gg); };
    for (const s of [-1, 1]) {
      const m = ([x, y, z]) => [x * s, y, z];
      seg(m(P[0]), m(P[1])); seg(m(P[2]), m(P[3])); seg(m(P[4]), m(P[5])); seg(m(P[0]), m(P[2])); seg(m(P[2]), m(P[4])); seg(m(P[1]), m(P[3])); seg(m(P[3]), m(P[5]));
      seg(m([-1.1, 1.25, -0.55]), m([-1.12, 1.2, 0.2])); seg(m([-1.0, 1.95, -0.75]), m([-1.05, 2.25, 0.2]));
    }
    scene.add(new THREE.Mesh(mergeGeometries(fr), M.dark));
    const wg = []; for (const s of [-1, 1]) { const q = new THREE.Shape([new THREE.Vector2(0, 1.35), new THREE.Vector2(0.62 * 1, 1.32), new THREE.Vector2(0.55, 2.0), new THREE.Vector2(0, 2.02)]); const sg = new THREE.ShapeGeometry(q); sg.rotateX(-0.35); sg.translate(0, 0, -1.18 + 0.0); if (s < 0) sg.scale(-1, 1, 1); wg.push(sg); }
    scene.add(new THREE.Mesh(mergeGeometries(wg), M.glass));
  }
  // --- ana gösterge paneli (P1/P2/P3) ---
  const asp = t => t && t.image ? t.image.width / t.image.height : 1.25;
  const mipY0 = 0.62, mipZ = -1.12;
  { const hw = 0.46, h2 = hw / asp(tP2); panel("p2", tP2, hw, [0, mipY0, mipZ], [0, mipY0 + h2, mipZ - 0.09], [0, 0.18, 1]); }
  for (const [id, t, s] of [["p1", tP1, -1], ["p3", tP3, 1]]) {
    const w = 0.6, h = w / asp(t), cx = 0.54 * s;
    panel(id, t, w, [cx, mipY0, mipZ + 0.06], [cx, mipY0 + h, mipZ - 0.03], [-0.22 * s, 0.18, 1]);
  }
  scene.add(new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.62, 0.25).translate(0, 0.31, mipZ - 0.1), M.trim));
  // --- glareshield (P7) ---
  { const W = 1.62, H = W / gl.aspect, y0 = 1.11, z0 = -1.02;
    panel("p7", gl.t, W, [0, y0, z0], [0, y0 + H, z0 - H * 0.6], [0, 0.75, 1]);
    const cowl = new THREE.Mesh(new THREE.BoxGeometry(1.95, 0.06, 0.42).translate(0, y0 + H + 0.03, z0 - 0.2), M.dark); scene.add(cowl); }
  // --- P9 (CDU'lar) ---
  { const t = drawnTex(1200, 420, (g, w, h) => {
      for (const x of [30, 830]) { g.strokeRect(x, 20, 340, 380); g.strokeRect(x + 30, 40, 280, 150); for (let r = 0; r < 5; r++) for (let c = 0; c < 6; c++) g.strokeRect(x + 30 + c * 47, 210 + r * 36, 38, 28); }
      g.strokeRect(410, 30, 380, 340); g.font = `700 30px ${FF}`; g.textAlign = "center"; g.fillText("LOWER DU", 600, 200); g.fillText("CDU 1", 200, 120); g.fillText("CDU 2", 1000, 120); });
    panel("p9", t, 0.62, [0, 0.42, -1.0], [0, 0.62, -1.08], [0, 0.6, 1]); }
  // --- kontrol sehpası (gaz kolları vb.) ---
  { const g = [new THREE.BoxGeometry(0.48, 0.32, 0.5).translate(0, 0.56, -0.72)], lv = [];
    for (const x of [-0.06, 0.06]) lv.push(new THREE.BoxGeometry(0.03, 0.2, 0.03).translate(x, 0.8, -0.75), new THREE.CylinderGeometry(0.025, 0.025, 0.12, 12).rotateZ(Math.PI / 2).translate(x, 0.9, -0.75));
    lv.push(new THREE.BoxGeometry(0.02, 0.16, 0.02).translate(-0.18, 0.78, -0.82), new THREE.BoxGeometry(0.02, 0.14, 0.02).translate(0.17, 0.78, -0.68));
    for (const x of [-0.04, 0.04]) lv.push(new THREE.BoxGeometry(0.02, 0.1, 0.02).translate(x, 0.76, -0.58));
    const stand = new THREE.Mesh(mergeGeometries(g), M.trim), levers = new THREE.Mesh(mergeGeometries(lv), M.chrome);
    stand.userData.panel = "stand"; levers.userData.panel = "stand"; scene.add(stand, levers);
    for (const s of [-1, 1]) { const wh = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.02, 8, 24).rotateY(Math.PI / 2).translate(0.27 * s, 0.6, -0.72), M.dark); wh.userData.panel = "stand"; scene.add(wh); }
    panels.stand = { mesh: stand, mat: stand.material, normal: new THREE.Vector3(0, 0.8, 0.6).normalize(), center: new THREE.Vector3(0, 0.75, -0.72), size: 0.5 }; }
  // --- P8 (aft elektronik panel) ---
  { const w = 0.46, l = w / asp(tP8); panel("p8", tP8, w, [0, 0.74, -0.47 + l * 0.98], [0, 0.72, -0.47], [0, 1, 0.12]);
    scene.add(new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.72, l + 0.05).translate(0, 0.35, -0.47 + l / 2), M.trim)); }
  // --- overhead ---
  { const w = 0.66, l = w / asp(tP5f); panel("p5f", tP5f, w, [0, 1.98, -0.98 + l * 0.0], [0, 2.17, -0.98 + l * 0.95], [0, -1, 0.35]);
    const la = w / asp(tP5a); panel("p5a", tP5a, w, [0, 2.18, -0.98 + l * 0.97], [0, 2.22, -0.98 + l * 0.97 + la], [0, -1, 0.08]); }
  // --- P6 / P18 ---
  for (const [id, s] of [["p18", -1], ["p6", 1]]) {
    const t = drawnTex(600, 420, (g, w, h) => { for (let r = 0; r < 6; r++) for (let c = 0; c < 10; c++) { g.beginPath(); g.arc(40 + c * 57, 50 + r * 64, 14, 0, 7); g.stroke(); } g.font = `700 34px ${FF}`; g.fillText(id.toUpperCase(), 10, 410); });
    panel(id, t, 0.55, [1.09 * s, 0.55, 1.15], [1.09 * s, 1.0, 1.15], [-s, 0, 0]);
  }
  // --- E/E kapağı ---
  { const hatch = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.012, 0.55).translate(0, 0.006, 0.55), new THREE.MeshStandardMaterial({ color: 0x6a5a3a, roughness: 0.8 })); hatch.userData.panel = "eebay"; scene.add(hatch);
    panels.eebay = { mesh: hatch, mat: hatch.material, normal: new THREE.Vector3(0, 1, 0.3).normalize(), center: new THREE.Vector3(0, 0, 0.55), size: 0.6 }; }
  // --- koltuklar ve kumandalar ---
  { const g = [], y = [];
    for (const s of [-1, 1]) { g.push(new THREE.BoxGeometry(0.5, 0.12, 0.5).translate(0.55 * s, 0.45, 0.55), new THREE.BoxGeometry(0.5, 0.7, 0.12).translate(0.55 * s, 0.85, 0.8), new THREE.BoxGeometry(0.3, 0.4, 0.3).translate(0.55 * s, 0.2, 0.55));
      y.push(new THREE.CylinderGeometry(0.03, 0.03, 0.6, 10).translate(0.55 * s, 0.3, -0.62), new THREE.TorusGeometry(0.15, 0.018, 8, 24, Math.PI * 1.3).rotateZ(-Math.PI * 0.15).translate(0.55 * s, 0.68, -0.62)); }
    scene.add(new THREE.Mesh(mergeGeometries(g), M.seat), new THREE.Mesh(mergeGeometries(y), M.dark)); }

  // --- görünümler ve seçim ---
  const VIEWS = { seat: [[0, 1.22, 0.55], [0, 1.0, -1.05]], up: [[0, 1.25, 0.2], [0, 2.1, -0.55]], ped: [[0, 1.45, 0.45], [0, 0.72, -0.45]], back: [[0, 1.3, -0.6], [0, 0.85, 1.2]] };
  let camAnim = null;
  function go(pos, tgt) { camAnim = { from: cam.position.clone(), to: new THREE.Vector3(...pos), tf: controls.target.clone(), tt: new THREE.Vector3(...tgt), t: 0 }; }
  function view(k) { go(...VIEWS[k]); rootEl.querySelectorAll(".v3-tools button").forEach(b => b.classList.toggle("on", b.dataset.t === k)); }
  cam.position.set(...VIEWS.seat[0]); controls.target.set(...VIEWS.seat[1]); controls.update();
  let sel = null;
  function showInfo() {
    const p = PANELS.find(q => q.id === sel);
    if (!p) { info.innerHTML = `<b>737NG kokpiti</b><p>Bir panele dokun: kamera o panele gider. Tekrar dokun veya <b>Paneli aç</b> ile o panelin ayrıntılı 3D görünümüne geç (ön yüz, arka bağlantılar, pinler, tuş açıklamaları ve çalışma mantığı).</p>`; return; }
    const ready = BUILT.has(p.id);
    info.innerHTML = `<small>Kokpit paneli</small><b>${esc(p.t)}</b><p>${esc(p.d)}</p><div class="row v3-row">${p.go ? `<button class="v3-btn pri" data-go="${p.go}">${ready ? "Paneli aç ›" : "Paneli aç (hazırlanıyor) ›"}</button>` : `<span class="v3-st">Ayrıntılı 3D görünüm hazırlanıyor</span>`}</div>`;
    const b = info.querySelector("[data-go]"); if (b) b.onclick = () => { location.hash = b.dataset.go; };
  }
  function select(id, fly) {
    sel = id;
    for (const k in panels) panels[k].mat.emissiveIntensity = k === id ? 0.35 : 0;
    rootEl.querySelectorAll("[data-p]").forEach(b => b.classList.toggle("on", b.dataset.p === id));
    showInfo();
    if (id && fly) { const P = panels[id]; const d = Math.max(0.45, P.size * 1.15); go(P.center.clone().addScaledVector(P.normal, d).toArray(), P.center.toArray()); }
    dirty = true;
  }
  const open = id => { const p = PANELS.find(q => q.id === id); if (p && p.go) location.hash = p.go; };
  rootEl.querySelectorAll("[data-p]").forEach(b => b.onclick = () => { if (sel === b.dataset.p) open(sel); else { select(b.dataset.p, true); stage.scrollIntoView({ behavior: "smooth", block: "start" }); } });
  rootEl.querySelectorAll(".v3-tools button").forEach(b => b.onclick = () => { if (b.dataset.t === "ac") { location.hash = "#/3d/ucak"; return; } select(null); view(b.dataset.t); });
  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(); let down = null, multi = false; const ptrs = new Set();
  canvasEl.addEventListener("pointerdown", e => { ptrs.add(e.pointerId); if (ptrs.size > 1) multi = true; if (ptrs.size === 1) { multi = false; down = [e.clientX, e.clientY]; } });
  canvasEl.addEventListener("pointercancel", e => { ptrs.delete(e.pointerId); down = null; });
  canvasEl.addEventListener("pointerup", e => {
    ptrs.delete(e.pointerId); if (!down || multi) { if (!ptrs.size) down = null; return; }
    const mv = Math.hypot(e.clientX - down[0], e.clientY - down[1]); down = null; if (mv > 14) return;
    const r = canvasEl.getBoundingClientRect(); ndc.set((e.clientX - r.left) / r.width * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1); ray.setFromCamera(ndc, cam);
    const h = ray.intersectObjects(scene.children, false).find(x => x.object.userData.panel);
    const id = h ? h.object.userData.panel : null;
    if (!id) { select(null); return; }
    if (id === sel) { open(id); return; }
    select(id, true);
  });
  showInfo();
  let alive = true;
  (function loop() {
    if (!alive) return; requestAnimationFrame(loop);
    if (camAnim) { camAnim.t = Math.min(1, camAnim.t + 0.05); const k = 1 - Math.pow(1 - camAnim.t, 3); cam.position.lerpVectors(camAnim.from, camAnim.to, k); controls.target.lerpVectors(camAnim.tf, camAnim.tt, k); if (camAnim.t >= 1) camAnim = null; dirty = true; }
    controls.update(); if (dirty) { renderer.render(scene, cam); dirty = false; }
  })();
  rootEl.__ck = { scene, cam, select, panels };
  return () => { alive = false; ro.disconnect(); controls.dispose(); scene.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => { m.map?.dispose(); m.dispose(); }); }); env.dispose(); pmrem.dispose(); renderer.dispose(); renderer.forceContextLoss?.(); };
}
