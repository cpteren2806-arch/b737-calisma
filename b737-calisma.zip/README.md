# B737 Çalışma

737NG ve 737 MAX sistemlerini ATA bölümlerine göre çalışmak için çevrimdışı Android uygulaması.

## İçerik
- 11 bölüm: ATA 21, 24, 26, 27, 28, 29, 30, 32, 36, 49 ve motor (71-80)
- Her bölümde: genel bilgi, bileşenler, çalışma mantığı, kokpit kontrolleri, bakım/güvenlik notları, MAX farkları
- 6 sistem şeması (APU, hidrolik, pnömatik, elektrik, yakıt, motor), dokununca büyür
- Bölüm quizleri ve karışık quiz
- NG ↔ MAX karşılaştırma tablosu, kısaltma ve el kitabı sözlüğü (AMM, CMM, IPC, FIM…)
- Tüm içerikte arama
- **P5 ön overhead panel (3D):** yerleşim AMM 31-11-94 Fig.101'den ölçüldü; arka bağlantılar WDM 91-02-05'ten (her modülün D-konnektör numarası, W-demeti, TB507/TB508, GD blokları, menteşe hattı); konnektör parça numaraları WDM Equipment List'ten, BACC45FT yapısı SWPM 20-61-11'den. Anahtarlar/kapaklar/ışıklar çalışır, ışık testi, modül çıkarma ve panelin menteşeden açılması.
- **Aft overhead panel (3D):** AMM 31-11-95 yerleşimi; IRS (ISDU, MSU), ELT, LE cihazları, gözlemci ses paneli, EEC, oksijen, FDR/mach/stall testleri; WDM Sheet 2 konnektörleri, TB501–TB506, GD508/GD509.
- **Uçak seçimi:** WDM ön sayfasındaki 104 kuyruk (THY/SNS 737-700/800/900ER). Konnektörler, pinler ve devre kesiciler seçili uçağın etkinliğine göre süzülür (ör. P5-17'de 737-700: D656/D90/D620/D618, 737-800: D90/D3996/D3998).
- **Pin düzeyi:** konnektöre dokun → kontak yüzü ve pin tablosu (tel no, demet, AWG, WDM şeması). Pine dokun → Wire List'ten uçtan uca iz: ayrılabilir bağlantılar (D4xxxxP/J), ekler, terminal blokları, röleler, toprak ve devre kesiciye kadar.
- **Devre izleme:** fiş ve demet 3D'de vurgulanır; anahtar/ışık seçince ilgili WDM devresi ve devre kesicileri listelenir.
- **Devre kesici panelleri (3D):** P18-1..3, P6-1..4, P6-11/12, P91, P92, J9 – WDM CB listesindeki ızgara konumlarıyla. Çek/it, emniyet etiketi, arama, CB'den P5 pinlerine geri bağlantı.
- **E/E bölmesi rafları (3D):** E1–E6, WDM 91-03-0x raf şemalarından (ünite, raf konnektörü, raf demetleri) ve 91-01-05 konum tablosundan (STA/WL/BL). P5 pin izinden rafa ve raftan P5'e geçiş.
- **Elektrik baraları:** her CB'nin beslendiği bara WDM 24-5x/24-6x dağıtım şemalarından; güç durumuna göre "bara enerjili/enerjisiz", CB panelinde bara vurgulama.
- **Gerçek CB panel yerleşimi:** P6-1..4, P6-11/12, P18-1..3 biçimi ve CB konumları WDM 91-02-06 / 91-02-18 şemalarından.
- **Güç durumları:** soğuk-karanlık / batarya / yer gücü / APU / motorlar. Jeneratör ve yer gücü anahtarları, APU start (EGT), IRS hizalama, ELEC göstergesi, hidrolik ve yakıt LOW PRESSURE mantığı (basitleştirilmiş).
- **AMM görevleri:** 23 modülün söküm/takma görevleri adım adım (AMM metni); "CB'leri aç ve etiketle", "paneli aç", "Dzus gevşet", "konnektörleri ayır", "modülü çıkar" gibi adımlar 3D'de uygulanır.
- **Arıza senaryoları ve WDM quiz:** gizli arıza (açık CB, ayrılmış fiş, yanık ampul) bul-gider; quiz soruları seçili uçağın WDM verisinden üretilir.
- **Gece aydınlatması:** PANEL ışığı açıkken panel yazıları arkadan aydınlanır; aft panelde DOME ışığı.
- **Diğer 3D modeller:** APU (131-9B) ve yuvarlak konnektör anatomisi. Döndür, yakınlaştır, parçalara ayır, parçaya dokunup açıklamasını oku. Modeller temsilidir.
- **Belgelerim:** kendi ders notlarını, eğitim PDF'lerini ve fotoğraflarını ATA bölümüne bağlayıp sakla (yalnız telefonda tutulur, PDF uygulama içinde açılır)

> Eğitim amaçlıdır. İçerik özgün özetlerdir; Boeing AMM/CMM/FCOM değildir ve onların yerine geçmez.

> **Gizlilik:** `app/src/main/assets/www/3d/p5/data/` klasörü ve AMM görev metinleri Boeing'e ait (proprietary) WDM/AMM verisinden türetilmiştir. Bu depo **Private** kalmalı ve APK paylaşılmamalıdır.

## APK nasıl alınır
Bu depo GitHub'a gönderildiğinde **Actions** sekmesindeki "APK derle" iş akışı otomatik çalışır (3-6 dk).
Bitince **Releases** bölümünde `B737-Calisma.apk` dosyası çıkar. Telefondan indirip açın;
Android "bilinmeyen kaynaklardan yükleme" izni isterse bu kaynağa izin verin.

Elle tekrar derlemek için: Actions → APK derle → Run workflow.

## İçeriği düzenleme
- Metinler ve quiz: `app/src/main/assets/www/data.js`
- Şemalar: `app/src/main/assets/www/data-diagrams.js`
- 3D modeller: `app/src/main/assets/www/3d/models.js`
- Overhead panel düzeni ve konnektör tablosu: `app/src/main/assets/www/3d/p5/layout.js` (ön), `layout_aft.js` (aft)
- Güç/ışık mantığı: `3d/p5/power.js` · pin, AMM, senaryo, quiz araçları: `3d/p5/tools.js` · CB panelleri: `3d/p5/cbpanel.js` · E/E rafları: `3d/p5/eebay.js`
- WDM/AMM verileri: `3d/p5/data/` (`pins.json`, `cbs.json`, `amm.json`, `meta.json`, `ee.json`, `buses.json`, `cblayout.json`)
Dosyayı GitHub'da düzenleyip kaydettiğinizde yeni APK otomatik derlenir.
